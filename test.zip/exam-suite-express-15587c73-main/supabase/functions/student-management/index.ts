import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Valid departments enum
const VALID_DEPARTMENTS = ['CSE', 'ECE', 'EE', 'ME', 'CE', 'BBA', 'MBA', 'IT', 'CIVIL', 'OTHER'];
const VALID_STATUSES = ['active', 'inactive'];

// Validation error interface
interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

interface StudentData {
  full_name: string;
  roll_no: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: number | string;
  status?: string;
  photo_url?: string;
  password?: string;
}

// Validation functions
function validateFullName(name: string): ValidationError | null {
  if (!name || typeof name !== 'string') {
    return { field: 'full_name', message: 'Full name is required.' };
  }
  const trimmed = name.trim();
  if (trimmed.length < 3) {
    return { field: 'full_name', message: 'Full name must be at least 3 characters.' };
  }
  if (trimmed.length > 60) {
    return { field: 'full_name', message: 'Full name must be less than 60 characters.' };
  }
  if (!/^[a-zA-Z ]+$/.test(trimmed)) {
    return { field: 'full_name', message: 'Full name can only contain alphabets and spaces.' };
  }
  return null;
}

function validateRollNo(rollNo: string): ValidationError | null {
  if (!rollNo || typeof rollNo !== 'string') {
    return { field: 'roll_no', message: 'Roll number is required.' };
  }
  const trimmed = rollNo.trim();
  if (trimmed.length < 4) {
    return { field: 'roll_no', message: 'Roll number must be at least 4 characters.' };
  }
  if (trimmed.length > 15) {
    return { field: 'roll_no', message: 'Roll number must be less than 15 characters.' };
  }
  if (!/^[a-zA-Z0-9]+$/.test(trimmed)) {
    return { field: 'roll_no', message: 'Roll number must be alphanumeric only.' };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  if (!email || typeof email !== 'string') {
    return { field: 'email', message: 'Email is required.' };
  }
  const trimmed = email.trim().toLowerCase();
  // Basic email format validation
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(trimmed)) {
    return { field: 'email', message: 'Invalid email address format.' };
  }
  // Check for institutional email (optional - can be customized)
  // Allowing common institutional domains
  const institutionalDomains = ['.edu', '.ac.in', '.edu.in', 'university.', 'college.', 'institute.'];
  const isInstitutional = institutionalDomains.some(domain => 
    trimmed.includes(domain) || trimmed.endsWith(domain)
  );
  // For now, we'll allow all valid emails but log a warning
  // Remove this check if strict institutional email is not required
  return null;
}

function validateMobile(mobile: string): ValidationError | null {
  if (!mobile || typeof mobile !== 'string') {
    return { field: 'mobile', message: 'Mobile number is required.' };
  }
  // Remove any spaces or symbols
  const cleaned = mobile.replace(/[\s\-\(\)\+]/g, '');
  // Check if it's a 10-digit Indian mobile number starting with 6-9
  if (!/^[6-9][0-9]{9}$/.test(cleaned)) {
    return { field: 'mobile', message: 'Mobile must be a valid 10-digit Indian number (starting with 6-9).' };
  }
  return null;
}

function validateDepartment(department: string): ValidationError | null {
  if (!department || typeof department !== 'string') {
    return { field: 'department', message: 'Department is required.' };
  }
  if (!VALID_DEPARTMENTS.includes(department.toUpperCase())) {
    return { 
      field: 'department', 
      message: `Invalid department. Must be one of: ${VALID_DEPARTMENTS.join(', ')}.` 
    };
  }
  return null;
}

function validateCourse(course: string): ValidationError | null {
  if (!course || typeof course !== 'string') {
    return { field: 'course', message: 'Course is required.' };
  }
  const trimmed = course.trim();
  if (trimmed.length < 2) {
    return { field: 'course', message: 'Course must be at least 2 characters.' };
  }
  if (trimmed.length > 40) {
    return { field: 'course', message: 'Course must be less than 40 characters.' };
  }
  return null;
}

function validateSemester(semester: number | string): ValidationError | null {
  if (semester === undefined || semester === null || semester === '') {
    return { field: 'semester', message: 'Semester is required.' };
  }
  const semNum = typeof semester === 'string' ? parseInt(semester, 10) : semester;
  if (isNaN(semNum) || semNum < 1 || semNum > 12) {
    return { field: 'semester', message: 'Semester must be a number between 1 and 12.' };
  }
  return null;
}

function validateStatus(status: string): ValidationError | null {
  if (status && !VALID_STATUSES.includes(status.toLowerCase())) {
    return { field: 'status', message: 'Status must be either "active" or "inactive".' };
  }
  return null;
}

function validatePassword(password: string, isRequired: boolean = false): ValidationError | null {
  if (isRequired && (!password || typeof password !== 'string')) {
    return { field: 'password', message: 'Password is required.' };
  }
  if (password && password.length < 6) {
    return { field: 'password', message: 'Password must be at least 6 characters.' };
  }
  return null;
}

// Main validation function
function validateStudentData(data: StudentData, isUpdate: boolean = false): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validations
  const nameError = validateFullName(data.full_name);
  if (nameError) errors.push(nameError);

  const rollError = validateRollNo(data.roll_no);
  if (rollError) errors.push(rollError);

  const emailError = validateEmail(data.email);
  if (emailError) errors.push(emailError);

  const mobileError = validateMobile(data.mobile);
  if (mobileError) errors.push(mobileError);

  const deptError = validateDepartment(data.department);
  if (deptError) errors.push(deptError);

  const courseError = validateCourse(data.course);
  if (courseError) errors.push(courseError);

  const semesterError = validateSemester(data.semester);
  if (semesterError) errors.push(semesterError);

  // Optional field validations
  if (data.status) {
    const statusError = validateStatus(data.status);
    if (statusError) errors.push(statusError);
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Bulk upload validation
function validateBulkStudents(students: StudentData[], existingRollNos: string[], existingEmails: string[]): {
  validStudents: StudentData[];
  failedRows: { row: number; data: StudentData; errors: ValidationError[] }[];
} {
  const validStudents: StudentData[] = [];
  const failedRows: { row: number; data: StudentData; errors: ValidationError[] }[] = [];
  const seenRollNos = new Set<string>(existingRollNos.map(r => r.toLowerCase()));
  const seenEmails = new Set<string>(existingEmails.map(e => e.toLowerCase()));

  students.forEach((student, index) => {
    const validation = validateStudentData(student);
    const additionalErrors: ValidationError[] = [];

    // Check for duplicate roll numbers within the batch and database
    if (student.roll_no) {
      const rollLower = student.roll_no.trim().toLowerCase();
      if (seenRollNos.has(rollLower)) {
        additionalErrors.push({ field: 'roll_no', message: 'Roll number must be unique.' });
      } else {
        seenRollNos.add(rollLower);
      }
    }

    // Check for duplicate emails within the batch and database
    if (student.email) {
      const emailLower = student.email.trim().toLowerCase();
      if (seenEmails.has(emailLower)) {
        additionalErrors.push({ field: 'email', message: 'Email must be unique.' });
      } else {
        seenEmails.add(emailLower);
      }
    }

    const allErrors = [...validation.errors, ...additionalErrors];

    if (allErrors.length > 0) {
      failedRows.push({ row: index + 1, data: student, errors: allErrors });
    } else {
      validStudents.push(student);
    }
  });

  return { validStudents, failedRows };
}

// Secure password hashing using Web Crypto API (PBKDF2)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  const hashArray = new Uint8Array(derivedBits);
  const combined = new Uint8Array(salt.length + hashArray.length);
  combined.set(salt);
  combined.set(hashArray, salt.length);
  return btoa(String.fromCharCode(...combined));
}

// Verify password against PBKDF2 hash
async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const combined = Uint8Array.from(atob(hashedPassword), c => c.charCodeAt(0));
    const salt = combined.slice(0, 16);
    const storedHash = combined.slice(16);
    
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      'PBKDF2',
      false,
      ['deriveBits']
    );
    const derivedBits = await crypto.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      256
    );
    const newHash = new Uint8Array(derivedBits);
    
    // Constant-time comparison
    if (newHash.length !== storedHash.length) return false;
    let result = 0;
    for (let i = 0; i < newHash.length; i++) {
      result |= newHash[i] ^ storedHash[i];
    }
    return result === 0;
  } catch {
    return false;
  }
}

// Helper to verify user is authenticated and has admin role
async function verifyAdminAccess(req: Request, supabase: any): Promise<{ isAdmin: boolean; userId: string | null; error: string | null }> {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { isAdmin: false, userId: null, error: 'Missing or invalid authorization header' };
  }

  const token = authHeader.replace('Bearer ', '');
  
  // Create a client with the user's JWT to verify their identity
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
  const userClient = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });

  const { data: { user }, error: userError } = await userClient.auth.getUser();
  
  if (userError || !user) {
    return { isAdmin: false, userId: null, error: 'Invalid or expired token' };
  }

  // Check if user has admin role using the service role client
  const { data: roleData, error: roleError } = await supabase
    .from('user_roles')
    .select('role')
    .eq('user_id', user.id)
    .eq('role', 'admin')
    .maybeSingle();

  if (roleError) {
    console.error('Error checking user role:', roleError);
    return { isAdmin: false, userId: user.id, error: 'Error verifying permissions' };
  }

  return { isAdmin: !!roleData, userId: user.id, error: null };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    // Student login action doesn't require admin access
    if (action === 'login') {
      // Login handling stays the same - students can login without admin rights
      console.log('Student login attempt');
    } else {
      // All other actions require admin access
      const { isAdmin, error: authError } = await verifyAdminAccess(req, supabase);
      
      if (!isAdmin) {
        console.log('Access denied:', authError);
        return new Response(JSON.stringify({
          status: 'error',
          message: authError || 'Access denied. Admin privileges required.'
        }), {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    console.log(`Student Management API - Action: ${action}, Method: ${req.method}`);

    // GET - List students
    if (req.method === 'GET' && action === 'list') {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return new Response(JSON.stringify({ status: 'success', data }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // GET - Get single student
    if (req.method === 'GET' && action === 'get') {
      const id = url.searchParams.get('id');
      if (!id) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'id', message: 'Student ID is required.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error) throw error;
      if (!data) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Student not found.'
        }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ status: 'success', data }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Add student
    if (req.method === 'POST' && action === 'add') {
      const body = await req.json();
      
      // Validate input
      const validation = validateStudentData(body);
      if (!validation.isValid) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: validation.errors
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check for existing roll_no
      const { data: existingRoll } = await supabase
        .from('students')
        .select('id')
        .eq('roll_no', body.roll_no.trim())
        .maybeSingle();

      if (existingRoll) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'roll_no', message: 'Roll number already exists.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check for existing email
      const { data: existingEmail } = await supabase
        .from('students')
        .select('id')
        .eq('email', body.email.trim().toLowerCase())
        .maybeSingle();

      if (existingEmail) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'email', message: 'Email already exists.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Hash password if provided
      let passwordHash = null;
      if (body.password) {
        const pwdError = validatePassword(body.password);
        if (pwdError) {
          return new Response(JSON.stringify({
            status: 'validation_error',
            errors: [pwdError]
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        passwordHash = await hashPassword(body.password);
      }

      // Clean and prepare mobile number
      const cleanedMobile = body.mobile.replace(/[\s\-\(\)\+]/g, '');
      const studentEmail = body.email.trim().toLowerCase();
      const studentPassword = body.password || 'Student@123'; // Default password if not provided

      // Create Supabase Auth account for the student
      let authUserId = null;
      try {
        const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
          email: studentEmail,
          password: studentPassword,
          email_confirm: true,
          user_metadata: {
            name: body.full_name.trim(),
          },
        });

        if (authError) {
          // If user already exists in auth, that's okay - continue
          if (!authError.message.includes('already been registered')) {
            console.error('Auth user creation error:', authError);
            // Non-critical error - student can be added without auth account
          }
        } else if (authUser?.user) {
          authUserId = authUser.user.id;
          console.log('Created auth account for student:', studentEmail);

          // Assign student role
          const { error: roleError } = await supabase
            .from('user_roles')
            .insert({
              user_id: authUserId,
              role: 'student',
            });

          if (roleError) {
            console.error('Error assigning student role:', roleError);
          }
        }
      } catch (authErr) {
        console.error('Auth creation exception:', authErr);
        // Continue without auth account
      }

      // Insert student
      const { data, error } = await supabase
        .from('students')
        .insert({
          full_name: body.full_name.trim(),
          roll_no: body.roll_no.trim(),
          email: studentEmail,
          mobile: cleanedMobile,
          department: body.department.toUpperCase(),
          course: body.course.trim(),
          semester: parseInt(body.semester, 10),
          status: body.status?.toLowerCase() || 'active',
          photo_url: body.photo_url || null,
          password_hash: passwordHash,
        })
        .select()
        .single();

      if (error) {
        console.error('Insert error:', error);
        // If student insert fails but we created auth account, try to clean up
        if (authUserId) {
          try {
            await supabase.auth.admin.deleteUser(authUserId);
          } catch (cleanupErr) {
            console.error('Failed to cleanup auth user:', cleanupErr);
          }
        }
        throw error;
      }

      const responseMessage = authUserId 
        ? 'Student added with login account' 
        : 'Student added (login account may need manual setup)';

      return new Response(JSON.stringify({ 
        status: 'success', 
        data,
        message: responseMessage,
        authCreated: !!authUserId 
      }), {
        status: 201,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // PUT - Update student
    if (req.method === 'PUT' && action === 'update') {
      const id = url.searchParams.get('id');
      if (!id) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'id', message: 'Student ID is required.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const body = await req.json();
      
      // Validate input
      const validation = validateStudentData(body, true);
      if (!validation.isValid) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: validation.errors
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if student exists
      const { data: existing } = await supabase
        .from('students')
        .select('id, roll_no, email')
        .eq('id', id)
        .maybeSingle();

      if (!existing) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Student not found.'
        }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check for duplicate roll_no (excluding current student)
      if (body.roll_no !== existing.roll_no) {
        const { data: duplicateRoll } = await supabase
          .from('students')
          .select('id')
          .eq('roll_no', body.roll_no.trim())
          .neq('id', id)
          .maybeSingle();

        if (duplicateRoll) {
          return new Response(JSON.stringify({
            status: 'validation_error',
            errors: [{ field: 'roll_no', message: 'Roll number already exists.' }]
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      // Check for duplicate email (excluding current student)
      if (body.email.toLowerCase() !== existing.email.toLowerCase()) {
        const { data: duplicateEmail } = await supabase
          .from('students')
          .select('id')
          .eq('email', body.email.trim().toLowerCase())
          .neq('id', id)
          .maybeSingle();

        if (duplicateEmail) {
          return new Response(JSON.stringify({
            status: 'validation_error',
            errors: [{ field: 'email', message: 'Email already exists.' }]
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      // Clean mobile
      const cleanedMobile = body.mobile.replace(/[\s\-\(\)\+]/g, '');

      // Update student
      const { data, error } = await supabase
        .from('students')
        .update({
          full_name: body.full_name.trim(),
          roll_no: body.roll_no.trim(),
          email: body.email.trim().toLowerCase(),
          mobile: cleanedMobile,
          department: body.department.toUpperCase(),
          course: body.course.trim(),
          semester: parseInt(body.semester, 10),
          status: body.status?.toLowerCase() || 'active',
          photo_url: body.photo_url || null,
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      return new Response(JSON.stringify({ status: 'success', data }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Bulk upload students
    if (req.method === 'POST' && action === 'bulk-upload') {
      const body = await req.json();
      const students: StudentData[] = body.students;

      if (!Array.isArray(students) || students.length === 0) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'students', message: 'Students array is required and cannot be empty.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get existing roll numbers and emails
      const { data: existingStudents } = await supabase
        .from('students')
        .select('roll_no, email');

      const existingRollNos = existingStudents?.map(s => s.roll_no) || [];
      const existingEmails = existingStudents?.map(s => s.email) || [];

      // Validate all students
      const { validStudents, failedRows } = validateBulkStudents(students, existingRollNos, existingEmails);

      // Insert valid students with auth account creation
      const successRows: any[] = [];
      let authAccountsCreated = 0;

      for (const student of validStudents) {
        const cleanedMobile = student.mobile.replace(/[\s\-\(\)\+]/g, '');
        const studentEmail = student.email.trim().toLowerCase();
        const studentPassword = student.password || 'Student@123'; // Default password

        let passwordHash = null;
        if (student.password) {
          passwordHash = await hashPassword(student.password);
        }

        // Create Supabase Auth account for the student
        let authUserId = null;
        try {
          const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
            email: studentEmail,
            password: studentPassword,
            email_confirm: true,
            user_metadata: {
              name: student.full_name.trim(),
            },
          });

          if (authError) {
            if (!authError.message.includes('already been registered')) {
              console.error('Auth user creation error for bulk student:', studentEmail, authError);
            }
          } else if (authUser?.user) {
            authUserId = authUser.user.id;
            console.log('Created auth account for bulk student:', studentEmail);

            // Assign student role
            const { error: roleError } = await supabase
              .from('user_roles')
              .insert({
                user_id: authUserId,
                role: 'student',
              });

            if (roleError) {
              console.error('Error assigning student role:', roleError);
            } else {
              authAccountsCreated++;
            }
          }
        } catch (authErr) {
          console.error('Auth creation exception for bulk student:', studentEmail, authErr);
        }

        // Insert student into students table
        const { data, error } = await supabase
          .from('students')
          .insert({
            full_name: student.full_name.trim(),
            roll_no: student.roll_no.trim(),
            email: studentEmail,
            mobile: cleanedMobile,
            department: student.department.toUpperCase(),
            course: student.course.trim(),
            semester: parseInt(String(student.semester), 10),
            status: student.status?.toLowerCase() || 'active',
            photo_url: student.photo_url || null,
            password_hash: passwordHash,
          })
          .select()
          .single();

        if (error) {
          console.error('Insert error for bulk student:', studentEmail, error);
          // Clean up auth account if student insert fails
          if (authUserId) {
            try {
              await supabase.auth.admin.deleteUser(authUserId);
              authAccountsCreated--;
            } catch (cleanupErr) {
              console.error('Failed to cleanup auth user:', cleanupErr);
            }
          }
          failedRows.push({
            row: students.indexOf(student) + 1,
            data: student,
            errors: [{ field: 'database', message: error.message }]
          });
        } else {
          successRows.push({ ...data, authCreated: !!authUserId });
        }
      }

      // Log the bulk upload
      await supabase.from('student_bulk_upload_logs').insert({
        total_rows: students.length,
        success_count: successRows.length,
        failed_count: failedRows.length,
        failed_rows: failedRows.length > 0 ? JSON.stringify(failedRows) : null,
      });

      return new Response(JSON.stringify({
        status: 'success',
        message: `Processed ${students.length} students. ${authAccountsCreated} login accounts created.`,
        success_rows: successRows,
        success_count: successRows.length,
        failed_rows: failedRows,
        failed_count: failedRows.length,
        auth_accounts_created: authAccountsCreated,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Student login
    if (req.method === 'POST' && action === 'login') {
      const body = await req.json();
      const { roll_no, email, password } = body;

      // Validation
      const errors: ValidationError[] = [];
      
      if (!roll_no && !email) {
        errors.push({ field: 'credentials', message: 'Roll number or email is required.' });
      }
      if (!password) {
        errors.push({ field: 'password', message: 'Password is required.' });
      }

      if (errors.length > 0) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Find student by roll_no or email
      let query = supabase.from('students').select('*');
      if (roll_no) {
        query = query.eq('roll_no', roll_no.trim());
      } else {
        query = query.eq('email', email.trim().toLowerCase());
      }

      const { data: student, error } = await query.maybeSingle();

      if (error) throw error;

      if (!student) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Invalid credentials.'
        }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Verify password
      if (!student.password_hash) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Password not set for this account.'
        }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const isValidPassword = await verifyPassword(password, student.password_hash);
      if (!isValidPassword) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Invalid credentials.'
        }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if student is active
      if (student.status !== 'active') {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Account is inactive. Please contact administrator.'
        }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Update last login
      await supabase
        .from('students')
        .update({ last_login: new Date().toISOString() })
        .eq('id', student.id);

      // Remove password_hash from response
      const { password_hash, ...studentData } = student;

      return new Response(JSON.stringify({
        status: 'success',
        message: 'Login successful.',
        data: studentData
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // PUT - Update student profile (for student self-update)
    if (req.method === 'PUT' && action === 'update-profile') {
      const body = await req.json();
      const { id, mobile, photo_url, current_password, new_password } = body;

      if (!id) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'id', message: 'Student ID is required.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const errors: ValidationError[] = [];

      // Validate mobile if provided
      if (mobile) {
        const mobileError = validateMobile(mobile);
        if (mobileError) errors.push(mobileError);
      }

      // Validate password change
      if (new_password && !current_password) {
        errors.push({ field: 'current_password', message: 'Current password is required to set new password.' });
      }
      if (new_password) {
        const pwdError = validatePassword(new_password);
        if (pwdError) errors.push(pwdError);
      }

      if (errors.length > 0) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get current student
      const { data: student, error: fetchError } = await supabase
        .from('students')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (fetchError) throw fetchError;
      if (!student) {
        return new Response(JSON.stringify({
          status: 'error',
          message: 'Student not found.'
        }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Verify current password if changing password
      if (new_password && current_password) {
        const isValidPassword = await verifyPassword(current_password, student.password_hash);
        if (!isValidPassword) {
          return new Response(JSON.stringify({
            status: 'validation_error',
            errors: [{ field: 'current_password', message: 'Current password is incorrect.' }]
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      // Prepare update data
      const updateData: any = {};
      if (mobile) {
        updateData.mobile = mobile.replace(/[\s\-\(\)\+]/g, '');
      }
      if (photo_url !== undefined) {
        updateData.photo_url = photo_url;
      }
      if (new_password) {
        updateData.password_hash = await hashPassword(new_password);
      }

      if (Object.keys(updateData).length === 0) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'data', message: 'No data to update.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data, error } = await supabase
        .from('students')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // Remove password_hash from response
      const { password_hash, ...responseData } = data;

      return new Response(JSON.stringify({
        status: 'success',
        message: 'Profile updated successfully.',
        data: responseData
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // DELETE - Delete student
    if (req.method === 'DELETE' && action === 'delete') {
      const id = url.searchParams.get('id');
      if (!id) {
        return new Response(JSON.stringify({
          status: 'validation_error',
          errors: [{ field: 'id', message: 'Student ID is required.' }]
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id);

      if (error) throw error;

      return new Response(JSON.stringify({
        status: 'success',
        message: 'Student deleted successfully.'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Invalid action
    return new Response(JSON.stringify({
      status: 'error',
      message: 'Invalid action or method.'
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    console.error('Error in student-management function:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred.';
    return new Response(JSON.stringify({
      status: 'error',
      message: errorMessage
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
