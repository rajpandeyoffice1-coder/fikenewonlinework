import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestAccount {
  email: string;
  password: string;
  name: string;
  role: 'admin' | 'student' | 'proctor' | 'evaluator';
}

const testAccounts: TestAccount[] = [
  {
    email: 'admin@examportal.com',
    password: 'Admin@123',
    name: 'System Administrator',
    role: 'admin',
  },
  {
    email: 'proctor@examportal.com',
    password: 'Proctor@123',
    name: 'Test Proctor',
    role: 'proctor',
  },
  {
    email: 'proctor.amit@examexpress.com',
    password: 'Amit@123',
    name: 'Amit Sharma',
    role: 'proctor',
  },
  {
    email: 'evaluator@examportal.com',
    password: 'Evaluator@123',
    name: 'Test Evaluator',
    role: 'evaluator',
  },
  // Student accounts
  {
    email: 'demo@urb.com',
    password: 'Student@123',
    name: 'Demo Student',
    role: 'student',
  },
  {
    email: 'rahul.sharma@university.edu',
    password: 'Student@123',
    name: 'Rahul Sharma',
    role: 'student',
  },
  {
    email: 'priya.patel@university.edu',
    password: 'Student@123',
    name: 'Priya Patel',
    role: 'student',
  },
  {
    email: 'amit.kumar@university.edu',
    password: 'Student@123',
    name: 'Amit Kumar',
    role: 'student',
  },
  {
    email: 'alice.johnson@university.edu',
    password: 'Student@123',
    name: 'Alice Johnson',
    role: 'student',
  },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;

    // Create client with user's JWT to verify they're an admin
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ success: false, error: 'Authorization header required' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
      );
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ success: false, error: 'Invalid authentication' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
      );
    }

    // Check if user is admin (skip check if no users exist - first-time setup)
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const userCount = existingUsers?.users?.length || 0;

    // If users exist, verify caller is admin
    if (userCount > 1) {
      const { data: roleData } = await supabaseAdmin
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .single();

      if (!roleData) {
        return new Response(
          JSON.stringify({ success: false, error: 'Admin access required to seed accounts' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 403 }
        );
      }
    }

    console.log('Fetching existing users...');

    const { data: userListData, error: listError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (listError) {
      throw new Error(`Failed to list users: ${listError.message}`);
    }

    const existingEmails = new Set(userListData?.users?.map(u => u.email) || []);
    const results: { email: string; status: string; password?: string; role?: string }[] = [];

    for (const account of testAccounts) {
      if (existingEmails.has(account.email)) {
        console.log(`${account.role} user already exists: ${account.email}`);
        results.push({
          email: account.email,
          status: 'exists',
          role: account.role,
        });
        continue;
      }

      console.log(`Creating ${account.role} user: ${account.email}`);

      const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email: account.email,
        password: account.password,
        email_confirm: true,
        user_metadata: {
          name: account.name,
        },
      });

      if (createError) {
        console.error(`Error creating ${account.role}:`, createError);
        results.push({
          email: account.email,
          status: `error: ${createError.message}`,
          role: account.role,
        });
        continue;
      }

      if (newUser?.user?.id) {
        const { error: roleError } = await supabaseAdmin
          .from('user_roles')
          .insert({
            user_id: newUser.user.id,
            role: account.role,
          });

        if (roleError) {
          console.error(`Error assigning ${account.role} role:`, roleError);
          await supabaseAdmin.auth.admin.deleteUser(newUser.user.id);
          results.push({
            email: account.email,
            status: `error: ${roleError.message}`,
            role: account.role,
          });
          continue;
        }

        console.log(`${account.role} created successfully`);
        results.push({
          email: account.email,
          password: account.password,
          status: 'created',
          role: account.role,
        });
      }
    }

    const createdAccounts = results.filter(r => r.status === 'created');
    const existingAccounts = results.filter(r => r.status === 'exists');

    return new Response(
      JSON.stringify({
        success: true,
        message: `Created ${createdAccounts.length} accounts, ${existingAccounts.length} already existed`,
        accounts: results,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to seed accounts';
    console.error('Seed error:', errorMessage);
    return new Response(
      JSON.stringify({
        success: false,
        error: errorMessage,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
