import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Helper to verify user is authenticated and get student info
async function verifyStudent(req: Request, supabase: any): Promise<{ student: any; error: string | null }> {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { student: null, error: 'Missing authorization header' };
  }

  const token = authHeader.replace('Bearer ', '');
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
  const userClient = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } }
  });

  const { data: { user }, error: userError } = await userClient.auth.getUser();
  if (userError || !user) {
    return { student: null, error: 'Invalid or expired token' };
  }

  // Get student record by email
  const { data: student, error: studentError } = await supabase
    .from('students')
    .select('*')
    .eq('email', user.email)
    .maybeSingle();

  if (studentError || !student) {
    return { student: null, error: 'Student record not found' };
  }

  return { student, error: null };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseKey);

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    console.log(`Exam Session API - Action: ${action}, Method: ${req.method}`);

    // GET - Get student's enrolled exams
    if (req.method === 'GET' && action === 'student-exams') {
      const { student, error: authError } = await verifyStudent(req, supabase);
      if (authError) {
        return new Response(JSON.stringify({ status: 'error', message: authError }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get directly enrolled exams
      const { data: enrollments, error: enrollError } = await supabase
        .from('exam_enrollments')
        .select(`
          id,
          status,
          enrolled_at,
          exam:exams(*)
        `)
        .eq('student_id', student.id);

      if (enrollError) {
        console.error('Error fetching enrollments:', enrollError);
      }

      // Get student's group memberships
      const { data: groupMemberships } = await supabase
        .from('student_group_members')
        .select('group_id')
        .eq('student_id', student.id);

      const groupIds = groupMemberships?.map((gm: any) => gm.group_id) || [];

      // Get exams assigned to student's groups
      let groupExams: any[] = [];
      if (groupIds.length > 0) {
        const { data: examsFromGroups } = await supabase
          .from('exams')
          .select('*')
          .in('group_id', groupIds)
          .in('status', ['scheduled', 'published', 'ongoing']);

        groupExams = examsFromGroups || [];
      }

      // Combine enrollments and group-based exams, avoiding duplicates
      const enrolledExamIds = new Set(enrollments?.map((e: any) => e.exam?.id).filter(Boolean) || []);
      const allExams: any[] = [];

      // Add directly enrolled exams
      enrollments?.forEach((enrollment: any) => {
        if (enrollment.exam) {
          allExams.push({
            exam: enrollment.exam,
            enrollmentId: enrollment.id,
            source: 'enrollment',
          });
        }
      });

      // Add group-based exams not already enrolled
      groupExams.forEach((exam: any) => {
        if (!enrolledExamIds.has(exam.id)) {
          allExams.push({
            exam,
            enrollmentId: null,
            source: 'group',
          });
        }
      });

      // Get existing sessions for this student
      const { data: sessions } = await supabase
        .from('exam_sessions')
        .select('exam_id, status, submitted_at')
        .eq('student_id', student.id);

      const sessionsMap = new Map(sessions?.map((s: any) => [s.exam_id, s]) || []);

      // Get results for completed exams
      const { data: results } = await supabase
        .from('exam_results')
        .select('*')
        .eq('student_id', student.id);

      const resultsMap = new Map(results?.map((r: any) => [r.exam_id, r]) || []);

      // Categorize exams
      const now = new Date();
      const upcoming: any[] = [];
      const ongoing: any[] = [];
      const completed: any[] = [];

      allExams.forEach((item: any) => {
        const exam = item.exam;
        if (!exam) return;

        const session = sessionsMap.get(exam.id);
        const result = resultsMap.get(exam.id);
        const startDate = exam.start_date ? new Date(exam.start_date) : null;
        const endDate = exam.end_date ? new Date(exam.end_date) : null;

        const examData = {
          id: exam.id,
          examId: exam.id,
          name: exam.title,
          examName: exam.title,
          examCode: exam.code,
          subject: exam.course || exam.department,
          department: exam.department,
          date: exam.start_date,
          dateTime: exam.start_date,
          duration: exam.duration,
          totalMarks: exam.total_marks,
          passingMarks: exam.passing_marks,
          description: exam.description,
          enrollmentId: item.enrollmentId,
          source: item.source,
        };

        if (session?.status === 'submitted' || result) {
          completed.push({
            ...examData,
            status: 'completed',
            score: result?.score || 0,
            totalMarks: result?.total_marks || exam.total_marks,
            percentage: result?.percentage || 0,
            result: result?.status || 'pending',
            completedAt: session?.submitted_at || result?.submitted_at,
            sessionId: session?.id,
          });
        } else if (startDate && endDate && now >= startDate && now <= endDate) {
          ongoing.push({
            ...examData,
            status: 'ongoing',
            canStart: true,
          });
        } else if (startDate && now < startDate) {
          upcoming.push({
            ...examData,
            status: 'upcoming',
            canStart: false,
          });
        } else {
          // Exam window passed without attempt
          completed.push({
            ...examData,
            status: 'missed',
            score: 0,
            result: 'missed',
          });
        }
      });

      return new Response(JSON.stringify({
        status: 'success',
        data: { upcoming, ongoing, completed, student },
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Start exam session
    if (req.method === 'POST' && action === 'start') {
      const { student, error: authError } = await verifyStudent(req, supabase);
      if (authError) {
        return new Response(JSON.stringify({ status: 'error', message: authError }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { exam_id } = await req.json();
      if (!exam_id) {
        return new Response(JSON.stringify({ status: 'error', message: 'exam_id is required' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if student is enrolled OR is a member of the exam's assigned group
      const { data: enrollment } = await supabase
        .from('exam_enrollments')
        .select('*')
        .eq('exam_id', exam_id)
        .eq('student_id', student.id)
        .maybeSingle();

      // Get exam to check group assignment
      const { data: exam, error: examError } = await supabase
        .from('exams')
        .select('*')
        .eq('id', exam_id)
        .single();

      if (examError || !exam) {
        return new Response(JSON.stringify({ status: 'error', message: 'Exam not found' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // If not directly enrolled, check group membership
      let hasAccess = !!enrollment;
      if (!hasAccess && exam.group_id) {
        const { data: groupMembership } = await supabase
          .from('student_group_members')
          .select('id')
          .eq('group_id', exam.group_id)
          .eq('student_id', student.id)
          .maybeSingle();
        
        hasAccess = !!groupMembership;
      }

      if (!hasAccess) {
        return new Response(JSON.stringify({ status: 'error', message: 'Not enrolled in this exam' }), {
          status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if session already exists
      const { data: existingSession } = await supabase
        .from('exam_sessions')
        .select('*')
        .eq('exam_id', exam_id)
        .eq('student_id', student.id)
        .maybeSingle();

      if (existingSession) {
        if (existingSession.status === 'submitted') {
          return new Response(JSON.stringify({ status: 'error', message: 'Exam already submitted' }), {
            status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        // Return existing session
        const { data: questions } = await supabase
          .from('exam_questions')
          .select(`
            id,
            question_order,
            marks,
            question:questions(*)
          `)
          .eq('exam_id', exam_id)
          .order('question_order');

        const { data: savedAnswers } = await supabase
          .from('exam_answers')
          .select('*')
          .eq('session_id', existingSession.id);

        return new Response(JSON.stringify({
          status: 'success',
          data: {
            session_id: existingSession.id,
            student_id: student.id,
            exam,
            questions: questions?.map((q: any) => ({
              id: q.question.id,
              questionNumber: q.question_order,
              type: mapQuestionType(q.question.type),
              text: q.question.question_text,
              question: q.question.question_text,
              options: q.question.options || [],
              marks: q.marks || q.question.marks,
              mediaUrl: q.question.media_url,
            })) || [],
            savedAnswers: savedAnswers || [],
            timeRemaining: existingSession.time_remaining || exam.duration * 60,
          },
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Create new session
      const { data: session, error: sessionError } = await supabase
        .from('exam_sessions')
        .insert({
          exam_id,
          student_id: student.id,
          status: 'in_progress',
          time_remaining: exam.duration * 60,
        })
        .select()
        .single();

      if (sessionError) {
        console.error('Error creating session:', sessionError);
        return new Response(JSON.stringify({ status: 'error', message: 'Failed to start exam' }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get questions for this exam
      const { data: questions } = await supabase
        .from('exam_questions')
        .select(`
          id,
          question_order,
          marks,
          question:questions(*)
        `)
        .eq('exam_id', exam_id)
        .order('question_order');

      return new Response(JSON.stringify({
        status: 'success',
        data: {
          session_id: session.id,
          student_id: student.id,
          exam,
          questions: questions?.map((q: any) => ({
            id: q.question.id,
            questionNumber: q.question_order,
            type: mapQuestionType(q.question.type),
            text: q.question.question_text,
            question: q.question.question_text,
            options: q.question.options || [],
            marks: q.marks || q.question.marks,
            mediaUrl: q.question.media_url,
          })) || [],
          savedAnswers: [],
          timeRemaining: exam.duration * 60,
        },
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Save answer
    if (req.method === 'POST' && action === 'save-answer') {
      const { student, error: authError } = await verifyStudent(req, supabase);
      if (authError) {
        return new Response(JSON.stringify({ status: 'error', message: authError }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { session_id, question_id, answer_text, answer_option, file_url, time_spent, is_flagged } = await req.json();

      if (!session_id || !question_id) {
        return new Response(JSON.stringify({ status: 'error', message: 'session_id and question_id required' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Verify session belongs to student
      const { data: session } = await supabase
        .from('exam_sessions')
        .select('*')
        .eq('id', session_id)
        .eq('student_id', student.id)
        .maybeSingle();

      if (!session || session.status === 'submitted') {
        return new Response(JSON.stringify({ status: 'error', message: 'Invalid or submitted session' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Upsert answer
      const { data: answer, error: answerError } = await supabase
        .from('exam_answers')
        .upsert({
          session_id,
          question_id,
          answer_text,
          answer_option,
          file_url,
          time_spent: time_spent || 0,
          is_flagged: is_flagged || false,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'session_id,question_id',
        })
        .select()
        .single();

      if (answerError) {
        console.error('Error saving answer:', answerError);
        return new Response(JSON.stringify({ status: 'error', message: 'Failed to save answer' }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({
        status: 'success',
        message: 'Answer saved',
        data: answer,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST - Submit exam
    if (req.method === 'POST' && action === 'submit') {
      const { student, error: authError } = await verifyStudent(req, supabase);
      if (authError) {
        return new Response(JSON.stringify({ status: 'error', message: authError }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { session_id } = await req.json();
      if (!session_id) {
        return new Response(JSON.stringify({ status: 'error', message: 'session_id required' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Verify session
      const { data: session } = await supabase
        .from('exam_sessions')
        .select('*, exam:exams(*)')
        .eq('id', session_id)
        .eq('student_id', student.id)
        .maybeSingle();

      if (!session) {
        return new Response(JSON.stringify({ status: 'error', message: 'Session not found' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      if (session.status === 'submitted') {
        return new Response(JSON.stringify({ status: 'error', message: 'Exam already submitted' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get all answers for this session
      const { data: answers } = await supabase
        .from('exam_answers')
        .select('*, question:questions(*)')
        .eq('session_id', session_id);

      // Calculate score for auto-gradable questions (MCQ, True/False)
      let totalScore = 0;
      const totalMarks = session.exam.total_marks;

      for (const answer of answers || []) {
        const question = answer.question;
        if (!question) continue;

        // Auto-grade MCQ and True/False
        if (question.type === 'mcq' || question.type === 'true-false') {
          const correctAnswer = question.correct_answer;
          const studentAnswer = answer.answer_option || answer.answer_text;
          
          if (correctAnswer && studentAnswer) {
            const isCorrect = Array.isArray(studentAnswer) 
              ? JSON.stringify(studentAnswer.sort()) === JSON.stringify([correctAnswer].sort())
              : studentAnswer === correctAnswer;
            
            if (isCorrect) {
              totalScore += question.marks;
            }
          }
        }
      }

      const percentage = totalMarks > 0 ? (totalScore / totalMarks) * 100 : 0;
      const passingMarks = session.exam.passing_marks || 40;
      const resultStatus = percentage >= passingMarks ? 'pass' : 'fail';

      // Update session status
      await supabase
        .from('exam_sessions')
        .update({
          status: 'submitted',
          submitted_at: new Date().toISOString(),
        })
        .eq('id', session_id);

      // Create result record
      const { data: result, error: resultError } = await supabase
        .from('exam_results')
        .insert({
          exam_id: session.exam_id,
          student_id: student.id,
          session_id,
          score: totalScore,
          total_marks: totalMarks,
          percentage,
          status: resultStatus,
          grade: calculateGrade(percentage),
          submitted_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (resultError) {
        console.error('Error creating result:', resultError);
      }

      return new Response(JSON.stringify({
        status: 'success',
        message: 'Exam submitted successfully',
        data: {
          score: totalScore,
          totalMarks,
          percentage: Math.round(percentage * 100) / 100,
          result: resultStatus,
          grade: calculateGrade(percentage),
        },
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // GET - Get result details
    if (req.method === 'GET' && action === 'result') {
      const { student, error: authError } = await verifyStudent(req, supabase);
      if (authError) {
        return new Response(JSON.stringify({ status: 'error', message: authError }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const session_id = url.searchParams.get('session_id');
      if (!session_id) {
        return new Response(JSON.stringify({ status: 'error', message: 'session_id required' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get result
      const { data: result } = await supabase
        .from('exam_results')
        .select('*, exam:exams(*)')
        .eq('session_id', session_id)
        .eq('student_id', student.id)
        .maybeSingle();

      if (!result) {
        return new Response(JSON.stringify({ status: 'error', message: 'Result not found' }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get answers with questions
      const { data: answers } = await supabase
        .from('exam_answers')
        .select('*, question:questions(*)')
        .eq('session_id', session_id);

      return new Response(JSON.stringify({
        status: 'success',
        data: {
          result,
          answers: answers?.map((a: any) => ({
            questionId: a.question_id,
            questionText: a.question?.question_text,
            yourAnswer: a.answer_text || a.answer_option,
            correctAnswer: a.question?.correct_answer,
            marks: a.question?.marks,
            timeSpent: a.time_spent,
          })) || [],
        },
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // GET - Admin: Get all exam results
    if (req.method === 'GET' && action === 'admin-results') {
      const exam_id = url.searchParams.get('exam_id');

      const query = supabase
        .from('exam_results')
        .select(`
          *,
          student:students(*),
          exam:exams(*)
        `)
        .order('submitted_at', { ascending: false });

      if (exam_id) {
        query.eq('exam_id', exam_id);
      }

      const { data: results, error } = await query;

      if (error) {
        console.error('Error fetching results:', error);
        return new Response(JSON.stringify({ status: 'error', message: 'Failed to fetch results' }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({
        status: 'success',
        data: results,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Invalid action
    return new Response(JSON.stringify({
      status: 'error',
      message: `Invalid action: ${action}`,
    }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    console.error('Error in exam-session function:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    return new Response(JSON.stringify({
      status: 'error',
      message: errorMessage,
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

// Helper functions
function mapQuestionType(type: string): string {
  const typeMap: Record<string, string> = {
    'mcq': 'mcq-single',
    'mcq-single': 'mcq-single',
    'mcq-multiple': 'mcq-multiple',
    'true-false': 'true-false',
    'subjective': 'long-answer',
    'short': 'short-answer',
    'short-answer': 'short-answer',
    'long': 'long-answer',
    'long-answer': 'long-answer',
    'code': 'code',
    'file-upload': 'file-upload',
  };
  return typeMap[type] || type;
}

function calculateGrade(percentage: number): string {
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B+';
  if (percentage >= 60) return 'B';
  if (percentage >= 50) return 'C';
  if (percentage >= 40) return 'D';
  return 'F';
}