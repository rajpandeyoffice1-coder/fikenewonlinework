import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;

    // Verify the user is an admin
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('No authorization header provided');
      return new Response(JSON.stringify({ error: 'No authorization header' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Extract the token from Bearer header
    const token = authHeader.replace('Bearer ', '');
    
    // Create client with user's token to verify identity
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: authError } = await userClient.auth.getUser(token);
    if (authError || !user) {
      console.error('Auth error:', authError?.message || 'No user found');
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    console.log('Authenticated user:', user.email);

    // Use service role client to check admin role
    const serviceClient = createClient(supabaseUrl, supabaseServiceKey);

    const { data: roleData, error: roleError } = await serviceClient
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (roleError || roleData?.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    // Fetch all reports data using service role (bypasses RLS)
    if (action === 'get-reports-data') {
      // Fetch exams
      const { data: exams, error: examsError } = await serviceClient
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false });

      if (examsError) throw examsError;

      // Fetch students
      const { data: students, error: studentsError } = await serviceClient
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (studentsError) throw studentsError;

      // Fetch questions
      const { data: questions, error: questionsError } = await serviceClient
        .from('questions')
        .select('*');

      if (questionsError) throw questionsError;

      // Fetch exam results with related data
      const { data: examResults, error: resultsError } = await serviceClient
        .from('exam_results')
        .select(`
          *,
          students(id, full_name, email, roll_no, department),
          exams(id, title, total_marks)
        `)
        .order('submitted_at', { ascending: false });

      if (resultsError) throw resultsError;

      // Fetch proctoring incidents for incident counts
      const { data: incidents, error: incidentsError } = await serviceClient
        .from('proctoring_incidents')
        .select('session_id, id');

      if (incidentsError) throw incidentsError;

      // Count incidents per session
      const incidentCounts: Record<string, number> = {};
      (incidents || []).forEach((incident: any) => {
        incidentCounts[incident.session_id] = (incidentCounts[incident.session_id] || 0) + 1;
      });

      return new Response(JSON.stringify({
        exams: exams || [],
        students: students || [],
        questions: questions || [],
        examResults: (examResults || []).map((r: any) => ({
          ...r,
          incidentCount: incidentCounts[r.session_id] || 0,
        })),
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch candidate breakdown
    if (action === 'get-candidate-breakdown') {
      const sessionId = url.searchParams.get('sessionId');
      if (!sessionId) {
        return new Response(JSON.stringify({ error: 'sessionId required' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Fetch answers with questions
      const { data: answers, error: answersError } = await serviceClient
        .from('exam_answers')
        .select(`
          *,
          questions(id, question_text, type, marks, difficulty, subject, correct_answer)
        `)
        .eq('session_id', sessionId);

      if (answersError) throw answersError;

      // Fetch screenshots
      const { data: screenshots, error: screenshotsError } = await serviceClient
        .from('proctoring_screenshots')
        .select('*')
        .eq('session_id', sessionId)
        .order('timestamp', { ascending: true });

      if (screenshotsError) throw screenshotsError;

      // Fetch incidents
      const { data: incidents, error: incidentsError } = await serviceClient
        .from('proctoring_incidents')
        .select('*')
        .eq('session_id', sessionId)
        .order('timestamp', { ascending: true });

      if (incidentsError) throw incidentsError;

      return new Response(JSON.stringify({
        answers: answers || [],
        screenshots: screenshots || [],
        incidents: incidents || [],
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: any) {
    console.error('Admin reports error:', error);
    return new Response(JSON.stringify({ error: error.message || 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
