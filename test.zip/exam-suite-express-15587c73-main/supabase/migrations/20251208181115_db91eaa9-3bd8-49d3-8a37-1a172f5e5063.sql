-- Drop the insecure INSERT policy
DROP POLICY IF EXISTS "Authenticated users can create audit logs" ON public.audit_logs;

-- Create a SECURITY DEFINER function for secure audit logging
CREATE OR REPLACE FUNCTION public.log_audit_action(
  _action text,
  _action_description text,
  _target_type text,
  _target_id text DEFAULT NULL,
  _target_name text DEFAULT NULL,
  _changes jsonb DEFAULT NULL,
  _ip_address text DEFAULT NULL,
  _browser text DEFAULT NULL,
  _os text DEFAULT NULL,
  _device_type text DEFAULT 'Desktop',
  _session_id text DEFAULT NULL,
  _raw_log jsonb DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid;
  _user_email text;
  _user_name text;
  _user_role text;
  _new_id uuid;
BEGIN
  -- Get the authenticated user's info
  _user_id := auth.uid();
  
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'User must be authenticated to log actions';
  END IF;
  
  -- Get user email from auth.users via JWT claims
  _user_email := auth.jwt() ->> 'email';
  _user_name := COALESCE(auth.jwt() -> 'user_metadata' ->> 'name', _user_email);
  
  -- Get user role from user_roles table
  SELECT role::text INTO _user_role
  FROM public.user_roles
  WHERE user_id = _user_id
  LIMIT 1;
  
  _user_role := COALESCE(_user_role, 'user');
  
  -- Insert the audit log with verified user information
  INSERT INTO public.audit_logs (
    user_id,
    user_email,
    user_name,
    user_role,
    action,
    action_description,
    target_type,
    target_id,
    target_name,
    changes,
    ip_address,
    browser,
    os,
    device_type,
    session_id,
    raw_log
  ) VALUES (
    _user_id,
    _user_email,
    _user_name,
    _user_role,
    _action,
    _action_description,
    _target_type,
    _target_id,
    _target_name,
    _changes,
    _ip_address,
    _browser,
    _os,
    _device_type,
    _session_id,
    _raw_log
  )
  RETURNING id INTO _new_id;
  
  RETURN _new_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.log_audit_action TO authenticated;