-- Create questions table
CREATE TABLE public.questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  question_text TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('mcq-single', 'mcq-multiple', 'true-false', 'short-answer', 'long-answer', 'code', 'file-upload')),
  subject TEXT NOT NULL,
  difficulty TEXT NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  options JSONB DEFAULT '[]'::jsonb,
  correct_answer TEXT,
  marks INTEGER NOT NULL DEFAULT 1,
  negative_marks NUMERIC DEFAULT 0,
  tags TEXT[] DEFAULT '{}',
  media_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

-- RLS policies - each admin sees only their own questions
CREATE POLICY "Users can view their own questions"
ON public.questions
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own questions"
ON public.questions
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own questions"
ON public.questions
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own questions"
ON public.questions
FOR DELETE
USING (auth.uid() = user_id);

-- Trigger for updated_at
CREATE TRIGGER update_questions_updated_at
BEFORE UPDATE ON public.questions
FOR EACH ROW
EXECUTE FUNCTION public.update_students_updated_at();