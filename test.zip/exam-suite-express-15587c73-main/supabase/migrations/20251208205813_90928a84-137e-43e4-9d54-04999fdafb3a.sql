-- Create proctoring_screenshots table to track screenshots
CREATE TABLE public.proctoring_screenshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES public.exam_sessions(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  screenshot_url TEXT NOT NULL,
  capture_type TEXT NOT NULL DEFAULT 'periodic', -- 'periodic', 'incident', 'manual'
  reason TEXT,
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX idx_proctoring_screenshots_session ON public.proctoring_screenshots(session_id);
CREATE INDEX idx_proctoring_screenshots_student ON public.proctoring_screenshots(student_id);

-- Enable RLS
ALTER TABLE public.proctoring_screenshots ENABLE ROW LEVEL SECURITY;

-- Students can insert their own screenshots during exams
CREATE POLICY "Students can insert own screenshots"
ON public.proctoring_screenshots
FOR INSERT
WITH CHECK (
  student_id IN (
    SELECT id FROM students 
    WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())::text
  )
);

-- Students can view their own screenshots
CREATE POLICY "Students can view own screenshots"
ON public.proctoring_screenshots
FOR SELECT
USING (
  student_id IN (
    SELECT id FROM students 
    WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())::text
  )
);

-- Admins can view all screenshots
CREATE POLICY "Admins can view all screenshots"
ON public.proctoring_screenshots
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can manage all screenshots
CREATE POLICY "Admins can manage screenshots"
ON public.proctoring_screenshots
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create storage bucket for proctoring screenshots
INSERT INTO storage.buckets (id, name, public)
VALUES ('proctoring-screenshots', 'proctoring-screenshots', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for proctoring screenshots bucket
CREATE POLICY "Students can upload own screenshots"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'proctoring-screenshots' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Students can view own screenshots"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'proctoring-screenshots'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admins can view all proctoring screenshots"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'proctoring-screenshots'
  AND has_role(auth.uid(), 'admin'::app_role)
);