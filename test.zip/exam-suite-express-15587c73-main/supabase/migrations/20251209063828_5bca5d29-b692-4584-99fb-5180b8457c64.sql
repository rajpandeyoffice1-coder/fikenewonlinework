-- Create evaluator_exam_assignments table
CREATE TABLE public.evaluator_exam_assignments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  evaluator_id UUID NOT NULL REFERENCES public.evaluators(id) ON DELETE CASCADE,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'evaluator' CHECK (role IN ('lead', 'evaluator', 'moderator')),
  assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  assigned_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(evaluator_id, exam_id)
);

-- Enable Row Level Security
ALTER TABLE public.evaluator_exam_assignments ENABLE ROW LEVEL SECURITY;

-- Create index for faster lookups
CREATE INDEX idx_evaluator_exam_assignments_evaluator ON public.evaluator_exam_assignments(evaluator_id);
CREATE INDEX idx_evaluator_exam_assignments_exam ON public.evaluator_exam_assignments(exam_id);

-- RLS Policies

-- Admins can view all assignments
CREATE POLICY "Admins can view all evaluator assignments"
ON public.evaluator_exam_assignments
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Admins can create assignments
CREATE POLICY "Admins can create evaluator assignments"
ON public.evaluator_exam_assignments
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'));

-- Admins can update assignments
CREATE POLICY "Admins can update evaluator assignments"
ON public.evaluator_exam_assignments
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Admins can delete assignments
CREATE POLICY "Admins can delete evaluator assignments"
ON public.evaluator_exam_assignments
FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- Evaluators can view their own assignments
CREATE POLICY "Evaluators can view own assignments"
ON public.evaluator_exam_assignments
FOR SELECT
USING (
  evaluator_id IN (
    SELECT id FROM public.evaluators WHERE user_id = auth.uid()
  )
);