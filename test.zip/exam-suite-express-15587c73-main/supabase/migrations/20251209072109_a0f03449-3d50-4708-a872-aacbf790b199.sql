-- Add self-access policy for evaluators to view their own profile
CREATE POLICY "Evaluators can view own profile"
ON public.evaluators
FOR SELECT
USING (user_id = auth.uid());

-- Add policy for evaluators to view exams they're assigned to
CREATE POLICY "Evaluators can view assigned exams"
ON public.exams
FOR SELECT
USING (
  id IN (
    SELECT exam_id FROM public.evaluator_exam_assignments
    WHERE evaluator_id IN (
      SELECT id FROM public.evaluators WHERE user_id = auth.uid()
    )
  )
);

-- Add self-access policy for proctors to view their own profile
CREATE POLICY "Proctors can view own profile"
ON public.proctors
FOR SELECT
USING (user_id = auth.uid());

-- Add policy for proctors to view exams they're assigned to
CREATE POLICY "Proctors can view assigned exams"
ON public.exams
FOR SELECT
USING (
  id IN (
    SELECT exam_id FROM public.proctor_exam_assignments
    WHERE proctor_id IN (
      SELECT id FROM public.proctors WHERE user_id = auth.uid()
    )
  )
);