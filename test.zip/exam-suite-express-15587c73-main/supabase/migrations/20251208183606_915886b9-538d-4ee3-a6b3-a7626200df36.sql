-- Create exam_enrollments table to link students to exams
CREATE TABLE public.exam_enrollments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  enrolled_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'enrolled',
  UNIQUE(exam_id, student_id)
);

-- Create exam_sessions table to track student exam attempts
CREATE TABLE public.exam_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  submitted_at TIMESTAMP WITH TIME ZONE,
  status TEXT NOT NULL DEFAULT 'in_progress',
  time_remaining INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(exam_id, student_id)
);

-- Create exam_answers table to store student answers
CREATE TABLE public.exam_answers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES public.exam_sessions(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  answer_text TEXT,
  answer_option JSONB,
  file_url TEXT,
  time_spent INTEGER DEFAULT 0,
  is_flagged BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(session_id, question_id)
);

-- Create exam_results table to store final results
CREATE TABLE public.exam_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  session_id UUID NOT NULL REFERENCES public.exam_sessions(id) ON DELETE CASCADE,
  score NUMERIC(5,2) DEFAULT 0,
  total_marks INTEGER NOT NULL,
  percentage NUMERIC(5,2) DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  grade TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  evaluated_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(session_id)
);

-- Create exam_questions junction table to link questions to exams
CREATE TABLE public.exam_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  question_order INTEGER DEFAULT 0,
  marks INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(exam_id, question_id)
);

-- Enable RLS on all new tables
ALTER TABLE public.exam_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_questions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for exam_enrollments
CREATE POLICY "Admins can manage enrollments" ON public.exam_enrollments
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Students can view own enrollments" ON public.exam_enrollments
  FOR SELECT USING (
    student_id IN (SELECT id FROM public.students WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid()))
  );

-- RLS Policies for exam_sessions
CREATE POLICY "Admins can view all sessions" ON public.exam_sessions
  FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Students can manage own sessions" ON public.exam_sessions
  FOR ALL USING (
    student_id IN (SELECT id FROM public.students WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid()))
  );

-- RLS Policies for exam_answers
CREATE POLICY "Admins can view all answers" ON public.exam_answers
  FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Students can manage own answers" ON public.exam_answers
  FOR ALL USING (
    session_id IN (
      SELECT es.id FROM public.exam_sessions es
      JOIN public.students s ON es.student_id = s.id
      WHERE s.email = (SELECT email FROM auth.users WHERE id = auth.uid())
    )
  );

-- RLS Policies for exam_results
CREATE POLICY "Admins can manage all results" ON public.exam_results
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Students can view own results" ON public.exam_results
  FOR SELECT USING (
    student_id IN (SELECT id FROM public.students WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid()))
  );

-- RLS Policies for exam_questions
CREATE POLICY "Admins can manage exam questions" ON public.exam_questions
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can view exam questions for enrolled exams" ON public.exam_questions
  FOR SELECT USING (true);

-- Create index for better query performance
CREATE INDEX idx_exam_enrollments_student ON public.exam_enrollments(student_id);
CREATE INDEX idx_exam_enrollments_exam ON public.exam_enrollments(exam_id);
CREATE INDEX idx_exam_sessions_student ON public.exam_sessions(student_id);
CREATE INDEX idx_exam_sessions_exam ON public.exam_sessions(exam_id);
CREATE INDEX idx_exam_answers_session ON public.exam_answers(session_id);
CREATE INDEX idx_exam_results_exam ON public.exam_results(exam_id);
CREATE INDEX idx_exam_results_student ON public.exam_results(student_id);