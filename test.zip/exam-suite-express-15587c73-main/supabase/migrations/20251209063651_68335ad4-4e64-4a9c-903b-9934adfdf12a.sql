-- Create proctor_exam_assignments table
CREATE TABLE public.proctor_exam_assignments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  proctor_id UUID NOT NULL REFERENCES public.proctors(id) ON DELETE CASCADE,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'support' CHECK (role IN ('lead', 'support')),
  assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  assigned_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(proctor_id, exam_id)
);

-- Enable Row Level Security
ALTER TABLE public.proctor_exam_assignments ENABLE ROW LEVEL SECURITY;

-- Create index for faster lookups
CREATE INDEX idx_proctor_exam_assignments_proctor ON public.proctor_exam_assignments(proctor_id);
CREATE INDEX idx_proctor_exam_assignments_exam ON public.proctor_exam_assignments(exam_id);

-- RLS Policies

-- Admins can view all assignments
CREATE POLICY "Admins can view all proctor assignments"
ON public.proctor_exam_assignments
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Admins can create assignments
CREATE POLICY "Admins can create proctor assignments"
ON public.proctor_exam_assignments
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'));

-- Admins can update assignments
CREATE POLICY "Admins can update proctor assignments"
ON public.proctor_exam_assignments
FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Admins can delete assignments
CREATE POLICY "Admins can delete proctor assignments"
ON public.proctor_exam_assignments
FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- Proctors can view their own assignments
CREATE POLICY "Proctors can view own assignments"
ON public.proctor_exam_assignments
FOR SELECT
USING (
  proctor_id IN (
    SELECT id FROM public.proctors WHERE user_id = auth.uid()
  )
);