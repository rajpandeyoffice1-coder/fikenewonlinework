-- Create enum for departments
CREATE TYPE public.department_enum AS ENUM ('CSE', 'ECE', 'EE', 'ME', 'CE', 'BBA', 'MBA', 'IT', 'CIVIL', 'OTHER');

-- Create enum for student status
CREATE TYPE public.student_status AS ENUM ('active', 'inactive');

-- Create students table
CREATE TABLE public.students (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  roll_no TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  mobile TEXT NOT NULL,
  department department_enum NOT NULL,
  course TEXT NOT NULL,
  semester INTEGER NOT NULL CHECK (semester >= 1 AND semester <= 12),
  status student_status NOT NULL DEFAULT 'active',
  photo_url TEXT,
  password_hash TEXT,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Validation constraints
  CONSTRAINT full_name_length CHECK (char_length(full_name) >= 3 AND char_length(full_name) <= 60),
  CONSTRAINT full_name_format CHECK (full_name ~ '^[a-zA-Z ]+$'),
  CONSTRAINT roll_no_length CHECK (char_length(roll_no) >= 4 AND char_length(roll_no) <= 15),
  CONSTRAINT roll_no_format CHECK (roll_no ~ '^[a-zA-Z0-9]+$'),
  CONSTRAINT email_format CHECK (email ~ '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),
  CONSTRAINT mobile_format CHECK (mobile ~ '^[6-9][0-9]{9}$'),
  CONSTRAINT course_length CHECK (char_length(course) >= 2 AND char_length(course) <= 40)
);

-- Create index for faster lookups
CREATE INDEX idx_students_roll_no ON public.students(roll_no);
CREATE INDEX idx_students_email ON public.students(email);
CREATE INDEX idx_students_department ON public.students(department);
CREATE INDEX idx_students_status ON public.students(status);

-- Enable Row Level Security
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

-- Policy for public read access (for admin dashboard)
CREATE POLICY "Allow public read access to students"
ON public.students
FOR SELECT
USING (true);

-- Policy for public insert (will be controlled via edge function)
CREATE POLICY "Allow public insert to students"
ON public.students
FOR INSERT
WITH CHECK (true);

-- Policy for public update
CREATE POLICY "Allow public update to students"
ON public.students
FOR UPDATE
USING (true);

-- Policy for public delete
CREATE POLICY "Allow public delete to students"
ON public.students
FOR DELETE
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_students_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_students_updated_at
BEFORE UPDATE ON public.students
FOR EACH ROW
EXECUTE FUNCTION public.update_students_updated_at();

-- Create student_bulk_upload_logs table for tracking bulk uploads
CREATE TABLE public.student_bulk_upload_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  uploaded_by TEXT,
  total_rows INTEGER NOT NULL DEFAULT 0,
  success_count INTEGER NOT NULL DEFAULT 0,
  failed_count INTEGER NOT NULL DEFAULT 0,
  failed_rows JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.student_bulk_upload_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public access to bulk upload logs"
ON public.student_bulk_upload_logs
FOR ALL
USING (true);