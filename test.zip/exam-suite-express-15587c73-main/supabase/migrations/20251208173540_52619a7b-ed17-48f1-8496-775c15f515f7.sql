-- Drop overly permissive public access policies
DROP POLICY IF EXISTS "Allow public read access to students" ON public.students;
DROP POLICY IF EXISTS "Allow public insert to students" ON public.students;
DROP POLICY IF EXISTS "Allow public update to students" ON public.students;
DROP POLICY IF EXISTS "Allow public delete to students" ON public.students;

-- Create secure admin-only policies using the existing has_role function
CREATE POLICY "Admins can view all students" 
ON public.students 
FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can create students" 
ON public.students 
FOR INSERT 
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update students" 
ON public.students 
FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete students" 
ON public.students 
FOR DELETE 
USING (public.has_role(auth.uid(), 'admin'));

-- Also fix the bulk upload logs table
DROP POLICY IF EXISTS "Allow public access to bulk upload logs" ON public.student_bulk_upload_logs;

CREATE POLICY "Admins can access bulk upload logs" 
ON public.student_bulk_upload_logs 
FOR ALL 
USING (public.has_role(auth.uid(), 'admin'));