-- Create a SECURITY DEFINER function to get the current user's email
-- This allows RLS policies to access auth.users safely
CREATE OR REPLACE FUNCTION public.get_current_user_email()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT email FROM auth.users WHERE id = auth.uid()
$$;

-- Drop old policies that reference auth.users directly
DROP POLICY IF EXISTS "Students can view own profile" ON public.students;
DROP POLICY IF EXISTS "Students can view own enrollments" ON public.exam_enrollments;

-- Recreate policies using the SECURITY DEFINER function
CREATE POLICY "Students can view own profile" 
ON public.students 
FOR SELECT 
USING (email = get_current_user_email());

CREATE POLICY "Students can view own enrollments" 
ON public.exam_enrollments 
FOR SELECT 
USING (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

-- Also fix policies on other tables that may have the same issue
DROP POLICY IF EXISTS "Students can manage own sessions" ON public.exam_sessions;
CREATE POLICY "Students can manage own sessions" 
ON public.exam_sessions 
FOR ALL 
USING (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

DROP POLICY IF EXISTS "Students can manage own answers" ON public.exam_answers;
CREATE POLICY "Students can manage own answers" 
ON public.exam_answers 
FOR ALL 
USING (
  session_id IN (
    SELECT es.id FROM exam_sessions es
    JOIN students s ON es.student_id = s.id
    WHERE s.email = get_current_user_email()
  )
);

DROP POLICY IF EXISTS "Students can view own results" ON public.exam_results;
CREATE POLICY "Students can view own results" 
ON public.exam_results 
FOR SELECT 
USING (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

DROP POLICY IF EXISTS "Students can view own incidents" ON public.proctoring_incidents;
DROP POLICY IF EXISTS "Students can insert own incidents" ON public.proctoring_incidents;
CREATE POLICY "Students can view own incidents" 
ON public.proctoring_incidents 
FOR SELECT 
USING (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

CREATE POLICY "Students can insert own incidents" 
ON public.proctoring_incidents 
FOR INSERT 
WITH CHECK (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

DROP POLICY IF EXISTS "Students can view own screenshots" ON public.proctoring_screenshots;
DROP POLICY IF EXISTS "Students can insert own screenshots" ON public.proctoring_screenshots;
CREATE POLICY "Students can view own screenshots" 
ON public.proctoring_screenshots 
FOR SELECT 
USING (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);

CREATE POLICY "Students can insert own screenshots" 
ON public.proctoring_screenshots 
FOR INSERT 
WITH CHECK (
  student_id IN (
    SELECT id FROM students WHERE email = get_current_user_email()
  )
);