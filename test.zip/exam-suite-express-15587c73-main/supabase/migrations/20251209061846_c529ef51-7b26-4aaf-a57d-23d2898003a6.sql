-- Add unique constraint on exam_answers for session_id and question_id
-- This is required for upsert operations to work correctly
ALTER TABLE public.exam_answers 
ADD CONSTRAINT exam_answers_session_question_unique 
UNIQUE (session_id, question_id);