-- Create exams table
CREATE TABLE public.exams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  code TEXT NOT NULL,
  department TEXT NOT NULL,
  course TEXT,
  semester TEXT,
  description TEXT,
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  duration INTEGER NOT NULL DEFAULT 60,
  total_marks INTEGER NOT NULL DEFAULT 100,
  passing_marks INTEGER DEFAULT 40,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'scheduled', 'live', 'completed', 'cancelled')),
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create proctors table
CREATE TABLE public.proctors (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  mobile TEXT,
  department TEXT,
  experience INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  permissions JSONB DEFAULT '{"liveMonitoring": true, "viewRecordings": true, "flagIncidents": true, "pauseExams": false, "terminateExams": false}'::jsonb,
  assigned_exams_count INTEGER DEFAULT 0,
  incidents_reported INTEGER DEFAULT 0,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create evaluators table
CREATE TABLE public.evaluators (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  mobile TEXT,
  department TEXT,
  subject_expertise TEXT[] DEFAULT '{}',
  experience INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  permissions JSONB DEFAULT '{"viewAnswerSheets": true, "scoreSubjectiveAnswers": true, "addComments": true, "reEvaluateSheets": false, "viewRubrics": true}'::jsonb,
  assigned_exams_count INTEGER DEFAULT 0,
  pending_sheets INTEGER DEFAULT 0,
  total_evaluations INTEGER DEFAULT 0,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proctors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.evaluators ENABLE ROW LEVEL SECURITY;

-- RLS policies for exams (admin can see all exams they created)
CREATE POLICY "Users can view their own exams" ON public.exams FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create exams" ON public.exams FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own exams" ON public.exams FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own exams" ON public.exams FOR DELETE USING (auth.uid() = user_id);

-- RLS policies for proctors (admin access)
CREATE POLICY "Admins can view all proctors" ON public.proctors FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can create proctors" ON public.proctors FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update proctors" ON public.proctors FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete proctors" ON public.proctors FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- RLS policies for evaluators (admin access)
CREATE POLICY "Admins can view all evaluators" ON public.evaluators FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can create evaluators" ON public.evaluators FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update evaluators" ON public.evaluators FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete evaluators" ON public.evaluators FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Update triggers
CREATE TRIGGER update_exams_updated_at BEFORE UPDATE ON public.exams FOR EACH ROW EXECUTE FUNCTION public.update_students_updated_at();
CREATE TRIGGER update_proctors_updated_at BEFORE UPDATE ON public.proctors FOR EACH ROW EXECUTE FUNCTION public.update_students_updated_at();
CREATE TRIGGER update_evaluators_updated_at BEFORE UPDATE ON public.evaluators FOR EACH ROW EXECUTE FUNCTION public.update_students_updated_at();