-- Enable realtime for proctoring_incidents table
ALTER TABLE public.proctoring_incidents REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.proctoring_incidents;