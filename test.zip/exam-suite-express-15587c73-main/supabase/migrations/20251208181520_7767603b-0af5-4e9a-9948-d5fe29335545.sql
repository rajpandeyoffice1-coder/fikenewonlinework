-- Create subjects table
CREATE TABLE public.subjects (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  department text NOT NULL,
  semester integer NOT NULL CHECK (semester >= 1 AND semester <= 12),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;

-- Create policies - Admins can manage subjects
CREATE POLICY "Admins can view all subjects" ON public.subjects
  FOR SELECT USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can create subjects" ON public.subjects
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update subjects" ON public.subjects
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete subjects" ON public.subjects
  FOR DELETE USING (has_role(auth.uid(), 'admin'));

-- Create trigger for updated_at
CREATE TRIGGER update_subjects_updated_at
  BEFORE UPDATE ON public.subjects
  FOR EACH ROW
  EXECUTE FUNCTION public.update_students_updated_at();

-- Create index for faster lookups
CREATE INDEX idx_subjects_department ON public.subjects(department);
CREATE INDEX idx_subjects_status ON public.subjects(status);