-- Allow admins to view all exams for reports
CREATE POLICY "Admins can view all exams"
ON public.exams
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to view all students for reports  
CREATE POLICY "Students can view own profile"
ON public.students
FOR SELECT
USING (email = (SELECT email FROM auth.users WHERE id = auth.uid()));