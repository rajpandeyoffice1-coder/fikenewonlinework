-- Drop the overly permissive policy that allows anyone to view all exam questions
DROP POLICY IF EXISTS "Anyone can view exam questions for enrolled exams" ON public.exam_questions;

-- Create policy for students: only view questions during active exam session
CREATE POLICY "Students can view questions during active exam"
ON public.exam_questions
FOR SELECT
USING (
  -- Check if student has an active (in_progress) session for this exam
  exam_id IN (
    SELECT es.exam_id 
    FROM public.exam_sessions es
    JOIN public.students s ON es.student_id = s.id
    WHERE s.email = get_current_user_email()
    AND es.status = 'in_progress'
  )
);

-- Allow evaluators to view exam questions for exams they're assigned to
CREATE POLICY "Evaluators can view assigned exam questions"
ON public.exam_questions
FOR SELECT
USING (
  exam_id IN (
    SELECT eea.exam_id 
    FROM public.evaluator_exam_assignments eea
    JOIN public.evaluators e ON eea.evaluator_id = e.id
    WHERE e.user_id = auth.uid()
  )
);

-- Allow proctors to view exam questions for exams they're assigned to
CREATE POLICY "Proctors can view assigned exam questions"
ON public.exam_questions
FOR SELECT
USING (
  exam_id IN (
    SELECT pea.exam_id 
    FROM public.proctor_exam_assignments pea
    JOIN public.proctors p ON pea.proctor_id = p.id
    WHERE p.user_id = auth.uid()
  )
);