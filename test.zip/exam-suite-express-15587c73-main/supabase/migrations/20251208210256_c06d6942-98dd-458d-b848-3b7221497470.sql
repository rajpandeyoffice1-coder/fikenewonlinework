-- Create proctoring_incidents table to track violations during exams
CREATE TABLE public.proctoring_incidents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES public.exam_sessions(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  incident_type TEXT NOT NULL, -- 'tab_switch', 'face_not_detected', 'multiple_faces', 'face_mismatch', 'looking_away', 'audio_detected', 'copy_paste', 'screen_share_stopped', 'browser_resize'
  severity TEXT NOT NULL DEFAULT 'medium', -- 'low', 'medium', 'high'
  message TEXT NOT NULL,
  details JSONB, -- Additional data like coordinates, confidence scores, etc.
  screenshot_id UUID REFERENCES public.proctoring_screenshots(id),
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for faster lookups
CREATE INDEX idx_proctoring_incidents_session ON public.proctoring_incidents(session_id);
CREATE INDEX idx_proctoring_incidents_student ON public.proctoring_incidents(student_id);
CREATE INDEX idx_proctoring_incidents_type ON public.proctoring_incidents(incident_type);
CREATE INDEX idx_proctoring_incidents_timestamp ON public.proctoring_incidents(timestamp);

-- Enable RLS
ALTER TABLE public.proctoring_incidents ENABLE ROW LEVEL SECURITY;

-- Students can insert their own incidents during exams
CREATE POLICY "Students can insert own incidents"
ON public.proctoring_incidents
FOR INSERT
WITH CHECK (
  student_id IN (
    SELECT id FROM students 
    WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())::text
  )
);

-- Students can view their own incidents
CREATE POLICY "Students can view own incidents"
ON public.proctoring_incidents
FOR SELECT
USING (
  student_id IN (
    SELECT id FROM students 
    WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())::text
  )
);

-- Admins can view all incidents
CREATE POLICY "Admins can view all incidents"
ON public.proctoring_incidents
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can manage all incidents
CREATE POLICY "Admins can manage incidents"
ON public.proctoring_incidents
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));