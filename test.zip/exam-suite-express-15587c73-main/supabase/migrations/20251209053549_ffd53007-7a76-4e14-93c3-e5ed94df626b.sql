-- Update the proctoring-screenshots bucket to be public so images can be viewed
UPDATE storage.buckets 
SET public = true 
WHERE id = 'proctoring-screenshots';