-- Create audit_logs table
CREATE TABLE public.audit_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  user_role TEXT NOT NULL,
  action TEXT NOT NULL,
  action_description TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT,
  target_name TEXT,
  ip_address TEXT,
  browser TEXT,
  os TEXT,
  device_type TEXT DEFAULT 'Desktop',
  session_id TEXT,
  changes JSONB,
  raw_log JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Admins can view all audit logs
CREATE POLICY "Admins can view all audit logs" ON public.audit_logs
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

-- Anyone authenticated can insert audit logs (for tracking their own actions)
CREATE POLICY "Authenticated users can create audit logs" ON public.audit_logs
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Create platform_settings table (single row for global settings)
CREATE TABLE public.platform_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  platform_name TEXT NOT NULL DEFAULT 'ExamExpress University Admin',
  university_name TEXT NOT NULL DEFAULT 'State University',
  logo_url TEXT,
  support_email TEXT DEFAULT 'support@university.edu',
  support_phone TEXT,
  default_timezone TEXT DEFAULT 'Asia/Kolkata',
  language TEXT DEFAULT 'en',
  proctoring_settings JSONB DEFAULT '{"enableProctoring": true, "webcamRequired": true, "microphoneRequired": true, "faceVerification": true}'::jsonb,
  exam_defaults JSONB DEFAULT '{"defaultDuration": 60, "defaultPassingMarks": 40, "questionShuffle": true, "negativeMarking": false}'::jsonb,
  security_settings JSONB DEFAULT '{"passwordMinLength": 8, "requireSpecialChars": true, "failedAttemptsLimit": 5}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

-- Admins can view settings
CREATE POLICY "Admins can view settings" ON public.platform_settings
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

-- Admins can update settings
CREATE POLICY "Admins can update settings" ON public.platform_settings
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

-- Insert default settings row
INSERT INTO public.platform_settings (platform_name, university_name) 
VALUES ('ExamExpress University Admin', 'State University');

-- Create index for faster audit log queries
CREATE INDEX idx_audit_logs_created_at ON public.audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_user_role ON public.audit_logs(user_role);
CREATE INDEX idx_audit_logs_action ON public.audit_logs(action);