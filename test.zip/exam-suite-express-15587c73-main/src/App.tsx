import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { AuthRedirect } from "@/components/auth/AuthRedirect";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import Index from "./pages/Index";
import Exams from "./pages/Exams";
import ExamDetails from "./pages/ExamDetails";
import EditExam from "./pages/EditExam";
import QuestionBank from "./pages/QuestionBank";
import CreateExam from "./pages/CreateExam";
import Students from "./pages/Students";
import Proctors from "./pages/Proctors";
import Evaluators from "./pages/Evaluators";
import Reports from "./pages/Reports";
import AuditLog from "./pages/AuditLog";
import Settings from "./pages/Settings";
import Subjects from "./pages/Subjects";
import StudentGroups from "./pages/StudentGroups";
import Login from "./pages/Login";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";
import { StudentAuth } from "./components/student/StudentAuth";
import { StudentLayout } from "./components/student/StudentLayout";
import { StudentDashboard } from "./components/student/StudentDashboard";
import { StudentExamsList } from "./components/student/StudentExamsList";
import { DeviceCheck } from "./components/student/DeviceCheck";
import { AdmitCard } from "./components/student/AdmitCard";
import { IdentityVerification } from "./components/student/IdentityVerification";
import { ProfileVerification } from "./components/student/ProfileVerification";
import { ExamInterface } from "./components/student/ExamInterface";
import { ExamSubmission } from "./components/student/ExamSubmission";
import { ResultsList } from "./components/student/ResultsList";
import { ExamResult } from "./components/student/ExamResult";
import { StudentProfile } from "./components/student/StudentProfile";
// Proctor Module
import { ProctorLayout } from "./components/proctor-module/ProctorLayout";
import { ProctorDashboard } from "./components/proctor-module/ProctorDashboard";
import { LiveInvigilation } from "./components/proctor-module/LiveInvigilation";
import { IncidentReview } from "./components/proctor-module/IncidentReview";
import { EvidenceReplay } from "./components/proctor-module/EvidenceReplay";
import { GlobalAlerts } from "./components/proctor-module/GlobalAlerts";
import { ProctorSettings } from "./components/proctor-module/ProctorSettings";
// Evaluator Module
import { EvaluatorLayout } from "./components/evaluator-module/EvaluatorLayout";
import { EvaluatorDashboard } from "./components/evaluator-module/EvaluatorDashboard";
import { EvaluationQueue } from "./components/evaluator-module/EvaluationQueue";
import { EvaluationWindow } from "./components/evaluator-module/EvaluationWindow";
import { ReEvaluationRequests } from "./components/evaluator-module/ReEvaluationRequests";
import { PlagiarismCheck } from "./components/evaluator-module/PlagiarismCheck";
import { EvaluationSummary } from "./components/evaluator-module/EvaluationSummary";
import { EvaluatorReports } from "./components/evaluator-module/EvaluatorReports";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/student/login" element={<StudentAuth />} />
            
            {/* Root - Redirects based on auth state */}
            <Route path="/" element={<AuthRedirect />} />
            
            {/* Admin Routes - Protected */}
            <Route path="/admin/dashboard" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Index />
              </ProtectedRoute>
            } />
            <Route path="/exams" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Exams />
              </ProtectedRoute>
            } />
            <Route path="/exams/:examId" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <ExamDetails />
              </ProtectedRoute>
            } />
            <Route path="/exams/:examId/edit" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <EditExam />
              </ProtectedRoute>
            } />
            <Route path="/question-bank" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <QuestionBank />
              </ProtectedRoute>
            } />
            <Route path="/create-exam" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <CreateExam />
              </ProtectedRoute>
            } />
            <Route path="/students" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Students />
              </ProtectedRoute>
            } />
            <Route path="/proctors" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Proctors />
              </ProtectedRoute>
            } />
            <Route path="/evaluators" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Evaluators />
              </ProtectedRoute>
            } />
            <Route path="/reports" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Reports />
              </ProtectedRoute>
            } />
            <Route path="/audit-log" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <AuditLog />
              </ProtectedRoute>
            } />
            <Route path="/settings" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Settings />
              </ProtectedRoute>
            } />
            <Route path="/subjects" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Subjects />
              </ProtectedRoute>
            } />
            <Route path="/student-groups" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <StudentGroups />
              </ProtectedRoute>
            } />
            
            {/* Student Portal Routes - Protected */}
            <Route path="/student" element={
              <ProtectedRoute allowedRoles={['student']}>
                <StudentLayout />
              </ProtectedRoute>
            }>
              <Route path="dashboard" element={<StudentDashboard />} />
              <Route path="exams" element={<StudentExamsList />} />
              <Route path="admit-card" element={<AdmitCard />} />
              <Route path="results" element={<ResultsList />} />
              <Route path="results/:examId" element={<ExamResult />} />
              <Route path="profile" element={<StudentProfile />} />
              <Route path="device-check/:examId" element={<DeviceCheck />} />
            </Route>
            <Route path="/student/exam/:examId/verify" element={
              <ProtectedRoute allowedRoles={['student']}>
                <IdentityVerification />
              </ProtectedRoute>
            } />
            <Route path="/student/exam/:examId/profile" element={
              <ProtectedRoute allowedRoles={['student']}>
                <ProfileVerification />
              </ProtectedRoute>
            } />
            <Route path="/student/exam/:examId" element={
              <ProtectedRoute allowedRoles={['student']}>
                <ExamInterface />
              </ProtectedRoute>
            } />
            <Route path="/student/exam/:examId/submit" element={
              <ProtectedRoute allowedRoles={['student']}>
                <ExamSubmission />
              </ProtectedRoute>
            } />
            
            {/* Proctor Portal Routes - Protected */}
            <Route path="/proctor-portal" element={
              <ProtectedRoute allowedRoles={['proctor']}>
                <ProctorLayout />
              </ProtectedRoute>
            }>
              <Route index element={<ProctorDashboard />} />
              <Route path="live" element={<LiveInvigilation />} />
              <Route path="incidents" element={<IncidentReview />} />
              <Route path="evidence" element={<EvidenceReplay />} />
              <Route path="alerts" element={<GlobalAlerts />} />
              <Route path="settings" element={<ProctorSettings />} />
            </Route>
            
            {/* Evaluator Portal Routes - Protected */}
            <Route path="/evaluator-portal" element={
              <ProtectedRoute allowedRoles={['evaluator']}>
                <EvaluatorLayout />
              </ProtectedRoute>
            }>
              <Route index element={<EvaluatorDashboard />} />
              <Route path="queue" element={<EvaluationQueue />} />
              <Route path="evaluate/:sheetId" element={<EvaluationWindow />} />
              <Route path="reevaluation" element={<ReEvaluationRequests />} />
              <Route path="plagiarism/:candidateId" element={<PlagiarismCheck />} />
              <Route path="reports" element={<EvaluatorReports />} />
              <Route path="profile" element={<EvaluatorDashboard />} />
            </Route>
            <Route path="/evaluator-portal/summary" element={
              <ProtectedRoute allowedRoles={['evaluator']}>
                <EvaluationSummary />
              </ProtectedRoute>
            } />
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
