import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface StudentExamData {
  id: string;
  examId: string;
  name: string;
  examName: string;
  examCode: string;
  subject: string;
  department: string;
  date: string;
  dateTime: string;
  duration: number;
  totalMarks: number;
  passingMarks: number;
  description: string;
  status: 'upcoming' | 'ongoing' | 'completed' | 'missed';
  canStart?: boolean;
  score?: number;
  percentage?: number;
  result?: string;
  completedAt?: string;
  sessionId?: string;
  enrollmentId: string;
}

export interface StudentData {
  id: string;
  full_name: string;
  roll_no: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: number;
  photo_url?: string;
  status: string;
}

interface UseStudentExamsReturn {
  upcoming: StudentExamData[];
  ongoing: StudentExamData[];
  completed: StudentExamData[];
  student: StudentData | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useStudentExams(): UseStudentExamsReturn {
  const [upcoming, setUpcoming] = useState<StudentExamData[]>([]);
  const [ongoing, setOngoing] = useState<StudentExamData[]>([]);
  const [completed, setCompleted] = useState<StudentExamData[]>([]);
  const [student, setStudent] = useState<StudentData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchExams = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setError('Please log in to view your exams');
        setIsLoading(false);
        return;
      }

      const { data, error: fnError } = await supabase.functions.invoke('exam-session', {
        body: {},
        headers: { 'Content-Type': 'application/json' },
        method: 'GET',
      });

      // Use query params approach
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/exam-session?action=student-exams`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
        }
      );

      const result = await response.json();

      if (result.status === 'success') {
        setUpcoming(result.data.upcoming || []);
        setOngoing(result.data.ongoing || []);
        setCompleted(result.data.completed || []);
        setStudent(result.data.student || null);
      } else {
        setError(result.message || 'Failed to fetch exams');
      }
    } catch (err) {
      console.error('Error fetching student exams:', err);
      setError('Failed to load exams');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchExams();
  }, [fetchExams]);

  return {
    upcoming,
    ongoing,
    completed,
    student,
    isLoading,
    error,
    refetch: fetchExams,
  };
}

export async function startExamSession(examId: string): Promise<{ 
  success: boolean; 
  sessionId?: string;
  studentId?: string;
  questions?: any[]; 
  exam?: any;
  savedAnswers?: any[];
  timeRemaining?: number;
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return { success: false, error: 'Not authenticated' };
    }

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/exam-session?action=start`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
          'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ exam_id: examId }),
      }
    );

    const result = await response.json();

    if (result.status === 'success') {
      return {
        success: true,
        sessionId: result.data.session_id,
        studentId: result.data.student_id,
        questions: result.data.questions,
        exam: result.data.exam,
        savedAnswers: result.data.savedAnswers,
        timeRemaining: result.data.timeRemaining,
      };
    }

    return { success: false, error: result.message };
  } catch (err) {
    console.error('Error starting exam:', err);
    return { success: false, error: 'Failed to start exam' };
  }
}

export async function saveAnswer(
  sessionId: string,
  questionId: string,
  answer: { text?: string; option?: any; fileUrl?: string },
  timeSpent: number,
  isFlagged: boolean
): Promise<boolean> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return false;

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/exam-session?action=save-answer`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
          'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({
          session_id: sessionId,
          question_id: questionId,
          answer_text: answer.text,
          answer_option: answer.option,
          file_url: answer.fileUrl,
          time_spent: timeSpent,
          is_flagged: isFlagged,
        }),
      }
    );

    const result = await response.json();
    return result.status === 'success';
  } catch (err) {
    console.error('Error saving answer:', err);
    return false;
  }
}

export async function submitExam(sessionId: string): Promise<{
  success: boolean;
  score?: number;
  totalMarks?: number;
  percentage?: number;
  result?: string;
  grade?: string;
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return { success: false, error: 'Not authenticated' };
    }

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/exam-session?action=submit`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
          'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ session_id: sessionId }),
      }
    );

    const result = await response.json();

    if (result.status === 'success') {
      return {
        success: true,
        score: result.data.score,
        totalMarks: result.data.totalMarks,
        percentage: result.data.percentage,
        result: result.data.result,
        grade: result.data.grade,
      };
    }

    return { success: false, error: result.message };
  } catch (err) {
    console.error('Error submitting exam:', err);
    return { success: false, error: 'Failed to submit exam' };
  }
}

export async function getExamResult(sessionId: string): Promise<{
  success: boolean;
  result?: any;
  answers?: any[];
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      return { success: false, error: 'Not authenticated' };
    }

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/exam-session?action=result&session_id=${sessionId}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
          'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
      }
    );

    const data = await response.json();

    if (data.status === 'success') {
      return {
        success: true,
        result: data.data.result,
        answers: data.data.answers,
      };
    }

    return { success: false, error: data.message };
  } catch (err) {
    console.error('Error fetching result:', err);
    return { success: false, error: 'Failed to fetch result' };
  }
}