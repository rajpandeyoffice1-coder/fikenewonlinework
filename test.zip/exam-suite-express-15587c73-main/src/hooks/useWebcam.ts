import { useState, useEffect, useRef, useCallback } from 'react';

interface UseWebcamOptions {
  video?: boolean | MediaTrackConstraints;
  audio?: boolean;
}

interface UseWebcamReturn {
  videoRef: React.RefObject<HTMLVideoElement>;
  stream: MediaStream | null;
  isLoading: boolean;
  error: string | null;
  isActive: boolean;
  startCamera: () => Promise<void>;
  stopCamera: () => void;
  captureImage: () => string | null;
}

export function useWebcam(options: UseWebcamOptions = { video: true, audio: false }): UseWebcamReturn {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isActive, setIsActive] = useState(false);

  const startCamera = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: options.video || {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user',
        },
        audio: options.audio,
      });

      setStream(mediaStream);
      setIsActive(true);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to access camera';
      if (errorMessage.includes('Permission denied') || errorMessage.includes('NotAllowedError')) {
        setError('Camera permission denied. Please allow camera access.');
      } else if (errorMessage.includes('NotFoundError') || errorMessage.includes('DevicesNotFoundError')) {
        setError('No camera found. Please connect a camera.');
      } else {
        setError(errorMessage);
      }
      setIsActive(false);
    } finally {
      setIsLoading(false);
    }
  }, [options.video, options.audio]);

  // Set srcObject when stream changes - this ensures video element is visible first
  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
      setIsActive(false);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, [stream]);

  const captureImage = useCallback((): string | null => {
    if (!videoRef.current || !isActive) return null;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    
    ctx.drawImage(videoRef.current, 0, 0);
    return canvas.toDataURL('image/jpeg', 0.8);
  }, [isActive]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [stream]);

  return {
    videoRef,
    stream,
    isLoading,
    error,
    isActive,
    startCamera,
    stopCamera,
    captureImage,
  };
}

// Hook for checking device permissions
export function useDevicePermissions() {
  const [permissions, setPermissions] = useState({
    camera: 'prompt' as PermissionState | 'unsupported',
    microphone: 'prompt' as PermissionState | 'unsupported',
    geolocation: 'prompt' as PermissionState | 'unsupported',
  });

  const checkPermission = async (name: 'camera' | 'microphone' | 'geolocation') => {
    try {
      if (!navigator.permissions) {
        return 'unsupported';
      }
      const result = await navigator.permissions.query({ name: name as PermissionName });
      return result.state;
    } catch {
      return 'unsupported';
    }
  };

  const checkAllPermissions = useCallback(async () => {
    const [camera, microphone, geolocation] = await Promise.all([
      checkPermission('camera'),
      checkPermission('microphone'),
      checkPermission('geolocation'),
    ]);

    setPermissions({
      camera: camera as PermissionState | 'unsupported',
      microphone: microphone as PermissionState | 'unsupported',
      geolocation: geolocation as PermissionState | 'unsupported',
    });
  }, []);

  useEffect(() => {
    checkAllPermissions();
  }, [checkAllPermissions]);

  return { permissions, checkAllPermissions };
}

// Note: useInternetSpeed has been moved to src/hooks/useInternetSpeed.ts
// for comprehensive speed testing with download, upload, and latency measurements
