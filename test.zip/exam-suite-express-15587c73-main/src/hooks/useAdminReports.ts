import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ReportsData {
  exams: any[];
  students: any[];
  questions: any[];
  examResults: any[];
}

export function useAdminReports() {
  const [data, setData] = useState<ReportsData>({
    exams: [],
    students: [],
    questions: [],
    examResults: [],
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Get fresh session - wait for it to be available
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !sessionData.session) {
        throw new Error('Not authenticated. Please log in again.');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-reports?action=get-reports-data`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${sessionData.session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch reports data');
      }

      const result = await response.json();
      setData(result);
    } catch (err: any) {
      console.error('Error fetching reports:', err);
      setError(err.message);
      toast.error(err.message || 'Failed to load reports data');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Listen for auth state changes and fetch when authenticated
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) {
        fetchData();
      }
    });

    // Initial fetch
    fetchData();

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchData]);

  const fetchCandidateBreakdown = async (sessionId: string) => {
    try {
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !sessionData.session) {
        throw new Error('Not authenticated. Please log in again.');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-reports?action=get-candidate-breakdown&sessionId=${sessionId}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${sessionData.session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch candidate breakdown');
      }

      return await response.json();
    } catch (err: any) {
      console.error('Error fetching breakdown:', err);
      toast.error(err.message || 'Failed to load candidate breakdown');
      throw err;
    }
  };

  return {
    ...data,
    isLoading,
    error,
    refetch: fetchData,
    fetchCandidateBreakdown,
  };
}
