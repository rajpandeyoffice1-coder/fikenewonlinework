import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface Subject {
  id: string;
  name: string;
  code: string;
  department: string;
  semester: number;
  status: string;
}

export function useSubjects() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchSubjects();
  }, []);

  const fetchSubjects = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("subjects")
      .select("*")
      .eq("status", "active")
      .order("name");

    if (error) {
      setError(error.message);
      console.error("Error fetching subjects:", error);
    } else {
      setSubjects(data || []);
    }
    setIsLoading(false);
  };

  const getSubjectsByDepartment = (department: string) => {
    if (!department) return subjects;
    return subjects.filter(
      (s) => s.department.toLowerCase() === department.toLowerCase()
    );
  };

  const getDepartments = () => {
    const depts = [...new Set(subjects.map((s) => s.department))];
    return depts.map((d) => ({ value: d.toLowerCase(), label: d }));
  };

  return {
    subjects,
    isLoading,
    error,
    refetch: fetchSubjects,
    getSubjectsByDepartment,
    getDepartments,
  };
}
