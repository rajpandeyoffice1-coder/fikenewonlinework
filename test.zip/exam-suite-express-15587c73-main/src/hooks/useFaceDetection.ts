import { useState, useEffect, useCallback, useRef } from 'react';
import * as faceapi from 'face-api.js';

export interface FaceDetectionResult {
  faceDetected: boolean;
  multipleFaces: boolean;
  lookingAway: boolean;
  eyesNotVisible: boolean;
  faceCount: number;
  confidence: number;
  landmarks?: faceapi.FaceLandmarks68;
  expressions?: faceapi.FaceExpressions;
}

interface UseFaceDetectionOptions {
  videoElement: HTMLVideoElement | null;
  enabled?: boolean;
  detectionInterval?: number;
}

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12/model';

export function useFaceDetection({
  videoElement,
  enabled = true,
  detectionInterval = 500,
}: UseFaceDetectionOptions) {
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FaceDetectionResult>({
    faceDetected: false,
    multipleFaces: false,
    lookingAway: false,
    eyesNotVisible: false,
    faceCount: 0,
    confidence: 0,
  });
  const [alerts, setAlerts] = useState<string[]>([]);
  const [descriptor, setDescriptor] = useState<Float32Array | null>(null);
  
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const alertCountsRef = useRef({
    noFace: 0,
    multipleFaces: 0,
    lookingAway: 0,
  });

  // Load face-api models
  useEffect(() => {
    const loadModels = async () => {
      try {
        setIsLoading(true);
        setError(null);

        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
          faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL),
          faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
          faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        ]);

        setIsModelLoaded(true);
        console.log('Face detection models loaded');
      } catch (err) {
        console.error('Failed to load face detection models:', err);
        setError('Failed to load face detection models');
      } finally {
        setIsLoading(false);
      }
    };

    loadModels();
  }, []);

  // Check if person is looking away based on landmarks
  const checkLookingAway = useCallback((landmarks: faceapi.FaceLandmarks68): boolean => {
    const leftEye = landmarks.getLeftEye();
    const rightEye = landmarks.getRightEye();
    const nose = landmarks.getNose();

    if (leftEye.length === 0 || rightEye.length === 0 || nose.length === 0) {
      return true;
    }

    // Calculate eye center positions
    const leftEyeCenter = {
      x: leftEye.reduce((sum, p) => sum + p.x, 0) / leftEye.length,
      y: leftEye.reduce((sum, p) => sum + p.y, 0) / leftEye.length,
    };
    const rightEyeCenter = {
      x: rightEye.reduce((sum, p) => sum + p.x, 0) / rightEye.length,
      y: rightEye.reduce((sum, p) => sum + p.y, 0) / rightEye.length,
    };

    // Calculate face angle based on eye positions
    const eyeDistance = Math.abs(rightEyeCenter.x - leftEyeCenter.x);
    const eyeYDiff = Math.abs(rightEyeCenter.y - leftEyeCenter.y);
    
    // If eyes are too vertically misaligned, person might be tilting head significantly
    const tiltRatio = eyeYDiff / eyeDistance;
    
    // Check nose position relative to eyes to detect horizontal turn
    const noseTop = nose[0];
    const midEyeX = (leftEyeCenter.x + rightEyeCenter.x) / 2;
    const noseOffset = Math.abs(noseTop.x - midEyeX) / eyeDistance;

    // Person is looking away if nose is significantly off-center or head is tilted
    return tiltRatio > 0.3 || noseOffset > 0.25;
  }, []);

  // Check if eyes are visible
  const checkEyesVisible = useCallback((landmarks: faceapi.FaceLandmarks68): boolean => {
    const leftEye = landmarks.getLeftEye();
    const rightEye = landmarks.getRightEye();
    
    // Check if eye landmarks are detected and have reasonable spread
    if (leftEye.length < 6 || rightEye.length < 6) {
      return false;
    }

    // Calculate eye openness (vertical distance between top and bottom of eye)
    const leftEyeHeight = Math.abs(leftEye[1].y - leftEye[5].y);
    const rightEyeHeight = Math.abs(rightEye[1].y - rightEye[5].y);
    const leftEyeWidth = Math.abs(leftEye[3].x - leftEye[0].x);
    const rightEyeWidth = Math.abs(rightEye[3].x - rightEye[0].x);

    // Eye aspect ratio (should be > 0.1 for open eyes)
    const leftEAR = leftEyeHeight / leftEyeWidth;
    const rightEAR = rightEyeHeight / rightEyeWidth;

    return leftEAR > 0.08 && rightEAR > 0.08;
  }, []);

  // Run face detection
  const detectFace = useCallback(async () => {
    if (!videoElement || !isModelLoaded || !enabled) return;

    try {
      const detections = await faceapi
        .detectAllFaces(videoElement, new faceapi.TinyFaceDetectorOptions({
          inputSize: 320,
          scoreThreshold: 0.5,
        }))
        .withFaceLandmarks(true)
        .withFaceExpressions()
        .withFaceDescriptors();

      const faceCount = detections.length;
      const faceDetected = faceCount > 0;
      const multipleFaces = faceCount > 1;

      let lookingAway = false;
      let eyesNotVisible = false;
      let confidence = 0;
      let landmarks: faceapi.FaceLandmarks68 | undefined;
      let expressions: faceapi.FaceExpressions | undefined;
      let faceDescriptor: Float32Array | null = null;

      if (faceDetected && detections[0]) {
        const detection = detections[0];
        confidence = detection.detection.score;
        landmarks = detection.landmarks;
        expressions = detection.expressions;
        faceDescriptor = detection.descriptor;

        if (landmarks) {
          lookingAway = checkLookingAway(landmarks);
          eyesNotVisible = !checkEyesVisible(landmarks);
        }
      }

      // Update face descriptor
      setDescriptor(faceDescriptor);

      // Update alert counts
      const newAlerts: string[] = [];
      
      if (!faceDetected) {
        alertCountsRef.current.noFace++;
        if (alertCountsRef.current.noFace >= 3) {
          newAlerts.push(`Face left frame (${alertCountsRef.current.noFace} times)`);
        }
      } else {
        alertCountsRef.current.noFace = 0;
      }

      if (multipleFaces) {
        alertCountsRef.current.multipleFaces++;
        newAlerts.push('Multiple persons detected');
      } else {
        alertCountsRef.current.multipleFaces = 0;
      }

      if (lookingAway && faceDetected) {
        alertCountsRef.current.lookingAway++;
        if (alertCountsRef.current.lookingAway >= 2) {
          newAlerts.push('Head movement detected');
        }
      } else {
        alertCountsRef.current.lookingAway = 0;
      }

      if (eyesNotVisible && faceDetected) {
        newAlerts.push('Eyes not visible');
      }

      setResult({
        faceDetected,
        multipleFaces,
        lookingAway,
        eyesNotVisible,
        faceCount,
        confidence,
        landmarks,
        expressions,
      });

      if (newAlerts.length > 0) {
        setAlerts(newAlerts);
      }

    } catch (err) {
      console.error('Face detection error:', err);
    }
  }, [videoElement, isModelLoaded, enabled, checkLookingAway, checkEyesVisible]);

  // Start detection loop
  useEffect(() => {
    if (!isModelLoaded || !enabled || !videoElement) {
      return;
    }

    // Initial detection
    detectFace();

    // Set up interval
    detectionIntervalRef.current = setInterval(detectFace, detectionInterval);

    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, [isModelLoaded, enabled, videoElement, detectionInterval, detectFace]);

  // Clear alerts after some time
  useEffect(() => {
    if (alerts.length > 0) {
      const timeout = setTimeout(() => {
        setAlerts([]);
      }, 5000);
      return () => clearTimeout(timeout);
    }
  }, [alerts]);

  const resetAlerts = useCallback(() => {
    alertCountsRef.current = {
      noFace: 0,
      multipleFaces: 0,
      lookingAway: 0,
    };
    setAlerts([]);
  }, []);

  return {
    isModelLoaded,
    isLoading,
    error,
    result,
    alerts,
    resetAlerts,
    descriptor,
  };
}
