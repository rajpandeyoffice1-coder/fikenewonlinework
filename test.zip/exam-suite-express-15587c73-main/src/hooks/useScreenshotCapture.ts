import { useState, useCallback, useEffect, useRef } from 'react';

export interface CapturedScreenshot {
  id: string;
  timestamp: Date;
  imageData: string; // base64 data URL
  type: 'periodic' | 'incident' | 'manual';
  reason?: string;
}

interface UseScreenshotCaptureOptions {
  videoElement: HTMLVideoElement | null;
  enabled?: boolean;
  intervalMs?: number; // Interval for periodic captures
  maxScreenshots?: number; // Maximum screenshots to store
}

export function useScreenshotCapture({
  videoElement,
  enabled = true,
  intervalMs = 30000, // Default: every 30 seconds
  maxScreenshots = 50,
}: UseScreenshotCaptureOptions) {
  const [screenshots, setScreenshots] = useState<CapturedScreenshot[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Create canvas on mount
  useEffect(() => {
    canvasRef.current = document.createElement('canvas');
    return () => {
      canvasRef.current = null;
    };
  }, []);

  // Capture a single screenshot
  const captureScreenshot = useCallback(
    (type: CapturedScreenshot['type'] = 'manual', reason?: string): CapturedScreenshot | null => {
      if (!videoElement || !canvasRef.current) return null;
      if (videoElement.videoWidth === 0 || videoElement.videoHeight === 0) return null;

      const canvas = canvasRef.current;
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;

      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL('image/jpeg', 0.7); // Use JPEG with 70% quality

      const screenshot: CapturedScreenshot = {
        id: `screenshot-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date(),
        imageData,
        type,
        reason,
      };

      setScreenshots((prev) => {
        const updated = [...prev, screenshot];
        // Keep only the most recent screenshots
        if (updated.length > maxScreenshots) {
          return updated.slice(-maxScreenshots);
        }
        return updated;
      });

      return screenshot;
    },
    [videoElement, maxScreenshots]
  );

  // Capture screenshot on incident
  const captureIncidentScreenshot = useCallback(
    (reason: string) => {
      return captureScreenshot('incident', reason);
    },
    [captureScreenshot]
  );

  // Start periodic capture
  const startPeriodicCapture = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    setIsCapturing(true);

    // Capture immediately
    captureScreenshot('periodic');

    // Set up interval
    intervalRef.current = setInterval(() => {
      captureScreenshot('periodic');
    }, intervalMs);
  }, [captureScreenshot, intervalMs]);

  // Stop periodic capture
  const stopPeriodicCapture = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsCapturing(false);
  }, []);

  // Auto-start/stop based on enabled state and video availability
  useEffect(() => {
    if (enabled && videoElement && videoElement.readyState >= 2) {
      startPeriodicCapture();
    } else {
      stopPeriodicCapture();
    }

    return () => {
      stopPeriodicCapture();
    };
  }, [enabled, videoElement, startPeriodicCapture, stopPeriodicCapture]);

  // Listen for video ready state changes
  useEffect(() => {
    if (!videoElement) return;

    const handleCanPlay = () => {
      if (enabled) {
        startPeriodicCapture();
      }
    };

    videoElement.addEventListener('canplay', handleCanPlay);
    return () => {
      videoElement.removeEventListener('canplay', handleCanPlay);
    };
  }, [videoElement, enabled, startPeriodicCapture]);

  // Clear all screenshots
  const clearScreenshots = useCallback(() => {
    setScreenshots([]);
  }, []);

  // Get statistics
  const getStats = useCallback(() => {
    const periodicCount = screenshots.filter((s) => s.type === 'periodic').length;
    const incidentCount = screenshots.filter((s) => s.type === 'incident').length;
    const manualCount = screenshots.filter((s) => s.type === 'manual').length;

    return {
      total: screenshots.length,
      periodic: periodicCount,
      incident: incidentCount,
      manual: manualCount,
    };
  }, [screenshots]);

  return {
    screenshots,
    isCapturing,
    captureScreenshot,
    captureIncidentScreenshot,
    startPeriodicCapture,
    stopPeriodicCapture,
    clearScreenshots,
    getStats,
  };
}
