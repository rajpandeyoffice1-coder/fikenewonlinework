import { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { toast } from 'sonner';

interface DashboardStats {
  ongoingExams: number;
  upcomingExams: number;
  activeCandidates: number;
  flaggedIncidents: number;
  inProgressNow: number;
}

interface DailyActivity {
  day: string;
  exams: number;
  students: number;
}

interface DepartmentPassRate {
  dept: string;
  pass: number;
}

interface QuestionTypeDistribution {
  name: string;
  value: number;
  color: string;
}

interface ExamData {
  id: string;
  title: string;
  code: string;
  start_date: string | null;
  end_date: string | null;
  duration: number;
  status: string;
  department: string;
}

export function useDashboardData() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({
    ongoingExams: 0,
    upcomingExams: 0,
    activeCandidates: 0,
    flaggedIncidents: 0,
    inProgressNow: 0,
  });
  const [exams, setExams] = useState<ExamData[]>([]);
  const [dailyActivity, setDailyActivity] = useState<DailyActivity[]>([]);
  const [departmentPassRates, setDepartmentPassRates] = useState<DepartmentPassRate[]>([]);
  const [questionTypeDistribution, setQuestionTypeDistribution] = useState<QuestionTypeDistribution[]>([]);
  const [newIncidentCount, setNewIncidentCount] = useState(0);

  // Initial data fetch
  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Real-time subscriptions for live updates
  useEffect(() => {
    console.log('Setting up real-time subscriptions for dashboard...');

    // Subscribe to exam_sessions changes
    const sessionsChannel = supabase
      .channel('dashboard-sessions')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'exam_sessions'
        },
        (payload) => {
          console.log('Exam session change:', payload);
          // Update active candidates count
          updateActiveCandidates();
          
          if (payload.eventType === 'INSERT') {
            toast.info('New exam session started', {
              description: 'A student has started an exam'
            });
          }
        }
      )
      .subscribe();

    // Subscribe to proctoring_incidents changes
    const incidentsChannel = supabase
      .channel('dashboard-incidents')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'proctoring_incidents'
        },
        (payload) => {
          console.log('New incident:', payload);
          // Increment flagged incidents count
          setStats(prev => ({
            ...prev,
            flaggedIncidents: prev.flaggedIncidents + 1
          }));
          setNewIncidentCount(prev => prev + 1);
          
          const severity = (payload.new as any)?.severity || 'medium';
          toast.warning(`New ${severity} incident detected`, {
            description: (payload.new as any)?.message || 'Proctoring alert'
          });
        }
      )
      .subscribe();

    // Subscribe to exams changes
    const examsChannel = supabase
      .channel('dashboard-exams')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'exams'
        },
        (payload) => {
          console.log('Exam change:', payload);
          // Refresh exams data
          fetchExamsData();
        }
      )
      .subscribe();

    return () => {
      console.log('Cleaning up real-time subscriptions...');
      supabase.removeChannel(sessionsChannel);
      supabase.removeChannel(incidentsChannel);
      supabase.removeChannel(examsChannel);
    };
  }, []);

  // Helper function to update active candidates count
  const updateActiveCandidates = useCallback(async () => {
    const { count: activeSessions } = await supabase
      .from('exam_sessions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'in_progress');

    const { count: inProgress } = await supabase
      .from('exam_sessions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'in_progress');

    setStats(prev => ({
      ...prev,
      activeCandidates: activeSessions || 0,
      inProgressNow: inProgress || 0,
    }));
  }, []);

  // Helper function to fetch exams data only
  const fetchExamsData = useCallback(async () => {
    const now = new Date();
    
    const { data: examsData } = await supabase
      .from('exams')
      .select('*')
      .order('start_date', { ascending: true });

    if (examsData) {
      setExams(examsData);

      const ongoing = examsData.filter(e => 
        e.status === 'ongoing' || 
        (e.status === 'scheduled' && e.start_date && new Date(e.start_date) <= now && e.end_date && new Date(e.end_date) >= now)
      ).length;

      const upcoming = examsData.filter(e => 
        e.status === 'scheduled' && e.start_date && new Date(e.start_date) > now
      ).length;

      setStats(prev => ({
        ...prev,
        ongoingExams: ongoing,
        upcomingExams: upcoming,
      }));
    }
  }, []);

  async function fetchDashboardData() {
    setLoading(true);
    try {
      const now = new Date();
      const nowISO = now.toISOString();

      // Fetch all exams
      const { data: examsData, error: examsError } = await supabase
        .from('exams')
        .select('*')
        .order('start_date', { ascending: true });

      if (examsError) throw examsError;

      setExams(examsData || []);

      // Calculate stats
      const ongoing = examsData?.filter(e => 
        e.status === 'ongoing' || 
        (e.status === 'scheduled' && e.start_date && new Date(e.start_date) <= now && e.end_date && new Date(e.end_date) >= now)
      ).length || 0;

      const upcoming = examsData?.filter(e => 
        e.status === 'scheduled' && e.start_date && new Date(e.start_date) > now
      ).length || 0;

      // Count active exam sessions (in_progress)
      const { count: activeSessions } = await supabase
        .from('exam_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'in_progress');

      // Count flagged incidents today
      const todayStart = startOfDay(now).toISOString();
      const todayEnd = endOfDay(now).toISOString();
      
      const { count: incidentsToday } = await supabase
        .from('proctoring_incidents')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', todayStart)
        .lte('created_at', todayEnd);

      // Count in-progress exam sessions
      const { count: inProgress } = await supabase
        .from('exam_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'in_progress');

      setStats({
        ongoingExams: ongoing,
        upcomingExams: upcoming,
        activeCandidates: activeSessions || 0,
        flaggedIncidents: incidentsToday || 0,
        inProgressNow: inProgress || 0,
      });

      // Fetch daily activity for last 7 days
      const dailyData: DailyActivity[] = [];
      for (let i = 6; i >= 0; i--) {
        const date = subDays(now, i);
        const dayStart = startOfDay(date).toISOString();
        const dayEnd = endOfDay(date).toISOString();
        const dayName = format(date, 'EEE');

        const { count: examsCount } = await supabase
          .from('exams')
          .select('*', { count: 'exact', head: true })
          .gte('start_date', dayStart)
          .lte('start_date', dayEnd);

        const { count: studentsCount } = await supabase
          .from('exam_sessions')
          .select('*', { count: 'exact', head: true })
          .gte('started_at', dayStart)
          .lte('started_at', dayEnd);

        dailyData.push({
          day: dayName,
          exams: examsCount || 0,
          students: studentsCount || 0,
        });
      }
      setDailyActivity(dailyData);

      // Fetch department-wise pass rates
      const { data: resultsData } = await supabase
        .from('exam_results')
        .select(`
          status,
          exam_id,
          exams!inner(department)
        `);

      // Group by department and calculate pass rates
      const deptStats: Record<string, { pass: number; total: number }> = {};
      resultsData?.forEach((result: any) => {
        const dept = result.exams?.department || 'Unknown';
        if (!deptStats[dept]) {
          deptStats[dept] = { pass: 0, total: 0 };
        }
        deptStats[dept].total++;
        if (result.status === 'passed') {
          deptStats[dept].pass++;
        }
      });

      const passRates = Object.entries(deptStats).map(([dept, data]) => ({
        dept,
        pass: data.total > 0 ? Math.round((data.pass / data.total) * 100) : 0,
      })).slice(0, 5);

      setDepartmentPassRates(passRates.length > 0 ? passRates : [
        { dept: 'CSE', pass: 0 },
        { dept: 'ECE', pass: 0 },
        { dept: 'ME', pass: 0 },
      ]);

      // Fetch question type distribution
      const { data: questionsData } = await supabase
        .from('questions')
        .select('type');

      const typeCounts: Record<string, number> = {};
      questionsData?.forEach(q => {
        const type = q.type || 'unknown';
        typeCounts[type] = (typeCounts[type] || 0) + 1;
      });

      const total = Object.values(typeCounts).reduce((a, b) => a + b, 0);
      const colors: Record<string, string> = {
        'mcq-single': 'hsl(221, 83%, 53%)',
        'mcq-multiple': 'hsl(262, 83%, 58%)',
        'true-false': 'hsl(142, 71%, 45%)',
        'short-answer': 'hsl(38, 92%, 50%)',
        'long-answer': 'hsl(0, 84%, 60%)',
        'code': 'hsl(199, 89%, 48%)',
        'file-upload': 'hsl(340, 82%, 52%)',
      };

      const typeDistribution = Object.entries(typeCounts).map(([type, count]) => ({
        name: type.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        value: total > 0 ? Math.round((count / total) * 100) : 0,
        color: colors[type] || 'hsl(220, 14%, 46%)',
      }));

      setQuestionTypeDistribution(typeDistribution.length > 0 ? typeDistribution : [
        { name: 'MCQ', value: 0, color: 'hsl(221, 83%, 53%)' },
      ]);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  const upcomingExams = useMemo(() => {
    const now = new Date();
    return exams
      .filter(e => e.start_date && new Date(e.start_date) > now)
      .slice(0, 10);
  }, [exams]);

  const clearNewIncidentCount = useCallback(() => {
    setNewIncidentCount(0);
  }, []);

  return {
    loading,
    stats,
    exams,
    upcomingExams,
    dailyActivity,
    departmentPassRates,
    questionTypeDistribution,
    newIncidentCount,
    clearNewIncidentCount,
    refetch: fetchDashboardData,
  };
}
