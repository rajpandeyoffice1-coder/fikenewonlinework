import { useCallback, useRef } from 'react';

export function useAudioAlert() {
  const audioContextRef = useRef<AudioContext | null>(null);

  const playAlert = useCallback((severity: 'low' | 'medium' | 'high' = 'high') => {
    try {
      // Create or reuse AudioContext
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContextRef.current;
      
      // Resume context if suspended (browser autoplay policy)
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      // Different sounds based on severity
      if (severity === 'high') {
        // Urgent alert: rapid beeps at higher frequency
        oscillator.frequency.setValueAtTime(880, ctx.currentTime); // A5
        oscillator.type = 'square';
        gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
        
        // Create pulsing effect
        for (let i = 0; i < 3; i++) {
          const startTime = ctx.currentTime + i * 0.2;
          gainNode.gain.setValueAtTime(0.3, startTime);
          gainNode.gain.setValueAtTime(0, startTime + 0.1);
        }
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.6);
      } else if (severity === 'medium') {
        // Warning: two medium beeps
        oscillator.frequency.setValueAtTime(660, ctx.currentTime); // E5
        oscillator.type = 'sine';
        gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
        gainNode.gain.setValueAtTime(0, ctx.currentTime + 0.15);
        gainNode.gain.setValueAtTime(0.2, ctx.currentTime + 0.25);
        gainNode.gain.setValueAtTime(0, ctx.currentTime + 0.4);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.4);
      } else {
        // Low: single soft beep
        oscillator.frequency.setValueAtTime(440, ctx.currentTime); // A4
        oscillator.type = 'sine';
        gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.2);
      }
    } catch (error) {
      console.error('Error playing audio alert:', error);
    }
  }, []);

  return { playAlert };
}
