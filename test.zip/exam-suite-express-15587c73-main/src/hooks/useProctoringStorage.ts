import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { CapturedScreenshot } from './useScreenshotCapture';

interface SaveScreenshotParams {
  sessionId: string;
  studentId: string;
  screenshot: CapturedScreenshot;
}

interface ProctoringScreenshot {
  id: string;
  session_id: string;
  student_id: string;
  screenshot_url: string;
  capture_type: string;
  reason: string | null;
  timestamp: string;
  created_at: string;
}

interface ProctoringIncident {
  id: string;
  session_id: string;
  student_id: string;
  incident_type: string;
  severity: string;
  message: string;
  details?: any;
  screenshot_id?: string;
  timestamp: string;
}

interface SaveIncidentParams {
  sessionId: string;
  studentId: string;
  incidentType: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
  details?: any;
  screenshotId?: string;
}

export function useProctoringStorage() {
  // Convert base64 to blob
  const base64ToBlob = (base64: string): Blob => {
    const parts = base64.split(';base64,');
    const contentType = parts[0].split(':')[1] || 'image/jpeg';
    const raw = window.atob(parts[1]);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);

    for (let i = 0; i < rawLength; ++i) {
      uInt8Array[i] = raw.charCodeAt(i);
    }

    return new Blob([uInt8Array], { type: contentType });
  };

  // Save a single screenshot to storage and database
  const saveScreenshot = useCallback(async ({
    sessionId,
    studentId,
    screenshot,
  }: SaveScreenshotParams): Promise<{ success: boolean; error?: string }> => {
    try {
      // Get current user for storage path
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return { success: false, error: 'User not authenticated' };
      }

      // Convert base64 to blob
      const blob = base64ToBlob(screenshot.imageData);
      const fileName = `${screenshot.id}.jpg`;
      const filePath = `${user.id}/${sessionId}/${fileName}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('proctoring-screenshots')
        .upload(filePath, blob, {
          contentType: 'image/jpeg',
          upsert: false,
        });

      if (uploadError) {
        console.error('Screenshot upload error:', uploadError);
        return { success: false, error: uploadError.message };
      }

      // Get public URL (or signed URL for private bucket)
      const { data: urlData } = supabase.storage
        .from('proctoring-screenshots')
        .getPublicUrl(filePath);

      // Insert record into database
      const { error: dbError } = await supabase
        .from('proctoring_screenshots')
        .insert({
          session_id: sessionId,
          student_id: studentId,
          screenshot_url: urlData.publicUrl || filePath,
          capture_type: screenshot.type,
          reason: screenshot.reason || null,
          timestamp: screenshot.timestamp.toISOString(),
        });

      if (dbError) {
        console.error('Screenshot DB insert error:', dbError);
        return { success: false, error: dbError.message };
      }

      console.log('Screenshot saved:', screenshot.id);
      return { success: true };
    } catch (err) {
      console.error('Save screenshot error:', err);
      return { success: false, error: 'Failed to save screenshot' };
    }
  }, []);

  // Save multiple screenshots (batch) - PARALLEL upload for speed
  const saveAllScreenshots = useCallback(async (
    sessionId: string,
    studentId: string,
    screenshots: CapturedScreenshot[]
  ): Promise<{ saved: number; failed: number }> => {
    if (screenshots.length === 0) {
      return { saved: 0, failed: 0 };
    }

    // Upload all screenshots in parallel for much faster completion
    const results = await Promise.allSettled(
      screenshots.map(screenshot => 
        saveScreenshot({ sessionId, studentId, screenshot })
      )
    );

    const saved = results.filter(r => r.status === 'fulfilled' && r.value.success).length;
    const failed = results.length - saved;

    return { saved, failed };
  }, [saveScreenshot]);

  // Save screenshots in background (fire-and-forget)
  const saveAllScreenshotsBackground = useCallback((
    sessionId: string,
    studentId: string,
    screenshots: CapturedScreenshot[]
  ): void => {
    if (screenshots.length === 0) return;
    
    // Fire and forget - don't await
    Promise.allSettled(
      screenshots.map(screenshot => 
        saveScreenshot({ sessionId, studentId, screenshot })
      )
    ).then(results => {
      const saved = results.filter(r => r.status === 'fulfilled' && r.value.success).length;
      console.log(`Background upload complete: ${saved}/${screenshots.length} screenshots saved`);
    }).catch(err => {
      console.error('Background screenshot upload error:', err);
    });
  }, [saveScreenshot]);

  // Fetch screenshots for a session (for reports)
  const getSessionScreenshots = useCallback(async (
    sessionId: string
  ): Promise<ProctoringScreenshot[]> => {
    const { data, error } = await supabase
      .from('proctoring_screenshots')
      .select('*')
      .eq('session_id', sessionId)
      .order('timestamp', { ascending: true });

    if (error) {
      console.error('Fetch screenshots error:', error);
      return [];
    }

    return data || [];
  }, []);

  // Get signed URL for a screenshot (for private bucket)
  const getSignedUrl = useCallback(async (filePath: string): Promise<string | null> => {
    const { data, error } = await supabase.storage
      .from('proctoring-screenshots')
      .createSignedUrl(filePath, 3600); // 1 hour expiry

    if (error) {
      console.error('Get signed URL error:', error);
      return null;
    }

    return data.signedUrl;
  }, []);

  // Save a proctoring incident
  const saveIncident = useCallback(async ({
    sessionId,
    studentId,
    incidentType,
    severity,
    message,
    details,
    screenshotId,
  }: SaveIncidentParams): Promise<{ success: boolean; id?: string; error?: string }> => {
    try {
      const { data, error } = await supabase
        .from('proctoring_incidents')
        .insert({
          session_id: sessionId,
          student_id: studentId,
          incident_type: incidentType,
          severity,
          message,
          details,
          screenshot_id: screenshotId,
        })
        .select('id')
        .single();

      if (error) {
        console.error('Save incident error:', error);
        return { success: false, error: error.message };
      }

      return { success: true, id: data.id };
    } catch (err) {
      console.error('Save incident error:', err);
      return { success: false, error: 'Failed to save incident' };
    }
  }, []);

  // Fetch incidents for a session
  const getSessionIncidents = useCallback(async (
    sessionId: string
  ): Promise<ProctoringIncident[]> => {
    const { data, error } = await supabase
      .from('proctoring_incidents')
      .select('*')
      .eq('session_id', sessionId)
      .order('timestamp', { ascending: true });

    if (error) {
      console.error('Fetch incidents error:', error);
      return [];
    }

    return data || [];
  }, []);

  return {
    saveScreenshot,
    saveAllScreenshots,
    saveAllScreenshotsBackground,
    getSessionScreenshots,
    getSignedUrl,
    saveIncident,
    getSessionIncidents,
  };
}
