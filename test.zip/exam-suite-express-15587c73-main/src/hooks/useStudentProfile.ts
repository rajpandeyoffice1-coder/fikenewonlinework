import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface StudentProfile {
  id: string;
  fullName: string;
  name: string;
  rollNumber: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: number;
  photoUrl?: string;
  status: string;
}

interface UseStudentProfileReturn {
  profile: StudentProfile | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useStudentProfile(): UseStudentProfileReturn {
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Get current user session
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.email) {
        setError('Please log in to view your profile');
        setIsLoading(false);
        return;
      }

      // Fetch student profile by email
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('email', session.user.email)
        .maybeSingle();

      if (studentError) {
        console.error('Error fetching student profile:', studentError);
        setError('Failed to load profile');
        setIsLoading(false);
        return;
      }

      if (!student) {
        setError('Student profile not found');
        setIsLoading(false);
        return;
      }

      setProfile({
        id: student.id,
        fullName: student.full_name,
        name: student.full_name,
        rollNumber: student.roll_no,
        email: student.email,
        mobile: student.mobile,
        department: student.department,
        course: student.course,
        semester: student.semester,
        photoUrl: student.photo_url || undefined,
        status: student.status,
      });
    } catch (err) {
      console.error('Error fetching student profile:', err);
      setError('Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  return {
    profile,
    isLoading,
    error,
    refetch: fetchProfile,
  };
}

// Helper function to get initials from a name
export function getInitials(name: string): string {
  if (!name) return '??';
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}
