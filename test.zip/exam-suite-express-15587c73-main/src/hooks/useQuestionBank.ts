import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface QuestionOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface QuestionFromDB {
  id: string;
  question_text: string;
  type: string;
  subject: string;
  difficulty: string;
  marks: number;
  negative_marks: number | null;
  options: QuestionOption[] | null;
  correct_answer: string | null;
  tags: string[] | null;
  media_url: string | null;
  folder_id: string | null;
  created_at: string;
}

// DB to TS type mapping
const DB_TO_TS_TYPE: Record<string, string> = {
  'mcq-single': 'mcq_single',
  'mcq-multiple': 'mcq_multiple',
  'true-false': 'true_false',
  'short-answer': 'short_answer',
  'long-answer': 'long_answer',
  'code': 'coding',
  'file-upload': 'file_upload',
};

// Normalize DB type (hyphens) to TS type (underscores)
const normalizeType = (dbType: string): string => {
  return DB_TO_TS_TYPE[dbType] || dbType?.replace(/-/g, '_') || 'mcq_single';
};

export function useQuestionBank(subjectFilter?: string) {
  const { user } = useAuth();
  const [questions, setQuestions] = useState<QuestionFromDB[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchQuestions = useCallback(async (subject?: string) => {
    if (!user) return;
    
    setIsLoading(true);
    setError(null);

    let query = supabase
      .from("questions")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (subject) {
      query = query.ilike("subject", `%${subject}%`);
    }

    const { data, error } = await query;

    if (error) {
      setError(error.message);
      console.error("Error fetching questions:", error);
    } else {
      // Parse options from JSON if needed and normalize type
      const parsedData = (data || []).map((q) => ({
        ...q,
        type: normalizeType(q.type),
        options: q.options ? (Array.isArray(q.options) ? q.options : JSON.parse(q.options as string)) : null,
      }));
      setQuestions(parsedData as QuestionFromDB[]);
    }
    setIsLoading(false);
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchQuestions(subjectFilter);
    }
  }, [user, subjectFilter, fetchQuestions]);

  return {
    questions,
    isLoading,
    error,
    refetch: fetchQuestions,
  };
}
