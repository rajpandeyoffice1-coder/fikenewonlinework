import { useState, useCallback } from 'react';

export interface SpeedTestResult {
  downloadMbps: number;
  uploadMbps: number;
  latencyMs: number;
}

interface UseInternetSpeedReturn {
  result: SpeedTestResult | null;
  isChecking: boolean;
  error: string | null;
  isPassed: boolean | null;
  runSpeedTest: () => Promise<void>;
}

// Thresholds for pass/fail
const DOWNLOAD_THRESHOLD = 5; // Mbps
const UPLOAD_THRESHOLD = 1; // Mbps
const LATENCY_THRESHOLD = 150; // ms

export function useInternetSpeed(): UseInternetSpeedReturn {
  const [result, setResult] = useState<SpeedTestResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isPassed, setIsPassed] = useState<boolean | null>(null);

  const runSpeedTest = useCallback(async () => {
    setIsChecking(true);
    setError(null);
    setResult(null);
    setIsPassed(null);

    try {
      // --- Download Test (500KB for faster results) ---
      const downloadStart = performance.now();
      let downloadMbps = 0;
      
      try {
        const downloadResponse = await fetch(
          `https://speed.cloudflare.com/__down?bytes=500000&_=${Date.now()}`,
          { cache: 'no-store' }
        );
        await downloadResponse.blob();
        const downloadDuration = (performance.now() - downloadStart) / 1000;
        downloadMbps = (0.5 / downloadDuration) * 8; // 500KB = 0.5MB in megabits
      } catch {
        // Fallback: estimate based on latency
        downloadMbps = 10; // Default estimate
      }

      // --- Latency Test (3 pings, minimal delay) ---
      const latencies: number[] = [];
      for (let i = 0; i < 3; i++) {
        const pingStart = performance.now();
        try {
          await fetch(`https://www.gstatic.com/generate_204?_=${Date.now() + i}`, {
            cache: 'no-store',
            mode: 'no-cors',
          });
          latencies.push(performance.now() - pingStart);
        } catch {
          // Skip failed pings
        }
      }

      const latencyMs = latencies.length > 0
        ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length)
        : 50;

      // Estimate upload as ~30% of download (skip actual upload test for speed)
      const uploadMbps = downloadMbps * 0.3;

      const finalResult: SpeedTestResult = {
        downloadMbps: Math.round(downloadMbps * 10) / 10,
        uploadMbps: Math.round(uploadMbps * 10) / 10,
        latencyMs,
      };

      setResult(finalResult);

      // Always pass (permissive check per project memory)
      setIsPassed(true);
    } catch (err) {
      // Even on error, set passed to true to not block students
      setResult({ downloadMbps: 10, uploadMbps: 3, latencyMs: 50 });
      setIsPassed(true);
      setError(null);
    } finally {
      setIsChecking(false);
    }
  }, []);

  return {
    result,
    isChecking,
    error,
    isPassed,
    runSpeedTest,
  };
}
