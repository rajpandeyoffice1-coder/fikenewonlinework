import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export type UserRole = 'admin' | 'student' | 'proctor' | 'evaluator';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  role: UserRole | null;
  isLoading: boolean;
  signIn: (identifier: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch user role from user_roles table - optimized for speed
  const fetchUserRole = async (userId: string, userEmail?: string): Promise<UserRole | null> => {
    try {
      // Query user_roles table - this should be the primary source
      const { data, error } = await (supabase
        .from('user_roles') as any)
        .select('role')
        .eq('user_id', userId)
        .maybeSingle();

      if (!error && data?.role) {
        return data.role as UserRole;
      }

      // Fallback: Check if this is a student by email (only if email provided)
      if (userEmail) {
        const { data: student } = await supabase
          .from('students')
          .select('id')
          .eq('email', userEmail)
          .maybeSingle();
        
        if (student) {
          return 'student';
        }
      }
      
      return null;
    } catch (error) {
      console.log('Role fetch error, defaulting to null:', error);
      return null;
    }
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Defer role fetching with setTimeout to avoid deadlock
        if (session?.user) {
          setTimeout(() => {
            fetchUserRole(session.user.id, session.user.email).then(setRole);
          }, 0);
        } else {
          setRole(null);
        }
        
        setIsLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchUserRole(session.user.id, session.user.email).then(setRole);
      }
      
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (identifier: string, password: string): Promise<{ error: string | null }> => {
    try {
      // Check if identifier is an email or roll number
      let email = identifier;
      
      // If not an email format, assume it's a roll number and look up the email
      if (!identifier.includes('@')) {
        const { data: student, error: studentError } = await supabase
          .from('students')
          .select('email, status')
          .eq('roll_no', identifier)
          .single();
        
        if (studentError || !student) {
          return { error: 'Invalid credentials. Please check your email/roll number or password.' };
        }
        
        if (student.status === 'inactive') {
          return { error: 'Your account is disabled. Contact administrator.' };
        }
        
        email = student.email;
      }

      // Attempt sign in with Supabase Auth
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        if (error.message.includes('Invalid login credentials')) {
          return { error: 'Invalid credentials. Please check your email/roll number or password.' };
        }
        return { error: error.message };
      }

      if (data.user) {
        const userRole = await fetchUserRole(data.user.id, data.user.email);
        setRole(userRole);
        
        // Update last_login for students
        if (userRole === 'student') {
          await supabase
            .from('students')
            .update({ last_login: new Date().toISOString() })
            .eq('email', email);
        }
      }

      return { error: null };
    } catch (error) {
      console.error('Sign in error:', error);
      return { error: 'An unexpected error occurred. Please try again.' };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setRole(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        role,
        isLoading,
        signIn,
        signOut,
        isAuthenticated: !!session,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Helper function to get redirect path based on role
export function getRedirectPath(role: UserRole | null): string {
  switch (role) {
    case 'admin':
      return '/admin/dashboard';
    case 'student':
      return '/student/dashboard';
    case 'proctor':
      return '/proctor-portal';
    case 'evaluator':
      return '/evaluator-portal';
    default:
      return '/login';
  }
}
