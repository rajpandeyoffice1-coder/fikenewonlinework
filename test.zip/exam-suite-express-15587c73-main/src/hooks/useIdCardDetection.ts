import { useState, useEffect, useCallback, useRef } from 'react';

export interface IdCardDetectionResult {
  cardDetected: boolean;
  confidence: number;
  isBlurry: boolean;
  message: string;
}

interface UseIdCardDetectionOptions {
  videoElement: HTMLVideoElement | null;
  enabled?: boolean;
  detectionInterval?: number;
}

export function useIdCardDetection({
  videoElement,
  enabled = true,
  detectionInterval = 500,
}: UseIdCardDetectionOptions) {
  const [result, setResult] = useState<IdCardDetectionResult>({
    cardDetected: false,
    confidence: 0,
    isBlurry: false,
    message: 'Position ID card in frame',
  });
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Detect edges and rectangular shapes in the frame
  const detectIdCard = useCallback(() => {
    if (!videoElement || !enabled) return;
    
    if (!canvasRef.current) {
      canvasRef.current = document.createElement('canvas');
    }
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = videoElement.videoWidth || 640;
    canvas.height = videoElement.videoHeight || 480;
    
    if (canvas.width === 0 || canvas.height === 0) return;

    // Draw video frame to canvas
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    // Get image data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // Calculate image statistics
    let totalBrightness = 0;
    let totalVariance = 0;
    let edgeCount = 0;
    let whitePixels = 0;
    let significantPixels = 0;
    
    const brightnessValues: number[] = [];
    
    // Sample every 4th pixel for performance
    for (let i = 0; i < data.length; i += 16) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const brightness = (r + g + b) / 3;
      brightnessValues.push(brightness);
      totalBrightness += brightness;
      
      // Count white/light pixels (potential card surface)
      if (brightness > 200) {
        whitePixels++;
      }
      
      // Count significant (non-uniform) pixels
      const saturation = Math.max(r, g, b) - Math.min(r, g, b);
      if (saturation > 20 || (brightness > 50 && brightness < 230)) {
        significantPixels++;
      }
    }
    
    const avgBrightness = totalBrightness / brightnessValues.length;
    
    // Calculate variance (for blur detection)
    for (const b of brightnessValues) {
      totalVariance += Math.pow(b - avgBrightness, 2);
    }
    const variance = totalVariance / brightnessValues.length;
    
    // Detect edges using simple gradient
    const width = canvas.width;
    for (let y = 1; y < canvas.height - 1; y += 4) {
      for (let x = 1; x < width - 1; x += 4) {
        const idx = (y * width + x) * 4;
        const idxRight = (y * width + x + 1) * 4;
        const idxDown = ((y + 1) * width + x) * 4;
        
        const gx = Math.abs(data[idx] - data[idxRight]) + 
                   Math.abs(data[idx + 1] - data[idxRight + 1]) +
                   Math.abs(data[idx + 2] - data[idxRight + 2]);
        const gy = Math.abs(data[idx] - data[idxDown]) +
                   Math.abs(data[idx + 1] - data[idxDown + 1]) +
                   Math.abs(data[idx + 2] - data[idxDown + 2]);
        
        const gradient = gx + gy;
        if (gradient > 100) {
          edgeCount++;
        }
      }
    }
    
    // Calculate metrics
    const totalSampledPixels = brightnessValues.length;
    const whiteRatio = whitePixels / totalSampledPixels;
    const significantRatio = significantPixels / totalSampledPixels;
    const edgeRatio = edgeCount / (canvas.width * canvas.height / 16);
    
    // Determine if card is detected
    // Card characteristics:
    // - Has some white/light areas (card surface)
    // - Has distinct edges (card borders, text)
    // - Not too uniform (not blank frame)
    // - Sufficient variance (not blurry)
    
    const hasWhiteArea = whiteRatio > 0.05 && whiteRatio < 0.8;
    const hasEdges = edgeRatio > 0.02;
    const hasContent = significantRatio > 0.3;
    const isNotBlurry = variance > 500;
    
    // Calculate confidence
    let confidence = 0;
    if (hasWhiteArea) confidence += 25;
    if (hasEdges) confidence += 35;
    if (hasContent) confidence += 25;
    if (isNotBlurry) confidence += 15;
    
    // Determine detection result
    const cardDetected = confidence >= 60;
    const isBlurry = !isNotBlurry;
    
    let message = 'Position ID card in frame';
    if (cardDetected) {
      message = 'ID card detected - Ready to capture';
    } else if (isBlurry) {
      message = 'Image is blurry - Hold steady';
    } else if (!hasEdges) {
      message = 'No card detected - Position ID in frame';
    } else if (!hasContent) {
      message = 'Frame appears empty';
    }
    
    setResult({
      cardDetected,
      confidence,
      isBlurry,
      message,
    });
  }, [videoElement, enabled]);

  // Start detection loop
  useEffect(() => {
    if (!enabled || !videoElement) {
      return;
    }

    // Initial detection after a short delay
    const initialTimeout = setTimeout(detectIdCard, 300);

    // Set up interval
    detectionIntervalRef.current = setInterval(detectIdCard, detectionInterval);

    return () => {
      clearTimeout(initialTimeout);
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, [enabled, videoElement, detectionInterval, detectIdCard]);

  // Reset when disabled
  useEffect(() => {
    if (!enabled) {
      setResult({
        cardDetected: false,
        confidence: 0,
        isBlurry: false,
        message: 'Position ID card in frame',
      });
    }
  }, [enabled]);

  return {
    result,
    detectIdCard,
  };
}
