import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAudioAlert } from './useAudioAlert';

export interface RealtimeIncident {
  id: string;
  session_id: string;
  student_id: string;
  incident_type: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
  details?: any;
  screenshot_id?: string;
  timestamp: string;
  created_at: string;
  // Joined data
  student_name?: string;
  exam_title?: string;
}

interface UseRealtimeIncidentsOptions {
  enabled?: boolean;
  showToasts?: boolean;
  audioAlerts?: boolean; // Enable audio alerts for incidents
  sessionIds?: string[]; // Optional filter by specific sessions
}

export function useRealtimeIncidents(options: UseRealtimeIncidentsOptions = {}) {
  const { enabled = true, showToasts = true, audioAlerts = true, sessionIds } = options;
  const [incidents, setIncidents] = useState<RealtimeIncident[]>([]);
  const [newIncidentCount, setNewIncidentCount] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const { playAlert } = useAudioAlert();

  // Fetch initial incidents
  const fetchIncidents = useCallback(async () => {
    let query = supabase
      .from('proctoring_incidents')
      .select(`
        *,
        students!inner(full_name),
        exam_sessions!inner(exam_id, exams!inner(title))
      `)
      .order('timestamp', { ascending: false })
      .limit(50);

    if (sessionIds && sessionIds.length > 0) {
      query = query.in('session_id', sessionIds);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching incidents:', error);
      return;
    }

    const mappedIncidents: RealtimeIncident[] = (data || []).map((incident: any) => ({
      ...incident,
      student_name: incident.students?.full_name,
      exam_title: incident.exam_sessions?.exams?.title,
    }));

    setIncidents(mappedIncidents);
  }, [sessionIds]);

  // Handle new incident from realtime subscription
  const handleNewIncident = useCallback(async (payload: any) => {
    console.log('New incident received:', payload);
    
    const newIncident = payload.new as RealtimeIncident;
    
    // Fetch additional details (student name, exam title)
    const { data: details } = await supabase
      .from('proctoring_incidents')
      .select(`
        *,
        students!inner(full_name),
        exam_sessions!inner(exam_id, exams!inner(title))
      `)
      .eq('id', newIncident.id)
      .single();

    if (details) {
      const enrichedIncident: RealtimeIncident = {
        ...details,
        severity: details.severity as 'low' | 'medium' | 'high',
        student_name: (details as any).students?.full_name,
        exam_title: (details as any).exam_sessions?.exams?.title,
      };

      setIncidents(prev => [enrichedIncident, ...prev]);
      setNewIncidentCount(prev => prev + 1);

      // Play audio alert for incidents
      if (audioAlerts) {
        playAlert(enrichedIncident.severity);
      }

      // Show toast notification
      if (showToasts) {
        const severityColors = {
          high: 'error',
          medium: 'warning',
          low: 'info',
        } as const;

        const toastFn = severityColors[enrichedIncident.severity] === 'error' 
          ? toast.error 
          : severityColors[enrichedIncident.severity] === 'warning'
          ? toast.warning
          : toast.info;

        toastFn(`🚨 ${enrichedIncident.incident_type.replace(/_/g, ' ').toUpperCase()}`, {
          description: `${enrichedIncident.student_name || 'Unknown Student'}: ${enrichedIncident.message}`,
          duration: enrichedIncident.severity === 'high' ? 10000 : 5000,
        });
      }
    }
  }, [showToasts, audioAlerts, playAlert]);

  // Clear new incident count
  const clearNewCount = useCallback(() => {
    setNewIncidentCount(0);
  }, []);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!enabled) return;

    fetchIncidents();

    const channel = supabase
      .channel('proctoring-incidents-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'proctoring_incidents',
        },
        handleNewIncident
      )
      .subscribe((status) => {
        console.log('Realtime subscription status:', status);
        setIsConnected(status === 'SUBSCRIBED');
      });

    return () => {
      console.log('Unsubscribing from realtime incidents');
      supabase.removeChannel(channel);
    };
  }, [enabled, fetchIncidents, handleNewIncident]);

  return {
    incidents,
    newIncidentCount,
    isConnected,
    clearNewCount,
    refetch: fetchIncidents,
  };
}
