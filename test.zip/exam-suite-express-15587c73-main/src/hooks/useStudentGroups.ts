import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StudentGroup, StudentGroupMember } from "@/types/studentGroup";
import { toast } from "sonner";

export function useStudentGroups() {
  const [groups, setGroups] = useState<StudentGroup[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchGroups = useCallback(async () => {
    try {
      setLoading(true);
      const { data: groupsData, error: groupsError } = await supabase
        .from("student_groups")
        .select("*")
        .order("created_at", { ascending: false });

      if (groupsError) throw groupsError;

      // Fetch member counts for each group
      const groupsWithCounts = await Promise.all(
        (groupsData || []).map(async (group) => {
          const { count } = await supabase
            .from("student_group_members")
            .select("*", { count: "exact", head: true })
            .eq("group_id", group.id);
          return { ...group, member_count: count || 0 };
        })
      );

      setGroups(groupsWithCounts);
    } catch (error) {
      console.error("Error fetching groups:", error);
      toast.error("Failed to load student groups");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchGroups();
  }, [fetchGroups]);

  const createGroup = async (groupData: Partial<StudentGroup>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("student_groups")
        .insert({
          group_name: groupData.group_name,
          group_code: groupData.group_code,
          department: groupData.department,
          semester: groupData.semester,
          description: groupData.description,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      await fetchGroups();
      toast.success("Student group created successfully");
      return data;
    } catch (error: any) {
      console.error("Error creating group:", error);
      if (error.code === "23505") {
        toast.error("Group code already exists");
      } else {
        toast.error("Failed to create student group");
      }
      throw error;
    }
  };

  const updateGroup = async (id: string, groupData: Partial<StudentGroup>) => {
    try {
      const { error } = await supabase
        .from("student_groups")
        .update({
          group_name: groupData.group_name,
          group_code: groupData.group_code,
          department: groupData.department,
          semester: groupData.semester,
          description: groupData.description,
        })
        .eq("id", id);

      if (error) throw error;
      await fetchGroups();
      toast.success("Student group updated successfully");
    } catch (error: any) {
      console.error("Error updating group:", error);
      if (error.code === "23505") {
        toast.error("Group code already exists");
      } else {
        toast.error("Failed to update student group");
      }
      throw error;
    }
  };

  const deleteGroup = async (id: string) => {
    try {
      // First delete all members
      await supabase
        .from("student_group_members")
        .delete()
        .eq("group_id", id);

      const { error } = await supabase
        .from("student_groups")
        .delete()
        .eq("id", id);

      if (error) throw error;
      await fetchGroups();
      toast.success("Student group deleted successfully");
    } catch (error) {
      console.error("Error deleting group:", error);
      toast.error("Failed to delete student group");
      throw error;
    }
  };

  const getGroupMembers = async (groupId: string): Promise<StudentGroupMember[]> => {
    try {
      const { data, error } = await supabase
        .from("student_group_members")
        .select(`
          *,
          student:students(id, full_name, roll_no, email, department, semester)
        `)
        .eq("group_id", groupId);

      if (error) throw error;
      return (data || []).map((item: any) => ({
        ...item,
        student: item.student,
      }));
    } catch (error) {
      console.error("Error fetching group members:", error);
      toast.error("Failed to load group members");
      return [];
    }
  };

  const addMembersToGroup = async (groupId: string, studentIds: string[]) => {
    try {
      const insertData = studentIds.map((studentId) => ({
        group_id: groupId,
        student_id: studentId,
      }));

      const { error } = await supabase
        .from("student_group_members")
        .insert(insertData);

      if (error) throw error;
      await fetchGroups();
      toast.success(`${studentIds.length} student(s) added to group`);
    } catch (error: any) {
      console.error("Error adding members:", error);
      if (error.code === "23505") {
        toast.error("Some students are already in this group");
      } else {
        toast.error("Failed to add students to group");
      }
      throw error;
    }
  };

  const removeMemberFromGroup = async (groupId: string, studentId: string) => {
    try {
      const { error } = await supabase
        .from("student_group_members")
        .delete()
        .eq("group_id", groupId)
        .eq("student_id", studentId);

      if (error) throw error;
      await fetchGroups();
      toast.success("Student removed from group");
    } catch (error) {
      console.error("Error removing member:", error);
      toast.error("Failed to remove student from group");
      throw error;
    }
  };

  return {
    groups,
    loading,
    fetchGroups,
    createGroup,
    updateGroup,
    deleteGroup,
    getGroupMembers,
    addMembersToGroup,
    removeMemberFromGroup,
  };
}
