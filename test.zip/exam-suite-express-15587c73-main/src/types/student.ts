export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: string;
  photoUrl?: string;
  status: 'active' | 'inactive';
  registeredExamsCount: number;
  lastLogin?: string;
  createdAt: string;
}

export interface StudentProfile {
  id: string;
  fullName: string;
  name: string;
  rollNumber: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: string;
  photoUrl?: string;
  dateOfBirth?: string;
  address?: string;
}

export interface SectionResult {
  name: string;
  score: number;
  total: number;
  percentage: number;
}

export interface QuestionBreakdown {
  questionNumber: number;
  yourAnswer: string;
  correctAnswer: string;
  marksObtained: number;
  maxMarks: number;
  timeSpent: number;
  isCorrect: boolean;
}

export interface ProctoringEvent {
  type: string;
  description: string;
  timestamp: string;
}

export interface StudentExam {
  id: string;
  examId: string;
  name: string;
  examName: string;
  examCode: string;
  subject: string;
  date: string;
  dateTime: string;
  time: string;
  duration: number;
  totalMarks: number;
  totalQuestions: number;
  status: 'upcoming' | 'completed' | 'missed';
  admitCardGenerated: boolean;
  score?: number;
  result?: 'pass' | 'fail';
  percentage?: number;
  percentile?: number;
  rank?: number;
  completedAt?: string;
  sections?: SectionResult[];
  questionBreakdown?: QuestionBreakdown[];
  proctoringEvents?: ProctoringEvent[];
}

export interface ExamEnrollment {
  id: string;
  examName: string;
  examDate: string;
  status: 'registered' | 'completed' | 'not_attempted';
  score?: number;
  totalMarks?: number;
}

export interface ExamAttempt {
  id: string;
  attemptId: string;
  examName: string;
  startTime: string;
  endTime: string;
  duration: string;
  flaggedIncidents: number;
  result: 'pass' | 'fail' | 'na';
  score?: number;
}

export interface IncidentReport {
  id: string;
  type: 'face_mismatch' | 'multiple_face' | 'tab_switch' | 'audio_alert';
  timestamp: string;
  evidenceUrl?: string;
  description: string;
}

export interface AuditLog {
  id: string;
  action: string;
  timestamp: string;
  ipAddress: string;
  performedBy: string;
  details: string;
}

export interface DeviceCheckResult {
  webcam: 'checking' | 'passed' | 'failed';
  microphone: 'checking' | 'passed' | 'failed';
  internet: 'checking' | 'passed' | 'failed';
  browser: 'checking' | 'passed' | 'failed';
  screenShare: 'checking' | 'passed' | 'failed';
  performance: 'checking' | 'passed' | 'failed';
}

export type QuestionType = 'mcq-single' | 'mcq-multiple' | 'true-false' | 'short-answer' | 'long-answer' | 'file-upload' | 'code';

export interface ExamQuestion {
  id: string;
  number: number;
  questionNumber: number;
  type: QuestionType;
  question: string;
  text: string;
  options?: string[];
  marks: number;
  timeLimit?: number;
  codeLanguage?: string;
}

export interface ExamAnswer {
  questionId: string;
  answer: string | string[] | null;
  status: 'answered' | 'not-answered' | 'flagged';
  isAnswered: boolean;
  isFlagged: boolean;
  timeSpent: number;
}

// Mock Data
export const mockStudentProfile: StudentProfile = {
  id: '1',
  fullName: 'Rahul Sharma',
  name: 'Rahul Sharma',
  rollNumber: 'CS2021001',
  email: 'rahul.sharma@university.edu',
  mobile: '+91 98765 43210',
  department: 'Computer Science',
  course: 'B.Tech',
  semester: '6th',
  photoUrl: '',
  dateOfBirth: '2002-05-15',
  address: '123 University Road, New Delhi',
};

export const mockUpcomingExams: StudentExam[] = [
  {
    id: '1',
    examId: '1',
    name: 'Data Structures Mid-Term',
    examName: 'Data Structures Mid-Term',
    examCode: 'CS301-MT',
    subject: 'Data Structures',
    date: '2024-01-20',
    dateTime: '2024-01-20T10:00:00',
    time: '10:00 AM',
    duration: 120,
    totalMarks: 100,
    totalQuestions: 50,
    status: 'upcoming',
    admitCardGenerated: false,
  },
  {
    id: '2',
    examId: '2',
    name: 'Algorithm Design Quiz',
    examName: 'Algorithm Design Quiz',
    examCode: 'CS302-Q1',
    subject: 'Algorithms',
    date: '2024-01-25',
    dateTime: '2024-01-25T14:00:00',
    time: '2:00 PM',
    duration: 60,
    totalMarks: 50,
    totalQuestions: 25,
    status: 'upcoming',
    admitCardGenerated: true,
  },
  {
    id: '3',
    examId: '3',
    name: 'Operating Systems Final',
    examName: 'Operating Systems Final',
    examCode: 'CS303-FN',
    subject: 'Operating Systems',
    date: '2024-02-01',
    dateTime: '2024-02-01T09:00:00',
    time: '9:00 AM',
    duration: 180,
    totalMarks: 100,
    totalQuestions: 60,
    status: 'upcoming',
    admitCardGenerated: false,
  },
];

export const mockPastExams: StudentExam[] = [
  {
    id: '4',
    examId: '4',
    name: 'Database Systems Final',
    examName: 'Database Systems Final',
    examCode: 'CS201-FN',
    subject: 'Database Systems',
    date: '2024-01-10',
    dateTime: '2024-01-10T14:00:00',
    time: '2:00 PM',
    duration: 180,
    totalMarks: 100,
    totalQuestions: 50,
    status: 'completed',
    admitCardGenerated: true,
    score: 85,
    result: 'pass',
    percentage: 85,
    percentile: 92,
    rank: 15,
    completedAt: '2024-01-10T17:00:00',
    sections: [
      { name: 'SQL Queries', score: 28, total: 30, percentage: 93.3 },
      { name: 'Normalization', score: 22, total: 25, percentage: 88 },
      { name: 'ER Diagrams', score: 18, total: 20, percentage: 90 },
      { name: 'Transactions', score: 17, total: 25, percentage: 68 },
    ],
    questionBreakdown: [
      { questionNumber: 1, yourAnswer: 'B', correctAnswer: 'B', marksObtained: 2, maxMarks: 2, timeSpent: 45, isCorrect: true },
      { questionNumber: 2, yourAnswer: 'A', correctAnswer: 'C', marksObtained: 0, maxMarks: 2, timeSpent: 60, isCorrect: false },
      { questionNumber: 3, yourAnswer: 'D', correctAnswer: 'D', marksObtained: 2, maxMarks: 2, timeSpent: 30, isCorrect: true },
    ],
    proctoringEvents: [],
  },
  {
    id: '5',
    examId: '5',
    name: 'Computer Networks Quiz',
    examName: 'Computer Networks Quiz',
    examCode: 'CS202-Q2',
    subject: 'Computer Networks',
    date: '2024-01-05',
    dateTime: '2024-01-05T11:00:00',
    time: '11:00 AM',
    duration: 45,
    totalMarks: 50,
    totalQuestions: 25,
    status: 'completed',
    admitCardGenerated: true,
    score: 42,
    result: 'pass',
    percentage: 84,
    percentile: 88,
    rank: 22,
    completedAt: '2024-01-05T11:45:00',
    sections: [
      { name: 'OSI Model', score: 15, total: 15, percentage: 100 },
      { name: 'TCP/IP', score: 12, total: 15, percentage: 80 },
      { name: 'Routing', score: 15, total: 20, percentage: 75 },
    ],
    questionBreakdown: [],
    proctoringEvents: [
      { type: 'tab_switch', description: 'Tab switch detected', timestamp: '2024-01-05T11:20:00' },
      { type: 'multiple_face', description: 'Multiple faces detected', timestamp: '2024-01-05T11:35:00' },
    ],
  },
  {
    id: '6',
    examId: '6',
    name: 'Software Engineering Mid-Term',
    examName: 'Software Engineering Mid-Term',
    examCode: 'CS203-MT',
    subject: 'Software Engineering',
    date: '2023-12-15',
    dateTime: '2023-12-15T10:00:00',
    time: '10:00 AM',
    duration: 120,
    totalMarks: 100,
    totalQuestions: 40,
    status: 'completed',
    admitCardGenerated: true,
    score: 72,
    result: 'pass',
    percentage: 72,
    percentile: 78,
    rank: 45,
    completedAt: '2023-12-15T12:00:00',
    sections: [
      { name: 'SDLC', score: 20, total: 25, percentage: 80 },
      { name: 'Design Patterns', score: 18, total: 25, percentage: 72 },
      { name: 'Testing', score: 16, total: 25, percentage: 64 },
      { name: 'Agile', score: 18, total: 25, percentage: 72 },
    ],
    questionBreakdown: [],
    proctoringEvents: [],
  },
];

export const mockExamQuestions: ExamQuestion[] = [
  {
    id: 'q1',
    number: 1,
    questionNumber: 1,
    type: 'mcq-single',
    question: 'What is the time complexity of binary search?',
    text: 'What is the time complexity of binary search?',
    options: ['O(n)', 'O(log n)', 'O(n²)', 'O(1)'],
    marks: 2,
  },
  {
    id: 'q2',
    number: 2,
    questionNumber: 2,
    type: 'mcq-multiple',
    question: 'Which of the following are valid sorting algorithms? (Select all that apply)',
    text: 'Which of the following are valid sorting algorithms? (Select all that apply)',
    options: ['Bubble Sort', 'Quick Sort', 'Binary Sort', 'Merge Sort', 'Linear Sort'],
    marks: 3,
  },
  {
    id: 'q3',
    number: 3,
    questionNumber: 3,
    type: 'true-false',
    question: 'A binary tree with n nodes has exactly n-1 edges.',
    text: 'A binary tree with n nodes has exactly n-1 edges.',
    options: ['True', 'False'],
    marks: 1,
  },
  {
    id: 'q4',
    number: 4,
    questionNumber: 4,
    type: 'short-answer',
    question: 'Define the term "Big O notation" in one or two sentences.',
    text: 'Define the term "Big O notation" in one or two sentences.',
    marks: 3,
  },
  {
    id: 'q5',
    number: 5,
    questionNumber: 5,
    type: 'long-answer',
    question: 'Explain the differences between a stack and a queue data structure. Provide real-world examples for each.',
    text: 'Explain the differences between a stack and a queue data structure. Provide real-world examples for each.',
    marks: 5,
  },
  {
    id: 'q6',
    number: 6,
    questionNumber: 6,
    type: 'code',
    question: 'Write a function to reverse a linked list in JavaScript.',
    text: 'Write a function to reverse a linked list in JavaScript.',
    marks: 10,
    codeLanguage: 'javascript',
  },
  {
    id: 'q7',
    number: 7,
    questionNumber: 7,
    type: 'file-upload',
    question: 'Upload your ER diagram for the given database schema requirements.',
    text: 'Upload your ER diagram for the given database schema requirements.',
    marks: 5,
  },
];

export const mockStudents: Student[] = [
  {
    id: '1',
    name: 'Rahul Sharma',
    rollNumber: 'CS2021001',
    email: 'rahul.sharma@university.edu',
    mobile: '+91 98765 43210',
    department: 'Computer Science',
    course: 'B.Tech',
    semester: '6th',
    photoUrl: '',
    status: 'active',
    registeredExamsCount: 5,
    lastLogin: '2024-01-15T10:30:00',
    createdAt: '2021-08-01',
  },
  {
    id: '2',
    name: 'Priya Patel',
    rollNumber: 'CS2021002',
    email: 'priya.patel@university.edu',
    mobile: '+91 98765 43211',
    department: 'Computer Science',
    course: 'B.Tech',
    semester: '6th',
    status: 'active',
    registeredExamsCount: 4,
    lastLogin: '2024-01-14T14:20:00',
    createdAt: '2021-08-01',
  },
  {
    id: '3',
    name: 'Amit Kumar',
    rollNumber: 'EE2021015',
    email: 'amit.kumar@university.edu',
    mobile: '+91 98765 43212',
    department: 'Electrical Engineering',
    course: 'B.Tech',
    semester: '6th',
    status: 'active',
    registeredExamsCount: 3,
    createdAt: '2021-08-01',
  },
  {
    id: '4',
    name: 'Sneha Gupta',
    rollNumber: 'ME2020008',
    email: 'sneha.gupta@university.edu',
    mobile: '+91 98765 43213',
    department: 'Mechanical Engineering',
    course: 'B.Tech',
    semester: '8th',
    status: 'inactive',
    registeredExamsCount: 6,
    createdAt: '2020-08-01',
  },
  {
    id: '5',
    name: 'Vikram Singh',
    rollNumber: 'CS2022010',
    email: 'vikram.singh@university.edu',
    mobile: '+91 98765 43214',
    department: 'Computer Science',
    course: 'M.Tech',
    semester: '2nd',
    status: 'active',
    registeredExamsCount: 2,
    lastLogin: '2024-01-15T09:00:00',
    createdAt: '2022-08-01',
  },
];

export const mockEnrollments: ExamEnrollment[] = [
  { id: '1', examName: 'Data Structures Mid-Term', examDate: '2024-01-20T10:00:00', status: 'registered', totalMarks: 100 },
  { id: '2', examName: 'Database Systems Final', examDate: '2024-01-10T14:00:00', status: 'completed', score: 85, totalMarks: 100 },
  { id: '3', examName: 'Computer Networks Quiz', examDate: '2024-01-05T11:00:00', status: 'completed', score: 42, totalMarks: 50 },
  { id: '4', examName: 'Operating Systems Lab', examDate: '2023-12-20T09:00:00', status: 'not_attempted', totalMarks: 50 },
];

export const mockAttempts: ExamAttempt[] = [
  { id: '1', attemptId: 'ATT-2024-001', examName: 'Database Systems Final', startTime: '2024-01-10T14:00:00', endTime: '2024-01-10T16:30:00', duration: '2h 30m', flaggedIncidents: 0, result: 'pass', score: 85 },
  { id: '2', attemptId: 'ATT-2024-002', examName: 'Computer Networks Quiz', startTime: '2024-01-05T11:00:00', endTime: '2024-01-05T11:45:00', duration: '45m', flaggedIncidents: 2, result: 'pass', score: 42 },
];

export const mockIncidents: IncidentReport[] = [
  { id: '1', type: 'tab_switch', timestamp: '2024-01-05T11:20:00', description: 'Student switched to another browser tab' },
  { id: '2', type: 'multiple_face', timestamp: '2024-01-05T11:35:00', description: 'Multiple faces detected in webcam frame' },
];

export const mockAuditLogs: AuditLog[] = [
  { id: '1', action: 'Profile Updated', timestamp: '2024-01-15T10:30:00', ipAddress: '192.168.1.100', performedBy: 'Admin User', details: 'Email address updated' },
  { id: '2', action: 'Exam Enrollment', timestamp: '2024-01-14T14:00:00', ipAddress: '192.168.1.100', performedBy: 'Admin User', details: 'Enrolled in Data Structures Mid-Term' },
  { id: '3', action: 'Password Reset', timestamp: '2024-01-10T09:00:00', ipAddress: '192.168.1.105', performedBy: 'System', details: 'Password reset link sent to email' },
];
