export interface StudentGroup {
  id: string;
  group_name: string;
  group_code: string;
  department: string | null;
  semester: number | null;
  description: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
  member_count?: number;
}

export interface StudentGroupMember {
  id: string;
  group_id: string;
  student_id: string;
  created_at: string;
  student?: {
    id: string;
    full_name: string;
    roll_no: string;
    email: string;
    department: string;
    semester: number;
  };
}
