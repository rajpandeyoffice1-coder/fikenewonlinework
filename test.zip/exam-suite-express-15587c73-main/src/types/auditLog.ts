export type UserType = 'Admin' | 'Proctor' | 'Evaluator' | 'Student';

export type ActionType = 
  | 'Login' 
  | 'Logout' 
  | 'Exam Modify' 
  | 'Student Modify' 
  | 'Question Update' 
  | 'Role Update' 
  | 'Settings Change' 
  | 'Proctor Action' 
  | 'Evaluation Action'
  | 'Failed Login';

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: {
    id: string;
    name: string;
    email: string;
    role: UserType;
  };
  action: ActionType;
  actionDescription: string;
  target: {
    type: 'Exam' | 'Student' | 'Question' | 'Setting' | 'User' | 'System';
    id: string;
    name: string;
  };
  ipAddress: string;
  device: {
    browser: string;
    os: string;
    deviceType: 'Desktop' | 'Mobile' | 'Tablet';
  };
  metadata: {
    sessionId: string;
    requestId: string;
  };
  changes?: {
    before: Record<string, unknown>;
    after: Record<string, unknown>;
  };
  rawLog: Record<string, unknown>;
}

export interface AuditLogInsight {
  totalLogs: number;
  highRiskActions: number;
  mostActiveUser: {
    name: string;
    actionCount: number;
  };
  failedLoginAttempts: number;
}

export interface SecurityAlert {
  id: string;
  type: 'failed_login' | 'new_device' | 'new_location' | 'role_change';
  severity: 'low' | 'medium' | 'high';
  description: string;
  timestamp: string;
  userId: string;
  userName: string;
  count?: number;
}

// Mock data
export const mockAuditLogs: AuditLogEntry[] = [
  {
    id: 'LOG001',
    timestamp: '2024-01-15T09:30:00Z',
    user: { id: 'USR001', name: 'Dr. Sarah Johnson', email: 'sarah.johnson@university.edu', role: 'Admin' },
    action: 'Exam Modify',
    actionDescription: 'Updated passing marks for Final Examination',
    target: { type: 'Exam', id: 'EXM001', name: 'Computer Science Final Exam' },
    ipAddress: '192.168.1.45',
    device: { browser: 'Chrome 120', os: 'Windows 11', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_abc123', requestId: 'req_xyz789' },
    changes: { before: { passingMarks: 40 }, after: { passingMarks: 50 } },
    rawLog: { action: 'exam.update', field: 'passing_marks', oldValue: 40, newValue: 50, timestamp: '2024-01-15T09:30:00Z' }
  },
  {
    id: 'LOG002',
    timestamp: '2024-01-15T09:15:00Z',
    user: { id: 'USR002', name: 'Prof. Michael Chen', email: 'michael.chen@university.edu', role: 'Evaluator' },
    action: 'Evaluation Action',
    actionDescription: 'Graded subjective answer for student',
    target: { type: 'Student', id: 'STU045', name: 'John Smith' },
    ipAddress: '192.168.1.102',
    device: { browser: 'Firefox 121', os: 'macOS Sonoma', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_def456', requestId: 'req_uvw321' },
    changes: { before: { score: null }, after: { score: 85 } },
    rawLog: { action: 'evaluation.grade', studentId: 'STU045', questionId: 'Q15', score: 85 }
  },
  {
    id: 'LOG003',
    timestamp: '2024-01-15T08:45:00Z',
    user: { id: 'USR003', name: 'Emily Davis', email: 'emily.davis@university.edu', role: 'Proctor' },
    action: 'Proctor Action',
    actionDescription: 'Issued warning to candidate for suspicious behavior',
    target: { type: 'Student', id: 'STU089', name: 'Alice Brown' },
    ipAddress: '192.168.1.78',
    device: { browser: 'Chrome 120', os: 'Windows 10', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_ghi789', requestId: 'req_rst654' },
    rawLog: { action: 'proctor.warning', candidateId: 'STU089', reason: 'Multiple face detected', timestamp: '2024-01-15T08:45:00Z' }
  },
  {
    id: 'LOG004',
    timestamp: '2024-01-15T08:30:00Z',
    user: { id: 'USR004', name: 'Admin User', email: 'admin@university.edu', role: 'Admin' },
    action: 'Role Update',
    actionDescription: 'Assigned Proctor role to new user',
    target: { type: 'User', id: 'USR010', name: 'Robert Wilson' },
    ipAddress: '192.168.1.1',
    device: { browser: 'Edge 120', os: 'Windows 11', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_jkl012', requestId: 'req_opq987' },
    changes: { before: { role: 'User' }, after: { role: 'Proctor' } },
    rawLog: { action: 'user.role_update', userId: 'USR010', oldRole: 'User', newRole: 'Proctor' }
  },
  {
    id: 'LOG005',
    timestamp: '2024-01-15T08:00:00Z',
    user: { id: 'USR005', name: 'James Wilson', email: 'james.wilson@university.edu', role: 'Student' },
    action: 'Login',
    actionDescription: 'Successful login to examination portal',
    target: { type: 'System', id: 'SYS001', name: 'Exam Portal' },
    ipAddress: '203.45.67.89',
    device: { browser: 'Safari 17', os: 'iOS 17', deviceType: 'Mobile' },
    metadata: { sessionId: 'sess_mno345', requestId: 'req_lmn654' },
    rawLog: { action: 'auth.login', success: true, method: 'password' }
  },
  {
    id: 'LOG006',
    timestamp: '2024-01-15T07:55:00Z',
    user: { id: 'USR006', name: 'Unknown', email: 'hacker@external.com', role: 'Student' },
    action: 'Failed Login',
    actionDescription: 'Failed login attempt - invalid credentials',
    target: { type: 'System', id: 'SYS001', name: 'Exam Portal' },
    ipAddress: '45.67.89.123',
    device: { browser: 'Chrome 118', os: 'Linux', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_pqr678', requestId: 'req_ijk321' },
    rawLog: { action: 'auth.login', success: false, reason: 'invalid_credentials', attempts: 3 }
  },
  {
    id: 'LOG007',
    timestamp: '2024-01-15T07:30:00Z',
    user: { id: 'USR001', name: 'Dr. Sarah Johnson', email: 'sarah.johnson@university.edu', role: 'Admin' },
    action: 'Question Update',
    actionDescription: 'Modified question difficulty level',
    target: { type: 'Question', id: 'Q102', name: 'Data Structures MCQ' },
    ipAddress: '192.168.1.45',
    device: { browser: 'Chrome 120', os: 'Windows 11', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_stu901', requestId: 'req_fgh098' },
    changes: { before: { difficulty: 'Easy' }, after: { difficulty: 'Medium' } },
    rawLog: { action: 'question.update', questionId: 'Q102', field: 'difficulty', oldValue: 'Easy', newValue: 'Medium' }
  },
  {
    id: 'LOG008',
    timestamp: '2024-01-15T07:00:00Z',
    user: { id: 'USR004', name: 'Admin User', email: 'admin@university.edu', role: 'Admin' },
    action: 'Settings Change',
    actionDescription: 'Updated proctoring settings for all exams',
    target: { type: 'Setting', id: 'SET001', name: 'Proctoring Configuration' },
    ipAddress: '192.168.1.1',
    device: { browser: 'Edge 120', os: 'Windows 11', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_vwx234', requestId: 'req_cde765' },
    changes: { before: { faceDetection: false }, after: { faceDetection: true } },
    rawLog: { action: 'settings.update', category: 'proctoring', field: 'faceDetection', enabled: true }
  },
  {
    id: 'LOG009',
    timestamp: '2024-01-14T18:30:00Z',
    user: { id: 'USR002', name: 'Prof. Michael Chen', email: 'michael.chen@university.edu', role: 'Evaluator' },
    action: 'Logout',
    actionDescription: 'User logged out from the system',
    target: { type: 'System', id: 'SYS001', name: 'Exam Portal' },
    ipAddress: '192.168.1.102',
    device: { browser: 'Firefox 121', os: 'macOS Sonoma', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_yza567', requestId: 'req_bcd432' },
    rawLog: { action: 'auth.logout', sessionDuration: 7200 }
  },
  {
    id: 'LOG010',
    timestamp: '2024-01-14T16:00:00Z',
    user: { id: 'USR001', name: 'Dr. Sarah Johnson', email: 'sarah.johnson@university.edu', role: 'Admin' },
    action: 'Student Modify',
    actionDescription: 'Updated student enrollment status',
    target: { type: 'Student', id: 'STU156', name: 'Mark Thompson' },
    ipAddress: '192.168.1.45',
    device: { browser: 'Chrome 120', os: 'Windows 11', deviceType: 'Desktop' },
    metadata: { sessionId: 'sess_efg890', requestId: 'req_hij109' },
    changes: { before: { status: 'Pending' }, after: { status: 'Active' } },
    rawLog: { action: 'student.update', studentId: 'STU156', field: 'status', oldValue: 'Pending', newValue: 'Active' }
  }
];

export const mockInsights: AuditLogInsight = {
  totalLogs: 1247,
  highRiskActions: 23,
  mostActiveUser: { name: 'Dr. Sarah Johnson', actionCount: 156 },
  failedLoginAttempts: 8
};

export const mockSecurityAlerts: SecurityAlert[] = [
  {
    id: 'SEC001',
    type: 'failed_login',
    severity: 'high',
    description: 'Multiple failed login attempts detected',
    timestamp: '2024-01-15T07:55:00Z',
    userId: 'USR006',
    userName: 'Unknown User',
    count: 5
  },
  {
    id: 'SEC002',
    type: 'new_device',
    severity: 'medium',
    description: 'Login from new device detected',
    timestamp: '2024-01-15T08:00:00Z',
    userId: 'USR005',
    userName: 'James Wilson'
  },
  {
    id: 'SEC003',
    type: 'new_location',
    severity: 'medium',
    description: 'Login from unusual IP location',
    timestamp: '2024-01-14T22:30:00Z',
    userId: 'USR007',
    userName: 'Lisa Anderson'
  },
  {
    id: 'SEC004',
    type: 'role_change',
    severity: 'high',
    description: 'Admin role assigned to user',
    timestamp: '2024-01-14T10:00:00Z',
    userId: 'USR010',
    userName: 'Robert Wilson'
  }
];
