export interface EvaluatorProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  department: string;
  specialization: string;
}

export interface AssignedExam {
  id: string;
  name: string;
  subject: string;
  section: string;
  totalSheets: number;
  pendingSheets: number;
  completedSheets: number;
  deadline: string;
  priority: 'high' | 'normal';
}

export interface AnswerSheet {
  id: string;
  candidateId: string;
  candidateName: string;
  rollNumber: string;
  examId: string;
  examName: string;
  questionId: string;
  questionNumber: number;
  questionText: string;
  questionType: 'short' | 'long' | 'file' | 'code';
  maxMarks: number;
  submissionType: 'text' | 'file' | 'image' | 'code';
  answer: string;
  fileUrl?: string;
  status: 'pending' | 'in-progress' | 'completed';
  priority: 'high' | 'normal';
  assignedMarks?: number;
  evaluatorComment?: string;
  evaluatedAt?: string;
}

export interface RubricCriterion {
  id: string;
  name: string;
  description: string;
  maxScore: number;
  awardedScore?: number;
}

export interface ReEvaluationRequest {
  id: string;
  candidateId: string;
  candidateName: string;
  rollNumber: string;
  examId: string;
  examName: string;
  questionId: string;
  questionNumber: number;
  originalMarks: number;
  requestedMarks: number;
  maxMarks: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  studentRemarks: string;
  previousComment: string;
  evidence?: string;
  createdAt: string;
}

export interface PlagiarismResult {
  candidateId: string;
  candidateName: string;
  rollNumber: string;
  overallSimilarity: number;
  questionResults: {
    questionId: string;
    questionNumber: number;
    similarity: number;
    matchedSources: {
      source: string;
      percentage: number;
      matchedText: string;
    }[];
  }[];
}

// Note: Mock data has been removed. All data should come from database.

export const mockRubricCriteria: RubricCriterion[] = [
  { id: 'R1', name: 'Correctness', description: 'Is the answer factually correct?', maxScore: 4 },
  { id: 'R2', name: 'Completeness', description: 'Does the answer cover all aspects of the question?', maxScore: 3 },
  { id: 'R3', name: 'Clarity', description: 'Is the explanation clear and easy to understand?', maxScore: 2 },
  { id: 'R4', name: 'Examples', description: 'Are appropriate examples provided?', maxScore: 1 },
];
