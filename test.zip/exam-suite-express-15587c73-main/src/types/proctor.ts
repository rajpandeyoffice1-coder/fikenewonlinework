export interface Proctor {
  id: string;
  name: string;
  proctorId: string;
  email: string;
  mobile: string;
  department: string;
  experience: number;
  photoUrl?: string;
  status: 'active' | 'inactive';
  assignedExamsCount: number;
  lastLogin?: string;
  createdAt: string;
  permissions: ProctorPermissions;
  totalExamsProctored: number;
  avgResponseTime: string;
  rating: number;
}

export interface ProctorPermissions {
  viewCandidates: boolean;
  sendWarnings: boolean;
  muteCandidate: boolean;
  pauseExam: boolean;
  endExam: boolean;
  viewEvidenceReplay: boolean;
}

export interface ProctorAssignment {
  id: string;
  examName: string;
  examDate: string;
  role: 'lead' | 'support';
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface ProctorActivityLog {
  id: string;
  timestamp: string;
  action: string;
  description: string;
  candidateName?: string;
  examName: string;
}

export interface ProctorPerformanceData {
  examName: string;
  incidentsHandled: number;
}

export interface IncidentCategoryData {
  category: string;
  count: number;
}

// Note: Mock data has been removed. All data should come from database.
