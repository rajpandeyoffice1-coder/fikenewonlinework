export interface ReportCandidate {
  id: string;
  name: string;
  rollNumber: string;
  score: number;
  totalMarks: number;
  percentage: number;
  status: 'pass' | 'fail';
  timeTaken: string;
  incidentCount: number;
  department: string;
  sessionId?: string;
  examId?: string;
  studentId?: string;
  email?: string;
}

export interface ScoreRange {
  range: string;
  count: number;
}

export interface DepartmentPerformance {
  department: string;
  passPercentage: number;
  totalCandidates: number;
}

export interface QuestionDifficulty {
  difficulty: string;
  count: number;
  correctPercentage: number;
}

export interface TimeAnalysis {
  questionNumber: number;
  avgTime: number;
}

export interface IncidentCategory {
  category: string;
  count: number;
}

export interface CandidateBreakdown {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
  department: string;
  totalScore: number;
  totalMarks: number;
  percentage: number;
  timeTaken: string;
  sections: SectionScore[];
  questions: QuestionResult[];
  incidents: IncidentTimeline[];
  screenshots?: ScreenshotData[];
}

export interface SectionScore {
  name: string;
  score: number;
  maxScore: number;
}

export interface QuestionResult {
  questionId: string;
  type: string;
  marks: number;
  maxMarks: number;
  attempted: boolean;
  correct: boolean;
  timeSpent: string;
}

export interface IncidentTimeline {
  id: string;
  type: string;
  timestamp: string;
  description: string;
}

export interface ScreenshotData {
  id: string;
  screenshot_url: string;
  capture_type: string;
  reason: string | null;
  timestamp: string;
}

// Note: Mock data has been removed. All data should come from database.
