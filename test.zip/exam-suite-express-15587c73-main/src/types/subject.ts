export interface Subject {
  id: string;
  code: string;
  name: string;
  department: string;
  semester: number;
  status: "active" | "inactive";
  created_at: string;
  updated_at: string;
}

export type SubjectFormData = Omit<Subject, "id" | "created_at" | "updated_at">;
