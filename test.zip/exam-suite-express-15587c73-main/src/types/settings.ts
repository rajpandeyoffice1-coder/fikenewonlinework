export interface GeneralSettings {
  platformName: string;
  universityName: string;
  logo: string | null;
  supportEmail: string;
  supportPhone: string;
  defaultTimezone: string;
  language: string;
}

export interface Role {
  id: string;
  name: string;
  permissions: RolePermissions;
  memberCount: number;
}

export interface RolePermissions {
  manageExams: boolean;
  manageQuestions: boolean;
  manageStudents: boolean;
  accessReports: boolean;
  proctorLiveSessions: boolean;
  evaluateAnswers: boolean;
  manageSystemSettings: boolean;
}

export interface SecuritySettings {
  passwordPolicy: {
    minLength: number;
    requireSpecialChars: boolean;
    requireNumbers: boolean;
    maxPasswordAge: number;
  };
  twoFactorAuth: {
    enableForAdmins: boolean;
    enableForStudents: boolean;
  };
  accountLockout: {
    failedAttemptsLimit: number;
    lockoutDuration: number;
  };
  allowedIPs: string[];
}

export interface ProctoringSettings {
  enableProctoring: boolean;
  webcamRequired: boolean;
  microphoneRequired: boolean;
  screenShareRequired: boolean;
  tabSwitchDetection: boolean;
  audioLevelAlerts: boolean;
  faceVerification: boolean;
  liveProctoringAccess: boolean;
  faceMismatchThreshold: number;
  multipleFaceSensitivity: number;
}

export interface ExamDefaults {
  defaultDuration: number;
  defaultPassingMarks: number;
  questionShuffle: boolean;
  negativeMarking: boolean;
  negativeMarkingValue: number;
  browserLockdown: boolean;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
  variables: string[];
}

export interface Integration {
  id: string;
  name: string;
  type: 'sso' | 'lms' | 'payment' | 'plagiarism';
  enabled: boolean;
  config: Record<string, string>;
}

export interface DataRetentionSettings {
  enableRetentionPolicy: boolean;
  deleteVideosAfterDays: number;
  deleteLogsAfterDays: number;
  deleteAttemptsAfterYears: number;
  allowDataDownloadRequest: boolean;
  allowDataDeleteRequest: boolean;
}

export interface SystemLogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  ipAddress: string;
  details: string;
}

export interface BackupEntry {
  id: string;
  timestamp: string;
  size: string;
  type: 'manual' | 'scheduled';
  status: 'completed' | 'failed';
}

export type SettingsSection = 
  | 'general'
  | 'users'
  | 'security'
  | 'proctoring'
  | 'exam-defaults'
  | 'notifications'
  | 'integrations'
  | 'data-retention'
  | 'system-logs'
  | 'backup';
