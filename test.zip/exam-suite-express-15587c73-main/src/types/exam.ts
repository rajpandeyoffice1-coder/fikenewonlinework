export interface ExamBasicInfo {
  title: string;
  code: string;
  autoGenerateCode: boolean;
  department: string;
  course: string;
  semester: string;
  description: string;
  groupId: string;
}

export interface ExamSchedule {
  startDate: Date | undefined;
  endDate: Date | undefined;
  duration: number;
  lateEntryBuffer: number;
  timezone: string;
}

export interface Student {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
}

export interface ExamEligibility {
  students: Student[];
  studentGroup: string;
}

export interface Question {
  id: string;
  text: string;
  type: "mcq" | "true-false" | "subjective";
  marks: number;
  difficulty: "easy" | "medium" | "hard";
}

export interface ExamQuestionPaper {
  questions: Question[];
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
}

export interface ExamProctoring {
  enableRemoteProctoring: boolean;
  requireWebcam: boolean;
  requireMicrophone: boolean;
  screenShareRequired: boolean;
  fullBrowserLockdown: boolean;
  proctorAssignment: string;
}

export interface ExamAntiCheating {
  faceMatchRequired: boolean;
  multipleFaceDetection: boolean;
  tabSwitchBlocking: boolean;
  copyPasteBlocking: boolean;
  allowedDeviceCount: number;
  ipRangeRestriction: string;
}

export interface ExamGrading {
  autoGradeMcqs: boolean;
  manualGradingSubjective: boolean;
  rubricTemplate: string;
  passingMarks: number;
  totalMarks: number;
}

export interface ExamNotifications {
  emailTemplate: string;
  smsTemplate: string;
  notifyStudentsOnPublish: boolean;
  notifyProctorsOnPublish: boolean;
}

export interface ExamData {
  basicInfo: ExamBasicInfo;
  schedule: ExamSchedule;
  eligibility: ExamEligibility;
  questionPaper: ExamQuestionPaper;
  proctoring: ExamProctoring;
  antiCheating: ExamAntiCheating;
  grading: ExamGrading;
  notifications: ExamNotifications;
}

export const initialExamData: ExamData = {
  basicInfo: {
    title: "",
    code: "",
    autoGenerateCode: true,
    department: "",
    course: "",
    semester: "",
    description: "",
    groupId: "",
  },
  schedule: {
    startDate: undefined,
    endDate: undefined,
    duration: 60,
    lateEntryBuffer: 10,
    timezone: "Asia/Kolkata",
  },
  eligibility: {
    students: [],
    studentGroup: "",
  },
  questionPaper: {
    questions: [],
    shuffleQuestions: true,
    shuffleOptions: true,
  },
  proctoring: {
    enableRemoteProctoring: true,
    requireWebcam: true,
    requireMicrophone: false,
    screenShareRequired: false,
    fullBrowserLockdown: false,
    proctorAssignment: "auto",
  },
  antiCheating: {
    faceMatchRequired: true,
    multipleFaceDetection: true,
    tabSwitchBlocking: true,
    copyPasteBlocking: true,
    allowedDeviceCount: 1,
    ipRangeRestriction: "",
  },
  grading: {
    autoGradeMcqs: true,
    manualGradingSubjective: true,
    rubricTemplate: "",
    passingMarks: 40,
    totalMarks: 0,
  },
  notifications: {
    emailTemplate: "Dear Student,\n\nYou have been enrolled for the exam: {{exam_title}}.\n\nDate: {{exam_date}}\nDuration: {{duration}} minutes\n\nPlease ensure you have a stable internet connection and a working webcam.\n\nBest regards,\nExamExpress Team",
    smsTemplate: "You are enrolled for {{exam_title}} on {{exam_date}}. Duration: {{duration}} mins. Login to ExamExpress for details.",
    notifyStudentsOnPublish: true,
    notifyProctorsOnPublish: true,
  },
};
