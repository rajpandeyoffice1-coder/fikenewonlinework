export interface ProctorProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  department: string;
  assignedExams: number;
}

export interface MonitoredCandidate {
  id: string;
  name: string;
  rollNumber: string;
  photo: string;
  status: 'normal' | 'warning' | 'flagged' | 'disconnected';
  examProgress: number;
  lastActivity: string;
  incidents: number;
  isOnline: boolean;
}

export interface ProctorExam {
  id: string;
  name: string;
  date: string;
  time: string;
  totalCandidates: number;
  onlineCandidates: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  incidents: number;
}

export interface Incident {
  id: string;
  candidateId: string;
  candidateName: string;
  candidateRollNumber: string;
  examId: string;
  examName: string;
  type: 'face_not_detected' | 'multiple_faces' | 'tab_switch' | 'audio_alert' | 'network_unstable' | 'looking_away' | 'unauthorized_device';
  severity: 'low' | 'medium' | 'high';
  timestamp: string;
  description: string;
  evidence?: string;
  reviewed: boolean;
  markedAsCheating: boolean;
  proctorNotes?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderType: 'proctor' | 'candidate';
  message: string;
  timestamp: string;
  read: boolean;
  attachment?: string;
}

export interface CandidateSession {
  candidateId: string;
  startTime: string;
  lastActivityTime: string;
  browser: string;
  device: string;
  ipAddress: string;
  attemptCount: number;
  networkQuality: 'good' | 'fair' | 'poor';
}

// Note: Mock data has been removed. All data should come from database.

export const predefinedWarnings = [
  'Please stay within the camera frame',
  'No additional devices allowed',
  'Do not look away from the screen',
  'Please ensure proper lighting',
  'Remove any unauthorized materials',
  'Keep your microphone unmuted',
];
