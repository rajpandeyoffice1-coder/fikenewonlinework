export interface Evaluator {
  id: string;
  name: string;
  evaluatorId: string;
  email: string;
  mobile: string;
  department: string;
  subjectExpertise: string[];
  experience: number;
  photoUrl?: string;
  status: 'active' | 'inactive';
  assignedExamsCount: number;
  pendingSheets: number;
  lastLogin?: string;
  createdAt: string;
  permissions: EvaluatorPermissions;
  totalEvaluationsCompleted: number;
  avgScoringTime: string;
  accuracyScore: number;
}

export interface EvaluatorPermissions {
  viewAnswerSheets: boolean;
  scoreSubjectiveAnswers: boolean;
  addComments: boolean;
  reEvaluateSheets: boolean;
  viewRubrics: boolean;
}

export interface EvaluatorExamAssignment {
  id: string;
  examName: string;
  subject: string;
  examDate: string;
  role: 'evaluator' | 'lead_evaluator';
  status: 'pending' | 'in_progress' | 'completed';
}

export interface EvaluationQueueItem {
  id: string;
  candidateId: string;
  candidateName: string;
  questionSection: string;
  submissionType: 'text' | 'image' | 'file';
  priority: 'high' | 'normal';
  status: 'not_started' | 'in_progress' | 'completed';
  examName: string;
}

export interface EvaluatorActivityLog {
  id: string;
  timestamp: string;
  action: string;
  examName: string;
  candidateId: string;
}

export interface EvaluatorPerformanceData {
  date: string;
  sheetsEvaluated: number;
}

export interface QuestionTypeData {
  type: string;
  count: number;
}

export const mockEvaluators: Evaluator[] = [
  {
    id: '1',
    name: 'Dr. Meera Krishnan',
    evaluatorId: 'EVAL001',
    email: 'meera.krishnan@university.edu',
    mobile: '+91 98765 43210',
    department: 'Computer Science',
    subjectExpertise: ['Data Structures', 'Algorithms', 'Database Systems'],
    experience: 12,
    status: 'active',
    assignedExamsCount: 8,
    pendingSheets: 45,
    lastLogin: '2024-01-15T10:30:00',
    createdAt: '2018-06-15',
    permissions: {
      viewAnswerSheets: true,
      scoreSubjectiveAnswers: true,
      addComments: true,
      reEvaluateSheets: true,
      viewRubrics: true,
    },
    totalEvaluationsCompleted: 1250,
    avgScoringTime: '4.2 min',
    accuracyScore: 96,
  },
  {
    id: '2',
    name: 'Prof. Ravi Shankar',
    evaluatorId: 'EVAL002',
    email: 'ravi.shankar@university.edu',
    mobile: '+91 98765 43211',
    department: 'Mathematics',
    subjectExpertise: ['Calculus', 'Linear Algebra', 'Statistics'],
    experience: 15,
    status: 'active',
    assignedExamsCount: 6,
    pendingSheets: 32,
    lastLogin: '2024-01-14T14:20:00',
    createdAt: '2016-03-10',
    permissions: {
      viewAnswerSheets: true,
      scoreSubjectiveAnswers: true,
      addComments: true,
      reEvaluateSheets: true,
      viewRubrics: true,
    },
    totalEvaluationsCompleted: 2100,
    avgScoringTime: '3.8 min',
    accuracyScore: 98,
  },
  {
    id: '3',
    name: 'Dr. Ananya Reddy',
    evaluatorId: 'EVAL003',
    email: 'ananya.reddy@university.edu',
    mobile: '+91 98765 43212',
    department: 'Physics',
    subjectExpertise: ['Mechanics', 'Thermodynamics', 'Optics'],
    experience: 8,
    status: 'active',
    assignedExamsCount: 4,
    pendingSheets: 28,
    lastLogin: '2024-01-13T09:00:00',
    createdAt: '2019-08-20',
    permissions: {
      viewAnswerSheets: true,
      scoreSubjectiveAnswers: true,
      addComments: true,
      reEvaluateSheets: false,
      viewRubrics: true,
    },
    totalEvaluationsCompleted: 890,
    avgScoringTime: '5.1 min',
    accuracyScore: 94,
  },
  {
    id: '4',
    name: 'Ms. Kavitha Nair',
    evaluatorId: 'EVAL004',
    email: 'kavitha.nair@university.edu',
    mobile: '+91 98765 43213',
    department: 'Chemistry',
    subjectExpertise: ['Organic Chemistry', 'Inorganic Chemistry'],
    experience: 5,
    status: 'inactive',
    assignedExamsCount: 0,
    pendingSheets: 0,
    createdAt: '2021-09-01',
    permissions: {
      viewAnswerSheets: true,
      scoreSubjectiveAnswers: true,
      addComments: false,
      reEvaluateSheets: false,
      viewRubrics: true,
    },
    totalEvaluationsCompleted: 320,
    avgScoringTime: '6.2 min',
    accuracyScore: 88,
  },
];

export const mockExamAssignments: EvaluatorExamAssignment[] = [
  { id: '1', examName: 'Data Structures Final', subject: 'Data Structures', examDate: '2024-01-20T10:00:00', role: 'lead_evaluator', status: 'pending' },
  { id: '2', examName: 'Database Systems Mid-Term', subject: 'Database Systems', examDate: '2024-01-18T14:00:00', role: 'evaluator', status: 'in_progress' },
  { id: '3', examName: 'Algorithm Design Quiz', subject: 'Algorithms', examDate: '2024-01-15T11:00:00', role: 'evaluator', status: 'completed' },
];

export const mockEvaluationQueue: EvaluationQueueItem[] = [
  { id: '1', candidateId: 'CS2021001', candidateName: 'Rahul Sharma', questionSection: 'Section B - Q3', submissionType: 'text', priority: 'high', status: 'not_started', examName: 'Data Structures Final' },
  { id: '2', candidateId: 'CS2021002', candidateName: 'Priya Patel', questionSection: 'Section B - Q4', submissionType: 'image', priority: 'normal', status: 'in_progress', examName: 'Data Structures Final' },
  { id: '3', candidateId: 'CS2021003', candidateName: 'Amit Kumar', questionSection: 'Section C - Q1', submissionType: 'file', priority: 'normal', status: 'not_started', examName: 'Database Systems Mid-Term' },
  { id: '4', candidateId: 'CS2021004', candidateName: 'Sneha Gupta', questionSection: 'Section B - Q2', submissionType: 'text', priority: 'high', status: 'completed', examName: 'Algorithm Design Quiz' },
];

export const mockActivityLogs: EvaluatorActivityLog[] = [
  { id: '1', timestamp: '2024-01-15T11:20:00', action: 'Graded answer sheet', examName: 'Data Structures Final', candidateId: 'CS2021005' },
  { id: '2', timestamp: '2024-01-15T10:45:00', action: 'Added comment', examName: 'Data Structures Final', candidateId: 'CS2021004' },
  { id: '3', timestamp: '2024-01-14T16:30:00', action: 'Re-evaluated', examName: 'Algorithm Design Quiz', candidateId: 'CS2021002' },
  { id: '4', timestamp: '2024-01-14T14:00:00', action: 'Graded answer sheet', examName: 'Database Systems Mid-Term', candidateId: 'CS2021001' },
];

export const mockPerformanceData: EvaluatorPerformanceData[] = [
  { date: 'Mon', sheetsEvaluated: 12 },
  { date: 'Tue', sheetsEvaluated: 18 },
  { date: 'Wed', sheetsEvaluated: 15 },
  { date: 'Thu', sheetsEvaluated: 22 },
  { date: 'Fri', sheetsEvaluated: 20 },
  { date: 'Sat', sheetsEvaluated: 8 },
  { date: 'Sun', sheetsEvaluated: 5 },
];

export const mockQuestionTypes: QuestionTypeData[] = [
  { type: 'Short Answer', count: 450 },
  { type: 'Long Answer', count: 320 },
  { type: 'File Upload', count: 180 },
  { type: 'Diagram', count: 90 },
];
