export interface QuestionOption {
  id: string;
  text: string;
  isCorrect: boolean;
  imageUrl?: string;
}

export type QuestionType = 
  | "mcq_single" 
  | "mcq_multiple" 
  | "true_false" 
  | "short_answer" 
  | "long_answer"
  | "coding"
  | "file_upload"
  | "image_based"
  | "video_based";

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  mcq_single: "MCQ (Single Answer)",
  mcq_multiple: "MCQ (Multiple Answers)",
  true_false: "True/False",
  short_answer: "Short Answer",
  long_answer: "Long Answer",
  coding: "Coding",
  file_upload: "File Upload",
  image_based: "Image Based",
  video_based: "Video Based",
};

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  marks: number;
  negativeMarking: boolean;
  negativeMarks: number;
  timeAllowed?: number;
  difficulty: "easy" | "medium" | "hard";
  tags: string[];
  subject: string;
  folderId?: string;
  author: string;
  lastUpdated: string;
  options?: QuestionOption[];
  correctAnswer?: boolean; // for true-false
  idealAnswer?: string; // for short/long answer
  wordLimit?: number;
  attachments?: { type: "image" | "audio" | "video"; url: string; name: string }[];
  codeTemplate?: string; // for coding questions
  codeLanguage?: string; // for coding questions
  mediaUrl?: string; // for image/video based questions
  allowedFileTypes?: string[]; // for file upload questions
}

export interface QuestionFolder {
  id: string;
  name: string;
  parentId?: string;
  count: number;
}

// Note: Mock data has been removed. All data should come from database via hooks.
// Use useQuestionBank hook to fetch questions dynamically.
// Use useSubjects hook to fetch subjects dynamically.

export const allTags = [
  "algorithms",
  "searching",
  "sorting",
  "complexity",
  "oop",
  "polymorphism",
  "inheritance",
  "data-structures",
  "stack",
  "queue",
  "web",
  "http",
  "sql",
  "database",
  "os",
  "process",
  "thread",
];

export const authors = ["Dr. Smith", "Prof. Johnson", "Dr. Williams", "Prof. Brown", "Dr. Davis"];
