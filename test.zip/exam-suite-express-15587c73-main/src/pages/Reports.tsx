import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ReportsPage } from '@/components/reports/ReportsPage';

const Reports = () => {
  return (
    <DashboardLayout>
      <ReportsPage />
    </DashboardLayout>
  );
};

export default Reports;
