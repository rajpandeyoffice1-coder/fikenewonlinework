import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { EditExamPage } from "@/components/exams/EditExamPage";

const EditExam = () => {
  return (
    <DashboardLayout>
      <EditExamPage />
    </DashboardLayout>
  );
};

export default EditExam;
