import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { ExamsPage } from "@/components/exams/ExamsPage";

const Exams = () => {
  return (
    <DashboardLayout>
      <ExamsPage />
    </DashboardLayout>
  );
};

export default Exams;
