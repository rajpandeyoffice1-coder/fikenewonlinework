import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { EvaluatorsPage } from '@/components/evaluators/EvaluatorsPage';

const Evaluators = () => {
  return (
    <DashboardLayout>
      <EvaluatorsPage />
    </DashboardLayout>
  );
};

export default Evaluators;
