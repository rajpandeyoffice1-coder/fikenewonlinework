import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SubjectsPage } from "@/components/subjects/SubjectsPage";

const Subjects = () => {
  return (
    <DashboardLayout>
      <SubjectsPage />
    </DashboardLayout>
  );
};

export default Subjects;
