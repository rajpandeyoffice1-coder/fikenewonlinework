import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ProctorsPage } from '@/components/proctors/ProctorsPage';

const Proctors = () => {
  return (
    <DashboardLayout>
      <ProctorsPage />
    </DashboardLayout>
  );
};

export default Proctors;
