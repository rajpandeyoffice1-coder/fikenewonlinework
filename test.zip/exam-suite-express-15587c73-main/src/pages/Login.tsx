import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, Loader2, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { useAuth, getRedirectPath } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';

const trustedOrganizations = ['LG', 'Philips', 'Google', 'Microsoft', 'Paytm', 'Walmart'];

// Validation schema
const loginSchema = z.object({
  identifier: z.string().min(1, 'Email or Roll Number is required'),
  password: z.string().min(1, 'Password is required'),
});

export default function Login() {
  const navigate = useNavigate();
  const { signIn, isAuthenticated, role, isLoading: authLoading } = useAuth();
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [loginData, setLoginData] = useState({ identifier: '', password: '' });
  const [errors, setErrors] = useState<{ identifier?: string; password?: string }>({});

  // Seed test accounts (admin, proctor, evaluator)
  const handleSeedAdmin = async () => {
    setIsSeeding(true);
    try {
      const { data, error } = await supabase.functions.invoke('seed-admin');
      
      if (error) throw error;
      
      if (data?.success) {
        const createdAccounts = data.accounts?.filter((a: any) => a.status === 'created') || [];
        const existingAccounts = data.accounts?.filter((a: any) => a.status === 'exists') || [];
        
        if (createdAccounts.length > 0) {
          const accountList = createdAccounts.map((a: any) => 
            `${a.role}: ${a.email} / ${a.password}`
          ).join('\n');
          
          toast.success(`Created ${createdAccounts.length} test account(s)!`, {
            description: accountList,
            duration: 15000,
          });
          
          // Pre-fill with admin credentials
          const admin = createdAccounts.find((a: any) => a.role === 'admin');
          if (admin) {
            setLoginData({
              identifier: admin.email,
              password: admin.password,
            });
          }
        } else if (existingAccounts.length > 0) {
          toast.info('All test accounts already exist', {
            description: 'Admin: admin@examportal.com',
          });
          setLoginData({
            identifier: 'admin@examportal.com',
            password: 'Admin@123',
          });
        }
      }
    } catch (error) {
      console.error('Seed error:', error);
      toast.error('Failed to create test accounts');
    } finally {
      setIsSeeding(false);
    }
  };

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated && role && !authLoading) {
      const redirectPath = getRedirectPath(role);
      navigate(redirectPath, { replace: true });
    }
  }, [isAuthenticated, role, authLoading, navigate]);

  const validateForm = (): boolean => {
    try {
      loginSchema.parse(loginData);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: { identifier?: string; password?: string } = {};
        error.errors.forEach((err) => {
          if (err.path[0] === 'identifier') {
            fieldErrors.identifier = err.message;
          }
          if (err.path[0] === 'password') {
            fieldErrors.password = err.message;
          }
        });
        setErrors(fieldErrors);
      }
      return false;
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    const { error } = await signIn(loginData.identifier, loginData.password);
    
    if (error) {
      toast.error('Login Failed', { description: error });
      setIsLoading(false);
      return;
    }
    
    toast.success('Login successful! Redirecting...');
    // Navigation happens via useEffect when role is set
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero Section */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-teal-50 to-blue-100 flex-col items-center justify-center p-12 relative">
        <div className="text-center max-w-lg">
          {/* Logo */}
          <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm mb-8">
            <span className="text-xl font-bold">
              <span className="text-slate-800">exam</span>
              <span className="text-teal-600">express</span>
            </span>
            <span className="text-teal-600">↗</span>
          </div>

          <h1 className="text-3xl font-bold text-slate-800 mb-3">
            ExamExpress University Portal
          </h1>
          <p className="text-slate-600 text-lg mb-8">
            AI-powered examination platform with real-time proctoring, evaluation, and comprehensive analytics.
          </p>

          {/* Illustration */}
          <div className="relative mb-10">
            <div className="w-80 h-52 mx-auto bg-white rounded-xl shadow-lg flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-teal-50 to-blue-50" />
              <div className="relative z-10 p-6 w-full">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center">
                      <span className="text-lg">👨‍💼</span>
                    </div>
                    <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div className="w-3/4 h-full bg-teal-500 rounded-full" />
                    </div>
                    <span className="text-xs text-slate-500">Admin</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                      <span className="text-lg">👨‍🎓</span>
                    </div>
                    <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div className="w-1/2 h-full bg-blue-500 rounded-full" />
                    </div>
                    <span className="text-xs text-slate-500">Student</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                      <span className="text-lg">👁️</span>
                    </div>
                    <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div className="w-2/3 h-full bg-purple-500 rounded-full" />
                    </div>
                    <span className="text-xs text-slate-500">Proctor</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                      <span className="text-lg">📝</span>
                    </div>
                    <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div className="w-4/5 h-full bg-amber-500 rounded-full" />
                    </div>
                    <span className="text-xs text-slate-500">Evaluator</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Trusted Organizations */}
          <div className="text-sm text-slate-500 mb-4">TRUSTED BY LEADING ORGANIZATIONS</div>
          <div className="flex flex-wrap justify-center gap-3">
            {trustedOrganizations.map((org) => (
              <span
                key={org}
                className="px-4 py-2 bg-teal-700 text-white text-sm font-medium rounded-md"
              >
                {org}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Right side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-md">
          <Card className="shadow-lg border-0">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-semibold text-slate-800">
                  Welcome Back <span className="text-2xl">👋</span>
                </h2>
                <p className="text-slate-500 mt-1">
                  Sign in to{' '}
                  <span className="text-teal-600 font-medium">ExamExpress</span>
                </p>
                <p className="text-xs text-slate-400 mt-2">
                  Admin • Student • Proctor • Evaluator
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-5">
                <div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input
                      placeholder="Email or Roll Number"
                      className={`pl-11 h-12 bg-slate-50 border-slate-200 focus:border-teal-500 focus:ring-teal-500 ${
                        errors.identifier ? 'border-red-500' : ''
                      }`}
                      value={loginData.identifier}
                      onChange={(e) => {
                        setLoginData({ ...loginData, identifier: e.target.value });
                        if (errors.identifier) setErrors({ ...errors, identifier: undefined });
                      }}
                    />
                  </div>
                  {errors.identifier && (
                    <p className="text-red-500 text-sm mt-1">{errors.identifier}</p>
                  )}
                </div>

                <div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Password"
                      className={`pl-11 pr-11 h-12 bg-slate-50 border-slate-200 focus:border-teal-500 focus:ring-teal-500 ${
                        errors.password ? 'border-red-500' : ''
                      }`}
                      value={loginData.password}
                      onChange={(e) => {
                        setLoginData({ ...loginData, password: e.target.value });
                        if (errors.password) setErrors({ ...errors, password: undefined });
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                  )}
                </div>

                <div className="flex justify-end">
                  <Link
                    to="/forgot-password"
                    className="text-sm text-teal-600 hover:text-teal-700 hover:underline"
                  >
                    Forgot Password?
                  </Link>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 bg-teal-700 hover:bg-teal-800 text-white text-base font-medium"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    'Login'
                  )}
                </Button>
              </form>

              <p className="text-center text-sm text-slate-500 mt-6">
                By signing in, you agree to our{' '}
                <Link to="#" className="text-teal-600 hover:underline">Terms</Link>
                {' '}and{' '}
                <Link to="#" className="text-teal-600 hover:underline">Privacy Policy</Link>
              </p>
            </CardContent>
          </Card>

          <p className="text-center text-sm text-slate-400 mt-6">
            © {new Date().getFullYear()} ExamExpress University. All rights reserved.
          </p>

          {/* First-time setup button */}
          <div className="text-center mt-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSeedAdmin}
              disabled={isSeeding}
              className="text-slate-400 hover:text-teal-600 text-xs"
            >
              {isSeeding ? (
                <>
                  <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  Setting up...
                </>
              ) : (
                <>
                  <Settings className="mr-1 h-3 w-3" />
                  First-time Setup
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
