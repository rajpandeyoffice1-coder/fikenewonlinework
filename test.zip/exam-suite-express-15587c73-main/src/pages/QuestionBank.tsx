import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { QuestionBankPage } from "@/components/question-bank/QuestionBankPage";

const QuestionBank = () => {
  return (
    <DashboardLayout>
      <QuestionBankPage />
    </DashboardLayout>
  );
};

export default QuestionBank;
