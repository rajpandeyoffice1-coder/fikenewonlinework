import { ExamWizard } from "@/components/exam-wizard/ExamWizard";

const CreateExam = () => {
  return <ExamWizard />;
};

export default CreateExam;
