import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { StudentGroupsPage } from "@/components/student-groups/StudentGroupsPage";

const StudentGroups = () => {
  return (
    <DashboardLayout>
      <StudentGroupsPage />
    </DashboardLayout>
  );
};

export default StudentGroups;
