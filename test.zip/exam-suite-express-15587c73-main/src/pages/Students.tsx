import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StudentsPage } from '@/components/students/StudentsPage';

const Students = () => {
  return (
    <DashboardLayout>
      <StudentsPage />
    </DashboardLayout>
  );
};

export default Students;
