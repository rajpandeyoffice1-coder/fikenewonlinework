import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { ExamDetailsPage } from "@/components/exams/ExamDetailsPage";

const ExamDetails = () => {
  return (
    <DashboardLayout>
      <ExamDetailsPage />
    </DashboardLayout>
  );
};

export default ExamDetails;
