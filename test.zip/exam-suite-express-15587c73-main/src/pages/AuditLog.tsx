import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { AuditLogPage } from '@/components/audit-log/AuditLogPage';

const AuditLog = () => {
  return (
    <DashboardLayout>
      <AuditLogPage />
    </DashboardLayout>
  );
};

export default AuditLog;
