import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Bell,
  Monitor,
  Volume2,
  Shield,
  Save,
} from "lucide-react";
import { toast } from "sonner";

export function ProctorSettings() {
  const [settings, setSettings] = useState({
    // Notification Settings
    soundAlerts: true,
    desktopNotifications: true,
    emailAlerts: false,
    alertThreshold: 'medium',
    
    // Display Settings
    defaultGrid: '3x3',
    autoRefresh: true,
    refreshInterval: '30',
    darkMode: true,
    
    // Monitoring Settings
    autoFlagThreshold: 3,
    showCandidateInfo: true,
    recordSessions: true,
  });

  const handleSave = () => {
    toast.success("Settings saved successfully");
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Proctor Settings</h1>
        <p className="text-slate-400">Configure your proctoring preferences</p>
      </div>

      {/* Notification Settings */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Configure how you receive alerts and notifications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Sound Alerts</Label>
              <p className="text-sm text-slate-400">Play sound when new incident detected</p>
            </div>
            <Switch
              checked={settings.soundAlerts}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, soundAlerts: checked }))}
            />
          </div>
          <Separator className="bg-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Desktop Notifications</Label>
              <p className="text-sm text-slate-400">Show browser notifications for alerts</p>
            </div>
            <Switch
              checked={settings.desktopNotifications}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, desktopNotifications: checked }))}
            />
          </div>
          <Separator className="bg-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Email Alerts</Label>
              <p className="text-sm text-slate-400">Send email for high-priority incidents</p>
            </div>
            <Switch
              checked={settings.emailAlerts}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, emailAlerts: checked }))}
            />
          </div>
          <Separator className="bg-slate-700" />
          <div className="space-y-2">
            <Label className="text-white">Alert Threshold</Label>
            <Select 
              value={settings.alertThreshold} 
              onValueChange={(value) => setSettings(prev => ({ ...prev, alertThreshold: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="low">Low - All alerts</SelectItem>
                <SelectItem value="medium">Medium - Medium & High only</SelectItem>
                <SelectItem value="high">High - High priority only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Display Settings */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Monitor className="h-5 w-5" />
            Display Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Customize the monitoring interface
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white">Default Grid Layout</Label>
            <Select 
              value={settings.defaultGrid} 
              onValueChange={(value) => setSettings(prev => ({ ...prev, defaultGrid: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="2x2">2x2 (4 candidates)</SelectItem>
                <SelectItem value="3x3">3x3 (9 candidates)</SelectItem>
                <SelectItem value="4x4">4x4 (16 candidates)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Separator className="bg-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Auto-Refresh Streams</Label>
              <p className="text-sm text-slate-400">Automatically refresh video feeds</p>
            </div>
            <Switch
              checked={settings.autoRefresh}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, autoRefresh: checked }))}
            />
          </div>
          {settings.autoRefresh && (
            <div className="space-y-2">
              <Label className="text-white">Refresh Interval (seconds)</Label>
              <Input
                type="number"
                value={settings.refreshInterval}
                onChange={(e) => setSettings(prev => ({ ...prev, refreshInterval: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white w-32"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Monitoring Settings */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Monitoring Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Configure monitoring behavior
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label className="text-white">Auto-Flag Threshold</Label>
            <p className="text-sm text-slate-400 mb-2">
              Number of warnings before auto-flagging candidate
            </p>
            <Input
              type="number"
              value={settings.autoFlagThreshold}
              onChange={(e) => setSettings(prev => ({ ...prev, autoFlagThreshold: parseInt(e.target.value) }))}
              className="bg-slate-700 border-slate-600 text-white w-32"
            />
          </div>
          <Separator className="bg-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Show Candidate Info</Label>
              <p className="text-sm text-slate-400">Display name and roll number on tiles</p>
            </div>
            <Switch
              checked={settings.showCandidateInfo}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, showCandidateInfo: checked }))}
            />
          </div>
          <Separator className="bg-slate-700" />
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Record Sessions</Label>
              <p className="text-sm text-slate-400">Save session recordings for evidence</p>
            </div>
            <Switch
              checked={settings.recordSessions}
              onCheckedChange={(checked) => setSettings(prev => ({ ...prev, recordSessions: checked }))}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
}
