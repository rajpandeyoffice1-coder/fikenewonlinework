import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Monitor, 
  Users, 
  AlertTriangle, 
  ClipboardList,
  Play,
  Eye,
  Calendar,
  Clock,
  Loader2,
  Wifi,
  WifiOff,
  Bell
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useRealtimeIncidents } from "@/hooks/useRealtimeIncidents";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ProctorExam {
  id: string;
  name: string;
  date: string;
  time: string;
  totalCandidates: number;
  onlineCandidates: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  incidents: number;
}

export function ProctorDashboard() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [proctorExams, setProctorExams] = useState<ProctorExam[]>([]);
  
  // Real-time incidents hook
  const { 
    incidents: realtimeIncidents, 
    newIncidentCount, 
    isConnected, 
    clearNewCount 
  } = useRealtimeIncidents({ enabled: true, showToasts: true });
  
  useEffect(() => {
    const fetchExams = async () => {
      setIsLoading(true);
      
      const { data: exams } = await supabase
        .from('exams')
        .select('*')
        .order('start_date', { ascending: false })
        .limit(5);
      
      if (exams) {
        const mappedExams: ProctorExam[] = exams.map(exam => {
          const startDate = exam.start_date ? new Date(exam.start_date) : new Date();
          const now = new Date();
          const endDate = exam.end_date ? new Date(exam.end_date) : new Date(startDate.getTime() + exam.duration * 60000);
          
          let status: 'upcoming' | 'ongoing' | 'completed' = 'upcoming';
          if (now >= startDate && now <= endDate) status = 'ongoing';
          else if (now > endDate) status = 'completed';
          
          return {
            id: exam.id,
            name: exam.title,
            date: startDate.toISOString().split('T')[0],
            time: startDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            totalCandidates: Math.floor(Math.random() * 50) + 20,
            onlineCandidates: status === 'ongoing' ? Math.floor(Math.random() * 40) + 10 : 0,
            status,
            incidents: 0,
          };
        });
        setProctorExams(mappedExams);
      }
      
      setIsLoading(false);
    };
    
    fetchExams();
  }, []);

  const stats = {
    ongoingExams: proctorExams.filter(e => e.status === 'ongoing').length,
    candidatesOnline: proctorExams.reduce((acc, e) => acc + e.onlineCandidates, 0),
    incidentsToday: realtimeIncidents.filter(i => {
      const today = new Date().toDateString();
      return new Date(i.timestamp).toDateString() === today;
    }).length,
    pendingReviews: realtimeIncidents.filter(i => i.severity === 'high').length,
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ongoing':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Ongoing</Badge>;
      case 'upcoming':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Upcoming</Badge>;
      case 'completed':
        return <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">Completed</Badge>;
      default:
        return null;
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High</Badge>;
      case 'medium':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Medium</Badge>;
      case 'low':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Low</Badge>;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Proctor Dashboard</h1>
          <p className="text-slate-400">Monitor and manage your assigned examinations</p>
        </div>
        <div className="flex items-center gap-2">
          {isConnected ? (
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 flex items-center gap-1">
              <Wifi className="h-3 w-3" />
              Live
            </Badge>
          ) : (
            <Badge className="bg-red-500/20 text-red-400 border-red-500/30 flex items-center gap-1">
              <WifiOff className="h-3 w-3" />
              Disconnected
            </Badge>
          )}
          {newIncidentCount > 0 && (
            <Badge className="bg-red-500 text-white animate-pulse flex items-center gap-1">
              <Bell className="h-3 w-3" />
              {newIncidentCount} New
            </Badge>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Ongoing Exams</p>
                <p className="text-3xl font-bold text-white">{stats.ongoingExams}</p>
              </div>
              <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Monitor className="h-6 w-6 text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Candidates Online</p>
                <p className="text-3xl font-bold text-white">{stats.candidatesOnline}</p>
              </div>
              <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Incidents Today</p>
                <p className="text-3xl font-bold text-white">{stats.incidentsToday}</p>
              </div>
              <div className="h-12 w-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">High Severity</p>
                <p className="text-3xl font-bold text-white">{stats.pendingReviews}</p>
              </div>
              <div className="h-12 w-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                <ClipboardList className="h-6 w-6 text-red-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Exam List */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Assigned Examinations</CardTitle>
          </CardHeader>
          <CardContent>
            {proctorExams.length === 0 ? (
              <p className="text-center text-slate-400 py-8">No exams assigned yet.</p>
            ) : (
              <div className="space-y-4">
                {proctorExams.map((exam) => (
                  <div
                    key={exam.id}
                    className="bg-slate-700/50 rounded-lg p-4 flex flex-col gap-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold text-white">{exam.name}</h3>
                        {getStatusBadge(exam.status)}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm text-slate-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {exam.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {exam.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {exam.onlineCandidates}/{exam.totalCandidates}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      {exam.status === 'ongoing' && (
                        <Button 
                          size="sm"
                          onClick={() => navigate('/proctor-portal/live')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Enter Live
                        </Button>
                      )}
                      <Button 
                        size="sm"
                        variant="outline" 
                        onClick={() => navigate('/proctor-portal/incidents')}
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Incidents
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Real-time Incident Feed */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-400" />
              Live Incident Feed
              {newIncidentCount > 0 && (
                <Badge className="bg-red-500 text-white ml-2">{newIncidentCount}</Badge>
              )}
            </CardTitle>
            {newIncidentCount > 0 && (
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={clearNewCount}
                className="text-slate-400 hover:text-white"
              >
                Mark Read
              </Button>
            )}
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] pr-4">
              {realtimeIncidents.length === 0 ? (
                <div className="text-center text-slate-400 py-8">
                  <AlertTriangle className="h-12 w-12 mx-auto mb-2 opacity-30" />
                  <p>No incidents recorded</p>
                  <p className="text-sm">Incidents will appear here in real-time</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {realtimeIncidents.slice(0, 20).map((incident) => (
                    <div
                      key={incident.id}
                      className={`bg-slate-700/50 rounded-lg p-3 border-l-4 ${
                        incident.severity === 'high' 
                          ? 'border-l-red-500' 
                          : incident.severity === 'medium'
                          ? 'border-l-amber-500'
                          : 'border-l-blue-500'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white text-sm">
                              {incident.incident_type.replace(/_/g, ' ').toUpperCase()}
                            </span>
                            {getSeverityBadge(incident.severity)}
                          </div>
                          <p className="text-sm text-slate-300 truncate">
                            {incident.student_name || 'Unknown Student'}
                          </p>
                          <p className="text-xs text-slate-400 mt-1">
                            {incident.message}
                          </p>
                        </div>
                        <span className="text-xs text-slate-500 whitespace-nowrap">
                          {new Date(incident.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      {incident.exam_title && (
                        <p className="text-xs text-slate-500 mt-2">
                          Exam: {incident.exam_title}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
