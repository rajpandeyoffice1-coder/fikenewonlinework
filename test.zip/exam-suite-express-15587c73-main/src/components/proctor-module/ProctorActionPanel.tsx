import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  MessageSquare,
  Send,
  AlertTriangle,
  Pause,
  XCircle,
  Image,
  Check,
  CheckCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { predefinedWarnings, ChatMessage, MonitoredCandidate } from "@/types/proctorModule";
import { toast } from "sonner";

interface ProctorActionPanelProps {
  candidateId: string;
  candidate?: MonitoredCandidate;
  onClose: () => void;
}

export function ProctorActionPanel({ candidateId, candidate: propCandidate, onClose }: ProctorActionPanelProps) {
  const [activeTab, setActiveTab] = useState("warning");
  const [selectedWarning, setSelectedWarning] = useState("");
  const [customWarning, setCustomWarning] = useState("");
  const [pauseReason, setPauseReason] = useState("");
  const [endReason, setEndReason] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const [showPauseConfirm, setShowPauseConfirm] = useState(false);
  const [showEndConfirm, setShowEndConfirm] = useState(false);

  // Use provided candidate or create placeholder
  const candidate: MonitoredCandidate = propCandidate || {
    id: candidateId,
    name: 'Unknown Candidate',
    rollNumber: candidateId,
    photo: '',
    status: 'normal',
    examProgress: 0,
    lastActivity: new Date().toISOString(),
    incidents: 0,
    isOnline: true,
  };

  // Mock chat messages
  const [messages] = useState<ChatMessage[]>([
    {
      id: '1',
      senderId: 'proctor',
      senderType: 'proctor',
      message: 'Please ensure your face is visible in the camera.',
      timestamp: '10:15 AM',
      read: true,
    },
    {
      id: '2',
      senderId: candidateId,
      senderType: 'candidate',
      message: 'Sorry, I have adjusted my camera position.',
      timestamp: '10:16 AM',
      read: true,
    },
  ]);

  const handleSendWarning = () => {
    const warningText = selectedWarning || customWarning;
    if (!warningText) {
      toast.error("Please select or enter a warning message");
      return;
    }
    toast.success(`Warning sent to ${candidate.name}`);
    setSelectedWarning("");
    setCustomWarning("");
  };

  const handlePauseExam = () => {
    if (!pauseReason) {
      toast.error("Please provide a reason for pausing");
      return;
    }
    setShowPauseConfirm(true);
  };

  const confirmPause = () => {
    toast.success(`Exam paused for ${candidate.name}`);
    setShowPauseConfirm(false);
    setPauseReason("");
    onClose();
  };

  const handleEndExam = () => {
    if (!endReason) {
      toast.error("Please provide a reason for ending the exam");
      return;
    }
    setShowEndConfirm(true);
  };

  const confirmEnd = () => {
    toast.success(`Exam ended for ${candidate.name}`);
    setShowEndConfirm(false);
    setEndReason("");
    onClose();
  };

  const handleSendChat = () => {
    if (!chatMessage.trim()) return;
    toast.success("Message sent");
    setChatMessage("");
  };

  return (
    <>
      <Dialog open onOpenChange={onClose}>
        <DialogContent className="max-w-md bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Proctor Actions</DialogTitle>
            <p className="text-sm text-slate-400">{candidate.name} • {candidate.rollNumber}</p>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-slate-700 w-full grid grid-cols-4">
              <TabsTrigger value="warning" className="data-[state=active]:bg-blue-600 text-xs">
                <AlertTriangle className="h-4 w-4" />
              </TabsTrigger>
              <TabsTrigger value="pause" className="data-[state=active]:bg-blue-600 text-xs">
                <Pause className="h-4 w-4" />
              </TabsTrigger>
              <TabsTrigger value="end" className="data-[state=active]:bg-blue-600 text-xs">
                <XCircle className="h-4 w-4" />
              </TabsTrigger>
              <TabsTrigger value="chat" className="data-[state=active]:bg-blue-600 text-xs">
                <MessageSquare className="h-4 w-4" />
              </TabsTrigger>
            </TabsList>

            {/* Send Warning Tab */}
            <TabsContent value="warning" className="space-y-4 mt-4">
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Predefined Warning</label>
                <Select value={selectedWarning} onValueChange={setSelectedWarning}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Select a warning..." />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {predefinedWarnings.map((warning, idx) => (
                      <SelectItem key={idx} value={warning} className="text-white">
                        {warning}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Or Custom Warning</label>
                <Textarea
                  value={customWarning}
                  onChange={(e) => setCustomWarning(e.target.value)}
                  placeholder="Type your warning message..."
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  rows={3}
                />
              </div>
              <Button 
                onClick={handleSendWarning} 
                className="w-full bg-amber-600 hover:bg-amber-700"
              >
                <Send className="h-4 w-4 mr-2" />
                Send Warning
              </Button>
            </TabsContent>

            {/* Pause Exam Tab */}
            <TabsContent value="pause" className="space-y-4 mt-4">
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                <p className="text-sm text-amber-400">
                  Pausing will temporarily stop the candidate's exam timer. They will not be able to submit answers until resumed.
                </p>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Reason for Pausing *</label>
                <Textarea
                  value={pauseReason}
                  onChange={(e) => setPauseReason(e.target.value)}
                  placeholder="Enter reason..."
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  rows={3}
                />
              </div>
              <Button 
                onClick={handlePauseExam} 
                className="w-full bg-yellow-600 hover:bg-yellow-700"
              >
                <Pause className="h-4 w-4 mr-2" />
                Pause Exam
              </Button>
            </TabsContent>

            {/* End Exam Tab */}
            <TabsContent value="end" className="space-y-4 mt-4">
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <p className="text-sm text-red-400">
                  <strong>Warning:</strong> This action is irreversible. The candidate's exam will be immediately terminated and their current answers will be submitted.
                </p>
              </div>
              <div>
                <label className="text-sm text-slate-400 mb-2 block">Reason for Ending *</label>
                <Textarea
                  value={endReason}
                  onChange={(e) => setEndReason(e.target.value)}
                  placeholder="Enter reason (required)..."
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  rows={3}
                />
              </div>
              <Button 
                onClick={handleEndExam} 
                variant="destructive"
                className="w-full"
              >
                <XCircle className="h-4 w-4 mr-2" />
                End Exam
              </Button>
            </TabsContent>

            {/* Chat Tab */}
            <TabsContent value="chat" className="mt-4">
              <ScrollArea className="h-64 bg-slate-700/50 rounded-lg p-3 mb-3">
                <div className="space-y-3">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={cn(
                        "max-w-[80%] p-3 rounded-lg",
                        msg.senderType === 'proctor'
                          ? "bg-blue-600 ml-auto"
                          : "bg-slate-600"
                      )}
                    >
                      <p className="text-sm text-white">{msg.message}</p>
                      <div className="flex items-center justify-end gap-1 mt-1">
                        <span className="text-xs text-slate-300">{msg.timestamp}</span>
                        {msg.senderType === 'proctor' && (
                          msg.read ? (
                            <CheckCheck className="h-3 w-3 text-blue-300" />
                          ) : (
                            <Check className="h-3 w-3 text-slate-300" />
                          )
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  className="shrink-0 border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <Image className="h-4 w-4" />
                </Button>
                <Input
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                  onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                />
                <Button 
                  onClick={handleSendChat}
                  size="icon"
                  className="shrink-0 bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Pause Confirmation */}
      <AlertDialog open={showPauseConfirm} onOpenChange={setShowPauseConfirm}>
        <AlertDialogContent className="bg-slate-800 border-slate-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Confirm Pause Exam</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              Are you sure you want to pause the exam for {candidate.name}? The timer will be stopped until you resume.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-slate-700 text-white hover:bg-slate-600 border-slate-600">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmPause} className="bg-yellow-600 hover:bg-yellow-700">
              Pause Exam
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* End Confirmation */}
      <AlertDialog open={showEndConfirm} onOpenChange={setShowEndConfirm}>
        <AlertDialogContent className="bg-slate-800 border-slate-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Confirm End Exam</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              This action cannot be undone. The exam for {candidate.name} will be immediately terminated and their current answers will be submitted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-slate-700 text-white hover:bg-slate-600 border-slate-600">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmEnd} className="bg-red-600 hover:bg-red-700">
              End Exam
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
