import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Grid3X3,
  Maximize2,
  RefreshCw,
  User,
  AlertTriangle,
  MessageSquare,
  Pause,
  XCircle,
  Eye,
  Video,
  Wifi,
  WifiOff,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { MonitoredCandidate, Incident } from "@/types/proctorModule";
import { CandidateDetailModal } from "./CandidateDetailModal";

// Placeholder data
const mockMonitoredCandidates: MonitoredCandidate[] = [];
const mockIncidents: Incident[] = [];
import { ProctorActionPanel } from "./ProctorActionPanel";

type GridSize = '2x2' | '3x3' | '4x4';

export function LiveInvigilation() {
  const [gridSize, setGridSize] = useState<GridSize>('3x3');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);
  const [showActionPanel, setShowActionPanel] = useState(false);
  const [actionCandidate, setActionCandidate] = useState<string | null>(null);

  const filteredCandidates = mockMonitoredCandidates.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         candidate.rollNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || candidate.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getGridCols = () => {
    switch (gridSize) {
      case '2x2': return 'grid-cols-1 md:grid-cols-2';
      case '3x3': return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
      case '4x4': return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-500';
      case 'warning': return 'bg-amber-500';
      case 'flagged': return 'bg-red-500';
      case 'disconnected': return 'bg-slate-500';
      default: return 'bg-slate-500';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'normal':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Normal</Badge>;
      case 'warning':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Warning</Badge>;
      case 'flagged':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Flagged</Badge>;
      case 'disconnected':
        return <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">Disconnected</Badge>;
      default:
        return null;
    }
  };

  const recentAlerts = mockIncidents.slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Live Invigilation</h1>
          <p className="text-slate-400">Data Structures Final Exam • 42 candidates online</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
            <Maximize2 className="h-4 w-4 mr-2" />
            Full Screen
          </Button>
          <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        {/* Left Sidebar - Candidate List */}
        <Card className="bg-slate-800 border-slate-700 w-72 shrink-0 hidden lg:block">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm">Candidates</CardTitle>
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="flagged">Flagged</SelectItem>
                  <SelectItem value="disconnected">Disconnected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[calc(100vh-320px)]">
              <div className="space-y-1 p-3">
                {filteredCandidates.map((candidate) => (
                  <button
                    key={candidate.id}
                    onClick={() => setSelectedCandidate(candidate.id)}
                    className={cn(
                      "w-full flex items-center gap-3 p-2 rounded-lg text-left transition-colors",
                      selectedCandidate === candidate.id
                        ? "bg-blue-600"
                        : "hover:bg-slate-700"
                    )}
                  >
                    <div className="relative">
                      <div className="h-8 w-8 bg-slate-600 rounded-full flex items-center justify-center">
                        <User className="h-4 w-4 text-slate-300" />
                      </div>
                      <div className={cn(
                        "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-slate-800",
                        getStatusColor(candidate.status)
                      )} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{candidate.name}</p>
                      <p className="text-xs text-slate-400">{candidate.rollNumber}</p>
                    </div>
                    {candidate.incidents > 0 && (
                      <span className="text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded">
                        {candidate.incidents}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Main Grid Area */}
        <div className="flex-1 space-y-4">
          {/* Grid Controls */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-400">Grid:</span>
            {(['2x2', '3x3', '4x4'] as GridSize[]).map((size) => (
              <Button
                key={size}
                variant={gridSize === size ? 'default' : 'outline'}
                size="sm"
                onClick={() => setGridSize(size)}
                className={cn(
                  gridSize === size
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'border-slate-600 text-slate-300 hover:bg-slate-700'
                )}
              >
                {size}
              </Button>
            ))}
          </div>

          {/* Candidate Grid */}
          <div className={cn("grid gap-4", getGridCols())}>
            {filteredCandidates.slice(0, gridSize === '2x2' ? 4 : gridSize === '3x3' ? 9 : 16).map((candidate) => (
              <Card key={candidate.id} className="bg-slate-800 border-slate-700 overflow-hidden group">
                <div className="relative aspect-video bg-slate-900">
                  {/* Mock Video Feed */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    {candidate.isOnline ? (
                      <Video className="h-12 w-12 text-slate-600" />
                    ) : (
                      <WifiOff className="h-12 w-12 text-slate-600" />
                    )}
                  </div>
                  
                  {/* Status Indicator */}
                  <div className={cn(
                    "absolute top-2 left-2 h-3 w-3 rounded-full animate-pulse",
                    getStatusColor(candidate.status)
                  )} />
                  
                  {/* Hover Actions */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setSelectedCandidate(candidate.id)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => {
                        setActionCandidate(candidate.id);
                        setShowActionPanel(true);
                      }}
                    >
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="text-amber-400">
                      <Pause className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="text-red-400">
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-white">{candidate.name}</p>
                      <p className="text-xs text-slate-400">{candidate.rollNumber}</p>
                    </div>
                    {getStatusBadge(candidate.status)}
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
                    <span>Progress: {candidate.examProgress}%</span>
                    <span className="flex items-center gap-1">
                      {candidate.isOnline ? (
                        <>
                          <Wifi className="h-3 w-3 text-green-400" />
                          Online
                        </>
                      ) : (
                        <>
                          <WifiOff className="h-3 w-3 text-red-400" />
                          Offline
                        </>
                      )}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Right Sidebar - Live Alerts */}
        <Card className="bg-slate-800 border-slate-700 w-80 shrink-0 hidden xl:block">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-400" />
              Live Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[calc(100vh-280px)]">
              <div className="space-y-2 p-3">
                {recentAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={cn(
                      "p-3 rounded-lg border-l-4",
                      alert.severity === 'high' 
                        ? "bg-red-500/10 border-red-500" 
                        : alert.severity === 'medium'
                        ? "bg-amber-500/10 border-amber-500"
                        : "bg-blue-500/10 border-blue-500"
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium text-white">{alert.candidateName}</p>
                        <p className="text-xs text-slate-400">{alert.type.replace(/_/g, ' ')}</p>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-xs",
                          alert.severity === 'high' 
                            ? "border-red-500 text-red-400" 
                            : alert.severity === 'medium'
                            ? "border-amber-500 text-amber-400"
                            : "border-blue-500 text-blue-400"
                        )}
                      >
                        {alert.severity}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">{alert.timestamp}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Candidate Detail Modal */}
      {selectedCandidate && (
        <CandidateDetailModal
          candidateId={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
          onAction={(action) => {
            setActionCandidate(selectedCandidate);
            setShowActionPanel(true);
          }}
        />
      )}

      {/* Proctor Action Panel */}
      {showActionPanel && actionCandidate && (
        <ProctorActionPanel
          candidateId={actionCandidate}
          onClose={() => {
            setShowActionPanel(false);
            setActionCandidate(null);
          }}
        />
      )}
    </div>
  );
}
