import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  Bell,
  AlertTriangle,
  Users,
  Eye,
  Play,
  CheckCircle,
  TrendingUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Incident, ProctorExam } from "@/types/proctorModule";
import { useNavigate } from "react-router-dom";

// Placeholder data
const mockIncidents: Incident[] = [];
const mockProctorExams: ProctorExam[] = [];

export function GlobalAlerts() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({
    search: '',
    type: 'all',
    severity: 'all',
    exam: 'all',
  });

  const filteredAlerts = mockIncidents.filter(incident => {
    const matchesSearch = incident.candidateName.toLowerCase().includes(filters.search.toLowerCase());
    const matchesType = filters.type === 'all' || incident.type === filters.type;
    const matchesSeverity = filters.severity === 'all' || incident.severity === filters.severity;
    const matchesExam = filters.exam === 'all' || incident.examId === filters.exam;
    return matchesSearch && matchesType && matchesSeverity && matchesExam;
  });

  // Stats
  const stats = {
    totalAlerts: mockIncidents.length,
    highRisk: mockIncidents.filter(i => i.severity === 'high').length,
    multipleFlags: 2,
    unreviewed: mockIncidents.filter(i => !i.reviewed).length,
  };

  // Mock chart data
  const alertsByHour = [
    { hour: '9 AM', count: 2 },
    { hour: '10 AM', count: 5 },
    { hour: '11 AM', count: 3 },
    { hour: '12 PM', count: 1 },
  ];

  const alertsByCategory = [
    { category: 'Tab Switch', count: 3, color: 'bg-blue-500' },
    { category: 'Multiple Faces', count: 2, color: 'bg-red-500' },
    { category: 'Looking Away', count: 4, color: 'bg-amber-500' },
    { category: 'Audio Alert', count: 1, color: 'bg-purple-500' },
  ];

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High</Badge>;
      case 'medium':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Medium</Badge>;
      case 'low':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Low</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Global Alerts</h1>
        <p className="text-slate-400">Monitor all proctoring alerts across examinations</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Total Alerts Today</p>
                <p className="text-3xl font-bold text-white">{stats.totalAlerts}</p>
              </div>
              <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Bell className="h-6 w-6 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">High-Risk Incidents</p>
                <p className="text-3xl font-bold text-white">{stats.highRisk}</p>
              </div>
              <div className="h-12 w-12 bg-red-500/20 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-red-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Multiple Flags</p>
                <p className="text-3xl font-bold text-white">{stats.multipleFlags}</p>
              </div>
              <div className="h-12 w-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Unreviewed Alerts</p>
                <p className="text-3xl font-bold text-white">{stats.unreviewed}</p>
              </div>
              <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Eye className="h-6 w-6 text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Alerts by Hour */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Alerts by Hour
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between h-32 gap-4">
              {alertsByHour.map((item) => (
                <div key={item.hour} className="flex-1 flex flex-col items-center gap-2">
                  <div 
                    className="w-full bg-blue-500 rounded-t"
                    style={{ height: `${(item.count / 5) * 100}%` }}
                  />
                  <span className="text-xs text-slate-400">{item.hour}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Alerts by Category */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">Alerts by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alertsByCategory.map((item) => (
                <div key={item.category} className="flex items-center gap-3">
                  <div className={cn("h-3 w-3 rounded-full", item.color)} />
                  <span className="flex-1 text-sm text-slate-300">{item.category}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className={cn("h-full rounded-full", item.color)}
                        style={{ width: `${(item.count / 10) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-white w-6">{item.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search candidate..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-9 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>
            <Select 
              value={filters.type} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Alert Type" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="tab_switch">Tab Switch</SelectItem>
                <SelectItem value="multiple_faces">Multiple Faces</SelectItem>
                <SelectItem value="looking_away">Looking Away</SelectItem>
                <SelectItem value="audio_alert">Audio Alert</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.severity} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, severity: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Severity</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.exam} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, exam: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Exam" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Exams</SelectItem>
                {mockProctorExams.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>{exam.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Alerts Table */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">All Alerts ({filteredAlerts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-slate-700 hover:bg-transparent">
                <TableHead className="text-slate-400">Candidate</TableHead>
                <TableHead className="text-slate-400">Exam</TableHead>
                <TableHead className="text-slate-400">Alert Type</TableHead>
                <TableHead className="text-slate-400">Timestamp</TableHead>
                <TableHead className="text-slate-400">Severity</TableHead>
                <TableHead className="text-slate-400">Status</TableHead>
                <TableHead className="text-slate-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAlerts.map((alert) => (
                <TableRow key={alert.id} className="border-slate-700">
                  <TableCell>
                    <div>
                      <p className="text-white font-medium">{alert.candidateName}</p>
                      <p className="text-sm text-slate-400">{alert.candidateRollNumber}</p>
                    </div>
                  </TableCell>
                  <TableCell className="text-slate-300 text-sm">
                    {alert.examName}
                  </TableCell>
                  <TableCell className="text-slate-300">
                    {alert.type.replace(/_/g, ' ')}
                  </TableCell>
                  <TableCell className="text-slate-400 text-sm">
                    {alert.timestamp}
                  </TableCell>
                  <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                  <TableCell>
                    {alert.reviewed ? (
                      <Badge className="bg-green-500/20 text-green-400">Reviewed</Badge>
                    ) : (
                      <Badge className="bg-amber-500/20 text-amber-400">Pending</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
                        onClick={() => navigate('/proctor-portal/incidents')}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
                        onClick={() => navigate('/proctor-portal/evidence')}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      {!alert.reviewed && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-green-400 hover:text-green-300 hover:bg-slate-700"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
