import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import {
  User,
  MessageSquare,
  Pause,
  XCircle,
  AlertTriangle,
  Video,
  Monitor,
  Mic,
  Wifi,
  Clock,
  Globe,
  Laptop,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { MonitoredCandidate, Incident } from "@/types/proctorModule";

// Placeholder data
const mockMonitoredCandidates: MonitoredCandidate[] = [];
const mockIncidents: Incident[] = [];

interface CandidateDetailModalProps {
  candidateId: string;
  onClose: () => void;
  onAction: (action: string) => void;
}

export function CandidateDetailModal({ candidateId, onClose, onAction }: CandidateDetailModalProps) {
  const [activeTab, setActiveTab] = useState("live");
  
  const candidate = mockMonitoredCandidates.find(c => c.id === candidateId);
  const candidateIncidents = mockIncidents.filter(i => i.candidateId === candidateId);

  if (!candidate) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'normal':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Normal</Badge>;
      case 'warning':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Warning</Badge>;
      case 'flagged':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Flagged</Badge>;
      case 'disconnected':
        return <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">Disconnected</Badge>;
      default:
        return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-400 bg-red-500/10';
      case 'medium': return 'text-amber-400 bg-amber-500/10';
      case 'low': return 'text-blue-400 bg-blue-500/10';
      default: return 'text-slate-400 bg-slate-500/10';
    }
  };

  // Mock session data
  const sessionInfo = {
    startTime: '10:00 AM',
    lastActivity: candidate.lastActivity,
    browser: 'Chrome 120.0',
    device: 'Windows 11 - Desktop',
    ipAddress: '192.168.1.105',
    attemptCount: 1,
    networkQuality: 'good' as const,
  };

  // Mock current alerts
  const currentAlerts = [
    { type: 'Face detected', status: 'ok' },
    { type: 'Single face', status: candidate.status === 'flagged' ? 'warning' : 'ok' },
    { type: 'Looking at screen', status: candidate.status === 'warning' ? 'warning' : 'ok' },
    { type: 'No unauthorized device', status: 'ok' },
  ];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-slate-800 border-slate-700 text-white">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 bg-slate-600 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-slate-300" />
              </div>
              <div>
                <DialogTitle className="text-xl text-white">{candidate.name}</DialogTitle>
                <p className="text-slate-400">{candidate.rollNumber}</p>
              </div>
              {getStatusBadge(candidate.status)}
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onAction('warning')}
                className="border-amber-500 text-amber-400 hover:bg-amber-500/10"
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Warning
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onAction('pause')}
                className="border-yellow-500 text-yellow-400 hover:bg-yellow-500/10"
              >
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onAction('end')}
                className="border-red-500 text-red-400 hover:bg-red-500/10"
              >
                <XCircle className="h-4 w-4 mr-2" />
                End Exam
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="bg-slate-700">
            <TabsTrigger value="live" className="data-[state=active]:bg-blue-600">Live View</TabsTrigger>
            <TabsTrigger value="timeline" className="data-[state=active]:bg-blue-600">Timeline</TabsTrigger>
            <TabsTrigger value="session" className="data-[state=active]:bg-blue-600">Session Info</TabsTrigger>
          </TabsList>

          <TabsContent value="live" className="mt-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Main Video Feed */}
              <div className="space-y-4">
                <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center relative">
                  <Video className="h-16 w-16 text-slate-600" />
                  <div className="absolute top-2 left-2 flex items-center gap-2">
                    <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-xs text-slate-400">Live</span>
                  </div>
                </div>
                {/* Screen Share Preview */}
                <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center">
                  <Monitor className="h-10 w-10 text-slate-600" />
                  <span className="ml-2 text-slate-500 text-sm">Screen Share</span>
                </div>
              </div>

              {/* Alerts & Meters */}
              <div className="space-y-4">
                {/* Audio Level */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Mic className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-300">Audio Level</span>
                  </div>
                  <Progress value={35} className="h-2" />
                </div>

                {/* Network Quality */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Wifi className="h-4 w-4 text-green-400" />
                    <span className="text-sm text-slate-300">Network: Good</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>

                {/* Current Alerts */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-white mb-3">Current Status</h4>
                  <div className="space-y-2">
                    {currentAlerts.map((alert, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span className="text-slate-300">{alert.type}</span>
                        {alert.status === 'ok' ? (
                          <Badge className="bg-green-500/20 text-green-400 text-xs">OK</Badge>
                        ) : (
                          <Badge className="bg-amber-500/20 text-amber-400 text-xs">Warning</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="timeline" className="mt-4">
            <ScrollArea className="h-80">
              <div className="space-y-3">
                {candidateIncidents.length > 0 ? (
                  candidateIncidents.map((incident) => (
                    <div
                      key={incident.id}
                      className={cn(
                        "p-3 rounded-lg flex items-start gap-3",
                        getSeverityColor(incident.severity)
                      )}
                    >
                      <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{incident.type.replace(/_/g, ' ')}</span>
                          <Badge variant="outline" className="text-xs">
                            {incident.severity}
                          </Badge>
                        </div>
                        <p className="text-sm opacity-80 mt-1">{incident.description}</p>
                        <p className="text-xs opacity-60 mt-1">{incident.timestamp}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No incidents recorded</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="session" className="mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">Start Time</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.startTime}</p>
                </div>
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <RefreshCw className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">Last Activity</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.lastActivity}</p>
                </div>
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Globe className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">IP Address</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.ipAddress}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Globe className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">Browser</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.browser}</p>
                </div>
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Laptop className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">Device</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.device}</p>
                </div>
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <RefreshCw className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">Attempt Count</span>
                  </div>
                  <p className="text-white font-medium">{sessionInfo.attemptCount}</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
