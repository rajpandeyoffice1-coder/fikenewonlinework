import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Download,
  Camera,
  Volume2,
  Maximize2,
  AlertTriangle,
  User,
  MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { MonitoredCandidate, Incident } from "@/types/proctorModule";

// Placeholder data
const mockMonitoredCandidates: MonitoredCandidate[] = [];
const mockIncidents: Incident[] = [];
import { toast } from "sonner";

export function EvidenceReplay() {
  const [selectedCandidate, setSelectedCandidate] = useState(mockMonitoredCandidates[2].id);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState('1x');
  const [currentTime, setCurrentTime] = useState(30);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState<Array<{ time: string; text: string }>>([
    { time: '10:22:15', text: 'Multiple faces detected in frame' },
    { time: '10:25:45', text: 'Candidate looked away from screen' },
  ]);

  const candidate = mockMonitoredCandidates.find(c => c.id === selectedCandidate);
  const candidateIncidents = mockIncidents.filter(i => i.candidateId === selectedCandidate);

  // Mock timeline markers (positions 0-100)
  const timelineMarkers = [
    { position: 15, type: 'warning', label: 'Tab switch' },
    { position: 35, type: 'danger', label: 'Multiple faces' },
    { position: 55, type: 'warning', label: 'Looking away' },
    { position: 80, type: 'info', label: 'Audio spike' },
  ];

  const handleScreenshot = () => {
    toast.success("Screenshot captured");
  };

  const handleDownload = () => {
    toast.success("Download started");
  };

  const handleAddComment = () => {
    if (!comment.trim()) return;
    const timeStr = `${Math.floor(currentTime / 60)}:${(currentTime % 60).toString().padStart(2, '0')}`;
    setComments(prev => [...prev, { time: timeStr, text: comment }]);
    setComment('');
    toast.success("Comment added");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Evidence Replay</h1>
          <p className="text-slate-400">Review recorded proctoring sessions</p>
        </div>
        <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
          <SelectTrigger className="w-64 bg-slate-700 border-slate-600 text-white">
            <SelectValue placeholder="Select candidate" />
          </SelectTrigger>
          <SelectContent className="bg-slate-700 border-slate-600">
            {mockMonitoredCandidates.map((c) => (
              <SelectItem key={c.id} value={c.id} className="text-white">
                {c.name} ({c.rollNumber})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Video Player Section */}
        <div className="xl:col-span-2 space-y-4">
          {/* Header Info */}
          {candidate && (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 bg-slate-600 rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-slate-300" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{candidate.name}</h3>
                      <p className="text-sm text-slate-400">{candidate.rollNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-400">Data Structures Final Exam</p>
                    <p className="text-sm text-slate-500">2024-01-20 • 10:00 AM - 12:00 PM</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Video Player */}
          <Card className="bg-slate-900 border-slate-700 overflow-hidden">
            <div className="aspect-video bg-black relative">
              {/* Video placeholder */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Play className="h-16 w-16 text-slate-600 mx-auto mb-2" />
                  <p className="text-slate-500">Session Recording</p>
                </div>
              </div>
              
              {/* Play button overlay */}
              {!isPlaying && (
                <button
                  onClick={() => setIsPlaying(true)}
                  className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/40 transition-colors"
                >
                  <div className="h-20 w-20 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                    <Play className="h-10 w-10 text-white ml-1" />
                  </div>
                </button>
              )}
            </div>

            {/* Timeline with markers */}
            <div className="px-4 py-3 bg-slate-800/50 relative">
              <div className="relative h-2 bg-slate-700 rounded-full mb-2">
                {/* Progress bar */}
                <div 
                  className="absolute h-full bg-blue-500 rounded-full"
                  style={{ width: `${currentTime}%` }}
                />
                {/* Markers */}
                {timelineMarkers.map((marker, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full cursor-pointer",
                      marker.type === 'danger' && "bg-red-500",
                      marker.type === 'warning' && "bg-amber-500",
                      marker.type === 'info' && "bg-blue-500"
                    )}
                    style={{ left: `${marker.position}%` }}
                    title={marker.label}
                  />
                ))}
              </div>
              <Slider
                value={[currentTime]}
                onValueChange={([value]) => setCurrentTime(value)}
                max={100}
                step={1}
                className="cursor-pointer"
              />
              <div className="flex items-center justify-between mt-2 text-sm text-slate-400">
                <span>00:{currentTime.toString().padStart(2, '0')}</span>
                <span>02:00:00</span>
              </div>
            </div>

            {/* Controls */}
            <div className="px-4 py-3 bg-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                  onClick={() => setCurrentTime(Math.max(0, currentTime - 10))}
                >
                  <SkipBack className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-12 w-12 text-white hover:bg-slate-700"
                  onClick={() => setIsPlaying(!isPlaying)}
                >
                  {isPlaying ? (
                    <Pause className="h-6 w-6" />
                  ) : (
                    <Play className="h-6 w-6 ml-0.5" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                  onClick={() => setCurrentTime(Math.min(100, currentTime + 10))}
                >
                  <SkipForward className="h-5 w-5" />
                </Button>
                <Select value={playbackSpeed} onValueChange={setPlaybackSpeed}>
                  <SelectTrigger className="w-20 h-8 bg-slate-700 border-slate-600 text-white text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="0.5x">0.5x</SelectItem>
                    <SelectItem value="1x">1x</SelectItem>
                    <SelectItem value="1.5x">1.5x</SelectItem>
                    <SelectItem value="2x">2x</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <Volume2 className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                  onClick={handleScreenshot}
                >
                  <Camera className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                  onClick={handleDownload}
                >
                  <Download className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <Maximize2 className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </Card>

          {/* Legend */}
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 bg-green-500 rounded-full" />
              <span className="text-slate-400">Normal</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 bg-amber-500 rounded-full" />
              <span className="text-slate-400">Warning</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 bg-red-500 rounded-full" />
              <span className="text-slate-400">Flagged Event</span>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Incident Summary */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Incident Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Face Detection Score</span>
                <Badge className="bg-amber-500/20 text-amber-400">85%</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Audio Spikes Detected</span>
                <span className="text-white">3</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Tab Switches</span>
                <span className="text-white">2</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Total Alerts</span>
                <span className="text-white">{candidateIncidents.length}</span>
              </div>
            </CardContent>
          </Card>

          {/* Incidents List */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-400" />
                Flagged Events
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-48">
                <div className="space-y-2 p-4 pt-0">
                  {candidateIncidents.map((incident) => (
                    <button
                      key={incident.id}
                      className="w-full text-left p-2 rounded-lg bg-slate-700/50 hover:bg-slate-700 transition-colors"
                      onClick={() => {
                        // Jump to incident time
                        toast.info(`Jumping to ${incident.timestamp}`);
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-white">
                          {incident.type.replace(/_/g, ' ')}
                        </span>
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "text-xs",
                            incident.severity === 'high' && "border-red-500 text-red-400",
                            incident.severity === 'medium' && "border-amber-500 text-amber-400",
                            incident.severity === 'low' && "border-blue-500 text-blue-400"
                          )}
                        >
                          {incident.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{incident.timestamp}</p>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Comments Section */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Proctor Comments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <ScrollArea className="h-32">
                <div className="space-y-2">
                  {comments.map((c, idx) => (
                    <div key={idx} className="bg-slate-700/50 p-2 rounded-lg">
                      <p className="text-sm text-white">{c.text}</p>
                      <p className="text-xs text-slate-400 mt-1">@ {c.time}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="space-y-2">
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Add comment at current timestamp..."
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 text-sm"
                  rows={2}
                />
                <Button
                  size="sm"
                  onClick={handleAddComment}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Add Comment
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
