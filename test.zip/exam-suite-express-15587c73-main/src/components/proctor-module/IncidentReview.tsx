import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  Filter,
  Eye,
  CheckCircle,
  AlertTriangle,
  Download,
  Play,
  Image,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Incident } from "@/types/proctorModule";
import { toast } from "sonner";

export function IncidentReview() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [proctorNotes, setProctorNotes] = useState("");
  const [filters, setFilters] = useState({
    search: '',
    type: 'all',
    severity: 'all',
    status: 'all',
  });

  const filteredIncidents = incidents.filter(incident => {
    const matchesSearch = incident.candidateName.toLowerCase().includes(filters.search.toLowerCase()) ||
                         incident.candidateRollNumber.toLowerCase().includes(filters.search.toLowerCase());
    const matchesType = filters.type === 'all' || incident.type === filters.type;
    const matchesSeverity = filters.severity === 'all' || incident.severity === filters.severity;
    const matchesStatus = filters.status === 'all' || 
                         (filters.status === 'reviewed' && incident.reviewed) ||
                         (filters.status === 'pending' && !incident.reviewed);
    return matchesSearch && matchesType && matchesSeverity && matchesStatus;
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High</Badge>;
      case 'medium':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Medium</Badge>;
      case 'low':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Low</Badge>;
      default:
        return null;
    }
  };

  const handleMarkReviewed = (incidentId: string) => {
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, reviewed: true } : i
    ));
    toast.success("Incident marked as reviewed");
  };

  const handleMarkCheating = (incidentId: string) => {
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, markedAsCheating: true, reviewed: true } : i
    ));
    toast.success("Incident marked as cheating");
    setSelectedIncident(null);
  };

  const handleClearIncident = (incidentId: string) => {
    setIncidents(prev => prev.map(i => 
      i.id === incidentId ? { ...i, reviewed: true, markedAsCheating: false } : i
    ));
    toast.success("Incident cleared");
    setSelectedIncident(null);
  };

  const handleSaveNotes = () => {
    if (selectedIncident) {
      setIncidents(prev => prev.map(i => 
        i.id === selectedIncident.id ? { ...i, proctorNotes } : i
      ));
      toast.success("Notes saved");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Incident Review</h1>
        <p className="text-slate-400">Review and manage proctoring incidents</p>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search candidate..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-9 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>
            <Select 
              value={filters.type} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Incident Type" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="face_not_detected">Face Not Detected</SelectItem>
                <SelectItem value="multiple_faces">Multiple Faces</SelectItem>
                <SelectItem value="tab_switch">Tab Switch</SelectItem>
                <SelectItem value="audio_alert">Audio Alert</SelectItem>
                <SelectItem value="network_unstable">Network Unstable</SelectItem>
                <SelectItem value="looking_away">Looking Away</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.severity} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, severity: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Severity</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.status} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="reviewed">Reviewed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Incident Table */}
        <Card className="bg-slate-800 border-slate-700 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white">Incidents ({filteredIncidents.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-transparent">
                  <TableHead className="text-slate-400">Candidate</TableHead>
                  <TableHead className="text-slate-400">Type</TableHead>
                  <TableHead className="text-slate-400">Timestamp</TableHead>
                  <TableHead className="text-slate-400">Severity</TableHead>
                  <TableHead className="text-slate-400">Status</TableHead>
                  <TableHead className="text-slate-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredIncidents.map((incident) => (
                  <TableRow 
                    key={incident.id} 
                    className={cn(
                      "border-slate-700 cursor-pointer",
                      selectedIncident?.id === incident.id && "bg-slate-700/50"
                    )}
                    onClick={() => {
                      setSelectedIncident(incident);
                      setProctorNotes(incident.proctorNotes || '');
                    }}
                  >
                    <TableCell>
                      <div>
                        <p className="text-white font-medium">{incident.candidateName}</p>
                        <p className="text-sm text-slate-400">{incident.candidateRollNumber}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-300">
                      {incident.type.replace(/_/g, ' ')}
                    </TableCell>
                    <TableCell className="text-slate-400 text-sm">
                      {incident.timestamp}
                    </TableCell>
                    <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                    <TableCell>
                      {incident.reviewed ? (
                        incident.markedAsCheating ? (
                          <Badge className="bg-red-500/20 text-red-400">Cheating</Badge>
                        ) : (
                          <Badge className="bg-green-500/20 text-green-400">Reviewed</Badge>
                        )
                      ) : (
                        <Badge className="bg-amber-500/20 text-amber-400">Pending</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {incident.evidence && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
                          >
                            <Image className="h-4 w-4" />
                          </Button>
                        )}
                        {!incident.reviewed && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-green-400 hover:text-green-300 hover:bg-slate-700"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkReviewed(incident.id);
                            }}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Detail Panel */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Incident Details</CardTitle>
            {selectedIncident && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-slate-400 hover:text-white"
                onClick={() => setSelectedIncident(null)}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {selectedIncident ? (
              <div className="space-y-4">
                {/* Evidence Thumbnail */}
                <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Image className="h-12 w-12 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm text-slate-500">Evidence Preview</p>
                  </div>
                </div>

                {/* Incident Info */}
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-slate-400">Candidate</p>
                    <p className="text-white font-medium">{selectedIncident.candidateName}</p>
                    <p className="text-sm text-slate-400">{selectedIncident.candidateRollNumber}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Incident Type</p>
                    <p className="text-white">{selectedIncident.type.replace(/_/g, ' ')}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Description</p>
                    <p className="text-white text-sm">{selectedIncident.description}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Timestamp</p>
                    <p className="text-white text-sm">{selectedIncident.timestamp}</p>
                  </div>
                </div>

                {/* Proctor Notes */}
                <div>
                  <p className="text-sm text-slate-400 mb-2">Proctor Notes</p>
                  <Textarea
                    value={proctorNotes}
                    onChange={(e) => setProctorNotes(e.target.value)}
                    placeholder="Add your notes..."
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                    rows={3}
                  />
                  <Button
                    size="sm"
                    onClick={handleSaveNotes}
                    className="mt-2 bg-blue-600 hover:bg-blue-700"
                  >
                    Save Notes
                  </Button>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-4 border-t border-slate-700">
                  <Button
                    variant="outline"
                    className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                  <Button
                    onClick={() => handleClearIncident(selectedIncident.id)}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Clear
                  </Button>
                  <Button
                    onClick={() => handleMarkCheating(selectedIncident.id)}
                    variant="destructive"
                    className="flex-1"
                  >
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Cheating
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">
                <Eye className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>Select an incident to view details</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
