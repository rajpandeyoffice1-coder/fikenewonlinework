import { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { User, Mail, Phone, Hash, BookOpen, GraduationCap } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useWebcam } from '@/hooks/useWebcam';
import { useFaceDetection } from '@/hooks/useFaceDetection';
import { WebcamPreview } from './WebcamPreview';
import { FaceDetectionStatus } from './FaceDetectionStatus';
import { useStudentProfile, getInitials } from '@/hooks/useStudentProfile';
import { Skeleton } from '@/components/ui/skeleton';

export function ProfileVerification() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [isReady, setIsReady] = useState(false);
  const { profile, isLoading: profileLoading } = useStudentProfile();

  const { videoRef, isActive, isLoading: cameraLoading, error, startCamera, stopCamera } = useWebcam({
    video: { width: 640, height: 480, facingMode: 'user' },
    audio: false,
  });

  const { result: faceResult, isLoading: faceLoading, isModelLoaded } = useFaceDetection({
    videoElement: videoRef.current,
    enabled: isActive,
    detectionInterval: 500,
  });

  // Start camera on mount
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  // Enable start button when camera is active and face is detected
  useEffect(() => {
    if (isActive && isModelLoaded && faceResult.faceDetected && !faceResult.multipleFaces) {
      const timer = setTimeout(() => setIsReady(true), 1500);
      return () => clearTimeout(timer);
    } else {
      setIsReady(false);
    }
  }, [isActive, isModelLoaded, faceResult.faceDetected, faceResult.multipleFaces]);

  const handleStartExam = () => {
    stopCamera();
    navigate(`/student/exam/${examId}`);
  };

  const getButtonText = () => {
    if (profileLoading) return 'Loading profile...';
    if (!isActive) return 'Enable Camera to Continue';
    if (faceLoading || !isModelLoaded) return 'Loading face detection...';
    if (!faceResult.faceDetected) return 'Position your face in camera';
    if (faceResult.multipleFaces) return 'Only one person allowed';
    if (!isReady) return 'Verifying...';
    return 'Start Exam';
  };

  const initials = profile ? getInitials(profile.fullName) : '??';

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold">
              <span className="text-slate-800">exam</span>
              <span className="text-teal-600">express</span>
            </span>
            <span className="text-teal-600">↗</span>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/student/dashboard">
              <User className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Profile Verification */}
          <div>
            <h2 className="text-xl font-bold text-slate-800 mb-2">Profile Verification</h2>
            <p className="text-slate-500 mb-6">Verify your details before starting the exam</p>

            <Card className="border-0 shadow-md">
              <CardContent className="p-6">
                {profileLoading ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 mb-6">
                      <Skeleton className="h-14 w-14 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-10 w-full" />
                    ))}
                  </div>
                ) : profile ? (
                  <>
                    {/* Candidate Avatar */}
                    <div className="flex items-center gap-4 mb-6">
                      {profile.photoUrl ? (
                        <img
                          src={profile.photoUrl}
                          alt={profile.fullName}
                          className="h-14 w-14 rounded-full object-cover"
                        />
                      ) : (
                        <div className="h-14 w-14 rounded-full bg-teal-600 flex items-center justify-center text-white text-xl font-semibold">
                          {initials}
                        </div>
                      )}
                      <div>
                        <h3 className="font-semibold text-slate-800">{profile.fullName}</h3>
                        <p className="text-sm text-slate-500">Candidate</p>
                      </div>
                    </div>

                    {/* Profile Details */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                        <User className="h-4 w-4 text-slate-400" />
                        <span className="text-sm text-slate-500 w-36">Full Name</span>
                        <span className="text-sm text-slate-800 font-medium">
                          {profile.fullName}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                        <Hash className="h-4 w-4 text-slate-400" />
                        <span className="text-sm text-slate-500 w-36">Roll Number</span>
                        <span className="text-sm text-slate-800 font-medium">
                          {profile.rollNumber}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                        <Mail className="h-4 w-4 text-slate-400" />
                        <span className="text-sm text-slate-500 w-36">Email Address</span>
                        <span className="text-sm text-slate-800 font-medium">
                          {profile.email}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
                        <Phone className="h-4 w-4 text-slate-400" />
                        <span className="text-sm text-slate-500 w-36">Phone Number</span>
                        <span className="text-sm text-slate-800 font-medium">
                          {profile.mobile}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex gap-8">
                          <div className="flex items-center gap-2">
                            <BookOpen className="h-4 w-4 text-slate-400" />
                            <div>
                              <span className="text-sm text-slate-500">Department</span>
                              <p className="text-sm text-slate-800 font-medium">{profile.department}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <GraduationCap className="h-4 w-4 text-slate-400" />
                            <div>
                              <span className="text-sm text-slate-500">Semester</span>
                              <p className="text-sm text-slate-800 font-medium">
                                {profile.semester}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    Unable to load profile. Please try again.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Camera Verification */}
          <div>
            <h2 className="text-xl font-bold text-slate-800 mb-2">Camera Verification</h2>
            <p className="text-slate-500 mb-6">Ensure your face is clearly visible</p>

            <Card className="border-0 shadow-md">
              <CardContent className="p-6">
                {/* Live Camera Preview */}
                <div className="mb-6">
                  <WebcamPreview
                    videoRef={videoRef}
                    isActive={isActive}
                    isLoading={cameraLoading}
                    error={error}
                    className="aspect-video"
                    onStart={startCamera}
                  />
                </div>

                {/* Face Detection Status */}
                <FaceDetectionStatus
                  result={faceResult}
                  isLoading={faceLoading}
                  isModelLoaded={isModelLoaded}
                />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Start Exam Button */}
        <div className="flex justify-center mt-8">
          <Button
            onClick={handleStartExam}
            disabled={!isReady}
            className={`px-12 h-12 text-base font-medium ${
              isReady
                ? 'bg-red-500 hover:bg-red-600'
                : 'bg-slate-300 text-slate-500 cursor-not-allowed'
            }`}
          >
            {getButtonText()}
          </Button>
        </div>
      </div>
    </div>
  );
}
