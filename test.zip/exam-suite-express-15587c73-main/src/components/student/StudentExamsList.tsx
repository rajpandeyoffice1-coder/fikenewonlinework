import { Link } from 'react-router-dom';
import { Calendar, Clock, FileText, ChevronRight, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStudentExams } from '@/hooks/useStudentExams';
import { format } from 'date-fns';

export function StudentExamsList() {
  const { upcoming, ongoing, completed, isLoading, error } = useStudentExams();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const allUpcoming = [...ongoing, ...upcoming];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">My Exams</h1>
        <p className="text-muted-foreground">View and manage your examinations</p>
      </div>

      <Tabs defaultValue="upcoming" className="space-y-4">
        <TabsList>
          <TabsTrigger value="upcoming">
            Upcoming ({allUpcoming.length})
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed ({completed.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          <div className="space-y-4">
            {allUpcoming.length > 0 ? (
              allUpcoming.map((exam) => (
                <Card key={exam.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center">
                          <FileText className="h-7 w-7 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{exam.name}</h3>
                          <p className="text-muted-foreground">{exam.subject}</p>
                          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                            {exam.dateTime && (
                              <>
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-4 w-4" />
                                  {format(new Date(exam.dateTime), 'MMM dd, yyyy')}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Clock className="h-4 w-4" />
                                  {format(new Date(exam.dateTime), 'hh:mm a')}
                                </span>
                              </>
                            )}
                            <span>{exam.duration} mins</span>
                            <span>{exam.totalMarks} marks</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {(() => {
                          const now = new Date();
                          const startDate = exam.dateTime ? new Date(exam.dateTime) : null;
                          const endDate = startDate && exam.duration 
                            ? new Date(startDate.getTime() + exam.duration * 60 * 1000) 
                            : null;
                          const isWithinWindow = startDate && endDate && now >= startDate && now <= endDate;
                          const isLive = exam.status === 'ongoing' || isWithinWindow;
                          
                          if (isLive) {
                            return (
                              <>
                                <Badge className="bg-green-100 text-green-700">Live Now</Badge>
                                <Button asChild>
                                  <Link to={`/student/device-check/${exam.id}`}>
                                    Start Exam
                                    <ChevronRight className="h-4 w-4 ml-2" />
                                  </Link>
                                </Button>
                              </>
                            );
                          }
                          return (
                            <>
                              <Badge variant="secondary">Scheduled</Badge>
                              <Button variant="outline" disabled>
                                Not Yet Available
                              </Button>
                            </>
                          );
                        })()}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold">No upcoming exams</h3>
                  <p className="text-muted-foreground">
                    You don't have any scheduled examinations at the moment.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed">
          <div className="space-y-4">
            {completed.length > 0 ? (
              completed.map((exam) => (
                <Card key={exam.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={`h-14 w-14 rounded-xl flex items-center justify-center ${
                            exam.result === 'pass' ? 'bg-green-100' : exam.result === 'fail' ? 'bg-red-100' : 'bg-gray-100'
                          }`}
                        >
                          <FileText
                            className={`h-7 w-7 ${
                              exam.result === 'pass' ? 'text-green-600' : exam.result === 'fail' ? 'text-red-600' : 'text-gray-600'
                            }`}
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{exam.name}</h3>
                          <p className="text-muted-foreground">
                            {exam.completedAt && `Completed on ${format(new Date(exam.completedAt), 'MMM dd, yyyy')}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="secondary">Submitted</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-semibold">No completed exams</h3>
                  <p className="text-muted-foreground">
                    You haven't completed any examinations yet.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}