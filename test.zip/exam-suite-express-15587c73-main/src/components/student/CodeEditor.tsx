import { useState, useEffect, useRef } from 'react';
import Editor from '@monaco-editor/react';
import { Button } from '@/components/ui/button';
import { Play, Trash2, WrapText, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  maxLength?: number;
  onAutoSave?: () => void;
}

const CODE_MAX_CHARS = 20000;
const AUTO_SAVE_INTERVAL = 10000;

const languageMap: Record<string, string> = {
  javascript: 'javascript',
  js: 'javascript',
  python: 'python',
  py: 'python',
  java: 'java',
  cpp: 'cpp',
  'c++': 'cpp',
  c: 'c',
  typescript: 'typescript',
  ts: 'typescript',
  html: 'html',
  css: 'css',
  sql: 'sql',
  go: 'go',
  rust: 'rust',
  php: 'php',
  ruby: 'ruby',
  swift: 'swift',
  kotlin: 'kotlin',
};

export function CodeEditor({
  value,
  onChange,
  language = 'javascript',
  maxLength = CODE_MAX_CHARS,
  onAutoSave,
}: CodeEditorProps) {
  const [wordWrap, setWordWrap] = useState<'on' | 'off'>('off');
  const [isLoading, setIsLoading] = useState(true);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedRef = useRef<string>(value);

  const editorLanguage = languageMap[language.toLowerCase()] || 'javascript';

  // Auto-save every 10 seconds
  useEffect(() => {
    if (autoSaveTimerRef.current) {
      clearInterval(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setInterval(() => {
      if (value && value !== lastSavedRef.current && value.trim().length > 0) {
        lastSavedRef.current = value;
        onAutoSave?.();
        toast.success('Code auto-saved', { duration: 2000 });
      }
    }, AUTO_SAVE_INTERVAL);

    return () => {
      if (autoSaveTimerRef.current) {
        clearInterval(autoSaveTimerRef.current);
      }
    };
  }, [value, onAutoSave]);

  const handleEditorChange = (newValue: string | undefined) => {
    const code = newValue || '';
    if (code.length <= maxLength) {
      onChange(code);
    } else {
      onChange(code.slice(0, maxLength));
      toast.warning('Code length limit reached', {
        description: `Maximum ${maxLength.toLocaleString()} characters allowed.`,
      });
    }
  };

  const handleClear = () => {
    onChange('');
    toast.success('Code cleared');
  };

  const handleRunSample = () => {
    toast.info('Code execution', {
      description: 'Code execution is not available in exam mode. Submit your code for evaluation.',
    });
  };

  const charCount = value?.length || 0;
  const charPercentage = (charCount / maxLength) * 100;

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex items-center justify-between bg-slate-800 rounded-t-lg px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="text-slate-300 text-sm font-medium">
            {editorLanguage.toUpperCase()}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setWordWrap(wordWrap === 'on' ? 'off' : 'on')}
            className={cn(
              'text-slate-300 hover:text-white hover:bg-slate-700',
              wordWrap === 'on' && 'bg-slate-700'
            )}
          >
            <WrapText className="h-4 w-4 mr-1" />
            Wrap
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleRunSample}
            className="text-slate-300 hover:text-white hover:bg-slate-700"
          >
            <Play className="h-4 w-4 mr-1" />
            Run Sample
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleClear}
            className="text-red-400 hover:text-red-300 hover:bg-slate-700"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="relative border border-slate-700 rounded-b-lg overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900 z-10">
            <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
            <span className="ml-2 text-slate-300">Loading editor...</span>
          </div>
        )}
        <Editor
          height="400px"
          language={editorLanguage}
          theme="vs-dark"
          value={value}
          onChange={handleEditorChange}
          onMount={() => setIsLoading(false)}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            lineNumbers: 'on',
            wordWrap: wordWrap,
            automaticLayout: true,
            tabSize: 2,
            scrollBeyondLastLine: false,
            renderLineHighlight: 'line',
            padding: { top: 16, bottom: 16 },
            folding: true,
            bracketPairColorization: { enabled: true },
            suggestOnTriggerCharacters: true,
            quickSuggestions: true,
          }}
        />
      </div>

      {/* Character count */}
      <div className="flex justify-between items-center text-xs">
        <span className="text-slate-500">
          Code editor with syntax highlighting • Auto-saves every 10 seconds
        </span>
        <span
          className={cn(
            'font-medium',
            charPercentage >= 90
              ? 'text-red-500'
              : charPercentage >= 75
              ? 'text-amber-500'
              : 'text-slate-500'
          )}
        >
          {charCount.toLocaleString()} / {maxLength.toLocaleString()} characters
        </span>
      </div>

      {!value?.trim() && (
        <p className="text-sm text-red-500">Please enter your code.</p>
      )}
    </div>
  );
}
