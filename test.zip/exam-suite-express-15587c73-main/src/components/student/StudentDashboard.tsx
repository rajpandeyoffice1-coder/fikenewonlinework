import { Link } from 'react-router-dom';
import { Calendar, Clock, FileText, AlertCircle, ChevronRight, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useStudentExams } from '@/hooks/useStudentExams';
import { format } from 'date-fns';

export function StudentDashboard() {
  const { upcoming, ongoing, completed, student, isLoading, error } = useStudentExams();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="border-destructive bg-destructive/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <h3 className="font-semibold text-destructive">Error Loading Dashboard</h3>
                <p className="text-sm text-muted-foreground mt-1">{error}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const allExams = [...upcoming, ...ongoing];
  const upcomingCount = upcoming.length + ongoing.length;
  const completedCount = completed.length;

  const statsCards = [
    {
      title: 'Upcoming Exams',
      value: upcomingCount,
      icon: Calendar,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Completed Exams',
      value: completedCount,
      icon: FileText,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
  ];

  const studentName = student?.full_name?.split(' ')[0] || 'Student';

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Welcome back, {studentName}!</h1>
        {student && (
          <p className="text-muted-foreground">
            Roll Number: {student.roll_no} • {student.course} • Semester {student.semester}
          </p>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statsCards.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Upcoming/Ongoing Exams */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Upcoming Exams</CardTitle>
            <CardDescription>Your scheduled examinations</CardDescription>
          </div>
          <Button variant="outline" asChild>
            <Link to="/student/exams">View All</Link>
          </Button>
        </CardHeader>
        <CardContent>
          {allExams.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No upcoming exams scheduled</p>
            </div>
          ) : (
            <div className="space-y-4">
              {allExams.slice(0, 3).map((exam) => (
                <div
                  key={exam.id}
                  className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{exam.name}</h3>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                        {exam.dateTime && (
                          <>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3.5 w-3.5" />
                              {format(new Date(exam.dateTime), 'MMM dd, yyyy')}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3.5 w-3.5" />
                              {format(new Date(exam.dateTime), 'hh:mm a')}
                            </span>
                          </>
                        )}
                        <span>{exam.duration} mins</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {exam.status === 'ongoing' ? (
                      <Badge className="bg-green-100 text-green-700">Live Now</Badge>
                    ) : (
                      <Badge variant="secondary">Scheduled</Badge>
                    )}
                    <Button size="sm" asChild disabled={exam.status !== 'ongoing'}>
                      <Link to={`/student/device-check/${exam.id}`}>
                        {exam.status === 'ongoing' ? 'Start Exam' : 'Not Yet'}
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Completed Exams - No results shown */}
      {completed.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Completed Exams</CardTitle>
            <CardDescription>Your submitted examinations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {completed.slice(0, 3).map((exam) => (
                <div
                  key={exam.id}
                  className="flex items-center justify-between p-4 rounded-lg border bg-card"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-lg bg-green-100 flex items-center justify-center">
                      <FileText className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{exam.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {exam.completedAt && `Submitted on ${format(new Date(exam.completedAt), 'MMM dd, yyyy')}`}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary">Submitted</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Important Notice */}
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-amber-800">Important Notice</h3>
              <p className="text-sm text-amber-700 mt-1">
                Please ensure you complete the device check before starting any exam. Make sure your
                webcam, microphone, and internet connection are working properly.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}