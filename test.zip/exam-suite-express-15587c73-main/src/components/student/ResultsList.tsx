import { Link } from 'react-router-dom';
import { Trophy, ChevronRight, Download, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useStudentExams } from '@/hooks/useStudentExams';
import { format } from 'date-fns';

export function ResultsList() {
  const { completed, isLoading, error } = useStudentExams();

  // Filter to only show completed exams (not missed)
  const completedExams = completed.filter(e => e.status === 'completed');
  const passedCount = completedExams.filter(e => e.result === 'pass').length;
  const failedCount = completedExams.filter(e => e.result === 'fail').length;
  const avgPercentage = completedExams.length > 0 
    ? Math.round(completedExams.reduce((acc, e) => acc + (e.percentage || 0), 0) / completedExams.length) 
    : 0;

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <p className="text-destructive">{error}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Results</h1>
          <p className="text-muted-foreground">View your exam results and scorecards</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export All
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{completedExams.length}</div>
            <p className="text-sm text-muted-foreground">Total Exams</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-600">{passedCount}</div>
            <p className="text-sm text-muted-foreground">Passed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-red-600">{failedCount}</div>
            <p className="text-sm text-muted-foreground">Failed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{avgPercentage}%</div>
            <p className="text-sm text-muted-foreground">Average Score</p>
          </CardContent>
        </Card>
      </div>

      {/* Results Table */}
      <Card>
        <CardHeader>
          <CardTitle>Exam History</CardTitle>
          <CardDescription>All your completed examinations</CardDescription>
        </CardHeader>
        <CardContent>
          {completedExams.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
              <p>No completed exams yet</p>
              <p className="text-sm">Your exam results will appear here after completion</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Exam Name</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Percentage</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[100px]">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedExams.map((result) => (
                  <TableRow key={result.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div
                          className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                            result.result === 'pass' ? 'bg-green-100' : 'bg-red-100'
                          }`}
                        >
                          <Trophy
                            className={`h-5 w-5 ${
                              result.result === 'pass' ? 'text-green-600' : 'text-red-600'
                            }`}
                          />
                        </div>
                        <span className="font-medium">{result.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {result.completedAt 
                        ? format(new Date(result.completedAt), 'MMM dd, yyyy')
                        : '-'}
                    </TableCell>
                    <TableCell className="font-medium">
                      {result.score || 0}/{result.totalMarks}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <span>{result.percentage || 0}%</span>
                        <Progress value={result.percentage || 0} className="w-20 h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={result.result === 'pass' ? 'default' : 'destructive'}
                        className={result.result === 'pass' ? 'bg-green-100 text-green-700' : ''}
                      >
                        {result.result === 'pass' ? 'Passed' : result.result === 'fail' ? 'Failed' : 'Pending'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" asChild>
                        <Link to={`/student/results/${result.id}`}>
                          View
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
