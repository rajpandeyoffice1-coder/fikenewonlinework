import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Check, Loader2, AlertCircle, Upload, Camera } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { submitExam } from '@/hooks/useStudentExams';
import { useProctoringStorage } from '@/hooks/useProctoringStorage';
import { CapturedScreenshot } from '@/hooks/useScreenshotCapture';
import { toast } from 'sonner';

interface LocationState {
  examDuration?: number;
  answeredCount?: number;
  totalQuestions?: number;
  sessionId?: string;
  studentId?: string;
  forcedSubmit?: boolean;
  screenshotsToUpload?: CapturedScreenshot[];
}

interface UploadProgress {
  total: number;
  uploaded: number;
  failed: number;
  status: 'pending' | 'uploading' | 'complete' | 'error';
}

export function ExamSubmission() {
  const location = useLocation();
  const state = location.state as LocationState;
  const { saveScreenshot } = useProctoringStorage();

  const [isSubmitting, setIsSubmitting] = useState(true);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({
    total: state?.screenshotsToUpload?.length || 0,
    uploaded: 0,
    failed: 0,
    status: 'pending',
  });
  
  // Track if upload has started to prevent duplicates
  const uploadStartedRef = useRef(false);

  // Submit exam on mount
  useEffect(() => {
    const doSubmit = async () => {
      if (!state?.sessionId) {
        setSubmitError('No session ID found');
        setIsSubmitting(false);
        return;
      }

      const response = await submitExam(state.sessionId);
      
      if (response.success) {
        toast.success('Exam submitted successfully!');
      } else {
        setSubmitError(response.error || 'Failed to submit exam');
        toast.error(response.error || 'Failed to submit exam');
      }
      setIsSubmitting(false);
    };

    doSubmit();
  }, [state?.sessionId]);

  // Upload screenshots in background after exam is submitted
  useEffect(() => {
    const uploadScreenshots = async () => {
      const screenshots = state?.screenshotsToUpload;
      const sessionId = state?.sessionId;
      const studentId = state?.studentId;

      if (!screenshots || screenshots.length === 0 || !sessionId || !studentId) {
        setUploadProgress(prev => ({ ...prev, status: 'complete' }));
        return;
      }

      if (uploadStartedRef.current) return;
      uploadStartedRef.current = true;

      setUploadProgress(prev => ({ ...prev, status: 'uploading' }));

      let uploaded = 0;
      let failed = 0;

      // Upload in parallel batches of 3 for balance between speed and reliability
      const batchSize = 3;
      for (let i = 0; i < screenshots.length; i += batchSize) {
        const batch = screenshots.slice(i, i + batchSize);
        const results = await Promise.allSettled(
          batch.map(screenshot =>
            saveScreenshot({ sessionId, studentId, screenshot })
          )
        );

        results.forEach(result => {
          if (result.status === 'fulfilled' && result.value.success) {
            uploaded++;
          } else {
            failed++;
          }
        });

        setUploadProgress({
          total: screenshots.length,
          uploaded,
          failed,
          status: 'uploading',
        });
      }

      setUploadProgress({
        total: screenshots.length,
        uploaded,
        failed,
        status: failed === screenshots.length ? 'error' : 'complete',
      });

      if (uploaded > 0) {
        console.log(`Screenshot upload complete: ${uploaded}/${screenshots.length} saved`);
      }
    };

    // Start upload after a brief delay to prioritize exam submission
    if (!isSubmitting && !submitError) {
      uploadScreenshots();
    }
  }, [isSubmitting, submitError, state?.screenshotsToUpload, state?.sessionId, state?.studentId, saveScreenshot]);

  const examDuration = state?.examDuration || 0;
  const answeredCount = state?.answeredCount || 0;
  const totalQuestions = state?.totalQuestions || 0;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins} min ${secs} sec`;
  };

  const summary = {
    attempted: answeredCount,
    total: totalQuestions,
    notAttempted: totalQuestions - answeredCount,
    timeTaken: formatDuration(examDuration),
  };

  const uploadPercentage = uploadProgress.total > 0 
    ? Math.round(((uploadProgress.uploaded + uploadProgress.failed) / uploadProgress.total) * 100)
    : 100;

  if (isSubmitting) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <Card className="max-w-md w-full text-center border-0 shadow-lg">
          <CardContent className="pt-12 pb-8">
            <Loader2 className="h-16 w-16 animate-spin text-teal-600 mx-auto mb-6" />
            <h1 className="text-xl font-bold mb-2 text-slate-800">Submitting Your Exam...</h1>
            <p className="text-slate-500 mb-6">Please wait while we save your answers.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (submitError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <Card className="max-w-md w-full text-center border-0 shadow-lg">
          <CardContent className="pt-12 pb-8">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-6" />
            <h1 className="text-xl font-bold mb-2 text-slate-800">Submission Failed</h1>
            <p className="text-slate-500 mb-6">{submitError}</p>
            <Button asChild className="bg-teal-600 hover:bg-teal-700">
              <Link to="/student/dashboard">Return to Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center gap-2 max-w-7xl mx-auto">
          <span className="text-xl font-bold">
            <span className="text-slate-800">exam</span>
            <span className="text-teal-600">express</span>
          </span>
          <span className="text-teal-600">↗</span>
        </div>
      </header>

      <div className="max-w-xl mx-auto p-6">
        {/* Success & Summary */}
        <div className="space-y-6">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-8 text-center">
              {/* Success Icon */}
              <div className="h-20 w-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                <Check className="h-10 w-10 text-green-600" strokeWidth={3} />
              </div>

              <h1 className="text-2xl font-bold text-green-600 mb-2">
                Exam Submitted Successfully!
              </h1>
              <p className="text-slate-500 mb-6">
                Your exam has been submitted and is being processed
              </p>

              {/* Exam Summary */}
              <div className="bg-slate-50 rounded-xl p-6 text-left">
                <h3 className="font-semibold text-slate-800 mb-4">Exam Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Questions Attempted</span>
                    <span className="font-medium text-slate-800">{summary.attempted}/{summary.total}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Not Attempted</span>
                    <span className="font-medium text-slate-800">{summary.notAttempted}/{summary.total}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Time Taken</span>
                    <span className="font-medium text-slate-800">{summary.timeTaken}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Screenshot Upload Progress */}
          {uploadProgress.total > 0 && (
            <Card className="border-0 shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Camera className="h-5 w-5 text-slate-600" />
                  <h3 className="font-semibold text-slate-800">Proctoring Data Upload</h3>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">
                      {uploadProgress.status === 'uploading' && (
                        <span className="flex items-center gap-2">
                          <Upload className="h-4 w-4 animate-pulse" />
                          Uploading screenshots...
                        </span>
                      )}
                      {uploadProgress.status === 'complete' && (
                        <span className="flex items-center gap-2 text-green-600">
                          <Check className="h-4 w-4" />
                          Upload complete
                        </span>
                      )}
                      {uploadProgress.status === 'error' && (
                        <span className="flex items-center gap-2 text-amber-600">
                          <AlertCircle className="h-4 w-4" />
                          Some uploads failed
                        </span>
                      )}
                      {uploadProgress.status === 'pending' && (
                        <span>Preparing upload...</span>
                      )}
                    </span>
                    <span className="font-medium text-slate-700">
                      {uploadProgress.uploaded}/{uploadProgress.total}
                    </span>
                  </div>
                  
                  <Progress 
                    value={uploadPercentage} 
                    className="h-2"
                  />
                  
                  {uploadProgress.failed > 0 && uploadProgress.status === 'complete' && (
                    <p className="text-xs text-amber-600">
                      {uploadProgress.failed} screenshot(s) failed to upload. This won't affect your exam result.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* What happens next */}
          <Card className="border-0 shadow-md">
            <CardContent className="p-6">
              <h3 className="font-semibold text-slate-800 mb-4">What happens next?</h3>
              <ul className="space-y-3 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  <span>Your exam responses are being reviewed by our AI proctoring system.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  <span>Any flagged activities will be manually verified by our proctoring team.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  <span>Results will be released by the administration after evaluation.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  <span>You will be notified once results are available.</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Action Button */}
          <Button
            asChild
            className="w-full bg-teal-600 hover:bg-teal-700"
          >
            <Link to="/student/dashboard">Return to Dashboard</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}