import { Link, useParams } from 'react-router-dom';
import { Download, Trophy, Award, TrendingUp, Clock, AlertTriangle, ChevronLeft, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useStudentExams } from '@/hooks/useStudentExams';
import { format } from 'date-fns';
import { toast } from 'sonner';

export function ExamResult() {
  const { examId } = useParams();
  const { completed, isLoading, error } = useStudentExams();
  
  const result = completed.find((r) => r.id === examId);

  const handleDownload = () => {
    toast.success('Downloading scorecard as PDF...');
  };

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="p-6">
        <Button variant="ghost" size="sm" className="mb-4" asChild>
          <Link to="/student/results">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Results
          </Link>
        </Button>
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <p className="text-destructive">{error || 'Result not found'}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isPassed = result.result === 'pass';
  const percentage = result.percentage || 0;
  const score = result.score || 0;
  const totalMarks = result.totalMarks || 100;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" size="sm" className="mb-2" asChild>
            <Link to="/student/results">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back to Results
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">{result.name}</h1>
          <p className="text-muted-foreground">
            {result.completedAt 
              ? `Completed on ${format(new Date(result.completedAt), 'MMMM dd, yyyy')}`
              : 'Completion date not available'}
          </p>
        </div>
        <Button onClick={handleDownload}>
          <Download className="h-4 w-4 mr-2" />
          Download Scorecard
        </Button>
      </div>

      {/* Score Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className={isPassed ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}>
          <CardContent className="pt-6 text-center">
            <Trophy className={`h-10 w-10 mx-auto mb-2 ${isPassed ? 'text-green-600' : 'text-red-600'}`} />
            <div className="text-4xl font-bold">{score}/{totalMarks}</div>
            <div className="text-sm mt-1">Total Score</div>
            <Badge
              className={`mt-3 ${
                isPassed ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}
            >
              {isPassed ? 'PASSED' : 'FAILED'}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <TrendingUp className="h-10 w-10 text-blue-600 mx-auto mb-2" />
            <div className="text-4xl font-bold">{Math.round(percentage)}%</div>
            <div className="text-sm text-muted-foreground mt-1">Percentage</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Award className="h-10 w-10 text-amber-600 mx-auto mb-2" />
            <div className="text-4xl font-bold">-</div>
            <div className="text-sm text-muted-foreground mt-1">Rank</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Clock className="h-10 w-10 text-purple-600 mx-auto mb-2" />
            <div className="text-4xl font-bold">{result.duration || '-'}</div>
            <div className="text-sm text-muted-foreground mt-1">Minutes Duration</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sections" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sections">Performance Overview</TabsTrigger>
          <TabsTrigger value="proctoring">Proctoring Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="sections">
          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
              <CardDescription>Your exam performance summary</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Overall Score</span>
                  <span className="text-sm text-muted-foreground">
                    {score}/{totalMarks} ({Math.round(percentage)}%)
                  </span>
                </div>
                <Progress value={percentage} className="h-3" />
              </div>
              <div className="text-center py-4 text-muted-foreground">
                <p>Detailed section-wise breakdown will be available after full evaluation</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="proctoring">
          <Card>
            <CardHeader>
              <CardTitle>Proctoring Summary</CardTitle>
              <CardDescription>Recorded events during your examination</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-8 w-8 text-green-600" />
                </div>
                <p className="font-medium text-green-700">Exam Completed</p>
                <p className="text-sm text-muted-foreground">
                  Proctoring details are available in the admin panel
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
