import { useState } from 'react';
import {
  AlertTriangle,
  Users,
  EyeOff,
  UserX,
  MonitorOff,
  Clock,
  ChevronDown,
  ChevronUp,
  Shield,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

export interface ProctoringIncident {
  id: string;
  type: 'face_not_detected' | 'multiple_faces' | 'looking_away' | 'tab_switch' | 'eyes_closed' | 'face_mismatch' | 'audio_detected' | 'copy_paste' | 'screen_share_stopped' | 'browser_resize';
  message: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high';
}

interface ProctoringIncidentReportProps {
  incidents: ProctoringIncident[];
  examDuration: number; // in seconds
  className?: string;
}

const incidentIcons = {
  face_not_detected: UserX,
  multiple_faces: Users,
  looking_away: EyeOff,
  tab_switch: MonitorOff,
  eyes_closed: EyeOff,
};

const incidentLabels = {
  face_not_detected: 'Face Not Detected',
  multiple_faces: 'Multiple Faces',
  looking_away: 'Looking Away',
  tab_switch: 'Tab Switch',
  eyes_closed: 'Eyes Closed',
};

const severityColors = {
  low: 'bg-amber-100 text-amber-700 border-amber-200',
  medium: 'bg-orange-100 text-orange-700 border-orange-200',
  high: 'bg-red-100 text-red-700 border-red-200',
};

export function ProctoringIncidentReport({
  incidents,
  examDuration,
  className,
}: ProctoringIncidentReportProps) {
  const [expanded, setExpanded] = useState(false);

  // Group incidents by type
  const incidentsByType = incidents.reduce((acc, incident) => {
    if (!acc[incident.type]) {
      acc[incident.type] = [];
    }
    acc[incident.type].push(incident);
    return acc;
  }, {} as Record<string, ProctoringIncident[]>);

  // Calculate statistics
  const totalIncidents = incidents.length;
  const highSeverityCount = incidents.filter((i) => i.severity === 'high').length;
  const mediumSeverityCount = incidents.filter((i) => i.severity === 'medium').length;
  const lowSeverityCount = incidents.filter((i) => i.severity === 'low').length;

  // Calculate integrity score (100 - penalty for incidents)
  const calculateIntegrityScore = () => {
    let penalty = 0;
    penalty += highSeverityCount * 10;
    penalty += mediumSeverityCount * 5;
    penalty += lowSeverityCount * 2;
    return Math.max(0, 100 - penalty);
  };

  const integrityScore = calculateIntegrityScore();

  const getScoreStatus = () => {
    if (integrityScore >= 90) return { label: 'Excellent', color: 'text-green-600', bg: 'bg-green-100' };
    if (integrityScore >= 70) return { label: 'Good', color: 'text-teal-600', bg: 'bg-teal-100' };
    if (integrityScore >= 50) return { label: 'Fair', color: 'text-amber-600', bg: 'bg-amber-100' };
    return { label: 'Needs Review', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const scoreStatus = getScoreStatus();

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  return (
    <Card className={cn('border-0 shadow-md', className)}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Shield className="h-5 w-5 text-teal-600" />
            Proctoring Report
          </CardTitle>
          {totalIncidents === 0 ? (
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
              <CheckCircle className="h-3 w-3 mr-1" />
              No Violations
            </Badge>
          ) : (
            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {totalIncidents} Incident{totalIncidents > 1 ? 's' : ''}
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Integrity Score */}
        <div className="text-center p-6 bg-slate-50 rounded-xl">
          <p className="text-sm text-slate-500 mb-2">Exam Integrity Score</p>
          <div className="flex items-center justify-center gap-3 mb-3">
            <span className={cn('text-4xl font-bold', scoreStatus.color)}>
              {integrityScore}%
            </span>
            <Badge className={cn(scoreStatus.bg, scoreStatus.color, 'hover:' + scoreStatus.bg)}>
              {scoreStatus.label}
            </Badge>
          </div>
          <Progress value={integrityScore} className="h-2 bg-slate-200" />
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-red-50 rounded-lg">
            <XCircle className="h-5 w-5 text-red-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-red-600">{highSeverityCount}</p>
            <p className="text-xs text-slate-500">High Severity</p>
          </div>
          <div className="text-center p-3 bg-orange-50 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-orange-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-orange-600">{mediumSeverityCount}</p>
            <p className="text-xs text-slate-500">Medium Severity</p>
          </div>
          <div className="text-center p-3 bg-amber-50 rounded-lg">
            <Clock className="h-5 w-5 text-amber-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-amber-600">{lowSeverityCount}</p>
            <p className="text-xs text-slate-500">Low Severity</p>
          </div>
        </div>

        {/* Incident Breakdown by Type */}
        {totalIncidents > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-800">Incident Breakdown</h4>
            <div className="space-y-2">
              {Object.entries(incidentsByType).map(([type, typeIncidents]) => {
                const Icon = incidentIcons[type as keyof typeof incidentIcons] || AlertTriangle;
                return (
                  <div
                    key={type}
                    className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center">
                        <Icon className="h-4 w-4 text-slate-600" />
                      </div>
                      <span className="text-sm font-medium text-slate-700">
                        {incidentLabels[type as keyof typeof incidentLabels] || type}
                      </span>
                    </div>
                    <Badge variant="secondary">{typeIncidents.length}</Badge>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Detailed Timeline (Expandable) */}
        {totalIncidents > 0 && (
          <div>
            <Button
              variant="ghost"
              onClick={() => setExpanded(!expanded)}
              className="w-full justify-between text-slate-600 hover:text-slate-800"
            >
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Detailed Timeline
              </span>
              {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>

            {expanded && (
              <ScrollArea className="h-64 mt-3">
                <div className="space-y-2 pr-4">
                  {incidents
                    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
                    .map((incident) => {
                      const Icon = incidentIcons[incident.type] || AlertTriangle;
                      return (
                        <div
                          key={incident.id}
                          className={cn(
                            'flex items-start gap-3 p-3 rounded-lg border',
                            severityColors[incident.severity]
                          )}
                        >
                          <Icon className="h-4 w-4 mt-0.5 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{incident.message}</p>
                            <p className="text-xs opacity-75">{formatTimestamp(incident.timestamp)}</p>
                          </div>
                          <Badge
                            variant="outline"
                            className={cn('text-xs capitalize', severityColors[incident.severity])}
                          >
                            {incident.severity}
                          </Badge>
                        </div>
                      );
                    })}
                </div>
              </ScrollArea>
            )}
          </div>
        )}

        {/* No Incidents Message */}
        {totalIncidents === 0 && (
          <div className="text-center py-6">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
            <p className="text-slate-600 font-medium">No proctoring violations detected</p>
            <p className="text-sm text-slate-500">
              Your exam session maintained integrity throughout.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
