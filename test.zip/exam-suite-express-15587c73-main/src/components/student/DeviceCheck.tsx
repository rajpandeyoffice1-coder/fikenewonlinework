import { useState, useEffect, useCallback } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Camera, Mic, MapPin, Wifi, CheckCircle, Loader2, XCircle, RefreshCw, User } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useWebcam } from '@/hooks/useWebcam';
import { useInternetSpeed } from '@/hooks/useInternetSpeed';
import { useStudentProfile, getInitials } from '@/hooks/useStudentProfile';
import { WebcamPreview } from './WebcamPreview';
import { toast } from 'sonner';

type CheckStatus = 'pending' | 'checking' | 'passed' | 'failed';

interface DeviceCheckState {
  camera: CheckStatus;
  microphone: CheckStatus;
  location: CheckStatus;
  internet: CheckStatus;
}

export function DeviceCheck() {
  const { examId } = useParams();
  const { profile, isLoading: profileLoading } = useStudentProfile();
  const [checkStatuses, setCheckStatuses] = useState<DeviceCheckState>({
    camera: 'pending',
    microphone: 'pending',
    location: 'pending',
    internet: 'pending',
  });

  const { videoRef, isActive, isLoading, error, startCamera, stopCamera } = useWebcam({ video: true, audio: false });
  const { result: speedResult, isChecking: isSpeedChecking, isPassed: speedPassed, runSpeedTest } = useInternetSpeed();

  const allPassed = Object.values(checkStatuses).every((status) => status === 'passed');

  // Camera check
  const handleCameraCheck = useCallback(async () => {
    setCheckStatuses((prev) => ({ ...prev, camera: 'checking' }));
    
    try {
      await startCamera();
      setCheckStatuses((prev) => ({ ...prev, camera: 'passed' }));
      toast.success('Camera access granted');
    } catch {
      setCheckStatuses((prev) => ({ ...prev, camera: 'failed' }));
      toast.error('Camera access denied');
    }
  }, [startCamera]);

  // Update camera status when webcam state changes
  useEffect(() => {
    if (isActive && checkStatuses.camera === 'checking') {
      setCheckStatuses((prev) => ({ ...prev, camera: 'passed' }));
    }
    if (error && checkStatuses.camera === 'checking') {
      setCheckStatuses((prev) => ({ ...prev, camera: 'failed' }));
    }
  }, [isActive, error, checkStatuses.camera]);

  // Microphone check
  const handleMicrophoneCheck = async () => {
    setCheckStatuses((prev) => ({ ...prev, microphone: 'checking' }));
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      setCheckStatuses((prev) => ({ ...prev, microphone: 'passed' }));
      toast.success('Microphone access granted');
    } catch {
      setCheckStatuses((prev) => ({ ...prev, microphone: 'failed' }));
      toast.error('Microphone access denied');
    }
  };

  // Location check
  const handleLocationCheck = async () => {
    setCheckStatuses((prev) => ({ ...prev, location: 'checking' }));
    
    try {
      await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: false,
          timeout: 10000,
        });
      });
      setCheckStatuses((prev) => ({ ...prev, location: 'passed' }));
      toast.success('Location access granted');
    } catch {
      setCheckStatuses((prev) => ({ ...prev, location: 'failed' }));
      toast.error('Location access denied');
    }
  };

  // Internet speed check
  const handleInternetCheck = async () => {
    setCheckStatuses((prev) => ({ ...prev, internet: 'checking' }));
    await runSpeedTest();
  };

  // Update internet status when speed check completes - always pass regardless of speed
  useEffect(() => {
    if (speedResult && checkStatuses.internet === 'checking') {
      setCheckStatuses((prev) => ({ ...prev, internet: 'passed' }));
      toast.success('Internet speed check passed');
    }
  }, [speedResult, checkStatuses.internet]);

  const deviceChecks = [
    { id: 'camera', label: 'Camera Check', icon: Camera, description: 'Required for proctoring', onCheck: handleCameraCheck },
    { id: 'microphone', label: 'Microphone Check', icon: Mic, description: 'Required for sound validation', onCheck: handleMicrophoneCheck },
    { id: 'location', label: 'Location Access', icon: MapPin, description: 'Required for exam monitoring', onCheck: handleLocationCheck },
    { id: 'internet', label: 'Internet Speed', icon: Wifi, description: 'Stable network required', onCheck: handleInternetCheck },
  ];

  const getStatusButton = (checkId: keyof DeviceCheckState, status: CheckStatus, onCheck: () => void) => {
    if (status === 'checking' || (checkId === 'camera' && isLoading) || (checkId === 'internet' && isSpeedChecking)) {
      return (
        <Button disabled className="bg-teal-600 hover:bg-teal-700 min-w-24">
          <Loader2 className="h-4 w-4 animate-spin" />
        </Button>
      );
    }
    if (status === 'passed') {
      return (
        <Button disabled className="bg-green-600 hover:bg-green-700 min-w-24">
          <CheckCircle className="h-4 w-4 mr-1" />
          Done
        </Button>
      );
    }
    if (status === 'failed') {
      return (
        <Button onClick={onCheck} variant="destructive" className="min-w-24">
          {checkId === 'internet' ? (
            <>
              <RefreshCw className="h-4 w-4 mr-1" />
              Retry
            </>
          ) : (
            <>
              <XCircle className="h-4 w-4 mr-1" />
              Retry
            </>
          )}
        </Button>
      );
    }
    return (
      <Button onClick={onCheck} className="bg-teal-600 hover:bg-teal-700 min-w-24">
        {checkId === 'internet' ? 'Start Test' : 'Check'}
      </Button>
    );
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6">
      <div className="max-w-2xl w-full space-y-6">
        {/* Student Info Card */}
        {profile && (
          <Card className="shadow-lg border-0">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={profile.photoUrl} />
                  <AvatarFallback className="bg-teal-600 text-white">
                    {getInitials(profile.fullName)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-slate-800">{profile.fullName}</p>
                  <p className="text-sm text-slate-500">Roll No: {profile.rollNumber}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="shadow-lg border-0">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold text-slate-800">Pre-Exam Environment Check</h1>
              <p className="text-slate-500 mt-2">
                Complete all system checks before starting the exam.
              </p>
            </div>

            <div className="space-y-4 mb-8">
              {deviceChecks.map((check) => {
                const Icon = check.icon;
                const status = checkStatuses[check.id as keyof DeviceCheckState];
                const isInternetCheck = check.id === 'internet';

                return (
                  <div
                    key={check.id}
                    className="flex flex-col p-4 bg-white rounded-xl border border-slate-200"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                          status === 'passed' ? 'bg-green-100' : 
                          status === 'failed' ? 'bg-red-100' : 'bg-slate-100'
                        }`}>
                          <Icon className={`h-5 w-5 ${
                            status === 'passed' ? 'text-green-600' : 
                            status === 'failed' ? 'text-red-600' : 'text-slate-600'
                          }`} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-800">{check.label}</h3>
                          <p className="text-sm text-slate-500">{check.description}</p>
                        </div>
                      </div>
                      {getStatusButton(check.id as keyof DeviceCheckState, status, check.onCheck)}
                    </div>
                    
                    {/* Speed test results */}
                    {isInternetCheck && speedResult && (
                      <div className={`mt-3 pt-3 border-t border-slate-100 text-sm ${
                        status === 'passed' ? 'text-green-700' : 
                        status === 'failed' ? 'text-red-600' : 'text-slate-600'
                      }`}>
                        <div className="flex items-center gap-1 flex-wrap">
                          <span className="font-medium">Download:</span>
                          <span>{speedResult.downloadMbps} Mbps</span>
                          <span className="mx-2">•</span>
                          <span className="font-medium">Upload:</span>
                          <span>{speedResult.uploadMbps} Mbps</span>
                          <span className="mx-2">•</span>
                          <span className="font-medium">Latency:</span>
                          <span>{speedResult.latencyMs} ms</span>
                        </div>
                        {status === 'failed' && (
                          <p className="mt-1 text-xs text-red-500">
                            Minimum required: Download ≥5 Mbps, Upload ≥1 Mbps, Latency ≤150ms
                          </p>
                        )}
                      </div>
                    )}
                    
                    {/* Slow network message for failed status */}
                    {isInternetCheck && status === 'failed' && !speedResult && (
                      <div className="mt-3 pt-3 border-t border-slate-100">
                        <p className="text-sm text-red-600">Slow Network - Please check your connection</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <Button
              asChild
              disabled={!allPassed}
              className={`w-full h-12 text-base font-medium ${
                allPassed
                  ? 'bg-teal-600 hover:bg-teal-700'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Link to={allPassed ? `/student/exam/${examId}/verify` : '#'}>
                {allPassed ? 'Continue to Verification' : 'Complete all checks to continue'}
              </Link>
            </Button>
          </CardContent>
        </Card>

        {/* Camera Preview */}
        {(checkStatuses.camera === 'passed' || checkStatuses.camera === 'checking') && (
          <Card className="shadow-lg border-0">
            <CardContent className="p-6">
              <h3 className="font-semibold text-slate-800 mb-4">Camera Preview</h3>
              <WebcamPreview
                videoRef={videoRef}
                isActive={isActive}
                isLoading={isLoading}
                error={error}
                className="aspect-video"
                onStart={handleCameraCheck}
              />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
