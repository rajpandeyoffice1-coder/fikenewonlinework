import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import {
  Clock,
  Flag,
  ChevronRight,
  ChevronLeft,
  AlertTriangle,
  Check,
  Users,
  EyeOff,
  UserX,
  MonitorOff,
  AlertCircle,
  Camera,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import { ExamAnswer, ExamQuestion } from '@/types/student';
import { toast } from 'sonner';
import { useWebcam } from '@/hooks/useWebcam';
import { useFaceDetection } from '@/hooks/useFaceDetection';
import { useScreenshotCapture } from '@/hooks/useScreenshotCapture';
import { useProctoringStorage } from '@/hooks/useProctoringStorage';
import { WebcamPreview } from './WebcamPreview';
import { ProctoringIncident } from './ProctoringIncidentReport';
import { CodeEditor } from './CodeEditor';
import { FileUploadQuestion } from './FileUploadQuestion';
import { startExamSession, saveAnswer, submitExam } from '@/hooks/useStudentExams';

interface AIAlert {
  id: string;
  type: 'warning' | 'info' | 'error';
  message: string;
  icon: typeof AlertTriangle;
  timestamp: Date;
}

// Character limits for text answers
const SHORT_ANSWER_MAX_CHARS = 500;
const LONG_ANSWER_MAX_CHARS = 5000;
const AUTO_SAVE_INTERVAL = 10000; // 10 seconds

export function ExamInterface() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60 * 60); // 1 hour in seconds
  const [answers, setAnswers] = useState<Record<string, ExamAnswer>>({});
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showMandatoryWarning, setShowMandatoryWarning] = useState(false);
  const [aiAlerts, setAiAlerts] = useState<AIAlert[]>([]);
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [proctoringIncidents, setProctoringIncidents] = useState<ProctoringIncident[]>([]);
  const [examStartTime] = useState(Date.now());
  const [initialFaceDescriptor, setInitialFaceDescriptor] = useState<Float32Array | null>(null);
  const [faceMismatchCount, setFaceMismatchCount] = useState(0);
  const [questionStartTime, setQuestionStartTime] = useState<number>(Date.now());
  const [questionTimeSpent, setQuestionTimeSpent] = useState<Record<string, number>>({});
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastIncidentCaptureRef = useRef<number>(0);
  const INCIDENT_CAPTURE_COOLDOWN = 4000; // 4 seconds between incident captures
  const [, setTick] = useState(0); // Force re-render for live time display
  
  // Backend integration state
  const [sessionId, setSessionId] = useState<string | null>(location.state?.sessionId || null);
  const [studentId, setStudentId] = useState<string | null>(location.state?.studentId || null);
  const [questions, setQuestions] = useState<ExamQuestion[]>(location.state?.questions || []);
  const [examInfo, setExamInfo] = useState<any>(location.state?.exam || null);
  const [isLoadingExam, setIsLoadingExam] = useState(!location.state?.questions);
  const [examError, setExamError] = useState<string | null>(null);

  // Proctoring storage for saving screenshots and incidents
  const { saveIncident } = useProctoringStorage();

  const { videoRef, isActive, isLoading, error, startCamera, stopCamera } = useWebcam({
    video: { width: 320, height: 240, facingMode: 'user' },
    audio: false,
  });

  const { result: faceResult, isLoading: faceLoading, isModelLoaded, alerts: faceAlerts, descriptor: currentFaceDescriptor } = useFaceDetection({
    videoElement: videoRef.current,
    enabled: isActive,
    detectionInterval: 1000,
  });

  const { 
    screenshots, 
    isCapturing, 
    captureIncidentScreenshot, 
    getStats: getScreenshotStats 
  } = useScreenshotCapture({
    videoElement: videoRef.current,
    enabled: isActive,
    intervalMs: 30000,
    maxScreenshots: 100,
  });

  const question = questions[currentQuestion];

  // Load exam session on mount if not passed via state
  useEffect(() => {
    const loadExamSession = async () => {
      if (!examId || (sessionId && questions.length > 0)) return;
      
      setIsLoadingExam(true);
      const result = await startExamSession(examId);
      
      if (result.success) {
        setSessionId(result.sessionId || null);
        setStudentId(result.studentId || null);
        setQuestions(result.questions?.map((q: any, idx: number) => ({
          ...q,
          number: idx + 1,
          questionNumber: idx + 1,
        })) || []);
        setExamInfo(result.exam);
        if (result.timeRemaining) {
          setTimeLeft(result.timeRemaining);
        }
        // Restore saved answers if any
        if (result.savedAnswers && result.savedAnswers.length > 0) {
          const savedAnswersMap: Record<string, ExamAnswer> = {};
          result.savedAnswers.forEach((sa: any) => {
            savedAnswersMap[sa.question_id] = {
              questionId: sa.question_id,
              answer: sa.answer_text || sa.answer_option,
              status: sa.answer_text || sa.answer_option ? 'answered' : 'not-answered',
              isAnswered: !!(sa.answer_text || sa.answer_option),
              isFlagged: sa.is_flagged || false,
              timeSpent: sa.time_spent || 0,
            };
          });
          setAnswers(savedAnswersMap);
        }
      } else {
        setExamError(result.error || 'Failed to start exam');
        toast.error('Failed to start exam', { description: result.error });
      }
      setIsLoadingExam(false);
    };

    loadExamSession();
  }, [examId]);

  // Get unanswered questions
  const getUnansweredQuestions = useCallback(() => {
    return questions.filter((q) => {
      const answer = answers[q.id];
      if (!answer) return true;
      if (!answer.isAnswered) return true;
      // For text answers, check if empty
      if ((q.type === 'short-answer' || q.type === 'long-answer' || q.type === 'code') && 
          (!answer.answer || (typeof answer.answer === 'string' && answer.answer.trim() === ''))) {
        return true;
      }
      // For file uploads, check if file URL exists
      if (q.type === 'file-upload' && 
          (!answer.answer || (typeof answer.answer === 'string' && answer.answer.trim() === ''))) {
        return true;
      }
      return false;
    });
  }, [answers, questions]);

  // Store initial face descriptor on first detection
  useEffect(() => {
    if (currentFaceDescriptor && !initialFaceDescriptor && faceResult.faceDetected) {
      setInitialFaceDescriptor(currentFaceDescriptor);
      console.log('Initial face captured for verification');
    }
  }, [currentFaceDescriptor, initialFaceDescriptor, faceResult.faceDetected]);

  // Face mismatch detection
  useEffect(() => {
    if (initialFaceDescriptor && currentFaceDescriptor && faceResult.faceDetected) {
      // Calculate Euclidean distance between face descriptors
      const distance = Math.sqrt(
        Array.from(initialFaceDescriptor).reduce((sum, val, i) => {
          const diff = val - currentFaceDescriptor[i];
          return sum + diff * diff;
        }, 0)
      );

      // Threshold for face mismatch (lower = more strict)
      const FACE_MATCH_THRESHOLD = 0.6;
      
      if (distance > FACE_MATCH_THRESHOLD) {
        setFaceMismatchCount((prev) => prev + 1);
        
        // Only trigger warning if consistent mismatch (3+ consecutive)
        if (faceMismatchCount >= 2) {
          const newAlert: AIAlert = {
            id: `face-mismatch-${Date.now()}`,
            type: 'error',
            message: 'Face does not match registered candidate!',
            icon: UserX,
            timestamp: new Date(),
          };
          setAiAlerts((prev) => [newAlert, ...prev].slice(0, 10));

          // Add to proctoring incidents
          const newIncident: ProctoringIncident = {
            id: `face-mismatch-${Date.now()}`,
            type: 'face_mismatch',
            message: 'Face mismatch detected - different person suspected',
            timestamp: new Date(),
            severity: 'high',
          };
          setProctoringIncidents((prev) => [...prev, newIncident]);

          // Save incident to database
          if (sessionId && studentId) {
            saveIncident({
              sessionId,
              studentId,
              incidentType: 'face_mismatch',
              severity: 'high',
              message: 'Face mismatch detected - different person suspected',
            });
          }

          // Throttle incident captures
          const now = Date.now();
          if (now - lastIncidentCaptureRef.current > INCIDENT_CAPTURE_COOLDOWN) {
            captureIncidentScreenshot('Face mismatch - different person detected');
            lastIncidentCaptureRef.current = now;
          }
          
          toast.error('Face Mismatch Detected!', {
            description: 'Your face does not match the registered candidate. This incident has been logged.',
          });

          // Reset counter after triggering
          setFaceMismatchCount(0);
        }
      } else {
        // Reset counter if face matches
        setFaceMismatchCount(0);
      }
    }
  }, [currentFaceDescriptor, initialFaceDescriptor, faceResult.faceDetected, faceMismatchCount, captureIncidentScreenshot, saveIncident, sessionId, studentId]);

  // Start camera on mount
  useEffect(() => {
    if (!isLoadingExam && questions.length > 0) {
      startCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isLoadingExam, questions.length]);

  // Auto-save for text answers
  useEffect(() => {
    if (autoSaveTimerRef.current) {
      clearInterval(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setInterval(async () => {
      if (!sessionId) return;
      
      // Calculate current time spent on this question
      const currentSessionTime = Math.floor((Date.now() - questionStartTime) / 1000);
      
      // Save current question's answer to backend with updated time
      const currentAnswer = answers[question?.id];
      if (question) {
        const existingTimeSpent = questionTimeSpent[question.id] || 0;
        const totalTimeSpent = existingTimeSpent + currentSessionTime;
        
        const saved = await saveAnswer(
          sessionId,
          question.id,
          { text: typeof currentAnswer?.answer === 'string' ? currentAnswer.answer : undefined, option: Array.isArray(currentAnswer?.answer) ? currentAnswer.answer : undefined },
          totalTimeSpent,
          currentAnswer?.isFlagged || false
        );
        if (saved) {
          console.log('Auto-saved answer for question:', question.id, 'time spent:', totalTimeSpent);
        }
      }
    }, AUTO_SAVE_INTERVAL);

    return () => {
      if (autoSaveTimerRef.current) {
        clearInterval(autoSaveTimerRef.current);
      }
    };
  }, [answers]);

  // Add face detection alerts to AI alerts and proctoring incidents
  useEffect(() => {
    if (faceAlerts.length > 0) {
      const newAlerts: AIAlert[] = faceAlerts.map((alert, index) => ({
        id: `face-${Date.now()}-${index}`,
        type: 'warning' as const,
        message: alert,
        icon: alert.includes('Multiple') ? Users : 
              alert.includes('Eyes') ? EyeOff : 
              alert.includes('Face') ? UserX : AlertTriangle,
        timestamp: new Date(),
      }));

      setAiAlerts((prev) => {
        const combined = [...newAlerts, ...prev];
        return combined.slice(0, 10);
      });

      const newIncidents: ProctoringIncident[] = faceAlerts.map((alert, index) => ({
        id: `face-${Date.now()}-${index}`,
        type: alert.includes('Multiple') ? 'multiple_faces' as const :
              alert.includes('Eyes') ? 'eyes_closed' as const :
              alert.includes('looking') ? 'looking_away' as const : 'face_not_detected' as const,
        message: alert,
        timestamp: new Date(),
        severity: alert.includes('Multiple') ? 'high' as const :
                  alert.includes('Face left') ? 'high' as const : 'medium' as const,
      }));

      setProctoringIncidents((prev) => [...prev, ...newIncidents]);

      // Throttled incident capture for face alerts
      const now = Date.now();
      if (now - lastIncidentCaptureRef.current > INCIDENT_CAPTURE_COOLDOWN) {
        faceAlerts.forEach((alert) => {
          if (alert.includes('Multiple') || alert.includes('Face left')) {
            captureIncidentScreenshot(alert);
            lastIncidentCaptureRef.current = now;
          }
        });
      }

      if (faceAlerts.some((a) => a.includes('Face left'))) {
        toast.warning('Face not detected!', {
          description: 'Please ensure your face is visible to the camera.',
        });
      }
    }
  }, [faceAlerts, captureIncidentScreenshot]);

  // Timer - also updates tick for live time display
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(timer);
          handleForceSubmit();
          return 0;
        }
        return prev - 1;
      });
      // Force re-render to update question time display
      setTick(t => t + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [examId]);

  // Tab visibility detection
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchCount((prev) => prev + 1);
        const newAlert: AIAlert = {
          id: `tab-${Date.now()}`,
          type: 'warning',
          message: `Tab switch attempt (${tabSwitchCount + 1})`,
          icon: MonitorOff,
          timestamp: new Date(),
        };
        setAiAlerts((prev) => [newAlert, ...prev].slice(0, 10));
        
        const severity = tabSwitchCount >= 2 ? 'high' : 'medium';
        const newIncident: ProctoringIncident = {
          id: `tab-${Date.now()}`,
          type: 'tab_switch',
          message: `Tab switch detected (attempt ${tabSwitchCount + 1})`,
          timestamp: new Date(),
          severity,
        };
        setProctoringIncidents((prev) => [...prev, newIncident]);

        // Save incident to database
        if (sessionId && studentId) {
          saveIncident({
            sessionId,
            studentId,
            incidentType: 'tab_switch',
            severity: severity as 'low' | 'medium' | 'high',
            message: `Tab switch detected (attempt ${tabSwitchCount + 1})`,
          });
        }
        
        // Throttle incident captures
        const now = Date.now();
        if (now - lastIncidentCaptureRef.current > INCIDENT_CAPTURE_COOLDOWN) {
          captureIncidentScreenshot(`Tab switch attempt ${tabSwitchCount + 1}`);
          lastIncidentCaptureRef.current = now;
        }
        
        toast.warning('Warning: Tab switch detected!', {
          description: 'Please stay on this page during the exam.',
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [tabSwitchCount, captureIncidentScreenshot, saveIncident, sessionId, studentId]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s
      .toString()
      .padStart(2, '0')}`;
  };

  // Get question status with proper color coding
  const getQuestionStatus = (questionId: string, questionType: string): 'answered' | 'not-answered' | 'flagged' => {
    const answer = answers[questionId];
    if (!answer) return 'not-answered';
    if (answer.isFlagged) return 'flagged';
    
    // Check if actually answered (not empty)
    if (answer.isAnswered) {
      // For text-based answers (short, long, code)
      if (questionType === 'short-answer' || questionType === 'long-answer' || questionType === 'code') {
        if (!answer.answer || (typeof answer.answer === 'string' && answer.answer.trim() === '')) {
          return 'not-answered';
        }
      }
      // For file uploads
      if (questionType === 'file-upload') {
        if (!answer.answer || (typeof answer.answer === 'string' && answer.answer.trim() === '')) {
          return 'not-answered';
        }
      }
      return 'answered';
    }
    return 'not-answered';
  };

  const handleAnswer = (questionId: string, answer: string | string[]) => {
    const isEmptyTextAnswer = typeof answer === 'string' && answer.trim() === '';
    
    // Calculate current time spent on this question
    const currentSessionTime = Math.floor((Date.now() - questionStartTime) / 1000);
    const previousTimeSpent = questionTimeSpent[questionId] || 0;
    const totalTimeSpent = previousTimeSpent + currentSessionTime;
    
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        questionId,
        answer,
        status: isEmptyTextAnswer ? 'not-answered' : 'answered',
        isAnswered: !isEmptyTextAnswer,
        isFlagged: prev[questionId]?.isFlagged || false,
        timeSpent: totalTimeSpent,
      },
    }));
  };

  const handleTextAnswer = (questionId: string, text: string, maxChars: number) => {
    const truncatedText = text.slice(0, maxChars);
    handleAnswer(questionId, truncatedText);
  };

  const handleMultipleChoice = (questionId: string, option: string, checked: boolean) => {
    const currentAnswer = answers[questionId]?.answer;
    let newAnswer: string[];
    
    if (Array.isArray(currentAnswer)) {
      newAnswer = checked 
        ? [...currentAnswer, option]
        : currentAnswer.filter((o) => o !== option);
    } else {
      newAnswer = checked ? [option] : [];
    }
    
    handleAnswer(questionId, newAnswer);
  };

  const handleFlag = (questionId: string) => {
    const currentAnswer = answers[questionId];
    const wasFlagged = currentAnswer?.isFlagged || false;
    
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        questionId,
        answer: prev[questionId]?.answer || null,
        status: wasFlagged ? (prev[questionId]?.isAnswered ? 'answered' : 'not-answered') : 'flagged',
        isAnswered: prev[questionId]?.isAnswered || false,
        isFlagged: !wasFlagged,
        timeSpent: prev[questionId]?.timeSpent || 0,
      },
    }));
    
    toast.success(wasFlagged ? 'Removed from review' : 'Marked for review');
  };

  const handleClear = (questionId: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        questionId,
        answer: null,
        status: 'not-answered',
        isAnswered: false,
        isFlagged: false,
        timeSpent: prev[questionId]?.timeSpent || 0,
      },
    }));
  };

  // Check if submission is allowed (all questions answered)
  const handleSubmitClick = () => {
    const unanswered = getUnansweredQuestions();
    
    if (unanswered.length > 0) {
      setShowMandatoryWarning(true);
    } else {
      setShowSubmitDialog(true);
    }
  };

  // Force submit (for timer expiry)
  const handleForceSubmit = () => {
    stopCamera();
    
    const examDuration = Math.floor((Date.now() - examStartTime) / 1000);
    navigate(`/student/exam/${examId}/submit`, {
      state: {
        proctoringIncidents,
        examDuration,
        answeredCount,
        totalQuestions: questions.length,
        screenshotStats: getScreenshotStats(),
        forcedSubmit: true,
        sessionId,
        studentId,
        // Pass screenshots for background upload on submission page
        screenshotsToUpload: screenshots,
      },
    });
  };

  const handleSubmit = () => {
    const unanswered = getUnansweredQuestions();
    
    if (unanswered.length > 0) {
      toast.error('Cannot submit exam', {
        description: `You have ${unanswered.length} unanswered question(s). All questions are mandatory.`,
      });
      return;
    }

    stopCamera();
    
    const examDuration = Math.floor((Date.now() - examStartTime) / 1000);
    navigate(`/student/exam/${examId}/submit`, {
      state: {
        proctoringIncidents,
        examDuration,
        answeredCount,
        totalQuestions: questions.length,
        screenshotStats: getScreenshotStats(),
        sessionId,
        studentId,
        // Pass screenshots for background upload on submission page
        screenshotsToUpload: screenshots,
      },
    });
  };

  const goToQuestion = (questionNumber: number) => {
    const index = questions.findIndex((q) => q.number === questionNumber);
    if (index !== -1) {
      // Track time spent on current question before switching
      if (question) {
        const timeOnCurrentQuestion = Math.floor((Date.now() - questionStartTime) / 1000);
        setQuestionTimeSpent((prev) => ({
          ...prev,
          [question.id]: (prev[question.id] || 0) + timeOnCurrentQuestion,
        }));
      }
      setCurrentQuestion(index);
      setQuestionStartTime(Date.now());
    }
  };

  const answeredCount = Object.values(answers).filter((a) => a.isAnswered).length;
  const notAnsweredCount = questions.length - answeredCount;
  const flaggedCount = Object.values(answers).filter((a) => a.isFlagged).length;
  const screenshotStats = getScreenshotStats();
  const unansweredQuestions = getUnansweredQuestions();

  const currentAnswerValue = question ? answers[question.id]?.answer : undefined;

  // Get proctoring status
  const getProctoringStatus = () => {
    if (!isActive) return { status: 'inactive', label: 'Inactive', color: 'bg-red-100 text-red-700' };
    if (faceLoading || !isModelLoaded) return { status: 'loading', label: 'Loading...', color: 'bg-amber-100 text-amber-700' };
    if (!faceResult.faceDetected) return { status: 'warning', label: 'No Face', color: 'bg-red-100 text-red-700' };
    if (faceResult.multipleFaces || faceResult.lookingAway) return { status: 'warning', label: 'Warning', color: 'bg-amber-100 text-amber-700' };
    return { status: 'active', label: 'Active', color: 'bg-green-100 text-green-700' };
  };

  const proctoringStatus = getProctoringStatus();

  // Render question input based on type
  const renderQuestionInput = (q: ExamQuestion) => {
    switch (q.type) {
      case 'short-answer':
        return (
          <div className="space-y-2">
            <Textarea
              value={(currentAnswerValue as string) || ''}
              onChange={(e) => handleTextAnswer(q.id, e.target.value, SHORT_ANSWER_MAX_CHARS)}
              placeholder="Enter your short answer here..."
              className="min-h-[100px] max-h-[150px] resize-none"
              maxLength={SHORT_ANSWER_MAX_CHARS}
            />
            <div className="flex justify-between text-xs text-slate-500">
              <span>Short answer (2-4 lines)</span>
              <span className={cn(
                (currentAnswerValue as string)?.length >= SHORT_ANSWER_MAX_CHARS * 0.9 ? 'text-red-500' : ''
              )}>
                {(currentAnswerValue as string)?.length || 0}/{SHORT_ANSWER_MAX_CHARS}
              </span>
            </div>
          </div>
        );

      case 'long-answer':
        return (
          <div className="space-y-2">
            <Textarea
              value={(currentAnswerValue as string) || ''}
              onChange={(e) => handleTextAnswer(q.id, e.target.value, LONG_ANSWER_MAX_CHARS)}
              placeholder="Enter your detailed answer here..."
              className="min-h-[300px] max-h-[500px] resize-y"
              maxLength={LONG_ANSWER_MAX_CHARS}
            />
            <div className="flex justify-between text-xs text-slate-500">
              <span>Long answer (10-20 lines)</span>
              <span className={cn(
                (currentAnswerValue as string)?.length >= LONG_ANSWER_MAX_CHARS * 0.9 ? 'text-red-500' : ''
              )}>
                {(currentAnswerValue as string)?.length || 0}/{LONG_ANSWER_MAX_CHARS}
              </span>
            </div>
          </div>
        );

      case 'code':
        return (
          <CodeEditor
            value={(currentAnswerValue as string) || ''}
            onChange={(code) => handleAnswer(q.id, code)}
            language={q.codeLanguage || 'javascript'}
            onAutoSave={() => console.log('Code auto-saved for question:', q.id)}
          />
        );

      case 'file-upload':
        return (
          <FileUploadQuestion
            value={(currentAnswerValue as string) || null}
            onChange={(fileUrl) => handleAnswer(q.id, fileUrl || '')}
            onAutoSave={() => console.log('File uploaded for question:', q.id)}
            questionId={q.id}
            examSessionId={examId || 'demo-session'}
          />
        );

      case 'mcq-multiple':
        return (
          <div className="space-y-3">
            {q.options?.map((option, index) => {
              // Handle both string options and object options with text property
              const optionText = typeof option === 'object' && option !== null ? (option as any).text || String(option) : String(option);
              const optionValue = optionText;
              const isSelected = Array.isArray(currentAnswerValue) && currentAnswerValue.includes(optionValue);
              return (
                <label
                  key={index}
                  className={cn(
                    'flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all',
                    isSelected
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  )}
                >
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={(checked) => handleMultipleChoice(q.id, optionValue, checked as boolean)}
                    className="border-teal-500 data-[state=checked]:bg-teal-600"
                  />
                  <span className="text-slate-700">
                    Option {String.fromCharCode(65 + index)}: {optionText}
                  </span>
                </label>
              );
            })}
            <p className="text-xs text-slate-500 mt-2">Select all that apply</p>
          </div>
        );

      case 'true-false':
        // True/False questions should always show "True" and "False" options
        const trueFalseOptions = ['True', 'False'];
        return (
          <RadioGroup
            value={currentAnswerValue as string}
            onValueChange={(value) => handleAnswer(q.id, value)}
            className="space-y-3"
          >
            {trueFalseOptions.map((option, index) => (
              <label
                key={index}
                className={cn(
                  'flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all',
                  currentAnswerValue === option
                    ? 'border-teal-500 bg-teal-50'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                )}
              >
                <RadioGroupItem value={option} className="border-teal-500 text-teal-600" />
                <span className="text-slate-700">{option}</span>
              </label>
            ))}
          </RadioGroup>
        );

      case 'mcq-single':
      default:
        return (
          <RadioGroup
            value={currentAnswerValue as string}
            onValueChange={(value) => handleAnswer(q.id, value)}
            className="space-y-3"
          >
            {q.options?.map((option, index) => {
              // Handle both string options and object options with text property
              const optionText = typeof option === 'object' && option !== null ? (option as any).text || String(option) : String(option);
              const optionValue = optionText;
              return (
                <label
                  key={index}
                  className={cn(
                    'flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all',
                    currentAnswerValue === optionValue
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  )}
                >
                  <RadioGroupItem value={optionValue} className="border-teal-500 text-teal-600" />
                  <span className="text-slate-700">
                    Option {String.fromCharCode(65 + index)}: {optionText}
                  </span>
                </label>
              );
            })}
          </RadioGroup>
        );
    }
  };

  // Loading state
  if (isLoadingExam) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <h2 className="text-xl font-semibold">Loading Exam...</h2>
          <p className="text-muted-foreground">Please wait while we prepare your exam session</p>
        </div>
      </div>
    );
  }

  if (examError || questions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-semibold">Unable to Load Exam</h2>
          <p className="text-muted-foreground">{examError || 'No questions available'}</p>
          <Button className="mt-4" onClick={() => navigate('/student/exams')}>
            Return to Exams
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold">
            <span className="text-slate-800">exam</span>
            <span className="text-teal-600">express</span>
          </span>
          <span className="text-teal-600">↗</span>
        </div>

        <div
          className={cn(
            'flex items-center gap-2 font-mono text-lg font-semibold',
            timeLeft < 300 ? 'text-red-600 animate-pulse' : 'text-teal-600'
          )}
        >
          <Clock className="h-5 w-5" />
          {formatTime(timeLeft)}
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Left Sidebar - Question Navigator */}
        <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
          <div className="p-4 border-b border-slate-200">
            <h2 className="font-semibold text-slate-800">Questions</h2>
            <div className="flex gap-2 mt-2 text-xs flex-wrap">
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-full bg-green-500" />
                Answered
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-full bg-amber-500" />
                Review
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-full bg-red-500" />
                Pending
              </span>
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {questions.map((q, index) => {
                const status = getQuestionStatus(q.id, q.type);
                // Calculate time spent: accumulated + current session if on this question
                const accumulatedTime = questionTimeSpent[q.id] || 0;
                const currentSessionTime = currentQuestion === index 
                  ? Math.floor((Date.now() - questionStartTime) / 1000) 
                  : 0;
                const totalTimeSpent = accumulatedTime + currentSessionTime;
                const timeDisplay = totalTimeSpent >= 60 
                  ? `${Math.floor(totalTimeSpent / 60)}m ${totalTimeSpent % 60}s`
                  : `${totalTimeSpent}s`;
                
                return (
                  <button
                    key={q.id}
                    onClick={() => goToQuestion(q.number)}
                    className={cn(
                      'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all text-left',
                      currentQuestion === index 
                        ? 'bg-slate-100 ring-2 ring-teal-500' 
                        : 'hover:bg-slate-50'
                    )}
                  >
                    <span
                      className={cn(
                        'h-7 w-7 rounded-full text-xs font-medium flex items-center justify-center flex-shrink-0',
                        status === 'answered'
                          ? 'bg-green-500 text-white'
                          : status === 'flagged'
                          ? 'bg-amber-500 text-white'
                          : 'bg-red-500 text-white'
                      )}
                    >
                      {q.number}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-slate-700 font-medium truncate">Q{q.number}</div>
                      <div className="flex items-center gap-1 text-xs text-slate-500">
                        <Clock className="h-3 w-3" />
                        <span>{timeDisplay}</span>
                      </div>
                    </div>
                    {answers[q.id]?.isFlagged && (
                      <Flag className="h-4 w-4 text-amber-500 flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </ScrollArea>

          <div className="p-4 border-t border-slate-200 space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Answered:</span>
              <span className="font-semibold text-green-600">{answeredCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">For Review:</span>
              <span className="font-semibold text-amber-600">{flaggedCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Not Answered:</span>
              <span className="font-semibold text-red-500">{notAnsweredCount}</span>
            </div>
          </div>

          <div className="p-4 border-t border-slate-200">
            <Button
              onClick={handleSubmitClick}
              className="w-full bg-red-500 hover:bg-red-600"
            >
              Submit Test
            </Button>
          </div>
        </aside>

        {/* Main Content - Question */}
        <main className="flex-1 p-6 overflow-auto">
          <Card className="max-w-3xl mx-auto border-0 shadow-md">
            <CardContent className="p-6">
              {/* Question Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <span className={cn(
                    'px-2 py-1 rounded text-xs font-medium',
                    getQuestionStatus(question.id, question.type) === 'answered' 
                      ? 'bg-green-100 text-green-700'
                      : getQuestionStatus(question.id, question.type) === 'flagged'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-red-100 text-red-700'
                  )}>
                    {getQuestionStatus(question.id, question.type) === 'answered' 
                      ? 'Answered' 
                      : getQuestionStatus(question.id, question.type) === 'flagged'
                      ? 'For Review'
                      : 'Not Answered'}
                  </span>
                  <span className="text-sm text-slate-500">
                    Question {question.number} of {questions.length}
                  </span>
                  <span className="text-xs text-slate-400 bg-slate-100 px-2 py-1 rounded">
                    {question.type.replace('-', ' ').toUpperCase()}
                  </span>
                </div>
                <button
                  onClick={() => handleFlag(question.id)}
                  className={cn(
                    'flex items-center gap-1 text-sm px-3 py-1 rounded-lg transition-colors',
                    answers[question.id]?.isFlagged
                      ? 'bg-amber-100 text-amber-700'
                      : 'text-slate-400 hover:bg-slate-100 hover:text-slate-600'
                  )}
                >
                  <Flag className="h-4 w-4" />
                  {answers[question.id]?.isFlagged ? 'Flagged' : 'Flag for Review'}
                </button>
              </div>

              {/* Question Text */}
              <h2 className="text-lg font-semibold text-slate-800 mb-6">
                Question {question.number}: {question.text}
              </h2>

              {/* Marks indicator */}
              <div className="mb-4 text-sm text-slate-500">
                Marks: {question.marks}
              </div>

              {/* Question Input based on type */}
              {renderQuestionInput(question)}

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-200">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                    disabled={currentQuestion === 0}
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" />
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleClear(question.id)}
                    className="text-slate-600"
                  >
                    Clear Response
                  </Button>
                </div>

                <Button
                  onClick={() => setCurrentQuestion(Math.min(questions.length - 1, currentQuestion + 1))}
                  disabled={currentQuestion === questions.length - 1}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  Save & Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>

        {/* Right Sidebar - AI Proctoring */}
        <aside className="w-72 bg-white border-l border-slate-200 flex flex-col">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="font-semibold text-slate-800">AI Proctoring</h2>
            <span
              className={cn(
                'px-2 py-1 text-xs font-medium rounded-full flex items-center gap-1',
                proctoringStatus.color
              )}
            >
              <span
                className={cn(
                  'w-1.5 h-1.5 rounded-full',
                  proctoringStatus.status === 'active' ? 'bg-green-500' : 
                  proctoringStatus.status === 'warning' ? 'bg-amber-500' : 'bg-red-500'
                )}
              />
              {proctoringStatus.label}
            </span>
          </div>

          {/* Live Camera Preview */}
          <div className="p-4">
            <WebcamPreview
              videoRef={videoRef}
              isActive={isActive}
              isLoading={isLoading}
              error={error}
              className="aspect-video"
              showOverlay={false}
              onStart={startCamera}
            />
            {initialFaceDescriptor && (
              <p className="text-xs text-green-600 mt-1 text-center">✓ Face registered</p>
            )}
            {!isActive && !isLoading && (
              <Button
                onClick={startCamera}
                className="w-full mt-2 bg-teal-600 hover:bg-teal-700"
                size="sm"
              >
                Enable Camera
              </Button>
            )}
          </div>

          {/* AI Alerts */}
          <div className="p-4 border-t border-slate-200 flex-1 overflow-hidden">
            <h3 className="text-sm font-semibold text-slate-800 mb-3">AI Alerts</h3>
            <ScrollArea className="h-48">
              <div className="space-y-2 pr-2">
                {aiAlerts.length === 0 ? (
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-green-50 text-green-600">
                    <Check className="h-4 w-4" />
                    <span>No alerts - All clear</span>
                  </div>
                ) : (
                  aiAlerts.map((alert) => {
                    const Icon = alert.icon;
                    return (
                      <div
                        key={alert.id}
                        className={cn(
                          'flex items-center gap-2 px-3 py-2 rounded-lg text-sm',
                          alert.type === 'warning'
                            ? 'bg-amber-50 text-amber-700'
                            : alert.type === 'error'
                            ? 'bg-red-50 text-red-700'
                            : 'bg-slate-50 text-slate-600'
                        )}
                      >
                        <Icon className="h-4 w-4 flex-shrink-0" />
                        <span className="truncate">{alert.message}</span>
                      </div>
                    );
                  })
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Progress */}
          <div className="mt-auto p-4 border-t border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">Progress</span>
              <span className="font-semibold text-slate-800">
                {answeredCount}/{questions.length}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 flex items-center gap-1">
                <Camera className="h-3 w-3" />
                Screenshots
              </span>
              <span className={cn(
                "font-semibold",
                isCapturing ? "text-teal-600" : "text-slate-400"
              )}>
                {screenshotStats.total}
              </span>
            </div>
          </div>
        </aside>
      </div>

      {/* Mandatory Questions Warning Dialog */}
      <AlertDialog open={showMandatoryWarning} onOpenChange={setShowMandatoryWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <AlertCircle className="h-5 w-5" />
              All Questions Are Mandatory
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>You must answer all questions before submitting the exam.</p>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="font-medium text-red-800 mb-2">
                  Unanswered Questions ({unansweredQuestions.length}):
                </p>
                <div className="flex flex-wrap gap-2">
                  {unansweredQuestions.slice(0, 10).map((q) => (
                    <button
                      key={q.id}
                      onClick={() => {
                        goToQuestion(q.number);
                        setShowMandatoryWarning(false);
                      }}
                      className="px-2 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600 transition-colors"
                    >
                      Q{q.number}
                    </button>
                  ))}
                  {unansweredQuestions.length > 10 && (
                    <span className="text-red-600 text-sm">
                      +{unansweredQuestions.length - 10} more
                    </span>
                  )}
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Go Back and Complete</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Submit Dialog */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Submit Exam?</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>Are you sure you want to submit your exam? This action cannot be undone.</p>
              <div className="bg-slate-100 rounded-lg p-4 space-y-2">
                <div className="flex justify-between">
                  <span>Answered</span>
                  <span className="font-medium text-green-600">{answeredCount}</span>
                </div>
                <div className="flex justify-between">
                  <span>Flagged for Review</span>
                  <span className="font-medium text-amber-600">{flaggedCount}</span>
                </div>
                <div className="flex justify-between">
                  <span>Proctoring Alerts</span>
                  <span className="font-medium text-red-600">{aiAlerts.length}</span>
                </div>
              </div>
              {answeredCount === questions.length && (
                <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg">
                  <Check className="h-5 w-5" />
                  <span>All questions answered!</span>
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Go Back</AlertDialogCancel>
            <AlertDialogAction onClick={handleSubmit} className="bg-red-500 hover:bg-red-600">
              Submit Final
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
