import { useEffect, forwardRef } from 'react';
import { Camera, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WebcamPreviewProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isActive: boolean;
  isLoading: boolean;
  error: string | null;
  className?: string;
  showOverlay?: boolean;
  onStart?: () => void;
}

export const WebcamPreview = forwardRef<HTMLDivElement, WebcamPreviewProps>(({
  videoRef,
  isActive,
  isLoading,
  error,
  className,
  showOverlay = true,
  onStart,
}, ref) => {
  return (
    <div
      ref={ref}
      className={cn(
        'relative bg-slate-900 rounded-xl overflow-hidden flex items-center justify-center',
        className
      )}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={cn(
          'w-full h-full object-cover',
          !isActive && 'hidden'
        )}
      />

      {/* Loading State */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
          <div className="text-center">
            <Loader2 className="h-10 w-10 text-teal-500 animate-spin mx-auto mb-2" />
            <p className="text-sm text-slate-400">Accessing camera...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
          <div className="text-center p-4">
            <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-2" />
            <p className="text-sm text-red-400 max-w-[200px]">{error}</p>
          </div>
        </div>
      )}

      {/* Inactive State */}
      {!isActive && !isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
          <div 
            className="text-center cursor-pointer"
            onClick={onStart}
          >
            <Camera className="h-12 w-12 text-slate-600 mx-auto mb-2" />
            <p className="text-sm text-slate-500">Click to start camera</p>
          </div>
        </div>
      )}

      {/* Active Indicator */}
      {isActive && showOverlay && (
        <div className="absolute top-3 left-3">
          <span className="px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full flex items-center gap-1.5">
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
            Camera Active
          </span>
        </div>
      )}
    </div>
  );
});

WebcamPreview.displayName = 'WebcamPreview';
