import { useState } from 'react';
import { Camera, Clock, AlertTriangle, ChevronLeft, ChevronRight, X, ZoomIn } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { CapturedScreenshot } from '@/hooks/useScreenshotCapture';

interface ScreenshotGalleryProps {
  screenshots: CapturedScreenshot[];
  screenshotStats?: {
    total: number;
    periodic: number;
    incident: number;
    manual: number;
  };
  className?: string;
}

export function ScreenshotGallery({
  screenshots,
  screenshotStats,
  className,
}: ScreenshotGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<CapturedScreenshot | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const handlePrevious = () => {
    if (selectedImage) {
      const currentIdx = screenshots.findIndex((s) => s.id === selectedImage.id);
      if (currentIdx > 0) {
        setSelectedImage(screenshots[currentIdx - 1]);
        setCurrentIndex(currentIdx - 1);
      }
    }
  };

  const handleNext = () => {
    if (selectedImage) {
      const currentIdx = screenshots.findIndex((s) => s.id === selectedImage.id);
      if (currentIdx < screenshots.length - 1) {
        setSelectedImage(screenshots[currentIdx + 1]);
        setCurrentIndex(currentIdx + 1);
      }
    }
  };

  const openImage = (screenshot: CapturedScreenshot, index: number) => {
    setSelectedImage(screenshot);
    setCurrentIndex(index);
  };

  const stats = screenshotStats || {
    total: screenshots.length,
    periodic: screenshots.filter((s) => s.type === 'periodic').length,
    incident: screenshots.filter((s) => s.type === 'incident').length,
    manual: screenshots.filter((s) => s.type === 'manual').length,
  };

  // Group screenshots by type
  const incidentScreenshots = screenshots.filter((s) => s.type === 'incident');
  const periodicScreenshots = screenshots.filter((s) => s.type === 'periodic');

  return (
    <>
      <Card className={cn('border-0 shadow-md', className)}>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Camera className="h-5 w-5 text-teal-600" />
              Screenshot Evidence
            </CardTitle>
            <Badge variant="secondary">{stats.total} Captured</Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <p className="text-2xl font-bold text-slate-700">{stats.periodic}</p>
              <p className="text-xs text-slate-500">Periodic</p>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <p className="text-2xl font-bold text-red-600">{stats.incident}</p>
              <p className="text-xs text-slate-500">Incidents</p>
            </div>
            <div className="text-center p-3 bg-teal-50 rounded-lg">
              <p className="text-2xl font-bold text-teal-600">{stats.manual}</p>
              <p className="text-xs text-slate-500">Manual</p>
            </div>
          </div>

          {/* Incident Screenshots */}
          {incidentScreenshots.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                Incident Captures
              </h4>
              <ScrollArea className="w-full whitespace-nowrap">
                <div className="flex gap-3 pb-3">
                  {incidentScreenshots.map((screenshot, idx) => (
                    <button
                      key={screenshot.id}
                      onClick={() => openImage(screenshot, screenshots.indexOf(screenshot))}
                      className="relative flex-shrink-0 group"
                    >
                      <img
                        src={screenshot.imageData}
                        alt={`Incident screenshot ${idx + 1}`}
                        className="h-20 w-28 object-cover rounded-lg border-2 border-red-200 transition-transform group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 rounded-lg transition-colors flex items-center justify-center">
                        <ZoomIn className="h-5 w-5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1.5">
                        !
                      </Badge>
                    </button>
                  ))}
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </div>
          )}

          {/* Periodic Screenshots */}
          {periodicScreenshots.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-slate-500" />
                Periodic Captures
              </h4>
              <ScrollArea className="w-full whitespace-nowrap">
                <div className="flex gap-3 pb-3">
                  {periodicScreenshots.slice(0, 10).map((screenshot, idx) => (
                    <button
                      key={screenshot.id}
                      onClick={() => openImage(screenshot, screenshots.indexOf(screenshot))}
                      className="relative flex-shrink-0 group"
                    >
                      <img
                        src={screenshot.imageData}
                        alt={`Periodic screenshot ${idx + 1}`}
                        className="h-20 w-28 object-cover rounded-lg border border-slate-200 transition-transform group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 rounded-lg transition-colors flex items-center justify-center">
                        <ZoomIn className="h-5 w-5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <span className="absolute bottom-1 left-1 text-[10px] bg-black/50 text-white px-1 rounded">
                        {formatTimestamp(screenshot.timestamp)}
                      </span>
                    </button>
                  ))}
                  {periodicScreenshots.length > 10 && (
                    <div className="flex-shrink-0 h-20 w-28 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center">
                      <span className="text-sm text-slate-500">
                        +{periodicScreenshots.length - 10} more
                      </span>
                    </div>
                  )}
                </div>
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </div>
          )}

          {/* Empty State */}
          {screenshots.length === 0 && (
            <div className="text-center py-8">
              <Camera className="h-12 w-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500">No screenshots captured</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lightbox Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-3xl p-0 overflow-hidden">
          <DialogHeader className="p-4 border-b">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Screenshot {currentIndex + 1} of {screenshots.length}
              </DialogTitle>
              <div className="flex items-center gap-2">
                {selectedImage?.type === 'incident' && (
                  <Badge className="bg-red-100 text-red-700">Incident</Badge>
                )}
                {selectedImage?.type === 'periodic' && (
                  <Badge variant="secondary">Periodic</Badge>
                )}
              </div>
            </div>
          </DialogHeader>

          {selectedImage && (
            <div className="relative">
              <img
                src={selectedImage.imageData}
                alt="Screenshot preview"
                className="w-full h-auto max-h-[60vh] object-contain bg-slate-900"
              />

              {/* Navigation */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                onClick={handlePrevious}
                disabled={currentIndex === 0}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                onClick={handleNext}
                disabled={currentIndex === screenshots.length - 1}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </div>
          )}

          {selectedImage && (
            <div className="p-4 bg-slate-50 border-t">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <span className="text-slate-500">
                    <Clock className="h-4 w-4 inline mr-1" />
                    {formatTimestamp(selectedImage.timestamp)}
                  </span>
                  <span className="text-slate-500">
                    {selectedImage.timestamp.toLocaleDateString()}
                  </span>
                </div>
                {selectedImage.reason && (
                  <Badge variant="outline" className="text-red-600 border-red-200">
                    {selectedImage.reason}
                  </Badge>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
