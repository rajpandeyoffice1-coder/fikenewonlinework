import { CheckCircle, AlertCircle, AlertTriangle, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { FaceDetectionResult } from '@/hooks/useFaceDetection';

interface FaceDetectionStatusProps {
  result: FaceDetectionResult;
  isLoading: boolean;
  isModelLoaded: boolean;
  className?: string;
}

interface StatusItem {
  id: string;
  label: string;
  status: 'success' | 'warning' | 'error' | 'loading';
}

export function FaceDetectionStatus({
  result,
  isLoading,
  isModelLoaded,
  className,
}: FaceDetectionStatusProps) {
  const getStatusItems = (): StatusItem[] => {
    if (isLoading || !isModelLoaded) {
      return [
        { id: 'loading', label: 'Loading face detection...', status: 'loading' },
      ];
    }

    const items: StatusItem[] = [
      {
        id: 'face_detected',
        label: result.faceDetected ? 'Face detected' : 'No face detected',
        status: result.faceDetected ? 'success' : 'error',
      },
      {
        id: 'multiple_faces',
        label: result.multipleFaces ? 'Multiple faces detected' : 'Single person',
        status: result.multipleFaces ? 'warning' : 'success',
      },
      {
        id: 'looking_away',
        label: result.lookingAway ? 'Looking away' : 'Looking at screen',
        status: result.lookingAway ? 'warning' : 'success',
      },
      {
        id: 'eyes_visible',
        label: result.eyesNotVisible ? 'Eyes not visible' : 'Eyes visible',
        status: result.eyesNotVisible ? 'warning' : 'success',
      },
    ];

    return items;
  };

  const getStatusIcon = (status: StatusItem['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-amber-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'loading':
        return <Loader2 className="h-4 w-4 text-slate-400 animate-spin" />;
    }
  };

  const getStatusBg = (status: StatusItem['status']) => {
    switch (status) {
      case 'success':
        return 'bg-green-50 border-green-200';
      case 'warning':
        return 'bg-amber-50 border-amber-200';
      case 'error':
        return 'bg-red-50 border-red-200';
      case 'loading':
        return 'bg-slate-50 border-slate-200';
    }
  };

  const statusItems = getStatusItems();

  return (
    <div className={cn('space-y-2', className)}>
      {statusItems.map((item) => (
        <div
          key={item.id}
          className={cn(
            'flex items-center gap-3 px-4 py-3 rounded-lg border transition-colors',
            getStatusBg(item.status)
          )}
        >
          {getStatusIcon(item.status)}
          <span className="text-sm text-slate-700">{item.label}</span>
        </div>
      ))}
      
      {isModelLoaded && result.faceDetected && (
        <div className="mt-2 px-4 py-2 bg-slate-50 rounded-lg text-xs text-slate-500">
          Confidence: {Math.round(result.confidence * 100)}%
        </div>
      )}
    </div>
  );
}
