import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const trustedOrganizations = ['LG', 'Philips', 'Google', 'Microsoft', 'Paytm', 'Walmart'];

export function StudentAuth() {
  const [showPassword, setShowPassword] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Login successful! Redirecting...');
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero Section */}
      <div className="hidden lg:flex flex-1 bg-[hsl(200,60%,94%)] flex-col items-center justify-center p-12 relative">
        <div className="text-center max-w-lg">
          {/* Logo */}
          <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm mb-8">
            <span className="text-xl font-bold">
              <span className="text-slate-800">exam</span>
              <span className="text-teal-600">express</span>
            </span>
            <span className="text-teal-600">↗</span>
          </div>

          <h1 className="text-3xl font-bold text-slate-800 mb-3">
            Secure Online Proctored Exams
          </h1>
          <p className="text-slate-600 text-lg mb-8">
            AI-powered monitoring ensures exam integrity with real-time proctoring.
          </p>

          {/* Illustration */}
          <div className="relative mb-10">
            <div className="w-72 h-48 mx-auto bg-white rounded-xl shadow-lg flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-teal-50 to-blue-50" />
              <div className="relative z-10 p-4">
                <div className="w-full h-32 bg-slate-100 rounded-lg border border-slate-200 flex flex-col p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-red-400" />
                    <div className="w-3 h-3 rounded-full bg-amber-400" />
                    <div className="w-3 h-3 rounded-full bg-green-400" />
                  </div>
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-sm text-slate-500">Online Exam Interface</div>
                  </div>
                </div>
              </div>
              {/* Decorative leaves */}
              <div className="absolute -bottom-2 -left-2 w-16 h-16 text-teal-400 opacity-60">
                <svg viewBox="0 0 100 100" fill="currentColor">
                  <ellipse cx="30" cy="70" rx="20" ry="40" transform="rotate(-30 30 70)" />
                </svg>
              </div>
              <div className="absolute -bottom-2 -right-2 w-16 h-16 text-teal-300 opacity-60">
                <svg viewBox="0 0 100 100" fill="currentColor">
                  <ellipse cx="70" cy="70" rx="20" ry="40" transform="rotate(30 70 70)" />
                </svg>
              </div>
            </div>
          </div>

          {/* Trusted Organizations */}
          <div className="text-sm text-slate-500 mb-4">TRUSTED BY LEADING ORGANIZATIONS</div>
          <div className="flex flex-wrap justify-center gap-3">
            {trustedOrganizations.map((org) => (
              <span
                key={org}
                className="px-4 py-2 bg-teal-700 text-white text-sm font-medium rounded-md"
              >
                {org}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Right side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-md">
          <Card className="shadow-lg border-0">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-semibold text-slate-800">
                  Student Login <span className="text-2xl">👋</span>
                </h2>
                <p className="text-slate-500 mt-1">
                  Sign in to{' '}
                  <span className="text-teal-600 font-medium">ExamExpress</span>
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-5">
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input
                    placeholder="CAN_27279296"
                    className="pl-11 h-12 bg-slate-50 border-slate-200 focus:border-teal-500 focus:ring-teal-500"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                  />
                </div>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="pl-11 pr-11 h-12 bg-slate-50 border-slate-200 focus:border-teal-500 focus:ring-teal-500"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 bg-teal-700 hover:bg-teal-800 text-white text-base font-medium"
                  asChild
                >
                  <Link to="/student/dashboard">Login</Link>
                </Button>
              </form>

              <p className="text-center text-sm text-slate-500 mt-6">
                By signing in, you agree to our{' '}
                <Link to="#" className="text-teal-600 hover:underline">Terms</Link>
                {' '}and{' '}
                <Link to="#" className="text-teal-600 hover:underline">Privacy Policy</Link>
              </p>
            </CardContent>
          </Card>

          <p className="text-center text-sm text-slate-500 mt-6">
            <Link to="/" className="hover:text-teal-600">← Back to Admin Portal</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
