import { useState, useEffect, useCallback } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { 
  Camera, 
  Upload, 
  Eye, 
  Monitor, 
  Activity, 
  Clock, 
  Mic, 
  Smartphone, 
  User,
  Check,
  X,
  AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { useWebcam } from '@/hooks/useWebcam';
import { WebcamPreview } from './WebcamPreview';
import { useFaceDetection } from '@/hooks/useFaceDetection';
import { useIdCardDetection } from '@/hooks/useIdCardDetection';

const examInstructions = [
  { 
    icon: Camera, 
    title: 'Camera must be ON', 
    description: 'Camera will be active throughout the exam.',
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  { 
    icon: Eye, 
    title: 'Face must be visible', 
    description: 'Keep your face clearly visible during the exam.',
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  { 
    icon: Monitor, 
    title: 'No tab switch', 
    description: 'Tab switching or new windows will be flagged.',
    color: 'text-amber-600',
    bgColor: 'bg-amber-100'
  },
  { 
    icon: Activity, 
    title: 'AI movement monitoring', 
    description: 'AI monitors head & eye direction.',
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  { 
    icon: Clock, 
    title: 'Screenshot every 1 min', 
    description: 'Screenshots recorded regularly.',
    color: 'text-slate-600',
    bgColor: 'bg-slate-100'
  },
  { 
    icon: Mic, 
    title: 'Mic monitored', 
    description: 'Noise & background sounds monitored.',
    color: 'text-rose-600',
    bgColor: 'bg-rose-100'
  },
  { 
    icon: Smartphone, 
    title: 'No mobile devices', 
    description: 'External device use prohibited.',
    color: 'text-slate-600',
    bgColor: 'bg-slate-100'
  },
];

export function IdentityVerification() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [selfieCapured, setSelfieCapured] = useState(false);
  const [selfieImage, setSelfieImage] = useState<string | null>(null);
  const [idCaptured, setIdCaptured] = useState(false);
  const [idImage, setIdImage] = useState<string | null>(null);
  const [agreedToInstructions, setAgreedToInstructions] = useState(false);
  const [captureMode, setCaptureMode] = useState<'selfie' | 'id' | null>(null);

  const { videoRef, isActive, isLoading, error, startCamera, stopCamera, captureImage } = useWebcam({ 
    video: { width: 640, height: 480, facingMode: 'user' }, 
    audio: false 
  });

  // Face detection for selfie
  const { 
    result: faceResult, 
    isLoading: faceLoading,
    isModelLoaded: faceModelLoaded 
  } = useFaceDetection({
    videoElement: captureMode === 'selfie' && isActive ? videoRef.current : null,
    enabled: captureMode === 'selfie' && isActive,
    detectionInterval: 300,
  });

  // ID card detection
  const { result: idResult } = useIdCardDetection({
    videoElement: captureMode === 'id' && isActive ? videoRef.current : null,
    enabled: captureMode === 'id' && isActive,
    detectionInterval: 400,
  });

  // Selfie capture is valid only when exactly 1 face is detected
  const canCaptureSelfie = faceResult.faceDetected && 
    !faceResult.multipleFaces && 
    faceResult.faceCount === 1 &&
    faceResult.confidence > 0.5;

  // ID capture is valid when card is detected
  const canCaptureId = idResult.cardDetected && !idResult.isBlurry;

  const canProceed = selfieCapured && idCaptured && agreedToInstructions;

  // Get selfie detection status message
  const getSelfieStatusMessage = () => {
    if (faceLoading || !faceModelLoaded) return { message: 'Loading face detection...', type: 'loading' };
    if (!faceResult.faceDetected) return { message: 'No face detected - Position your face in frame', type: 'error' };
    if (faceResult.multipleFaces) return { message: 'Multiple faces detected - Only one person allowed', type: 'error' };
    if (faceResult.faceCount === 1 && faceResult.confidence > 0.5) return { message: 'Face detected - Ready to capture', type: 'success' };
    return { message: 'Adjust position for better detection', type: 'warning' };
  };

  // Start camera for selfie capture
  const handleStartSelfieCapture = useCallback(async () => {
    setCaptureMode('selfie');
    await startCamera();
  }, [startCamera]);

  // Start camera for ID capture
  const handleStartIdCapture = useCallback(async () => {
    setCaptureMode('id');
    await startCamera();
  }, [startCamera]);

  const handleCaptureSelfie = () => {
    if (!canCaptureSelfie) {
      toast.error('Please ensure your face is clearly visible');
      return;
    }
    const image = captureImage();
    if (image) {
      setSelfieImage(image);
      setSelfieCapured(true);
      stopCamera();
      setCaptureMode(null);
      toast.success('Selfie captured successfully');
    }
  };

  const handleCaptureId = () => {
    if (!canCaptureId) {
      toast.error('Please ensure ID card is clearly visible');
      return;
    }
    const image = captureImage();
    if (image) {
      setIdImage(image);
      setIdCaptured(true);
      stopCamera();
      setCaptureMode(null);
      toast.success('ID captured successfully');
    }
  };

  const handleRetakeSelfie = () => {
    setSelfieCapured(false);
    setSelfieImage(null);
    handleStartSelfieCapture();
  };

  const handleRetakeId = () => {
    setIdCaptured(false);
    setIdImage(null);
    handleStartIdCapture();
  };

  const handleProceed = () => {
    if (canProceed) {
      navigate(`/student/exam/${examId}/profile`);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold">
              <span className="text-slate-800">exam</span>
              <span className="text-teal-600">express</span>
            </span>
            <span className="text-teal-600">↗</span>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/student/dashboard">
              <User className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-slate-800">Exam Instructions</h1>
          <p className="text-slate-500">Read before starting exam</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Instructions */}
          <div className="space-y-4">
            {examInstructions.map((instruction, index) => {
              const Icon = instruction.icon;
              return (
                <div key={index} className="flex items-start gap-4 p-4 bg-white rounded-xl border border-slate-200">
                  <div className={`h-10 w-10 rounded-lg ${instruction.bgColor} flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`h-5 w-5 ${instruction.color}`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">{instruction.title}</h3>
                    <p className="text-sm text-slate-500">{instruction.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column - Identity Verification */}
          <div className="space-y-6">
            {/* Verification Examples */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-semibold text-slate-800 mb-4 text-center">Identity Verification</h3>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <span className="px-2 py-1 bg-red-100 text-red-600 text-xs font-medium rounded mb-2 inline-block">Don't</span>
                  <div className="aspect-square bg-slate-100 rounded-lg flex items-center justify-center">
                    <div className="text-center p-2">
                      <div className="w-12 h-12 mx-auto mb-1 bg-slate-200 rounded-full flex items-center justify-center">
                        <X className="h-6 w-6 text-red-500" />
                      </div>
                      <p className="text-xs text-slate-500">Face not visible</p>
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <span className="px-2 py-1 bg-green-100 text-green-600 text-xs font-medium rounded mb-2 inline-block">Do</span>
                  <div className="aspect-square bg-slate-100 rounded-lg flex items-center justify-center">
                    <div className="text-center p-2">
                      <div className="w-12 h-12 mx-auto mb-1 bg-slate-200 rounded-full flex items-center justify-center">
                        <Check className="h-6 w-6 text-green-500" />
                      </div>
                      <p className="text-xs text-slate-500">Correct position</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Selfie Capture */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-semibold text-slate-800 mb-4 text-center">Selfie</h3>
              <div className="aspect-video bg-slate-100 rounded-lg flex items-center justify-center mb-2 border-2 border-dashed border-slate-300 overflow-hidden relative">
                {selfieCapured && selfieImage ? (
                  <img src={selfieImage} alt="Captured selfie" className="w-full h-full object-cover" />
                ) : captureMode === 'selfie' ? (
                  <>
                    <WebcamPreview
                      videoRef={videoRef}
                      isActive={isActive}
                      isLoading={isLoading}
                      error={error}
                      className="w-full h-full"
                      showOverlay={false}
                      onStart={handleStartSelfieCapture}
                    />
                    {/* Face detection overlay */}
                    {isActive && (
                      <div className={`absolute bottom-2 left-2 right-2 px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                        canCaptureSelfie 
                          ? 'bg-green-500/90 text-white' 
                          : faceResult.multipleFaces 
                            ? 'bg-red-500/90 text-white'
                            : 'bg-amber-500/90 text-white'
                      }`}>
                        {canCaptureSelfie ? (
                          <><Check className="h-4 w-4" /> Face detected - Ready to capture</>
                        ) : faceResult.multipleFaces ? (
                          <><AlertTriangle className="h-4 w-4" /> Multiple faces detected - Only one person allowed</>
                        ) : faceLoading || !faceModelLoaded ? (
                          <><Activity className="h-4 w-4 animate-pulse" /> Loading face detection...</>
                        ) : (
                          <><AlertTriangle className="h-4 w-4" /> No face detected - Position your face in frame</>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center">
                    <Camera className="h-12 w-12 text-slate-400 mx-auto mb-2" />
                    <p className="text-slate-400">Take Selfie</p>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                {selfieCapured ? (
                  <>
                    <Button 
                      onClick={handleRetakeSelfie}
                      variant="outline"
                      className="border-teal-600 text-teal-600 hover:bg-teal-50"
                    >
                      Retake
                    </Button>
                    <Button disabled className="bg-green-600">
                      <Check className="h-4 w-4 mr-2" />
                      Captured
                    </Button>
                  </>
                ) : captureMode === 'selfie' && isActive ? (
                  <>
                    <Button 
                      onClick={() => { stopCamera(); setCaptureMode(null); }}
                      variant="outline"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCaptureSelfie}
                      disabled={!canCaptureSelfie}
                      className={canCaptureSelfie ? "bg-teal-600 hover:bg-teal-700" : "bg-slate-300 cursor-not-allowed"}
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      Capture
                    </Button>
                  </>
                ) : (
                  <Button 
                    onClick={handleStartSelfieCapture}
                    className="col-span-2 bg-teal-600 hover:bg-teal-700"
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Start Camera
                  </Button>
                )}
              </div>
            </div>

            {/* ID Document Capture */}
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-semibold text-slate-800 mb-4 text-center">ID Document</h3>
              <div className="aspect-video bg-slate-100 rounded-lg flex items-center justify-center mb-2 border-2 border-dashed border-slate-300 overflow-hidden relative">
                {idCaptured && idImage ? (
                  <img src={idImage} alt="Captured ID" className="w-full h-full object-cover" />
                ) : captureMode === 'id' ? (
                  <>
                    <WebcamPreview
                      videoRef={videoRef}
                      isActive={isActive}
                      isLoading={isLoading}
                      error={error}
                      className="w-full h-full"
                      showOverlay={false}
                      onStart={handleStartIdCapture}
                    />
                    {/* ID detection overlay */}
                    {isActive && (
                      <div className={`absolute bottom-2 left-2 right-2 px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                        canCaptureId 
                          ? 'bg-green-500/90 text-white' 
                          : idResult.isBlurry 
                            ? 'bg-amber-500/90 text-white'
                            : 'bg-amber-500/90 text-white'
                      }`}>
                        {canCaptureId ? (
                          <><Check className="h-4 w-4" /> {idResult.message}</>
                        ) : idResult.isBlurry ? (
                          <><AlertTriangle className="h-4 w-4" /> Image is blurry - Hold steady</>
                        ) : (
                          <><AlertTriangle className="h-4 w-4" /> {idResult.message}</>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center">
                    <Upload className="h-12 w-12 text-slate-400 mx-auto mb-2" />
                    <p className="text-slate-400">Capture ID Document</p>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                {idCaptured ? (
                  <>
                    <Button 
                      onClick={handleRetakeId}
                      variant="outline"
                      className="border-teal-600 text-teal-600 hover:bg-teal-50"
                    >
                      Retake
                    </Button>
                    <Button disabled className="bg-green-600">
                      <Check className="h-4 w-4 mr-2" />
                      Captured
                    </Button>
                  </>
                ) : captureMode === 'id' && isActive ? (
                  <>
                    <Button 
                      onClick={() => { stopCamera(); setCaptureMode(null); }}
                      variant="outline"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCaptureId}
                      disabled={!canCaptureId}
                      className={canCaptureId ? "bg-teal-600 hover:bg-teal-700" : "bg-slate-300 cursor-not-allowed"}
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      Capture
                    </Button>
                  </>
                ) : (
                  <Button 
                    onClick={handleStartIdCapture}
                    className="col-span-2 bg-teal-600 hover:bg-teal-700"
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Start Camera
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Warning & Agreement */}
        <div className="mt-8 max-w-3xl mx-auto">
          <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg mb-4">
            <div className="text-amber-600 text-lg">⚠</div>
            <p className="text-sm text-amber-700">
              Violation may result in disqualification. AI continuously monitors your activity.
            </p>
          </div>

          <div className="flex items-center justify-center gap-3 mb-6">
            <Checkbox
              id="agree"
              checked={agreedToInstructions}
              onCheckedChange={(checked) => setAgreedToInstructions(checked as boolean)}
            />
            <label htmlFor="agree" className="text-sm text-slate-600 cursor-pointer">
              I agree to all instructions
            </label>
          </div>

          <div className="flex justify-center">
            <Button
              onClick={handleProceed}
              disabled={!canProceed}
              className={`px-12 h-12 text-base font-medium ${
                canProceed 
                  ? 'bg-teal-600 hover:bg-teal-700' 
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              Proceed to Profile
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
