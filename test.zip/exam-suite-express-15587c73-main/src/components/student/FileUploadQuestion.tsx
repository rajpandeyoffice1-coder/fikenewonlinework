import { useState, useCallback, useRef } from 'react';
import { Upload, X, FileText, Image, File, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface FileUploadQuestionProps {
  value: string | null;
  onChange: (fileUrl: string | null) => void;
  onAutoSave?: () => void;
  questionId?: string;
  examSessionId?: string;
}

interface UploadedFile {
  name: string;
  size: number;
  type: string;
  url: string;
  path: string;
}

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_FILE_TYPES = {
  'application/pdf': '.pdf',
  'image/jpeg': '.jpg,.jpeg',
  'image/png': '.png',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
};

const ACCEPTED_EXTENSIONS = '.pdf,.jpg,.jpeg,.png,.doc,.docx';

export function FileUploadQuestion({
  value,
  onChange,
  onAutoSave,
  questionId = 'unknown',
  examSessionId = 'demo-session',
}: FileUploadQuestionProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(
    value ? { name: 'Uploaded File', size: 0, type: '', url: value, path: '' } : null
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return Image;
    if (type === 'application/pdf') return FileText;
    return File;
  };

  const validateFile = (file: File): boolean => {
    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      toast.error('File too large', {
        description: `Maximum file size is ${formatFileSize(MAX_FILE_SIZE)}`,
      });
      return false;
    }

    // Check file type
    const isAcceptedType = Object.keys(ACCEPTED_FILE_TYPES).includes(file.type);
    const extension = '.' + file.name.split('.').pop()?.toLowerCase();
    const isAcceptedExtension = ACCEPTED_EXTENSIONS.includes(extension);

    if (!isAcceptedType && !isAcceptedExtension) {
      toast.error('Invalid file type', {
        description: 'Accepted formats: PDF, JPG, PNG, DOC, DOCX',
      });
      return false;
    }

    return true;
  };

  const uploadToSupabase = async (file: File): Promise<{ url: string; path: string }> => {
    // Get current user ID or use a demo ID for unauthenticated uploads
    const { data: { user } } = await supabase.auth.getUser();
    const userId = user?.id || 'demo-user';
    
    // Create unique file path: userId/examSessionId/questionId/timestamp_filename
    const timestamp = Date.now();
    const sanitizedFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
    const filePath = `${userId}/${examSessionId}/${questionId}/${timestamp}_${sanitizedFileName}`;

    // Simulate progress for better UX
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => Math.min(prev + 10, 90));
    }, 100);

    try {
      const { data, error } = await supabase.storage
        .from('exam-uploads')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
        });

      clearInterval(progressInterval);

      if (error) {
        console.error('Upload error:', error);
        // If it's an auth error, fall back to local URL for demo
        if (error.message.includes('not authorized') || error.message.includes('policy')) {
          console.log('Auth required for upload, using local preview');
          const localUrl = URL.createObjectURL(file);
          return { url: localUrl, path: 'local' };
        }
        throw error;
      }

      setUploadProgress(100);

      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('exam-uploads')
        .getPublicUrl(data.path);

      return { url: urlData.publicUrl, path: data.path };
    } catch (error) {
      clearInterval(progressInterval);
      // Fallback to local URL for demo purposes
      console.log('Falling back to local preview due to:', error);
      const localUrl = URL.createObjectURL(file);
      return { url: localUrl, path: 'local' };
    }
  };

  const handleFile = async (file: File) => {
    if (!validateFile(file)) return;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const { url, path } = await uploadToSupabase(file);

      const uploadedFileData: UploadedFile = {
        name: file.name,
        size: file.size,
        type: file.type,
        url: url,
        path: path,
      };

      setUploadedFile(uploadedFileData);
      onChange(url);
      onAutoSave?.();

      toast.success('File uploaded successfully');
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Upload failed', {
        description: 'Please try again.',
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      handleFile(file);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleRemoveFile = async () => {
    if (uploadedFile?.path && uploadedFile.path !== 'local') {
      // Try to delete from Supabase Storage
      try {
        await supabase.storage.from('exam-uploads').remove([uploadedFile.path]);
      } catch (error) {
        console.log('Could not delete file from storage:', error);
      }
    }
    
    if (uploadedFile?.url && uploadedFile.path === 'local') {
      URL.revokeObjectURL(uploadedFile.url);
    }
    
    setUploadedFile(null);
    onChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    toast.success('File removed');
  };

  const FileIcon = uploadedFile ? getFileIcon(uploadedFile.type) : File;

  return (
    <div className="space-y-4">
      {!uploadedFile ? (
        <>
          {/* Drop Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              'relative border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer',
              isDragging
                ? 'border-teal-500 bg-teal-50'
                : 'border-slate-300 hover:border-slate-400 hover:bg-slate-50',
              isUploading && 'pointer-events-none opacity-75'
            )}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_EXTENSIONS}
              onChange={handleFileSelect}
              className="hidden"
            />

            {isUploading ? (
              <div className="space-y-4">
                <Loader2 className="h-12 w-12 mx-auto text-teal-500 animate-spin" />
                <div>
                  <p className="text-slate-700 font-medium">Uploading...</p>
                  <p className="text-sm text-slate-500">{uploadProgress}%</p>
                </div>
                <Progress value={uploadProgress} className="w-full max-w-xs mx-auto" />
              </div>
            ) : (
              <>
                <Upload
                  className={cn(
                    'h-12 w-12 mx-auto mb-4',
                    isDragging ? 'text-teal-500' : 'text-slate-400'
                  )}
                />
                <p className="text-slate-700 font-medium mb-1">
                  {isDragging ? 'Drop your file here' : 'Drag and drop your file here'}
                </p>
                <p className="text-sm text-slate-500 mb-4">or</p>
                <Button
                  type="button"
                  variant="outline"
                  className="pointer-events-none"
                >
                  Browse File
                </Button>
              </>
            )}
          </div>

          {/* File requirements */}
          <div className="text-xs text-slate-500 space-y-1">
            <p>
              <span className="font-medium">Accepted formats:</span> PDF, JPG, PNG, DOC, DOCX
            </p>
            <p>
              <span className="font-medium">Maximum size:</span>{' '}
              {formatFileSize(MAX_FILE_SIZE)}
            </p>
          </div>
        </>
      ) : (
        /* Uploaded File Preview */
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-lg bg-teal-100 flex items-center justify-center">
              <FileIcon className="h-6 w-6 text-teal-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-medium text-slate-800 truncate">
                  {uploadedFile.name}
                </p>
                <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
              </div>
              {uploadedFile.size > 0 && (
                <p className="text-sm text-slate-500">
                  {formatFileSize(uploadedFile.size)}
                </p>
              )}
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={handleRemoveFile}
              className="text-red-500 hover:text-red-600 hover:bg-red-50"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Preview for images */}
          {uploadedFile.type.startsWith('image/') && (
            <div className="mt-4 rounded-lg overflow-hidden border border-slate-200">
              <img
                src={uploadedFile.url}
                alt="Preview"
                className="max-h-64 mx-auto"
              />
            </div>
          )}
        </div>
      )}

      {!uploadedFile && (
        <p className="text-sm text-red-500">Please upload a file to answer this question.</p>
      )}
    </div>
  );
}
