import { useState } from 'react';
import { Download, Printer, Mail, QrCode, User, Calendar, Clock, MapPin, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useStudentProfile, getInitials } from '@/hooks/useStudentProfile';
import { useStudentExams } from '@/hooks/useStudentExams';
import { format } from 'date-fns';
import { toast } from 'sonner';

export function AdmitCard() {
  const { profile, isLoading: profileLoading } = useStudentProfile();
  const { upcoming, ongoing, isLoading: examsLoading } = useStudentExams();
  const [selectedExam, setSelectedExam] = useState<string>('');
  const [showCard, setShowCard] = useState(false);

  // Combine upcoming and ongoing exams for admit card generation
  const availableExams = [...upcoming, ...ongoing];
  const selectedExamData = availableExams.find((e) => e.id === selectedExam);

  const handleGenerate = () => {
    if (!selectedExam) {
      toast.error('Please select an exam');
      return;
    }
    setShowCard(true);
    toast.success('Admit card generated successfully');
  };

  const handleDownload = () => {
    toast.success('Downloading admit card as PDF...');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEmail = () => {
    toast.success('Admit card sent to your email');
  };

  const isLoading = profileLoading || examsLoading;

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-destructive">Unable to load profile. Please try again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Generate Admit Card</h1>
        <p className="text-muted-foreground">Download your admit card for upcoming exams</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Exam</CardTitle>
          <CardDescription>Choose the exam for which you need an admit card</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Exam</Label>
            <Select value={selectedExam} onValueChange={setSelectedExam}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select an exam" />
              </SelectTrigger>
              <SelectContent className="bg-background border">
                {availableExams.length === 0 ? (
                  <SelectItem value="none" disabled>No exams available</SelectItem>
                ) : (
                  availableExams.map((exam) => (
                    <SelectItem key={exam.id} value={exam.id}>
                      {exam.name} - {exam.date ? format(new Date(exam.date), 'MMM dd, yyyy') : 'Date TBD'}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          {selectedExamData && (
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Student Name</p>
                <p className="font-medium">{profile.fullName}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Roll Number</p>
                <p className="font-medium">{profile.rollNumber}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Exam Date & Time</p>
                <p className="font-medium">
                  {selectedExamData.dateTime 
                    ? format(new Date(selectedExamData.dateTime), 'MMM dd, yyyy hh:mm a')
                    : 'Date TBD'}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Duration</p>
                <p className="font-medium">{selectedExamData.duration} minutes</p>
              </div>
            </div>
          )}

          <Button onClick={handleGenerate} disabled={!selectedExam || availableExams.length === 0}>
            Generate Admit Card
          </Button>
        </CardContent>
      </Card>

      {showCard && selectedExamData && (
        <Card className="print:shadow-none" id="admit-card">
          <CardContent className="p-8">
            {/* Header */}
            <div className="text-center border-b pb-6 mb-6">
              <h2 className="text-2xl font-bold text-primary">ExamExpress University</h2>
              <p className="text-lg font-semibold mt-2">ADMIT CARD</p>
              <p className="text-muted-foreground">Online Proctored Examination</p>
            </div>

            {/* Main Content */}
            <div className="grid grid-cols-3 gap-6">
              {/* Left - Photo & QR */}
              <div className="space-y-4">
                <div className="aspect-square bg-muted rounded-lg border-2 border-dashed flex items-center justify-center overflow-hidden">
                  {profile.photoUrl ? (
                    <Avatar className="h-full w-full rounded-lg">
                      <AvatarImage src={profile.photoUrl} className="object-cover" />
                      <AvatarFallback className="text-4xl bg-primary text-primary-foreground rounded-lg">
                        {getInitials(profile.fullName)}
                      </AvatarFallback>
                    </Avatar>
                  ) : (
                    <User className="h-16 w-16 text-muted-foreground" />
                  )}
                </div>
                <div className="aspect-square bg-muted rounded-lg border flex items-center justify-center">
                  <QrCode className="h-16 w-16 text-muted-foreground" />
                </div>
              </div>

              {/* Center - Details */}
              <div className="col-span-2 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Student Name</p>
                    <p className="font-semibold text-lg">{profile.fullName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Roll Number</p>
                    <p className="font-semibold text-lg">{profile.rollNumber}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-sm text-muted-foreground">Exam Name</p>
                  <p className="font-semibold">{selectedExamData.name}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Date</p>
                      <p className="font-medium">
                        {selectedExamData.dateTime 
                          ? format(new Date(selectedExamData.dateTime), 'MMMM dd, yyyy')
                          : 'Date TBD'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Time</p>
                      <p className="font-medium">
                        {selectedExamData.dateTime 
                          ? format(new Date(selectedExamData.dateTime), 'hh:mm a')
                          : 'Time TBD'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-medium">{selectedExamData.duration} minutes</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Exam Mode</p>
                    <p className="font-medium">Online Proctored</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Reporting Time</p>
                    <p className="font-medium">15 minutes before exam start time</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="mt-6 p-4 bg-muted rounded-lg">
              <h3 className="font-semibold mb-2">Instructions:</h3>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Ensure stable internet connection (minimum 2 Mbps)</li>
                <li>• Keep your webcam and microphone enabled throughout the exam</li>
                <li>• Have a valid photo ID ready for verification</li>
                <li>• Do not switch tabs or open other applications during the exam</li>
                <li>• Complete the device check before starting the exam</li>
              </ul>
            </div>

            {/* Footer */}
            <div className="mt-6 pt-4 border-t flex items-center justify-between text-sm text-muted-foreground">
              <span>Exam Code: {selectedExamData.examCode || selectedExamData.id}</span>
              <span>Generated on: {format(new Date(), 'MMM dd, yyyy hh:mm a')}</span>
            </div>
          </CardContent>

          {/* Action Buttons */}
          <div className="p-4 border-t flex items-center justify-end gap-3 print:hidden">
            <Button variant="outline" onClick={handleEmail}>
              <Mail className="h-4 w-4 mr-2" />
              Email to Me
            </Button>
            <Button variant="outline" onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button onClick={handleDownload}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
