import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Search, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { StudentGroup, StudentGroupMember } from "@/types/studentGroup";
import { Constants } from "@/integrations/supabase/types";

interface Student {
  id: string;
  full_name: string;
  roll_no: string;
  email: string;
  department: string;
  semester: number;
}

interface AssignStudentsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  group: StudentGroup;
  onAssign: (groupId: string, studentIds: string[]) => Promise<void>;
  getGroupMembers: (groupId: string) => Promise<StudentGroupMember[]>;
}

const departments = Constants.public.Enums.department_enum;
const semesters = [1, 2, 3, 4, 5, 6, 7, 8];

export function AssignStudentsModal({
  open,
  onOpenChange,
  group,
  onAssign,
  getGroupMembers,
}: AssignStudentsModalProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [existingMemberIds, setExistingMemberIds] = useState<Set<string>>(new Set());
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [semesterFilter, setSemesterFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      loadData();
    }
  }, [open, group.id]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Fetch all students
      const { data: studentsData, error } = await supabase
        .from("students")
        .select("id, full_name, roll_no, email, department, semester")
        .eq("status", "active")
        .order("full_name");

      if (error) throw error;
      setStudents(studentsData || []);

      // Fetch existing members
      const members = await getGroupMembers(group.id);
      setExistingMemberIds(new Set(members.map((m) => m.student_id)));
    } catch (error) {
      console.error("Error loading students:", error);
    } finally {
      setLoading(false);
    }
    setSelectedIds(new Set());
    setSearchQuery("");
    setDepartmentFilter("all");
    setSemesterFilter("all");
  };

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.roll_no.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = departmentFilter === "all" || student.department === departmentFilter;
    const matchesSemester = semesterFilter === "all" || student.semester.toString() === semesterFilter;
    const notAlreadyMember = !existingMemberIds.has(student.id);

    return matchesSearch && matchesDepartment && matchesSemester && notAlreadyMember;
  });

  const toggleStudent = (studentId: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(studentId)) {
      newSelected.delete(studentId);
    } else {
      newSelected.add(studentId);
    }
    setSelectedIds(newSelected);
  };

  const toggleAll = () => {
    if (selectedIds.size === filteredStudents.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredStudents.map((s) => s.id)));
    }
  };

  const handleSubmit = async () => {
    if (selectedIds.size === 0) return;

    setSubmitting(true);
    try {
      await onAssign(group.id, Array.from(selectedIds));
      onOpenChange(false);
    } catch (error) {
      // Error handled in hook
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Add Students to {group.group_name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, roll no, email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={semesterFilter} onValueChange={setSemesterFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Semester" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Semesters</SelectItem>
                {semesters.map((sem) => (
                  <SelectItem key={sem} value={sem.toString()}>
                    Semester {sem}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {selectedIds.size > 0 && (
              <Badge variant="secondary" className="ml-auto">
                {selectedIds.size} selected
              </Badge>
            )}
          </div>

          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading students...
            </div>
          ) : filteredStudents.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {students.length === existingMemberIds.size
                ? "All students are already in this group"
                : "No students found matching your filters"}
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 px-2">
                <Checkbox
                  checked={selectedIds.size === filteredStudents.length && filteredStudents.length > 0}
                  onCheckedChange={toggleAll}
                />
                <span className="text-sm text-muted-foreground">
                  Select all ({filteredStudents.length} students)
                </span>
              </div>

              <ScrollArea className="h-[300px] border rounded-md">
                <div className="p-2 space-y-1">
                  {filteredStudents.map((student) => (
                    <div
                      key={student.id}
                      className="flex items-center gap-3 p-2 hover:bg-muted rounded-md cursor-pointer"
                      onClick={() => toggleStudent(student.id)}
                    >
                      <Checkbox
                        checked={selectedIds.has(student.id)}
                        onCheckedChange={() => toggleStudent(student.id)}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{student.full_name}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {student.roll_no} • {student.email}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Badge variant="outline" className="text-xs">
                          {student.department}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          Sem {student.semester}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={selectedIds.size === 0 || submitting}>
            {submitting ? "Adding..." : `Add ${selectedIds.size} Student(s)`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
