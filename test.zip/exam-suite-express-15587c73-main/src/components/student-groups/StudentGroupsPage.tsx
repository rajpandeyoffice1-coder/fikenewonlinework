import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
  Users,
  UserPlus,
} from "lucide-react";
import { useStudentGroups } from "@/hooks/useStudentGroups";
import { StudentGroup } from "@/types/studentGroup";
import { CreateGroupModal } from "./CreateGroupModal";
import { AssignStudentsModal } from "./AssignStudentsModal";
import { GroupMembersModal } from "./GroupMembersModal";

export function StudentGroupsPage() {
  const { groups, loading, createGroup, updateGroup, deleteGroup, getGroupMembers, addMembersToGroup, removeMemberFromGroup } = useStudentGroups();
  const [searchQuery, setSearchQuery] = useState("");
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<StudentGroup | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [groupToDelete, setGroupToDelete] = useState<StudentGroup | null>(null);
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [membersModalOpen, setMembersModalOpen] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState<StudentGroup | null>(null);

  const filteredGroups = groups.filter(
    (group) =>
      group.group_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.group_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (group.department?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
  );

  const handleCreateGroup = async (data: Partial<StudentGroup>) => {
    await createGroup(data);
    setCreateModalOpen(false);
  };

  const handleUpdateGroup = async (data: Partial<StudentGroup>) => {
    if (editingGroup) {
      await updateGroup(editingGroup.id, data);
      setEditingGroup(null);
    }
  };

  const handleDeleteGroup = async () => {
    if (groupToDelete) {
      await deleteGroup(groupToDelete.id);
      setGroupToDelete(null);
      setDeleteDialogOpen(false);
    }
  };

  const handleViewMembers = (group: StudentGroup) => {
    setSelectedGroup(group);
    setMembersModalOpen(true);
  };

  const handleAddStudents = (group: StudentGroup) => {
    setSelectedGroup(group);
    setAssignModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Student Groups</h1>
          <p className="text-muted-foreground">
            Manage student batches, sections, and custom groups
          </p>
        </div>
        <Button onClick={() => setCreateModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Group
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search groups..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading groups...
            </div>
          ) : filteredGroups.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchQuery ? "No groups found matching your search" : "No student groups yet. Create your first group!"}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Group Name</TableHead>
                  <TableHead>Group Code</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Semester</TableHead>
                  <TableHead>Total Students</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredGroups.map((group) => (
                  <TableRow key={group.id}>
                    <TableCell className="font-medium">{group.group_name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{group.group_code}</Badge>
                    </TableCell>
                    <TableCell>{group.department || "-"}</TableCell>
                    <TableCell>{group.semester ? `Sem ${group.semester}` : "-"}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{group.member_count || 0} students</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewMembers(group)}>
                            <Users className="mr-2 h-4 w-4" />
                            View Members
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAddStudents(group)}>
                            <UserPlus className="mr-2 h-4 w-4" />
                            Add Students
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setEditingGroup(group)}>
                            <Pencil className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => {
                              setGroupToDelete(group);
                              setDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <CreateGroupModal
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        onSubmit={handleCreateGroup}
      />

      <CreateGroupModal
        open={!!editingGroup}
        onOpenChange={(open) => !open && setEditingGroup(null)}
        onSubmit={handleUpdateGroup}
        group={editingGroup}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Student Group</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{groupToDelete?.group_name}"? This will remove all student assignments from this group. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteGroup} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {selectedGroup && (
        <>
          <AssignStudentsModal
            open={assignModalOpen}
            onOpenChange={setAssignModalOpen}
            group={selectedGroup}
            onAssign={addMembersToGroup}
            getGroupMembers={getGroupMembers}
          />

          <GroupMembersModal
            open={membersModalOpen}
            onOpenChange={setMembersModalOpen}
            group={selectedGroup}
            getGroupMembers={getGroupMembers}
            onRemoveMember={removeMemberFromGroup}
          />
        </>
      )}
    </div>
  );
}
