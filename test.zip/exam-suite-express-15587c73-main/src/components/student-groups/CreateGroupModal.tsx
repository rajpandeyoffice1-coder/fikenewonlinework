import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { StudentGroup } from "@/types/studentGroup";
import { Constants } from "@/integrations/supabase/types";

interface CreateGroupModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: Partial<StudentGroup>) => Promise<void>;
  group?: StudentGroup | null;
}

const departments = Constants.public.Enums.department_enum;
const semesters = [1, 2, 3, 4, 5, 6, 7, 8];

export function CreateGroupModal({ open, onOpenChange, onSubmit, group }: CreateGroupModalProps) {
  const [formData, setFormData] = useState({
    group_name: "",
    group_code: "",
    department: "",
    semester: "",
    description: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (group) {
      setFormData({
        group_name: group.group_name,
        group_code: group.group_code,
        department: group.department || "",
        semester: group.semester?.toString() || "",
        description: group.description || "",
      });
    } else {
      setFormData({
        group_name: "",
        group_code: "",
        department: "",
        semester: "",
        description: "",
      });
    }
    setErrors({});
  }, [group, open]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.group_name || formData.group_name.length < 3) {
      newErrors.group_name = "Group name must be at least 3 characters";
    }
    if (!formData.group_code) {
      newErrors.group_code = "Group code is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    try {
      await onSubmit({
        group_name: formData.group_name,
        group_code: formData.group_code,
        department: formData.department || null,
        semester: formData.semester ? parseInt(formData.semester) : null,
        description: formData.description || null,
      });
      onOpenChange(false);
    } catch (error) {
      // Error handled in hook
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{group ? "Edit Student Group" : "Create Student Group"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="group_name">Group Name *</Label>
            <Input
              id="group_name"
              value={formData.group_name}
              onChange={(e) => setFormData({ ...formData, group_name: e.target.value })}
              placeholder="e.g., CSE Batch 2024"
            />
            {errors.group_name && (
              <p className="text-sm text-destructive">{errors.group_name}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="group_code">Group Code *</Label>
            <Input
              id="group_code"
              value={formData.group_code}
              onChange={(e) => setFormData({ ...formData, group_code: e.target.value.toUpperCase() })}
              placeholder="e.g., CSE-2024-A"
            />
            {errors.group_code && (
              <p className="text-sm text-destructive">{errors.group_code}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Select
                value={formData.department}
                onValueChange={(value) => setFormData({ ...formData, department: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="semester">Semester</Label>
              <Select
                value={formData.semester}
                onValueChange={(value) => setFormData({ ...formData, semester: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select semester" />
                </SelectTrigger>
                <SelectContent>
                  {semesters.map((sem) => (
                    <SelectItem key={sem} value={sem.toString()}>
                      Semester {sem}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Optional description for this group"
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? "Saving..." : group ? "Update Group" : "Create Group"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
