import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Search, UserMinus, Users } from "lucide-react";
import { StudentGroup, StudentGroupMember } from "@/types/studentGroup";

interface GroupMembersModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  group: StudentGroup;
  getGroupMembers: (groupId: string) => Promise<StudentGroupMember[]>;
  onRemoveMember: (groupId: string, studentId: string) => Promise<void>;
}

export function GroupMembersModal({
  open,
  onOpenChange,
  group,
  getGroupMembers,
  onRemoveMember,
}: GroupMembersModalProps) {
  const [members, setMembers] = useState<StudentGroupMember[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);
  const [memberToRemove, setMemberToRemove] = useState<StudentGroupMember | null>(null);
  const [removing, setRemoving] = useState(false);

  useEffect(() => {
    if (open) {
      loadMembers();
    }
  }, [open, group.id]);

  const loadMembers = async () => {
    setLoading(true);
    try {
      const data = await getGroupMembers(group.id);
      setMembers(data);
    } catch (error) {
      console.error("Error loading members:", error);
    } finally {
      setLoading(false);
    }
    setSearchQuery("");
  };

  const filteredMembers = members.filter((member) => {
    if (!member.student) return false;
    return (
      member.student.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.student.roll_no.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.student.email.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const handleRemove = async () => {
    if (!memberToRemove) return;

    setRemoving(true);
    try {
      await onRemoveMember(group.id, memberToRemove.student_id);
      setMembers(members.filter((m) => m.id !== memberToRemove.id));
      setMemberToRemove(null);
      setRemoveDialogOpen(false);
    } catch (error) {
      // Error handled in hook
    } finally {
      setRemoving(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Members of {group.group_name}
              <Badge variant="secondary" className="ml-2">
                {members.length} students
              </Badge>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search members..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {loading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading members...
              </div>
            ) : members.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No students in this group yet
              </div>
            ) : filteredMembers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No members found matching your search
              </div>
            ) : (
              <ScrollArea className="h-[400px] border rounded-md">
                <div className="p-2 space-y-1">
                  {filteredMembers.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center gap-3 p-3 hover:bg-muted rounded-md"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{member.student?.full_name}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {member.student?.roll_no} • {member.student?.email}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {member.student?.department}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          Sem {member.student?.semester}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => {
                            setMemberToRemove(member);
                            setRemoveDialogOpen(true);
                          }}
                        >
                          <UserMinus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={removeDialogOpen} onOpenChange={setRemoveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Student from Group</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove "{memberToRemove?.student?.full_name}" from {group.group_name}?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={removing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRemove}
              disabled={removing}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {removing ? "Removing..." : "Remove"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
