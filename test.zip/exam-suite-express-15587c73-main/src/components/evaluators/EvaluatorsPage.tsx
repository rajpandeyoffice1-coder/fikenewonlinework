import { useState, useMemo, useEffect } from 'react';
import { Plus, UserX, ClipboardList, Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { EvaluatorStats } from './EvaluatorStats';
import { EvaluatorFilters } from './EvaluatorFilters';
import { EvaluatorsTable } from './EvaluatorsTable';
import { AddEvaluatorModal } from './AddEvaluatorModal';
import { EvaluatorProfileModal } from './EvaluatorProfileModal';
import { AssignEvaluatorModal } from './AssignEvaluatorModal';
import { EvaluationWindow } from './EvaluationWindow';

interface Evaluator {
  id: string;
  name: string;
  evaluatorId: string;
  email: string;
  mobile: string;
  department: string;
  subjectExpertise: string[];
  experience: number;
  photoUrl?: string;
  status: 'active' | 'inactive';
  assignedExamsCount: number;
  pendingSheets: number;
  lastLogin?: string;
  createdAt: string;
  permissions: {
    viewAnswerSheets: boolean;
    scoreSubjectiveAnswers: boolean;
    addComments: boolean;
    reEvaluateSheets: boolean;
    viewRubrics: boolean;
  };
  totalEvaluationsCompleted: number;
  avgScoringTime: string;
  accuracyScore: number;
}

// Convert DB row to Evaluator type
const dbToEvaluator = (row: any): Evaluator => ({
  id: row.id,
  name: row.name,
  evaluatorId: `EVAL${row.id.slice(0, 6).toUpperCase()}`,
  email: row.email,
  mobile: row.mobile || '',
  department: row.department || '',
  subjectExpertise: row.subject_expertise || [],
  experience: row.experience || 0,
  photoUrl: undefined,
  status: row.status,
  assignedExamsCount: row.assigned_exams_count || 0,
  pendingSheets: row.pending_sheets || 0,
  lastLogin: row.last_login,
  createdAt: row.created_at,
  permissions: row.permissions || {
    viewAnswerSheets: true,
    scoreSubjectiveAnswers: true,
    addComments: false,
    reEvaluateSheets: false,
    viewRubrics: true,
  },
  totalEvaluationsCompleted: row.total_evaluations || 0,
  avgScoringTime: '0 min',
  accuracyScore: 0,
});

export function EvaluatorsPage() {
  const [evaluators, setEvaluators] = useState<Evaluator[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [department, setDepartment] = useState('All Departments');
  const [status, setStatus] = useState('All Status');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const [addModalOpen, setAddModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [evaluationWindowOpen, setEvaluationWindowOpen] = useState(false);
  const [editingEvaluator, setEditingEvaluator] = useState<Evaluator | null>(null);
  const [viewingEvaluator, setViewingEvaluator] = useState<Evaluator | null>(null);
  const [assigningEvaluator, setAssigningEvaluator] = useState<Evaluator | null>(null);

  // Fetch evaluators from database
  useEffect(() => {
    const fetchEvaluators = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('evaluators')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching evaluators:', error);
        toast.error('Failed to load evaluators');
      } else {
        setEvaluators((data || []).map(dbToEvaluator));
      }
      setIsLoading(false);
    };

    fetchEvaluators();
  }, []);

  const stats = useMemo(() => ({
    totalEvaluators: evaluators.length,
    activeEvaluators: evaluators.filter((e) => e.status === 'active').length,
    pendingEvaluations: evaluators.reduce((acc, e) => acc + e.pendingSheets, 0),
    avgEvaluationTime: '4.5 min',
  }), [evaluators]);

  const filteredEvaluators = useMemo(() => {
    return evaluators.filter((evaluator) => {
      const matchesSearch =
        searchQuery === '' ||
        evaluator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        evaluator.evaluatorId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        evaluator.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = status === 'All Status' || evaluator.status === status.toLowerCase();
      const matchesDept = department === 'All Departments' || evaluator.department === department;
      const matchesSubjects = selectedSubjects.length === 0 || 
        selectedSubjects.some((s) => evaluator.subjectExpertise.includes(s));
      return matchesSearch && matchesStatus && matchesDept && matchesSubjects;
    });
  }, [evaluators, searchQuery, status, department, selectedSubjects]);

  const handleAddEvaluator = () => {
    setEditingEvaluator(null);
    setAddModalOpen(true);
  };

  const handleEditEvaluator = (evaluator: Evaluator) => {
    setEditingEvaluator(evaluator);
    setAddModalOpen(true);
  };

  const handleViewEvaluator = (evaluator: Evaluator) => {
    setViewingEvaluator(evaluator);
    setProfileModalOpen(true);
  };

  const handleSaveEvaluator = async (data: Partial<Evaluator> & { password?: string }) => {
    const dbData = {
      name: data.name || '',
      email: data.email || '',
      mobile: data.mobile || '',
      department: data.department || '',
      subject_expertise: data.subjectExpertise || [],
      experience: data.experience || 0,
      status: data.status || 'active',
      permissions: data.permissions || {
        viewAnswerSheets: true,
        scoreSubjectiveAnswers: true,
        addComments: false,
        reEvaluateSheets: false,
        viewRubrics: true,
      },
    };

    if (editingEvaluator) {
      const { error } = await supabase
        .from('evaluators')
        .update(dbData)
        .eq('id', editingEvaluator.id);

      if (error) {
        console.error('Error updating evaluator:', error);
        toast.error('Failed to update evaluator');
        return;
      }

      setEvaluators((prev) =>
        prev.map((e) => (e.id === editingEvaluator.id ? { ...e, ...data } : e))
      );
      toast.success('Evaluator updated successfully');
    } else {
      // Use edge function to create user (avoids logging out current admin)
      const { data: result, error: fnError } = await supabase.functions.invoke('staff-management', {
        body: {
          action: 'create-evaluator',
          email: data.email || '',
          password: data.password || '',
          name: data.name || '',
          mobile: data.mobile || '',
          department: data.department || '',
          experience: data.experience || 0,
          subject_expertise: data.subjectExpertise || [],
          permissions: data.permissions || {
            viewAnswerSheets: true,
            scoreSubjectiveAnswers: true,
            addComments: false,
            reEvaluateSheets: false,
            viewRubrics: true,
          },
        },
      });

      if (fnError || !result?.success) {
        console.error('Error creating evaluator:', fnError || result?.error);
        toast.error(`Failed to create evaluator: ${result?.error || fnError?.message}`);
        return;
      }

      setEvaluators((prev) => [dbToEvaluator(result.data), ...prev]);
      toast.success(
        `Evaluator added successfully!\n\nLogin credentials:\nEmail: ${result.credentials.email}\nPassword: ${result.credentials.password}`,
        { duration: 8000 }
      );
    }
  };

  const handleToggleStatus = async (evaluator: Evaluator) => {
    const newStatus = evaluator.status === 'active' ? 'inactive' : 'active';

    const { error } = await supabase
      .from('evaluators')
      .update({ status: newStatus })
      .eq('id', evaluator.id);

    if (error) {
      console.error('Error toggling status:', error);
      toast.error('Failed to update status');
      return;
    }

    setEvaluators((prev) =>
      prev.map((e) =>
        e.id === evaluator.id ? { ...e, status: newStatus } : e
      )
    );
    toast.success(`Evaluator ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
  };

  const handleBulkAction = async (action: string) => {
    if (selectedIds.length === 0) {
      toast.error('Please select evaluators first');
      return;
    }

    switch (action) {
      case 'deactivate':
        const { error } = await supabase
          .from('evaluators')
          .update({ status: 'inactive' })
          .in('id', selectedIds);

        if (error) {
          toast.error('Failed to deactivate evaluators');
          return;
        }

        setEvaluators((prev) =>
          prev.map((e) => (selectedIds.includes(e.id) ? { ...e, status: 'inactive' } : e))
        );
        toast.success(`${selectedIds.length} evaluators deactivated`);
        break;
      case 'assign':
        setAssigningEvaluator(null);
        setAssignModalOpen(true);
        break;
      case 'export':
        toast.success(`Exporting ${selectedIds.length} evaluators...`);
        break;
    }
    setSelectedIds([]);
  };

  const handleAssignToExam = () => {
    setAssigningEvaluator(null);
    setAssignModalOpen(true);
  };

  const handleAssignExam = async (examIds: string[], role: string) => {
    const evaluatorIdsToAssign = assigningEvaluator ? [assigningEvaluator.id] : selectedIds;
    
    if (evaluatorIdsToAssign.length === 0) {
      toast.error('No evaluators selected');
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    
    // Create assignments for each evaluator and each exam
    const assignments = evaluatorIdsToAssign.flatMap(evaluatorId =>
      examIds.map(examId => ({
        evaluator_id: evaluatorId,
        exam_id: examId,
        role: role,
        assigned_by: user?.id,
      }))
    );

    const { error } = await supabase
      .from('evaluator_exam_assignments')
      .upsert(assignments, { onConflict: 'evaluator_id,exam_id' });

    if (error) {
      console.error('Error assigning evaluators:', error);
      toast.error('Failed to assign evaluator(s) to exam(s)');
      throw error;
    }

    // Update local state - increment assigned exams count by number of exams
    setEvaluators((prev) =>
      prev.map((e) =>
        evaluatorIdsToAssign.includes(e.id)
          ? { ...e, assignedExamsCount: e.assignedExamsCount + examIds.length }
          : e
      )
    );

    toast.success(`Assigned ${evaluatorIdsToAssign.length} evaluator(s) to ${examIds.length} exam(s)`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Evaluators</h1>
          <p className="text-muted-foreground">Manage evaluators and grading assignments ({evaluators.length} total)</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleAssignToExam}>
            <ClipboardList className="h-4 w-4 mr-2" /> Assign to Exam
          </Button>
          <Button onClick={handleAddEvaluator}>
            <Plus className="h-4 w-4 mr-2" /> Add Evaluator
          </Button>
        </div>
      </div>

      <EvaluatorStats {...stats} />

      <EvaluatorFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        department={department}
        onDepartmentChange={setDepartment}
        status={status}
        onStatusChange={setStatus}
        selectedSubjects={selectedSubjects}
        onSubjectsChange={setSelectedSubjects}
      />

      {selectedIds.length > 0 && (
        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
          <span className="text-sm font-medium">{selectedIds.length} selected</span>
          <div className="flex-1" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                Bulk Actions
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover">
              <DropdownMenuItem onClick={() => handleBulkAction('deactivate')}>
                <UserX className="h-4 w-4 mr-2" /> Deactivate Selected
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleBulkAction('assign')}>
                <ClipboardList className="h-4 w-4 mr-2" /> Assign to Exam
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleBulkAction('export')}>
                <Download className="h-4 w-4 mr-2" /> Export List
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      <EvaluatorsTable
        evaluators={filteredEvaluators}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
        onView={handleViewEvaluator}
        onEdit={handleEditEvaluator}
        onToggleStatus={handleToggleStatus}
      />

      <AddEvaluatorModal
        open={addModalOpen}
        onOpenChange={setAddModalOpen}
        evaluator={editingEvaluator}
        onSave={handleSaveEvaluator}
      />

      <EvaluatorProfileModal
        open={profileModalOpen}
        onOpenChange={setProfileModalOpen}
        evaluator={viewingEvaluator}
        onToggleStatus={handleToggleStatus}
        onAssignExam={() => {
          setAssigningEvaluator(viewingEvaluator);
          setAssignModalOpen(true);
        }}
        onOpenEvaluation={() => setEvaluationWindowOpen(true)}
      />

      <AssignEvaluatorModal
        open={assignModalOpen}
        onOpenChange={setAssignModalOpen}
        evaluatorId={assigningEvaluator?.id}
        evaluatorName={assigningEvaluator?.name}
        evaluatorIds={!assigningEvaluator && selectedIds.length > 0 ? selectedIds : undefined}
        onAssign={handleAssignExam}
      />

      <EvaluationWindow
        open={evaluationWindowOpen}
        onOpenChange={setEvaluationWindowOpen}
      />
    </div>
  );
}