import { useState, useEffect } from 'react';
import { Upload, X } from 'lucide-react';
import { Evaluator, EvaluatorPermissions } from '@/types/evaluator';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';

interface AddEvaluatorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  evaluator?: Evaluator | null;
  onSave: (evaluator: Partial<Evaluator>) => void;
}

const departments = ['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Electrical Engineering', 'Mechanical Engineering'];
const allSubjects = ['Data Structures', 'Algorithms', 'Database Systems', 'Calculus', 'Linear Algebra', 'Statistics', 'Mechanics', 'Thermodynamics', 'Optics', 'Organic Chemistry', 'Inorganic Chemistry'];

const defaultPermissions: EvaluatorPermissions = {
  viewAnswerSheets: true,
  scoreSubjectiveAnswers: true,
  addComments: false,
  reEvaluateSheets: false,
  viewRubrics: true,
};

export function AddEvaluatorModal({ open, onOpenChange, evaluator, onSave }: AddEvaluatorModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    evaluatorId: '',
    email: '',
    mobile: '',
    department: '',
    subjectExpertise: [] as string[],
    experience: 0,
    photoUrl: '',
    status: 'active' as 'active' | 'inactive',
    permissions: defaultPermissions,
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (evaluator) {
      setFormData({
        name: evaluator.name,
        evaluatorId: evaluator.evaluatorId,
        email: evaluator.email,
        mobile: evaluator.mobile,
        department: evaluator.department,
        subjectExpertise: evaluator.subjectExpertise,
        experience: evaluator.experience,
        photoUrl: evaluator.photoUrl || '',
        status: evaluator.status,
        permissions: evaluator.permissions,
        password: '',
        confirmPassword: '',
      });
    } else {
      setFormData({
        name: '',
        evaluatorId: '',
        email: '',
        mobile: '',
        department: '',
        subjectExpertise: [],
        experience: 0,
        photoUrl: '',
        status: 'active',
        permissions: defaultPermissions,
        password: '',
        confirmPassword: '',
      });
    }
    setErrors({});
  }, [evaluator, open]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.evaluatorId.trim()) newErrors.evaluatorId = 'Evaluator ID is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Invalid email format';
    if (!formData.department) newErrors.department = 'Department is required';
    
    // Password validation only for new evaluators
    if (!evaluator) {
      if (!formData.password) newErrors.password = 'Password is required';
      else if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
      if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave(formData);
    toast.success(evaluator ? 'Evaluator updated successfully' : 'Evaluator added successfully');
    onOpenChange(false);
  };

  const updatePermission = (key: keyof EvaluatorPermissions, value: boolean) => {
    setFormData({
      ...formData,
      permissions: { ...formData.permissions, [key]: value },
    });
  };

  const toggleSubject = (subject: string) => {
    if (formData.subjectExpertise.includes(subject)) {
      setFormData({
        ...formData,
        subjectExpertise: formData.subjectExpertise.filter((s) => s !== subject),
      });
    } else {
      setFormData({
        ...formData,
        subjectExpertise: [...formData.subjectExpertise, subject],
      });
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const permissionLabels: { key: keyof EvaluatorPermissions; label: string }[] = [
    { key: 'viewAnswerSheets', label: 'View Answer Sheets' },
    { key: 'scoreSubjectiveAnswers', label: 'Score Subjective Answers' },
    { key: 'addComments', label: 'Add Comments' },
    { key: 'reEvaluateSheets', label: 'Re-evaluate Sheets' },
    { key: 'viewRubrics', label: 'View Rubrics' },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{evaluator ? 'Edit Evaluator' : 'Add New Evaluator'}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={formData.photoUrl} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {formData.name ? getInitials(formData.name) : 'EV'}
              </AvatarFallback>
            </Avatar>
            <div>
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" /> Upload Photo
              </Button>
              <p className="text-xs text-muted-foreground mt-1">JPG, PNG. Max 2MB.</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className={errors.name ? 'border-destructive' : ''}
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="evaluatorId">Evaluator ID *</Label>
              <Input
                id="evaluatorId"
                value={formData.evaluatorId}
                onChange={(e) => setFormData({ ...formData, evaluatorId: e.target.value })}
                className={errors.evaluatorId ? 'border-destructive' : ''}
              />
              {errors.evaluatorId && <p className="text-xs text-destructive">{errors.evaluatorId}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={errors.email ? 'border-destructive' : ''}
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="mobile">Mobile Number</Label>
              <Input
                id="mobile"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Department *</Label>
              <Select value={formData.department} onValueChange={(v) => setFormData({ ...formData, department: v })}>
                <SelectTrigger className={errors.department ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.department && <p className="text-xs text-destructive">{errors.department}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="experience">Experience (Years)</Label>
              <Input
                id="experience"
                type="number"
                min="0"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: parseInt(e.target.value) || 0 })}
              />
            </div>

            {!evaluator && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={errors.password ? 'border-destructive' : ''}
                    placeholder="Min 8 characters"
                  />
                  {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className={errors.confirmPassword ? 'border-destructive' : ''}
                  />
                  {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword}</p>}
                </div>
              </>
            )}
          </div>

          <div className="space-y-3">
            <Label>Subject Expertise</Label>
            <Select onValueChange={toggleSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Add subjects..." />
              </SelectTrigger>
              <SelectContent>
                {allSubjects.filter((s) => !formData.subjectExpertise.includes(s)).map((subject) => (
                  <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {formData.subjectExpertise.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.subjectExpertise.map((subject) => (
                  <Badge key={subject} variant="secondary" className="gap-1">
                    {subject}
                    <X className="h-3 w-3 cursor-pointer" onClick={() => toggleSubject(subject)} />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <Label>Permissions</Label>
            <div className="grid grid-cols-2 gap-3">
              {permissionLabels.map(({ key, label }) => (
                <div key={key} className="flex items-center gap-2">
                  <Checkbox
                    id={key}
                    checked={formData.permissions[key]}
                    onCheckedChange={(checked) => updatePermission(key, !!checked)}
                  />
                  <Label htmlFor={key} className="font-normal cursor-pointer">{label}</Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <div className="flex items-center gap-3 pt-1">
              <Switch
                checked={formData.status === 'active'}
                onCheckedChange={(checked) => setFormData({ ...formData, status: checked ? 'active' : 'inactive' })}
              />
              <span className="text-sm">{formData.status === 'active' ? 'Active' : 'Inactive'}</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit}>{evaluator ? 'Update Evaluator' : 'Add Evaluator'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
