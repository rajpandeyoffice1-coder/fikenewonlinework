import { useState } from 'react';
import { X, ChevronRight, Flag, MessageSquare, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

interface EvaluationWindowProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const rubricItems = [
  { id: '1', criterion: 'Correct approach/methodology', maxScore: 3 },
  { id: '2', criterion: 'Accurate calculations', maxScore: 3 },
  { id: '3', criterion: 'Clear explanation/reasoning', maxScore: 2 },
  { id: '4', criterion: 'Proper notation/formatting', maxScore: 2 },
];

export function EvaluationWindow({ open, onOpenChange }: EvaluationWindowProps) {
  const [score, setScore] = useState('');
  const [comment, setComment] = useState('');
  const [checkedRubrics, setCheckedRubrics] = useState<string[]>([]);
  const [markForReEvaluation, setMarkForReEvaluation] = useState(false);

  const handleRubricToggle = (id: string) => {
    if (checkedRubrics.includes(id)) {
      setCheckedRubrics(checkedRubrics.filter((r) => r !== id));
    } else {
      setCheckedRubrics([...checkedRubrics, id]);
    }
  };

  const handleSaveNext = () => {
    toast.success('Evaluation saved. Loading next answer...');
    setScore('');
    setComment('');
    setCheckedRubrics([]);
    setMarkForReEvaluation(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-hidden p-0">
        <DialogHeader className="p-4 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <DialogTitle>Evaluation Window</DialogTitle>
              <Badge variant="secondary">CS2021001 - Rahul Sharma</Badge>
              <Badge variant="outline">Section B - Q3</Badge>
            </div>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="flex h-[calc(95vh-120px)]">
          {/* Left Panel - Student Answer */}
          <div className="flex-1 border-r overflow-y-auto p-6">
            <h3 className="font-semibold mb-4">Student Answer</h3>
            <Card>
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">
                  Question: Explain the time complexity of QuickSort algorithm with best, average, and worst case scenarios.
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <p className="mb-4">
                    <strong>QuickSort Time Complexity Analysis:</strong>
                  </p>
                  <p className="mb-3">
                    QuickSort is a divide-and-conquer algorithm that works by selecting a 'pivot' element and partitioning the array around it.
                  </p>
                  <p className="mb-3">
                    <strong>Best Case: O(n log n)</strong><br />
                    This occurs when the pivot always divides the array into two equal halves. The recursion depth is log n, and at each level, we do O(n) work for partitioning.
                  </p>
                  <p className="mb-3">
                    <strong>Average Case: O(n log n)</strong><br />
                    On average, the pivot divides the array in a balanced manner, leading to similar performance as the best case.
                  </p>
                  <p className="mb-3">
                    <strong>Worst Case: O(n²)</strong><br />
                    This happens when the pivot is always the smallest or largest element (e.g., already sorted array with first element as pivot). The recursion depth becomes n, and we do O(n) work at each level.
                  </p>
                  <p>
                    To avoid worst case, we can use randomized pivot selection or median-of-three strategy.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Evaluation Controls */}
          <div className="w-[400px] overflow-y-auto p-6 bg-muted/30">
            <h3 className="font-semibold mb-4">Evaluation</h3>

            {/* Rubric Checklist */}
            <Card className="mb-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Rubric Checklist</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {rubricItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id={item.id}
                        checked={checkedRubrics.includes(item.id)}
                        onCheckedChange={() => handleRubricToggle(item.id)}
                      />
                      <Label htmlFor={item.id} className="text-sm font-normal cursor-pointer">
                        {item.criterion}
                      </Label>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {item.maxScore} pts
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Score Input */}
            <div className="space-y-2 mb-4">
              <Label htmlFor="score">Score (out of 10)</Label>
              <Input
                id="score"
                type="number"
                min="0"
                max="10"
                value={score}
                onChange={(e) => setScore(e.target.value)}
                placeholder="Enter score"
              />
            </div>

            {/* Comments */}
            <div className="space-y-2 mb-4">
              <Label htmlFor="comment" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" /> Comments
              </Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add feedback for the student..."
                rows={4}
              />
            </div>

            <Separator className="my-4" />

            {/* Re-evaluation Toggle */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Flag className="h-4 w-4 text-orange-500" />
                <Label htmlFor="re-eval" className="text-sm">Mark for Re-evaluation</Label>
              </div>
              <Switch
                id="re-eval"
                checked={markForReEvaluation}
                onCheckedChange={setMarkForReEvaluation}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button className="flex-1" onClick={handleSaveNext}>
                <Save className="h-4 w-4 mr-2" /> Save & Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
