import { Users, UserCheck, FileText, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface EvaluatorStatsProps {
  totalEvaluators: number;
  activeEvaluators: number;
  pendingEvaluations: number;
  avgEvaluationTime: string;
}

export function EvaluatorStats({
  totalEvaluators,
  activeEvaluators,
  pendingEvaluations,
  avgEvaluationTime,
}: EvaluatorStatsProps) {
  const stats = [
    {
      title: 'Total Evaluators',
      value: totalEvaluators,
      icon: Users,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      title: 'Active Evaluators',
      value: activeEvaluators,
      icon: UserCheck,
      color: 'text-green-600',
      bg: 'bg-green-100',
    },
    {
      title: 'Pending Evaluations',
      value: pendingEvaluations,
      icon: FileText,
      color: 'text-orange-600',
      bg: 'bg-orange-100',
    },
    {
      title: 'Avg. Evaluation Time',
      value: avgEvaluationTime,
      icon: Clock,
      color: 'text-blue-600',
      bg: 'bg-blue-100',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${stat.bg}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{stat.value}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
