import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Mail, Phone, Briefcase, Award, Clock, Target, FileCheck, ExternalLink, Loader2, KeyRound, Trash2 } from 'lucide-react';
import {
  Evaluator,
  mockEvaluationQueue,
  mockActivityLogs,
  mockPerformanceData,
  mockQuestionTypes,
} from '@/types/evaluator';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AssignedExam {
  id: string;
  examName: string;
  examDate: string | null;
  role: 'lead' | 'evaluator' | 'moderator';
  status: 'pending' | 'in_progress' | 'completed';
}

interface EvaluatorProfileModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  evaluator: Evaluator | null;
  onToggleStatus: (evaluator: Evaluator) => void;
  onAssignExam: () => void;
  onOpenEvaluation: () => void;
}

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

export function EvaluatorProfileModal({ open, onOpenChange, evaluator, onToggleStatus, onAssignExam, onOpenEvaluation }: EvaluatorProfileModalProps) {
  const [assignments, setAssignments] = useState<AssignedExam[]>([]);
  const [isLoadingAssignments, setIsLoadingAssignments] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [assignmentToRemove, setAssignmentToRemove] = useState<AssignedExam | null>(null);
  const [isRemoving, setIsRemoving] = useState(false);

  const handleResetPassword = async () => {
    if (!evaluator?.email) return;
    
    setIsResettingPassword(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(evaluator.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        toast.error(`Failed to send reset email: ${error.message}`);
      } else {
        toast.success(`Password reset email sent to ${evaluator.email}`);
      }
    } catch (err) {
      toast.error('An error occurred while sending reset email');
    } finally {
      setIsResettingPassword(false);
    }
  };

  const handleRemoveAssignment = async () => {
    if (!assignmentToRemove) return;
    
    setIsRemoving(true);
    try {
      const { error } = await supabase
        .from('evaluator_exam_assignments')
        .delete()
        .eq('id', assignmentToRemove.id);

      if (error) {
        toast.error('Failed to remove assignment');
        console.error('Error removing assignment:', error);
      } else {
        setAssignments((prev) => prev.filter((a) => a.id !== assignmentToRemove.id));
        toast.success(`Removed from ${assignmentToRemove.examName}`);
      }
    } catch (err) {
      toast.error('An error occurred');
    } finally {
      setIsRemoving(false);
      setAssignmentToRemove(null);
    }
  };

  // Fetch assignments when modal opens
  useEffect(() => {
    const fetchAssignments = async () => {
      if (!open || !evaluator) return;
      
      setIsLoadingAssignments(true);
      try {
        const { data, error } = await supabase
          .from('evaluator_exam_assignments')
          .select(`
            id,
            role,
            assigned_at,
            exams:exam_id (
              id,
              title,
              start_date,
              end_date,
              status
            )
          `)
          .eq('evaluator_id', evaluator.id)
          .order('assigned_at', { ascending: false });

        if (error) {
          console.error('Error fetching evaluator assignments:', error);
          return;
        }

        const formattedAssignments: AssignedExam[] = (data || []).map((item: any) => {
          const exam = item.exams;
          let status: 'pending' | 'in_progress' | 'completed' = 'pending';
          
          if (exam) {
            if (exam.status === 'completed') {
              status = 'completed';
            } else if (exam.status === 'ongoing' || exam.status === 'published') {
              status = 'in_progress';
            } else {
              status = 'pending';
            }
          }

          return {
            id: item.id,
            examName: exam?.title || 'Unknown Exam',
            examDate: exam?.start_date,
            role: item.role as 'lead' | 'evaluator' | 'moderator',
            status,
          };
        });

        setAssignments(formattedAssignments);
      } catch (err) {
        console.error('Error fetching assignments:', err);
      } finally {
        setIsLoadingAssignments(false);
      }
    };

    fetchAssignments();
  }, [open, evaluator]);

  if (!evaluator) return null;

  const getInitials = (name: string) => {
    return name.split(' ').map((n) => n[0]).join('').toUpperCase();
  };

  const getRoleBadge = (role: 'lead' | 'evaluator' | 'moderator') => {
    const labels: Record<string, string> = {
      lead: 'Lead Evaluator',
      evaluator: 'Evaluator',
      moderator: 'Moderator',
    };
    return (
      <Badge variant={role === 'lead' ? 'default' : 'secondary'}>
        {labels[role] || role}
      </Badge>
    );
  };

  const getStatusBadge = (status: 'pending' | 'in_progress' | 'completed') => {
    const variants: Record<string, 'secondary' | 'default' | 'outline'> = {
      pending: 'secondary',
      in_progress: 'default',
      completed: 'outline',
    };
    return <Badge variant={variants[status]}>{status.replace('_', ' ')}</Badge>;
  };

  const getQueueStatusBadge = (status: 'not_started' | 'in_progress' | 'completed') => {
    const variants: Record<string, 'secondary' | 'default' | 'outline'> = {
      not_started: 'secondary',
      in_progress: 'default',
      completed: 'outline',
    };
    return <Badge variant={variants[status]}>{status.replace('_', ' ')}</Badge>;
  };

  const getPriorityBadge = (priority: 'high' | 'normal') => {
    return (
      <Badge variant={priority === 'high' ? 'destructive' : 'outline'}>
        {priority}
      </Badge>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Evaluator Profile</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="assignments">Assigned Exams</TabsTrigger>
            <TabsTrigger value="queue">Evaluation Queue</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="activity">Activity Log</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="flex items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={evaluator.photoUrl} />
                <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                  {getInitials(evaluator.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-semibold">{evaluator.name}</h2>
                    <p className="text-muted-foreground font-mono">{evaluator.evaluatorId}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleResetPassword}
                      disabled={isResettingPassword}
                    >
                      {isResettingPassword ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <KeyRound className="h-4 w-4 mr-2" />
                      )}
                      Reset Password
                    </Button>
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Switch
                      checked={evaluator.status === 'active'}
                      onCheckedChange={() => onToggleStatus(evaluator)}
                    />
                    <Badge variant={evaluator.status === 'active' ? 'default' : 'destructive'}>
                      {evaluator.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{evaluator.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{evaluator.mobile}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span>{evaluator.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Award className="h-4 w-4 text-muted-foreground" />
                    <span>{evaluator.experience} years experience</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {evaluator.subjectExpertise.map((subject) => (
                    <Badge key={subject} variant="secondary">{subject}</Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <FileCheck className="h-4 w-4" /> Total Evaluations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{evaluator.totalEvaluationsCompleted}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Clock className="h-4 w-4" /> Avg Scoring Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{evaluator.avgScoringTime}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Pending Sheets</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-orange-500">{evaluator.pendingSheets}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Target className="h-4 w-4" /> Accuracy Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-600">{evaluator.accuracyScore}%</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="assignments" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">Assigned Exams</h3>
              <Button size="sm" onClick={onAssignExam}>+ Assign to Exam</Button>
            </div>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAssignments ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  ) : assignments.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No exams assigned yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    assignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell className="font-medium">{assignment.examName}</TableCell>
                        <TableCell>
                          {assignment.examDate 
                            ? format(new Date(assignment.examDate), 'MMM d, yyyy')
                            : 'Not scheduled'
                          }
                        </TableCell>
                        <TableCell>{getRoleBadge(assignment.role)}</TableCell>
                        <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={() => setAssignmentToRemove(assignment)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="queue" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">Evaluation Queue</h3>
              <Badge variant="outline">{mockEvaluationQueue.filter(q => q.status !== 'completed').length} pending</Badge>
            </div>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Candidate</TableHead>
                    <TableHead>Question/Section</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockEvaluationQueue.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No items in evaluation queue
                      </TableCell>
                    </TableRow>
                  ) : (
                    mockEvaluationQueue.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{item.candidateName}</p>
                            <p className="text-xs text-muted-foreground">{item.candidateId}</p>
                          </div>
                        </TableCell>
                        <TableCell>{item.questionSection}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">{item.submissionType}</Badge>
                        </TableCell>
                        <TableCell>{getPriorityBadge(item.priority)}</TableCell>
                        <TableCell>{getQueueStatusBadge(item.status)}</TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" onClick={onOpenEvaluation} disabled={item.status === 'completed'}>
                            <ExternalLink className="h-3 w-3 mr-1" /> Open
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="mt-6">
            <h3 className="font-semibold mb-4">Evaluation Performance Analytics</h3>
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Sheets Evaluated Per Day</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    {mockPerformanceData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        No performance data available
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={mockPerformanceData}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis dataKey="date" className="text-xs" />
                          <YAxis className="text-xs" />
                          <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                          <Bar dataKey="sheetsEvaluated" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Question Types Evaluated</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    {mockQuestionTypes.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        No data available
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={mockQuestionTypes}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="count"
                            nameKey="type"
                          >
                            {mockQuestionTypes.map((_, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle className="text-base">Evaluation Accuracy Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={[
                        { week: 'Week 1', accuracy: 92 },
                        { week: 'Week 2', accuracy: 94 },
                        { week: 'Week 3', accuracy: 93 },
                        { week: 'Week 4', accuracy: 96 },
                        { week: 'Week 5', accuracy: 95 },
                        { week: 'Week 6', accuracy: 98 },
                      ]}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="week" className="text-xs" />
                        <YAxis domain={[85, 100]} className="text-xs" />
                        <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                        <Line type="monotone" dataKey="accuracy" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: 'hsl(var(--primary))' }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <h3 className="font-semibold mb-4">Activity Log</h3>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Candidate ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockActivityLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                        No activity logs yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    mockActivityLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(log.timestamp), 'MMM d, h:mm a')}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{log.action}</Badge>
                        </TableCell>
                        <TableCell>{log.examName}</TableCell>
                        <TableCell className="font-mono text-sm">{log.candidateId}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>

      <AlertDialog open={!!assignmentToRemove} onOpenChange={(open) => !open && setAssignmentToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Assignment</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove {evaluator?.name} from "{assignmentToRemove?.examName}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isRemoving}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRemoveAssignment}
              disabled={isRemoving}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isRemoving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}
