import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface EvaluatorFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  department: string;
  onDepartmentChange: (value: string) => void;
  status: string;
  onStatusChange: (value: string) => void;
  selectedSubjects: string[];
  onSubjectsChange: (subjects: string[]) => void;
}

const departments = ['All Departments', 'Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Electrical Engineering'];
const statuses = ['All Status', 'Active', 'Inactive'];
const allSubjects = ['Data Structures', 'Algorithms', 'Database Systems', 'Calculus', 'Linear Algebra', 'Statistics', 'Mechanics', 'Thermodynamics', 'Optics', 'Organic Chemistry', 'Inorganic Chemistry'];

export function EvaluatorFilters({
  searchQuery,
  onSearchChange,
  department,
  onDepartmentChange,
  status,
  onStatusChange,
  selectedSubjects,
  onSubjectsChange,
}: EvaluatorFiltersProps) {
  const handleSubjectToggle = (subject: string) => {
    if (selectedSubjects.includes(subject)) {
      onSubjectsChange(selectedSubjects.filter((s) => s !== subject));
    } else {
      onSubjectsChange([...selectedSubjects, subject]);
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, email, or evaluator ID..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>
      <div className="flex flex-wrap gap-3">
        <Select value={department} onValueChange={onDepartmentChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Department" />
          </SelectTrigger>
          <SelectContent>
            {departments.map((dept) => (
              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={status} onValueChange={onStatusChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {statuses.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select onValueChange={handleSubjectToggle}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Subject Expertise" />
          </SelectTrigger>
          <SelectContent>
            {allSubjects.map((subject) => (
              <SelectItem key={subject} value={subject}>{subject}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedSubjects.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedSubjects.map((subject) => (
            <Badge key={subject} variant="secondary" className="gap-1">
              {subject}
              <X
                className="h-3 w-3 cursor-pointer"
                onClick={() => handleSubjectToggle(subject)}
              />
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
