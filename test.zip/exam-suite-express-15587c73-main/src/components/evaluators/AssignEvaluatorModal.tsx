import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Calendar, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface Exam {
  id: string;
  title: string;
  start_date: string | null;
  status: string;
}

interface AssignEvaluatorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  evaluatorId?: string;
  evaluatorName?: string;
  evaluatorIds?: string[]; // For bulk assignment
  onAssign: (examIds: string[], role: string) => Promise<void>;
}

export function AssignEvaluatorModal({ 
  open, 
  onOpenChange, 
  evaluatorId,
  evaluatorName, 
  evaluatorIds,
  onAssign 
}: AssignEvaluatorModalProps) {
  const [selectedExams, setSelectedExams] = useState<string[]>([]);
  const [role, setRole] = useState('');
  const [timeline, setTimeline] = useState<Date | undefined>();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [exams, setExams] = useState<Exam[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch exams from database
  useEffect(() => {
    const fetchExams = async () => {
      if (!open) return;
      
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('exams')
          .select('id, title, start_date, status')
          .in('status', ['scheduled', 'published', 'completed', 'draft'])
          .order('start_date', { ascending: true });

        if (error) {
          console.error('Error fetching exams:', error);
          toast.error('Failed to load exams');
          return;
        }

        setExams(data || []);
      } catch (err) {
        console.error('Error fetching exams:', err);
        toast.error('Failed to load exams');
      } finally {
        setIsLoading(false);
      }
    };

    fetchExams();
  }, [open]);

  const toggleExam = (examId: string) => {
    setSelectedExams((prev) =>
      prev.includes(examId)
        ? prev.filter((id) => id !== examId)
        : [...prev, examId]
    );
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (selectedExams.length === 0) newErrors.exam = 'Please select at least one exam';
    if (!role) newErrors.role = 'Please select a role';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAssign = async () => {
    if (!validate()) return;
    
    setIsSubmitting(true);
    try {
      await onAssign(selectedExams, role);
      handleClose();
    } catch (error) {
      console.error('Assignment error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setSelectedExams([]);
    setRole('');
    setTimeline(undefined);
    setErrors({});
    onOpenChange(false);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'outline'> = {
      published: 'default',
      scheduled: 'secondary',
      completed: 'outline',
      draft: 'outline',
    };
    return <Badge variant={variants[status] || 'outline'} className="text-xs">{status}</Badge>;
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Assign Evaluator to Exams</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {evaluatorName && (
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Assigning:</p>
              <p className="font-medium">{evaluatorName}</p>
            </div>
          )}
          
          {evaluatorIds && evaluatorIds.length > 0 && !evaluatorName && (
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Bulk assignment:</p>
              <p className="font-medium">{evaluatorIds.length} evaluator(s) selected</p>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Select Exams *</Label>
              {selectedExams.length > 0 && (
                <Badge variant="secondary">{selectedExams.length} selected</Badge>
              )}
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center py-8 border rounded-lg">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : exams.length === 0 ? (
              <div className="py-8 text-center text-sm text-muted-foreground border rounded-lg">
                No exams available
              </div>
            ) : (
              <ScrollArea className={`border rounded-lg ${errors.exam ? 'border-destructive' : ''}`}>
                <div className="max-h-[200px] p-2 space-y-1">
                  {exams.map((exam) => (
                    <div
                      key={exam.id}
                      className={`flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-muted/50 transition-colors ${
                        selectedExams.includes(exam.id) ? 'bg-primary/10' : ''
                      }`}
                      onClick={() => toggleExam(exam.id)}
                    >
                      <Checkbox
                        checked={selectedExams.includes(exam.id)}
                        onCheckedChange={() => toggleExam(exam.id)}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{exam.title}</p>
                        {exam.start_date && (
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(exam.start_date), 'MMM d, yyyy')}
                          </p>
                        )}
                      </div>
                      {getStatusBadge(exam.status)}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
            {errors.exam && <p className="text-xs text-destructive">{errors.exam}</p>}
          </div>

          <div className="space-y-2">
            <Label>Evaluation Role *</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger className={errors.role ? 'border-destructive' : ''}>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="evaluator">Evaluator</SelectItem>
                <SelectItem value="lead">Lead Evaluator</SelectItem>
                <SelectItem value="moderator">Moderator</SelectItem>
              </SelectContent>
            </Select>
            {errors.role && <p className="text-xs text-destructive">{errors.role}</p>}
          </div>

          <div className="space-y-2">
            <Label>Expected Completion Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !timeline && 'text-muted-foreground'
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {timeline ? format(timeline, 'PPP') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={timeline}
                  onSelect={setTimeline}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancel</Button>
          <Button onClick={handleAssign} disabled={isLoading || isSubmitting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Assign to {selectedExams.length || 0} Exam{selectedExams.length !== 1 ? 's' : ''}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}