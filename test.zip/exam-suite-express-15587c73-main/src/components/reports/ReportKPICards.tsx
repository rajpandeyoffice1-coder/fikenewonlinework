import { Users, TrendingUp, Award, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ReportKPICardsProps {
  totalCandidates: number;
  averageScore: number;
  passPercentage: number;
  flaggedIncidents: number;
}

export function ReportKPICards({
  totalCandidates,
  averageScore,
  passPercentage,
  flaggedIncidents,
}: ReportKPICardsProps) {
  const cards = [
    {
      title: 'Total Candidates Appeared',
      value: totalCandidates.toLocaleString(),
      description: '+12% vs last exam',
      icon: Users,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      title: 'Average Score',
      value: `${averageScore}%`,
      description: '+5% vs last exam',
      icon: TrendingUp,
      color: 'text-green-600',
      bg: 'bg-green-100',
    },
    {
      title: 'Pass Percentage',
      value: `${passPercentage}%`,
      description: 'Above 40% threshold',
      icon: Award,
      color: 'text-blue-600',
      bg: 'bg-blue-100',
    },
    {
      title: 'Flagged Incidents',
      value: flaggedIncidents.toString(),
      description: '-8% vs last exam',
      icon: AlertTriangle,
      color: 'text-orange-600',
      bg: 'bg-orange-100',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {card.title}
            </CardTitle>
            <div className={`p-2 rounded-lg ${card.bg}`}>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{card.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{card.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
