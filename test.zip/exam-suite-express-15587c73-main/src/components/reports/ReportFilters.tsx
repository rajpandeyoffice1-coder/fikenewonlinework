import { useState } from 'react';
import { format } from 'date-fns';
import { Calendar, FileDown, FileSpreadsheet, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { useSubjects } from '@/hooks/useSubjects';

interface ReportFiltersProps {
  exam: string;
  onExamChange: (value: string) => void;
  department: string;
  onDepartmentChange: (value: string) => void;
  studentGroup: string;
  onStudentGroupChange: (value: string) => void;
  dateRange: { from: Date | undefined; to: Date | undefined };
  onDateRangeChange: (range: { from: Date | undefined; to: Date | undefined }) => void;
  onExportPDF: () => void;
  onExportCSV: () => void;
  onScheduleEmail: () => void;
}

const exams = ['All Exams', 'Data Structures Final', 'Database Systems Mid-Term', 'Computer Networks Quiz', 'Operating Systems Lab'];
const studentGroups = ['All Groups', 'Group A', 'Group B', 'Group C', 'Regular Students', 'Repeaters'];

export function ReportFilters({
  exam,
  onExamChange,
  department,
  onDepartmentChange,
  studentGroup,
  onStudentGroupChange,
  dateRange,
  onDateRangeChange,
  onExportPDF,
  onExportCSV,
  onScheduleEmail,
}: ReportFiltersProps) {
  const { getDepartments, isLoading } = useSubjects();
  const departments = getDepartments();

  return (
    <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b pb-4 mb-6">
      <div className="flex flex-wrap items-center gap-3">
        <Select value={exam} onValueChange={onExamChange}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select Exam" />
          </SelectTrigger>
          <SelectContent>
            {exams.map((e) => (
              <SelectItem key={e} value={e}>{e}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={department} onValueChange={onDepartmentChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={isLoading ? "Loading..." : "Department"} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="All Departments">All Departments</SelectItem>
            {departments.map((d) => (
              <SelectItem key={d.value} value={d.label}>{d.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className={cn('w-[240px] justify-start text-left font-normal', !dateRange.from && 'text-muted-foreground')}>
              <Calendar className="mr-2 h-4 w-4" />
              {dateRange.from ? (
                dateRange.to ? (
                  `${format(dateRange.from, 'MMM d')} - ${format(dateRange.to, 'MMM d, yyyy')}`
                ) : (
                  format(dateRange.from, 'MMM d, yyyy')
                )
              ) : (
                'Select date range'
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="range"
              selected={{ from: dateRange.from, to: dateRange.to }}
              onSelect={(range) => onDateRangeChange({ from: range?.from, to: range?.to })}
              numberOfMonths={2}
              className="pointer-events-auto"
            />
          </PopoverContent>
        </Popover>

        <Select value={studentGroup} onValueChange={onStudentGroupChange}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Student Group" />
          </SelectTrigger>
          <SelectContent>
            {studentGroups.map((g) => (
              <SelectItem key={g} value={g}>{g}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex-1" />

        <Button variant="outline" onClick={onExportPDF}>
          <FileDown className="h-4 w-4 mr-2" /> Export PDF
        </Button>
        <Button variant="outline" onClick={onExportCSV}>
          <FileSpreadsheet className="h-4 w-4 mr-2" /> Export CSV
        </Button>
        <Button variant="outline" onClick={onScheduleEmail}>
          <Mail className="h-4 w-4 mr-2" /> Schedule Email
        </Button>
      </div>
    </div>
  );
}
