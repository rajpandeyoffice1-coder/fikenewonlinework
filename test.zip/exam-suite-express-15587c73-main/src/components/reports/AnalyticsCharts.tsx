import {
  ScoreRange,
  DepartmentPerformance,
  QuestionDifficulty,
  TimeAnalysis,
  IncidentCategory,
} from '@/types/report';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';

interface AnalyticsChartsProps {
  scoreDistribution: ScoreRange[];
  departmentPerformance: DepartmentPerformance[];
  questionDifficulty: QuestionDifficulty[];
  timeAnalysis: TimeAnalysis[];
  incidentCategories: IncidentCategory[];
}

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];
const DIFFICULTY_COLORS = ['#22c55e', '#f59e0b', '#ef4444'];

export function AnalyticsCharts({
  scoreDistribution,
  departmentPerformance,
  questionDifficulty,
  timeAnalysis,
  incidentCategories,
}: AnalyticsChartsProps) {
  const tooltipStyle = {
    backgroundColor: 'hsl(var(--popover))',
    border: '1px solid hsl(var(--border))',
    borderRadius: '8px',
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      {/* Score Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Score Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoreDistribution}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="range" className="text-xs" tick={{ fontSize: 11 }} />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(value: number) => [`${value} candidates`, 'Count']}
                />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Department-wise Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Department-wise Pass Percentage</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" domain={[0, 100]} className="text-xs" />
                <YAxis dataKey="department" type="category" width={100} className="text-xs" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(value: number, name: string, props: any) => [
                    `${value}% (${props.payload.totalCandidates} candidates)`,
                    'Pass Rate',
                  ]}
                />
                <Bar dataKey="passPercentage" fill="hsl(var(--chart-2))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Question Difficulty */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Question Difficulty Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={questionDifficulty}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="count"
                  nameKey="difficulty"
                  label={({ difficulty, correctPercentage }) => `${difficulty}: ${correctPercentage}% correct`}
                  labelLine={false}
                >
                  {questionDifficulty.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={DIFFICULTY_COLORS[index % DIFFICULTY_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => [`${value} questions`, 'Count']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Time Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Average Time per Question (seconds)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeAnalysis}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="questionNumber" className="text-xs" label={{ value: 'Question #', position: 'insideBottom', offset: -5 }} />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(value: number) => [`${value}s`, 'Avg Time']}
                  labelFormatter={(label) => `Question ${label}`}
                />
                <Line
                  type="monotone"
                  dataKey="avgTime"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: 'hsl(var(--primary))' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Proctoring Incidents - Full Width */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Proctoring Incident Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={incidentCategories}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="category" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip contentStyle={tooltipStyle} formatter={(value: number) => [`${value} incidents`, 'Count']} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {incidentCategories.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
