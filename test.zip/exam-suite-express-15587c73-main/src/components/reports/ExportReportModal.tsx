import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

interface ExportReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  exportType: 'pdf' | 'csv';
}

const exportOptions = [
  { id: 'full', label: 'Full Report (All sections)', description: 'Complete analytics with all charts and tables' },
  { id: 'scores', label: 'Score Distribution Only', description: 'Score ranges and distribution data' },
  { id: 'candidates', label: 'Candidate Performance CSV', description: 'Individual candidate scores and status' },
  { id: 'incidents', label: 'Proctoring Incidents Only', description: 'All flagged incidents and details' },
  { id: 'departments', label: 'Department-wise Statistics', description: 'Pass rates and performance by department' },
];

export function ExportReportModal({ open, onOpenChange, exportType }: ExportReportModalProps) {
  const [selectedOptions, setSelectedOptions] = useState<string[]>(['full']);

  const toggleOption = (id: string) => {
    if (id === 'full') {
      setSelectedOptions(['full']);
    } else {
      const newOptions = selectedOptions.filter((o) => o !== 'full');
      if (selectedOptions.includes(id)) {
        setSelectedOptions(newOptions.filter((o) => o !== id));
      } else {
        setSelectedOptions([...newOptions, id]);
      }
    }
  };

  const handleExport = () => {
    toast.success(`Exporting report as ${exportType.toUpperCase()}...`);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Export Report ({exportType.toUpperCase()})</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <p className="text-sm text-muted-foreground">
            Select the sections you want to include in the export:
          </p>
          <div className="space-y-3">
            {exportOptions.map((option) => (
              <div
                key={option.id}
                className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedOptions.includes(option.id) ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                }`}
                onClick={() => toggleOption(option.id)}
              >
                <Checkbox
                  checked={selectedOptions.includes(option.id)}
                  onCheckedChange={() => toggleOption(option.id)}
                />
                <div>
                  <Label className="cursor-pointer font-medium">{option.label}</Label>
                  <p className="text-xs text-muted-foreground">{option.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleExport} disabled={selectedOptions.length === 0}>
            Export {exportType.toUpperCase()}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
