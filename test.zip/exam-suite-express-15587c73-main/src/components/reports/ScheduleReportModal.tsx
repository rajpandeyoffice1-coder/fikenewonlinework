import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

interface ScheduleReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const frequencies = ['Daily', 'Weekly', 'After Exam Ends'];
const reportTypes = ['Full Report', 'Score Distribution', 'Candidate Performance', 'Proctoring Summary', 'Department Statistics'];

export function ScheduleReportModal({ open, onOpenChange }: ScheduleReportModalProps) {
  const [emails, setEmails] = useState<string[]>([]);
  const [emailInput, setEmailInput] = useState('');
  const [frequency, setFrequency] = useState('');
  const [reportType, setReportType] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const addEmail = () => {
    const email = emailInput.trim();
    if (!email) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setErrors({ email: 'Invalid email format' });
      return;
    }
    if (emails.includes(email)) {
      setErrors({ email: 'Email already added' });
      return;
    }
    setEmails([...emails, email]);
    setEmailInput('');
    setErrors({});
  };

  const removeEmail = (email: string) => {
    setEmails(emails.filter((e) => e !== email));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addEmail();
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (emails.length === 0) newErrors.emails = 'Add at least one recipient';
    if (!frequency) newErrors.frequency = 'Select frequency';
    if (!reportType) newErrors.reportType = 'Select report type';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSchedule = () => {
    if (!validate()) return;
    toast.success('Report scheduled successfully!');
    handleClose();
  };

  const handleClose = () => {
    setEmails([]);
    setEmailInput('');
    setFrequency('');
    setReportType('');
    setMessage('');
    setErrors({});
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Schedule Report Email</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Recipients *</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter email address"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className={errors.email ? 'border-destructive' : ''}
              />
              <Button type="button" variant="outline" onClick={addEmail}>Add</Button>
            </div>
            {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            {errors.emails && <p className="text-xs text-destructive">{errors.emails}</p>}
            {emails.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {emails.map((email) => (
                  <Badge key={email} variant="secondary" className="gap-1">
                    {email}
                    <X className="h-3 w-3 cursor-pointer" onClick={() => removeEmail(email)} />
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Frequency *</Label>
            <Select value={frequency} onValueChange={setFrequency}>
              <SelectTrigger className={errors.frequency ? 'border-destructive' : ''}>
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                {frequencies.map((f) => (
                  <SelectItem key={f} value={f}>{f}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.frequency && <p className="text-xs text-destructive">{errors.frequency}</p>}
          </div>

          <div className="space-y-2">
            <Label>Report Type *</Label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className={errors.reportType ? 'border-destructive' : ''}>
                <SelectValue placeholder="Select report type" />
              </SelectTrigger>
              <SelectContent>
                {reportTypes.map((r) => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.reportType && <p className="text-xs text-destructive">{errors.reportType}</p>}
          </div>

          <div className="space-y-2">
            <Label>Add Message (Optional)</Label>
            <Textarea
              placeholder="Add a custom message to include in the email..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSchedule}>Schedule</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
