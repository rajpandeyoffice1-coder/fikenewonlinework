import { useState, useMemo } from 'react';
import { Loader2 } from 'lucide-react';
import { ReportFilters } from './ReportFilters';
import { ReportKPICards } from './ReportKPICards';
import { AnalyticsCharts } from './AnalyticsCharts';
import { CandidatePerformanceTable } from './CandidatePerformanceTable';
import { CandidateBreakdownModal } from './CandidateBreakdownModal';
import { ExportReportModal } from './ExportReportModal';
import { ScheduleReportModal } from './ScheduleReportModal';
import { supabase } from '@/integrations/supabase/client';
import { ReportCandidate, CandidateBreakdown } from '@/types/report';
import { toast } from 'sonner';
import { useAdminReports } from '@/hooks/useAdminReports';

export function ReportsPage() {
  const { exams, students, questions, examResults, isLoading, fetchCandidateBreakdown } = useAdminReports();
  
  const [exam, setExam] = useState('All Exams');
  const [department, setDepartment] = useState('All Departments');
  const [studentGroup, setStudentGroup] = useState('All Groups');
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: undefined,
    to: undefined,
  });

  const [breakdownModalOpen, setBreakdownModalOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [exportType, setExportType] = useState<'pdf' | 'csv'>('pdf');
  const [selectedBreakdown, setSelectedBreakdown] = useState<CandidateBreakdown | null>(null);
  const [loadingBreakdown, setLoadingBreakdown] = useState(false);

  // Generate analytics from real data
  const scoreDistribution = useMemo(() => {
    if (examResults.length === 0) {
      return [
        { range: '0-20', count: 0 },
        { range: '21-40', count: 0 },
        { range: '41-60', count: 0 },
        { range: '61-80', count: 0 },
        { range: '81-100', count: 0 },
      ];
    }

    const distribution = { '0-20': 0, '21-40': 0, '41-60': 0, '61-80': 0, '81-100': 0 };
    examResults.forEach((r) => {
      const pct = Number(r.percentage) || 0;
      if (pct <= 20) distribution['0-20']++;
      else if (pct <= 40) distribution['21-40']++;
      else if (pct <= 60) distribution['41-60']++;
      else if (pct <= 80) distribution['61-80']++;
      else distribution['81-100']++;
    });

    return Object.entries(distribution).map(([range, count]) => ({ range, count }));
  }, [examResults]);

  const departmentPerformance = useMemo(() => {
    const deptData: Record<string, { total: number; passed: number }> = {};
    
    examResults.forEach((r) => {
      const dept = r.students?.department || 'Unknown';
      if (!deptData[dept]) {
        deptData[dept] = { total: 0, passed: 0 };
      }
      deptData[dept].total++;
      if (r.status === 'pass') {
        deptData[dept].passed++;
      }
    });

    return Object.entries(deptData).map(([department, data]) => ({
      department,
      passPercentage: data.total > 0 ? Math.round((data.passed / data.total) * 100) : 0,
      totalCandidates: data.total,
    }));
  }, [examResults]);

  const questionDifficulty = useMemo(() => {
    const difficultyCounts: Record<string, number> = { Easy: 0, Medium: 0, Hard: 0 };
    questions.forEach((q) => {
      const diff = q.difficulty?.charAt(0).toUpperCase() + q.difficulty?.slice(1) || 'Medium';
      if (difficultyCounts[diff] !== undefined) {
        difficultyCounts[diff]++;
      }
    });

    return [
      { difficulty: 'Easy', count: difficultyCounts.Easy || 0, correctPercentage: 85 },
      { difficulty: 'Medium', count: difficultyCounts.Medium || 0, correctPercentage: 65 },
      { difficulty: 'Hard', count: difficultyCounts.Hard || 0, correctPercentage: 40 },
    ];
  }, [questions]);

  const timeAnalysis = useMemo(() => {
    return [
      { questionNumber: 1, avgTime: 45 },
      { questionNumber: 2, avgTime: 60 },
      { questionNumber: 3, avgTime: 90 },
      { questionNumber: 4, avgTime: 120 },
      { questionNumber: 5, avgTime: 75 },
    ];
  }, []);

  const incidentCategories = useMemo(() => {
    return [
      { category: 'Tab Switch', count: 0 },
      { category: 'Face Not Detected', count: 0 },
      { category: 'Multiple Faces', count: 0 },
      { category: 'Audio Detected', count: 0 },
      { category: 'Copy Paste', count: 0 },
    ];
  }, []);

  // Generate candidate list from actual exam results
  const candidates: ReportCandidate[] = useMemo(() => {
    return examResults.map((result) => {
      const student = result.students;
      return {
        id: result.id,
        name: student?.full_name || 'Unknown',
        rollNumber: student?.roll_no || '',
        department: student?.department || '',
        score: Number(result.score) || 0,
        totalMarks: result.total_marks || 100,
        percentage: Number(result.percentage) || 0,
        status: result.status === 'pass' ? 'pass' as const : 'fail' as const,
        timeTaken: result.submitted_at 
          ? `${Math.round((new Date(result.submitted_at).getTime() - new Date(result.created_at).getTime()) / 60000)} min`
          : '0 min',
        incidentCount: result.incidentCount || 0,
        sessionId: result.session_id,
        examId: result.exam_id,
        studentId: result.student_id,
        email: student?.email || '',
      };
    });
  }, [examResults]);

  // Calculate KPIs
  const totalCandidates = candidates.length;
  const averageScore = candidates.length > 0
    ? Math.round(candidates.reduce((acc, c) => acc + c.percentage, 0) / candidates.length)
    : 0;
  const passPercentage = candidates.length > 0
    ? Math.round((candidates.filter((c) => c.status === 'pass').length / candidates.length) * 100)
    : 0;
  const flaggedIncidents = candidates.reduce((acc, c) => acc + c.incidentCount, 0);

  const handleExportPDF = () => {
    setExportType('pdf');
    setExportModalOpen(true);
  };

  const handleExportCSV = () => {
    setExportType('csv');
    setExportModalOpen(true);
  };

  const handleViewBreakdown = async (candidate: ReportCandidate) => {
    setLoadingBreakdown(true);
    setBreakdownModalOpen(true);

    try {
      const data = await fetchCandidateBreakdown(candidate.sessionId || '');
      const answersData = data.answers || [];
      const screenshotsData = data.screenshots || [];
      const incidentsData = data.incidents || [];

      // Group questions by subject for section-wise scores
      const sectionScores: Record<string, { score: number; maxScore: number }> = {};
      const questionResults = answersData.map((answer: any) => {
        const question = answer.questions;
        const subject = question?.subject || 'General';
        
        if (!sectionScores[subject]) {
          sectionScores[subject] = { score: 0, maxScore: 0 };
        }
        
        const maxMarks = question?.marks || 1;
        sectionScores[subject].maxScore += maxMarks;

        // Determine if answer is correct
        let isCorrect = false;
        
        if (question?.type === 'mcq-single' || question?.type === 'mcq' || question?.type === 'mcq-multiple') {
          // For MCQ: Check if selected option matches the correct answer
          // The correct answer could be stored in correct_answer field OR we check isCorrect in options
          const answerText = answer.answer_text;
          const options = question.options || [];
          
          // Check if answer matches correct_answer field
          if (question.correct_answer && answerText === question.correct_answer) {
            isCorrect = true;
          } else {
            // Check if selected answer matches an option marked as isCorrect
            const selectedOption = options.find((opt: any) => opt.text === answerText);
            if (selectedOption?.isCorrect) {
              isCorrect = true;
            }
          }
        } else if (question?.type === 'true-false') {
          // For True/False: Direct comparison
          isCorrect = answer.answer_text === question.correct_answer;
        }
        // For other types (short-answer, long-answer, coding, file-upload), manual grading is needed
        
        if (isCorrect) {
          sectionScores[subject].score += maxMarks;
        }

        const attempted = !!(answer.answer_text || answer.answer_option || answer.file_url);

        return {
          questionId: question?.id?.substring(0, 8) || '',
          type: question?.type || 'unknown',
          marks: isCorrect ? maxMarks : 0,
          maxMarks: maxMarks,
          attempted,
          correct: isCorrect,
          timeSpent: answer.time_spent ? `${Math.floor(answer.time_spent / 60)}m ${answer.time_spent % 60}s` : '0s',
        };
      });

      const sections = Object.entries(sectionScores).map(([name, data]) => ({
        name,
        score: data.score,
        maxScore: data.maxScore,
      }));

      const incidents = incidentsData.map((incident: any) => ({
        id: incident.id,
        type: incident.incident_type,
        timestamp: new Date(incident.timestamp).toLocaleString(),
        description: incident.message,
      }));

      const breakdown: CandidateBreakdown = {
        id: candidate.id,
        name: candidate.name,
        rollNumber: candidate.rollNumber,
        email: candidate.email || '',
        department: candidate.department,
        totalScore: candidate.score,
        totalMarks: candidate.totalMarks,
        percentage: candidate.percentage,
        timeTaken: candidate.timeTaken,
        sections,
        questions: questionResults,
        incidents,
        screenshots: screenshotsData,
      };

      setSelectedBreakdown(breakdown);
    } catch (error) {
      console.error('Error fetching breakdown:', error);
      toast.error('Failed to load candidate breakdown');
      setBreakdownModalOpen(false);
    } finally {
      setLoadingBreakdown(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Reports & Analytics</h1>
        <p className="text-muted-foreground">
          Comprehensive exam performance insights and analytics
          {exams.length > 0 && ` • ${exams.length} exams, ${examResults.length} submissions`}
        </p>
      </div>

      <ReportFilters
        exam={exam}
        onExamChange={setExam}
        department={department}
        onDepartmentChange={setDepartment}
        studentGroup={studentGroup}
        onStudentGroupChange={setStudentGroup}
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
        onExportPDF={handleExportPDF}
        onExportCSV={handleExportCSV}
        onScheduleEmail={() => setScheduleModalOpen(true)}
      />

      <ReportKPICards
        totalCandidates={totalCandidates}
        averageScore={averageScore}
        passPercentage={passPercentage}
        flaggedIncidents={flaggedIncidents}
      />

      <AnalyticsCharts
        scoreDistribution={scoreDistribution}
        departmentPerformance={departmentPerformance}
        questionDifficulty={questionDifficulty}
        timeAnalysis={timeAnalysis}
        incidentCategories={incidentCategories}
      />

      <CandidatePerformanceTable
        candidates={candidates}
        onViewBreakdown={handleViewBreakdown}
      />

      <CandidateBreakdownModal
        open={breakdownModalOpen}
        onOpenChange={setBreakdownModalOpen}
        breakdown={selectedBreakdown}
        loading={loadingBreakdown}
      />

      <ExportReportModal
        open={exportModalOpen}
        onOpenChange={setExportModalOpen}
        exportType={exportType}
      />

      <ScheduleReportModal
        open={scheduleModalOpen}
        onOpenChange={setScheduleModalOpen}
      />
    </div>
  );
}
