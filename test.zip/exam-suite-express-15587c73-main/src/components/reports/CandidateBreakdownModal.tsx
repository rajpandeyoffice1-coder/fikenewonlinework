import { FileDown, Check, X, Clock, AlertTriangle, Loader2, Image as ImageIcon } from 'lucide-react';
import { CandidateBreakdown } from '@/types/report';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

interface CandidateBreakdownModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  breakdown: CandidateBreakdown | null;
  loading?: boolean;
}

export function CandidateBreakdownModal({ open, onOpenChange, breakdown, loading }: CandidateBreakdownModalProps) {
  const handleExportPDF = () => {
    toast.success('Exporting candidate report as PDF...');
  };

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Loading candidate data...</span>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!breakdown) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Candidate Performance Breakdown</DialogTitle>
            <Button variant="outline" size="sm" onClick={handleExportPDF}>
              <FileDown className="h-4 w-4 mr-2" /> Export PDF
            </Button>
          </div>
        </DialogHeader>

        {/* Candidate Details */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium">{breakdown.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Roll Number</p>
                <p className="font-mono">{breakdown.rollNumber}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Department</p>
                <p>{breakdown.department}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="text-sm truncate">{breakdown.email}</p>
              </div>
            </div>
            <Separator className="my-4" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total Score</p>
                <p className="text-2xl font-bold">{breakdown.totalScore}/{breakdown.totalMarks}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Percentage</p>
                <p className="text-2xl font-bold text-primary">{breakdown.percentage.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <Badge variant={breakdown.percentage >= 40 ? 'default' : 'destructive'} className="mt-1">
                  {breakdown.percentage >= 40 ? 'Pass' : 'Fail'}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Time Taken</p>
                <p className="text-lg font-medium flex items-center gap-1">
                  <Clock className="h-4 w-4" /> {breakdown.timeTaken}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Section-wise Scores */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Section-wise Scores</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {breakdown.sections.length > 0 ? (
              breakdown.sections.map((section) => (
                <div key={section.name} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{section.name}</span>
                    <span className="font-medium">{section.score}/{section.maxScore}</span>
                  </div>
                  <Progress value={section.maxScore > 0 ? (section.score / section.maxScore) * 100 : 0} className="h-2" />
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">No section data available</p>
            )}
          </CardContent>
        </Card>

        {/* Question-wise Results */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Question-wise Results</CardTitle>
          </CardHeader>
          <CardContent>
            {breakdown.questions.length > 0 ? (
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Question ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-center">Marks</TableHead>
                      <TableHead className="text-center">Attempted</TableHead>
                      <TableHead className="text-center">Correct</TableHead>
                      <TableHead className="text-center">Time Spent</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {breakdown.questions.map((q, index) => (
                      <TableRow key={q.questionId || index}>
                        <TableCell className="font-mono">{q.questionId || `Q${index + 1}`}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{q.type}</Badge>
                        </TableCell>
                        <TableCell className="text-center">{q.marks}/{q.maxMarks}</TableCell>
                        <TableCell className="text-center">
                          {q.attempted ? (
                            <Check className="h-4 w-4 text-green-500 mx-auto" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mx-auto" />
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          {q.attempted ? (
                            q.correct ? (
                              <Check className="h-4 w-4 text-green-500 mx-auto" />
                            ) : (
                              <X className="h-4 w-4 text-red-500 mx-auto" />
                            )
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center">{q.timeSpent}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-4">No question data available</p>
            )}
          </CardContent>
        </Card>

        {/* Proctoring Timeline */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" /> Proctoring Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            {breakdown.incidents.length > 0 ? (
              <div className="space-y-3">
                {breakdown.incidents.map((incident) => (
                  <div key={incident.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                    <Badge variant="destructive">{incident.type}</Badge>
                    <div>
                      <p className="text-sm">{incident.description}</p>
                      <p className="text-xs text-muted-foreground">{incident.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                <Check className="h-8 w-8 mx-auto mb-2 text-green-500" />
                <p>No proctoring incidents recorded</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Screenshots Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ImageIcon className="h-4 w-4" /> Screenshots ({breakdown.screenshots?.length || 0})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {breakdown.screenshots && breakdown.screenshots.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {breakdown.screenshots.map((screenshot) => (
                  <div key={screenshot.id} className="space-y-2">
                    <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                      <img 
                        src={screenshot.screenshot_url} 
                        alt={`Screenshot - ${screenshot.capture_type}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/placeholder.svg';
                        }}
                      />
                    </div>
                    <div className="text-xs">
                      <Badge variant={screenshot.capture_type === 'incident' ? 'destructive' : 'secondary'}>
                        {screenshot.capture_type}
                      </Badge>
                      <p className="text-muted-foreground mt-1">
                        {new Date(screenshot.timestamp).toLocaleTimeString()}
                      </p>
                      {screenshot.reason && (
                        <p className="text-muted-foreground truncate">{screenshot.reason}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                <ImageIcon className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No screenshots captured during this exam session</p>
              </div>
            )}
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}
