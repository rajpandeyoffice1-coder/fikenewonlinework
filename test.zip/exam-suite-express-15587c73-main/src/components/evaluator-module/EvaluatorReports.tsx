import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Download,
  TrendingUp,
  Users,
  Award,
  Clock,
  Loader2,
} from "lucide-react";
import { AssignedExam, AnswerSheet } from "@/types/evaluatorModule";
import { supabase } from "@/integrations/supabase/client";

export function EvaluatorReports() {
  const [isLoading, setIsLoading] = useState(true);
  const [assignedExams, setAssignedExams] = useState<AssignedExam[]>([]);
  const [completedSheets, setCompletedSheets] = useState<AnswerSheet[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      const { data: exams } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (exams) {
        const mappedExams: AssignedExam[] = exams.map(exam => ({
          id: exam.id,
          name: exam.title,
          subject: exam.course || 'General',
          section: exam.department,
          totalSheets: 45,
          pendingSheets: 28,
          completedSheets: 17,
          deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          priority: 'normal' as const,
        }));
        setAssignedExams(mappedExams);
      }
      
      // Demo completed sheet
      const demoSheet: AnswerSheet = {
        id: 'AS004',
        candidateId: 'C004',
        candidateName: 'Demo Student',
        rollNumber: 'CS2021004',
        examId: exams?.[0]?.id || 'EX001',
        examName: exams?.[0]?.title || 'Sample Exam',
        questionId: 'Q3',
        questionNumber: 3,
        questionText: 'Implement a binary search tree.',
        questionType: 'code',
        maxMarks: 20,
        submissionType: 'code',
        answer: 'class BST...',
        status: 'completed',
        priority: 'normal',
        assignedMarks: 18,
        evaluatorComment: 'Excellent implementation.',
        evaluatedAt: new Date().toISOString(),
      };
      setCompletedSheets([demoSheet]);
      setIsLoading(false);
    };
    
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Score Reports</h1>
          <p className="text-slate-400">View evaluation statistics and reports</p>
        </div>
        <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <Select defaultValue="all">
              <SelectTrigger className="w-[200px] bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Select Exam" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Exams</SelectItem>
                {assignedExams.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>{exam.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select defaultValue="week">
              <SelectTrigger className="w-[150px] bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Time Period" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Total Evaluated</p>
                <p className="text-3xl font-bold text-white">{completedSheets.length}</p>
              </div>
              <div className="h-12 w-12 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Average Score</p>
                <p className="text-3xl font-bold text-white">14.2</p>
              </div>
              <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Highest Score</p>
                <p className="text-3xl font-bold text-white">18/20</p>
              </div>
              <div className="h-12 w-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <Award className="h-6 w-6 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Avg Time/Answer</p>
                <p className="text-3xl font-bold text-white">4.5m</p>
              </div>
              <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Results Table */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Evaluated Answers</CardTitle>
        </CardHeader>
        <CardContent>
          {completedSheets.length === 0 ? (
            <p className="text-center text-slate-400 py-8">No evaluations completed yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-transparent">
                  <TableHead className="text-slate-400">Candidate</TableHead>
                  <TableHead className="text-slate-400">Question</TableHead>
                  <TableHead className="text-slate-400">Marks</TableHead>
                  <TableHead className="text-slate-400">Type</TableHead>
                  <TableHead className="text-slate-400">Evaluated At</TableHead>
                  <TableHead className="text-slate-400">Comment</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedSheets.map((sheet) => (
                  <TableRow key={sheet.id} className="border-slate-700">
                    <TableCell>
                      <div>
                        <p className="text-white font-medium">{sheet.candidateName}</p>
                        <p className="text-sm text-slate-400">{sheet.rollNumber}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-slate-300">Q{sheet.questionNumber}</TableCell>
                    <TableCell>
                      <span className="text-emerald-400 font-medium">{sheet.assignedMarks}</span>
                      <span className="text-slate-500">/{sheet.maxMarks}</span>
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-slate-600/50 text-slate-300 capitalize">
                        {sheet.questionType}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-slate-400 text-sm">
                      {sheet.evaluatedAt ? new Date(sheet.evaluatedAt).toLocaleString() : '-'}
                    </TableCell>
                    <TableCell className="text-slate-400 text-sm max-w-[200px] truncate">
                      {sheet.evaluatorComment || '-'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
