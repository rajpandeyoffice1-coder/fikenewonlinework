import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import {
  Download,
  AlertTriangle,
  ExternalLink,
  User,
  FileText,
  MessageSquare,
  Flag,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { PlagiarismResult } from "@/types/evaluatorModule";
import { toast } from "sonner";

// Default plagiarism result for demo
const defaultPlagiarismResult: PlagiarismResult = {
  candidateId: 'C007',
  candidateName: 'Demo Student',
  rollNumber: 'CS2021007',
  overallSimilarity: 35,
  questionResults: [
    {
      questionId: 'Q1',
      questionNumber: 1,
      similarity: 45,
      matchedSources: [
        { source: 'geeksforgeeks.org/stack-vs-queue', percentage: 30, matchedText: 'Stack is a LIFO data structure...' },
        { source: 'Student CS2021008', percentage: 15, matchedText: 'Examples include browser history...' },
      ],
    },
    {
      questionId: 'Q2',
      questionNumber: 2,
      similarity: 25,
      matchedSources: [
        { source: 'stackoverflow.com/linked-list-reversal', percentage: 25, matchedText: 'def reverse_linked_list(head):...' },
      ],
    },
  ],
};

export function PlagiarismCheck() {
  const [activeTab, setActiveTab] = useState("overall");
  const [comment, setComment] = useState("");
  const result = defaultPlagiarismResult;

  const getSimilarityColor = (similarity: number) => {
    if (similarity >= 50) return 'text-red-400';
    if (similarity >= 30) return 'text-amber-400';
    return 'text-emerald-400';
  };

  const getSimilarityBg = (similarity: number) => {
    if (similarity >= 50) return 'bg-red-500';
    if (similarity >= 30) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const handleDownload = () => {
    toast.success("Report download started");
  };

  const handleMarkPlagiarized = () => {
    toast.success("Marked as plagiarized");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Plagiarism & Similarity Check</h1>
          <p className="text-slate-400">Review similarity report for submitted answers</p>
        </div>
        <Button onClick={handleDownload} variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
          <Download className="h-4 w-4 mr-2" />
          Download Report (PDF)
        </Button>
      </div>

      {/* Student Info */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 bg-slate-600 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-slate-300" />
              </div>
              <div>
                <p className="font-semibold text-white">{result.candidateName}</p>
                <p className="text-sm text-slate-400">{result.rollNumber}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-400">Overall Similarity</p>
              <p className={cn("text-4xl font-bold", getSimilarityColor(result.overallSimilarity))}>
                {result.overallSimilarity}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-slate-700">
              <TabsTrigger value="overall" className="data-[state=active]:bg-emerald-600">Overall Report</TabsTrigger>
              <TabsTrigger value="sources" className="data-[state=active]:bg-emerald-600">Matched Sources</TabsTrigger>
              <TabsTrigger value="questions" className="data-[state=active]:bg-emerald-600">Question-wise</TabsTrigger>
            </TabsList>

            {/* Overall Report */}
            <TabsContent value="overall" className="mt-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Similarity Overview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Similarity Gauge */}
                  <div className="flex items-center justify-center py-8">
                    <div className="relative h-48 w-48">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle
                          cx="96"
                          cy="96"
                          r="88"
                          stroke="currentColor"
                          strokeWidth="12"
                          fill="none"
                          className="text-slate-700"
                        />
                        <circle
                          cx="96"
                          cy="96"
                          r="88"
                          stroke="currentColor"
                          strokeWidth="12"
                          fill="none"
                          strokeDasharray={`${result.overallSimilarity * 5.53} 553`}
                          className={getSimilarityColor(result.overallSimilarity).replace('text', 'text')}
                          style={{ stroke: result.overallSimilarity >= 50 ? '#f87171' : result.overallSimilarity >= 30 ? '#fbbf24' : '#34d399' }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <p className={cn("text-5xl font-bold", getSimilarityColor(result.overallSimilarity))}>
                            {result.overallSimilarity}%
                          </p>
                          <p className="text-sm text-slate-400">Similarity</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Legend */}
                  <div className="flex justify-center gap-8 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 bg-emerald-500 rounded-full" />
                      <span className="text-slate-400">0-29% Low</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 bg-amber-500 rounded-full" />
                      <span className="text-slate-400">30-49% Medium</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 bg-red-500 rounded-full" />
                      <span className="text-slate-400">50%+ High</span>
                    </div>
                  </div>

                  {/* Question-wise Bar */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-white">Similarity by Question</h4>
                    {result.questionResults.map((qr) => (
                      <div key={qr.questionId} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">Question {qr.questionNumber}</span>
                          <span className={getSimilarityColor(qr.similarity)}>{qr.similarity}%</span>
                        </div>
                        <Progress 
                          value={qr.similarity} 
                          className={cn("h-2", getSimilarityBg(qr.similarity))}
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Matched Sources */}
            <TabsContent value="sources" className="mt-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Matched Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-4">
                      {result.questionResults.flatMap(qr => 
                        qr.matchedSources.map((source, idx) => (
                          <div 
                            key={`${qr.questionId}-${idx}`}
                            className="p-4 bg-slate-700/50 rounded-lg"
                          >
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2">
                                {source.source.startsWith('Student') ? (
                                  <User className="h-4 w-4 text-amber-400" />
                                ) : (
                                  <ExternalLink className="h-4 w-4 text-blue-400" />
                                )}
                                <span className="text-white font-medium">{source.source}</span>
                              </div>
                              <Badge className={cn(
                                "border",
                                source.percentage >= 30 
                                  ? "bg-red-500/20 text-red-400 border-red-500/30"
                                  : "bg-amber-500/20 text-amber-400 border-amber-500/30"
                              )}>
                                {source.percentage}% match
                              </Badge>
                            </div>
                            <p className="text-sm text-slate-400 mb-2">Question {qr.questionNumber}</p>
                            <div className="bg-slate-800 p-3 rounded border-l-4 border-red-500">
                              <p className="text-sm text-slate-300 italic">"{source.matchedText}"</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Question-wise */}
            <TabsContent value="questions" className="mt-4">
              <div className="space-y-4">
                {result.questionResults.map((qr) => (
                  <Card key={qr.questionId} className="bg-slate-800/50 border-slate-700">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white text-sm">Question {qr.questionNumber}</CardTitle>
                        <Badge className={cn(
                          "border",
                          getSimilarityColor(qr.similarity).includes('red')
                            ? "bg-red-500/20 text-red-400 border-red-500/30"
                            : getSimilarityColor(qr.similarity).includes('amber')
                            ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
                            : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                        )}>
                          {qr.similarity}% similar
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {qr.matchedSources.map((source, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm p-2 bg-slate-700/50 rounded">
                            <span className="text-slate-300 truncate max-w-[200px]">{source.source}</span>
                            <span className={getSimilarityColor(source.percentage)}>{source.percentage}%</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Actions */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                onClick={handleMarkPlagiarized}
                variant="destructive" 
                className="w-full"
              >
                <Flag className="h-4 w-4 mr-2" />
                Mark as Plagiarized
              </Button>
              <Button 
                variant="outline" 
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <AlertTriangle className="h-4 w-4 mr-2" />
                Issue Warning
              </Button>
            </CardContent>
          </Card>

          {/* Add Comment */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Add Comment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add your observations..."
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
                rows={4}
              />
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                Save Comment
              </Button>
            </CardContent>
          </Card>

          {/* Summary */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Total Sources Matched</span>
                <span className="text-white">
                  {result.questionResults.reduce((acc, qr) => acc + qr.matchedSources.length, 0)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">External Sources</span>
                <span className="text-white">
                  {result.questionResults.reduce((acc, qr) => 
                    acc + qr.matchedSources.filter(s => !s.source.startsWith('Student')).length, 0
                  )}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Student Matches</span>
                <span className="text-white">
                  {result.questionResults.reduce((acc, qr) => 
                    acc + qr.matchedSources.filter(s => s.source.startsWith('Student')).length, 0
                  )}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
