import { useState, useEffect } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  LayoutDashboard,
  ClipboardList,
  RefreshCw,
  FileText,
  User,
  LogOut,
  Bell,
  ChevronLeft,
  GraduationCap,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, path: "/evaluator-portal" },
  { id: "queue", label: "Evaluation Queue", icon: ClipboardList, path: "/evaluator-portal/queue" },
  { id: "reevaluation", label: "Re-evaluation Requests", icon: RefreshCw, path: "/evaluator-portal/reevaluation" },
  { id: "reports", label: "Score Reports", icon: FileText, path: "/evaluator-portal/reports" },
  { id: "profile", label: "Profile", icon: User, path: "/evaluator-portal/profile" },
];

export function EvaluatorLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, user } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [profile, setProfile] = useState({
    id: '',
    name: 'Evaluator',
    email: '',
    avatar: '',
    department: '',
    specialization: '',
  });

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user?.email) return;
      
      const { data } = await supabase
        .from('evaluators')
        .select('*')
        .eq('email', user.email)
        .single();
      
      if (data) {
        setProfile({
          id: data.id,
          name: data.name,
          email: data.email,
          avatar: '',
          department: data.department || '',
          specialization: '',
        });
      }
    };
    
    fetchProfile();
  }, [user]);

  const handleLogout = async () => {
    try {
      await signOut();
      toast.success("Logged out successfully");
      navigate("/login");
    } catch (error) {
      console.error("Logout error:", error);
      toast.error("Failed to log out");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-900 text-slate-100">
      {/* Header */}
      <header className="bg-slate-800/80 backdrop-blur-sm border-b border-slate-700 h-16 flex items-center justify-between px-6 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <GraduationCap className="h-8 w-8 text-emerald-400" />
          <span className="font-bold text-xl">Evaluator Console</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-slate-400 hidden md:block">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric'
            })}
          </span>
          <Button variant="ghost" size="icon" className="relative text-slate-300 hover:text-white hover:bg-slate-700">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-emerald-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              0
            </span>
          </Button>
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9">
              <AvatarImage src={profile.avatar} />
              <AvatarFallback className="bg-emerald-600">{profile.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="hidden md:block">
              <p className="text-sm font-medium">{profile.name}</p>
              <p className="text-xs text-slate-400">Evaluator</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={cn(
            "bg-slate-800/50 backdrop-blur-sm border-r border-slate-700 flex flex-col transition-all duration-300 sticky top-16 h-[calc(100vh-4rem)]",
            collapsed ? "w-16" : "w-64"
          )}
        >
          <nav className="flex-1 p-3 space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;

              return (
                <Link
                  key={item.id}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    isActive
                      ? "bg-emerald-600 text-white"
                      : "text-slate-300 hover:bg-slate-700 hover:text-white",
                    collapsed && "justify-center px-2"
                  )}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              );
            })}
          </nav>

          <div className="p-3 border-t border-slate-700 space-y-2">
            <button
              onClick={handleLogout}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-slate-700 hover:text-red-300 transition-colors w-full",
                collapsed && "justify-center px-2"
              )}
              title={collapsed ? "Logout" : undefined}
            >
              <LogOut className="h-5 w-5 shrink-0" />
              {!collapsed && <span>Logout</span>}
            </button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCollapsed(!collapsed)}
              className="w-full justify-center text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
            </Button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
