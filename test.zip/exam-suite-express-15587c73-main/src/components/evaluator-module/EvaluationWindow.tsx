import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  ChevronLeft,
  ChevronRight,
  Save,
  SkipForward,
  RefreshCw,
  User,
  Clock,
  FileText,
  ZoomIn,
  ZoomOut,
  RotateCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { mockRubricCriteria, AnswerSheet, RubricCriterion } from "@/types/evaluatorModule";
import { toast } from "sonner";

// Default answer sheet for demo
const defaultSheet: AnswerSheet = {
  id: 'AS001',
  candidateId: 'C001',
  candidateName: 'Sample Student',
  rollNumber: 'CS2021001',
  examId: 'EX001',
  examName: 'Sample Exam',
  questionId: 'Q1',
  questionNumber: 1,
  questionText: 'Explain the difference between a stack and a queue. Provide real-world examples for each.',
  questionType: 'long',
  maxMarks: 10,
  submissionType: 'text',
  answer: 'A stack is a Last-In-First-Out (LIFO) data structure where elements are added and removed from the same end called the top. Examples include browser history, undo operations in text editors, and function call stacks in programming.\n\nA queue is a First-In-First-Out (FIFO) data structure where elements are added at the rear and removed from the front. Examples include print job scheduling, customer service lines, and message queues in distributed systems.',
  status: 'pending',
  priority: 'normal',
};

export function EvaluationWindow() {
  const navigate = useNavigate();
  const { sheetId } = useParams();
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const pendingSheets = [defaultSheet];
  const currentSheet = pendingSheets[currentIndex] || defaultSheet;
  
  const [marks, setMarks] = useState(currentSheet.assignedMarks?.toString() || '');
  const [comment, setComment] = useState(currentSheet.evaluatorComment || '');
  const [rubricScores, setRubricScores] = useState<Record<string, number>>({});
  const [zoom, setZoom] = useState(100);

  const totalRubricScore = Object.values(rubricScores).reduce((a, b) => a + b, 0);
  const maxRubricScore = mockRubricCriteria.reduce((a, b) => a + b.maxScore, 0);

  const handleSave = () => {
    if (!marks) {
      toast.error("Please enter marks");
      return;
    }
    toast.success("Evaluation saved");
  };

  const handleSaveAndNext = () => {
    handleSave();
    if (currentIndex < pendingSheets.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setMarks('');
      setComment('');
      setRubricScores({});
    } else {
      navigate('/evaluator-portal/summary');
    }
  };

  const handleMarkForReEval = () => {
    toast.info("Marked for re-evaluation");
  };

  const handleSkip = () => {
    if (currentIndex < pendingSheets.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setMarks('');
      setComment('');
      setRubricScores({});
    }
  };

  const updateRubricScore = (criterionId: string, score: number) => {
    setRubricScores(prev => ({ ...prev, [criterionId]: score }));
    const newTotal = { ...rubricScores, [criterionId]: score };
    const total = Object.values(newTotal).reduce((a, b) => a + b, 0);
    setMarks(total.toString());
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-900">
      {/* Top Bar */}
      <div className="bg-slate-800/80 backdrop-blur-sm border-b border-slate-700 px-6 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/evaluator-portal/queue')}
            className="text-slate-300 hover:text-white"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Queue
          </Button>
          <Separator orientation="vertical" className="h-6 bg-slate-700" />
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8 border-slate-600 text-slate-300 hover:bg-slate-700"
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(prev => prev - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm text-slate-300">
              {currentIndex + 1} / {pendingSheets.length}
            </span>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8 border-slate-600 text-slate-300 hover:bg-slate-700"
              disabled={currentIndex === pendingSheets.length - 1}
              onClick={() => setCurrentIndex(prev => prev + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <Clock className="h-4 w-4" />
            <span>Deadline: Jan 25, 2024</span>
          </div>
          <Progress value={((currentIndex + 1) / pendingSheets.length) * 100} className="w-32 h-2" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-60px)]">
        {/* Left Panel - Student Response */}
        <div className="flex-1 border-r border-slate-700 flex flex-col">
          <div className="p-4 bg-slate-800/50 border-b border-slate-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-slate-600 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-slate-300" />
                </div>
                <div>
                  <p className="font-medium text-white">{currentSheet.candidateName}</p>
                  <p className="text-sm text-slate-400">{currentSheet.rollNumber}</p>
                </div>
              </div>
              <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                Q{currentSheet.questionNumber} • {currentSheet.maxMarks} marks
              </Badge>
            </div>
          </div>

          <ScrollArea className="flex-1 p-6">
            {/* Question */}
            <Card className="bg-slate-800/50 border-slate-700 mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <FileText className="h-4 w-4 text-emerald-400" />
                  Question
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300">{currentSheet.questionText}</p>
              </CardContent>
            </Card>

            {/* Student Answer */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-white text-sm">Student's Answer</CardTitle>
                {(currentSheet.submissionType === 'file' || currentSheet.submissionType === 'image') && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 border-slate-600 text-slate-300 hover:bg-slate-700"
                      onClick={() => setZoom(prev => Math.max(50, prev - 25))}
                    >
                      <ZoomOut className="h-4 w-4" />
                    </Button>
                    <span className="text-xs text-slate-400">{zoom}%</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 border-slate-600 text-slate-300 hover:bg-slate-700"
                      onClick={() => setZoom(prev => Math.min(200, prev + 25))}
                    >
                      <ZoomIn className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <RotateCw className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {currentSheet.submissionType === 'code' ? (
                  <pre className="bg-slate-900 p-4 rounded-lg overflow-x-auto text-sm text-emerald-300 font-mono">
                    {currentSheet.answer}
                  </pre>
                ) : currentSheet.submissionType === 'file' ? (
                  <div 
                    className="bg-slate-900 rounded-lg p-8 text-center"
                    style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
                  >
                    <FileText className="h-16 w-16 text-slate-600 mx-auto mb-4" />
                    <p className="text-slate-400">PDF Document</p>
                    <Button variant="outline" className="mt-4 border-slate-600 text-slate-300">
                      Open Full Viewer
                    </Button>
                  </div>
                ) : (
                  <div className="text-slate-300 whitespace-pre-wrap">
                    {currentSheet.answer}
                  </div>
                )}
              </CardContent>
            </Card>
          </ScrollArea>
        </div>

        {/* Right Panel - Scoring */}
        <div className="w-[400px] flex flex-col bg-slate-800/30">
          <ScrollArea className="flex-1 p-6">
            {/* Marks Input */}
            <div className="space-y-4 mb-6">
              <Label className="text-white">Marks Awarded</Label>
              <div className="flex items-center gap-3">
                <Input
                  type="number"
                  value={marks}
                  onChange={(e) => setMarks(e.target.value)}
                  placeholder="0"
                  className="bg-slate-700 border-slate-600 text-white text-2xl font-bold h-14 text-center"
                  max={currentSheet.maxMarks}
                  min={0}
                />
                <span className="text-slate-400 text-lg">/ {currentSheet.maxMarks}</span>
              </div>
            </div>

            {/* Rubric Scoring */}
            <Card className="bg-slate-800/50 border-slate-700 mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-sm">Rubric Scoring</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockRubricCriteria.map((criterion) => (
                  <div key={criterion.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-slate-300 text-sm">{criterion.name}</Label>
                      <span className="text-xs text-slate-500">{criterion.description}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {Array.from({ length: criterion.maxScore + 1 }, (_, i) => (
                        <Button
                          key={i}
                          variant="outline"
                          size="sm"
                          className={cn(
                            "h-8 w-8 p-0 border-slate-600",
                            rubricScores[criterion.id] === i
                              ? "bg-emerald-600 border-emerald-600 text-white"
                              : "text-slate-300 hover:bg-slate-700"
                          )}
                          onClick={() => updateRubricScore(criterion.id, i)}
                        >
                          {i}
                        </Button>
                      ))}
                      <span className="text-xs text-slate-400 ml-2">/ {criterion.maxScore}</span>
                    </div>
                  </div>
                ))}
                <Separator className="bg-slate-700" />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Rubric Total:</span>
                  <span className="text-white font-medium">{totalRubricScore} / {maxRubricScore}</span>
                </div>
              </CardContent>
            </Card>

            {/* Comment */}
            <div className="space-y-2 mb-6">
              <Label className="text-white">Evaluator Comment</Label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add feedback for the student..."
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 min-h-[120px]"
              />
            </div>
          </ScrollArea>

          {/* Action Buttons */}
          <div className="p-4 border-t border-slate-700 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleSave}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
              <Button
                onClick={handleSaveAndNext}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Save & Next
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleMarkForReEval}
                variant="outline"
                className="border-amber-500 text-amber-400 hover:bg-amber-500/10"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Re-evaluate
              </Button>
              <Button
                onClick={handleSkip}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <SkipForward className="h-4 w-4 mr-2" />
                Skip
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
