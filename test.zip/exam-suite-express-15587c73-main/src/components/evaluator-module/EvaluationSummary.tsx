import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  CheckCircle2,
  Clock,
  FileText,
  BarChart3,
  ArrowRight,
  Home,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export function EvaluationSummary() {
  const navigate = useNavigate();

  const stats = {
    totalEvaluated: 28,
    timeSpent: '2h 15m',
    marksRange: { min: 3, max: 18 },
    avgMarks: 12.5,
    consistencyScore: 94,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-900 flex items-center justify-center p-6">
      <Card className="bg-slate-800/50 border-slate-700 max-w-2xl w-full">
        <CardContent className="pt-12 pb-8 px-8">
          {/* Success Icon */}
          <div className="flex justify-center mb-8">
            <div className="h-24 w-24 bg-emerald-500/20 rounded-full flex items-center justify-center">
              <CheckCircle2 className="h-16 w-16 text-emerald-400" />
            </div>
          </div>

          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Evaluation Completed!</h1>
            <p className="text-slate-400">Great work! You've finished evaluating all assigned answer sheets.</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-slate-700/50 rounded-lg p-4 text-center">
              <FileText className="h-6 w-6 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{stats.totalEvaluated}</p>
              <p className="text-xs text-slate-400">Questions Evaluated</p>
            </div>
            <div className="bg-slate-700/50 rounded-lg p-4 text-center">
              <Clock className="h-6 w-6 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{stats.timeSpent}</p>
              <p className="text-xs text-slate-400">Total Time Spent</p>
            </div>
            <div className="bg-slate-700/50 rounded-lg p-4 text-center">
              <BarChart3 className="h-6 w-6 text-amber-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{stats.marksRange.min}-{stats.marksRange.max}</p>
              <p className="text-xs text-slate-400">Marks Range</p>
            </div>
            <div className="bg-slate-700/50 rounded-lg p-4 text-center">
              <CheckCircle2 className="h-6 w-6 text-emerald-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{stats.consistencyScore}%</p>
              <p className="text-xs text-slate-400">Consistency Score</p>
            </div>
          </div>

          {/* Additional Stats */}
          <Card className="bg-slate-700/30 border-slate-600 mb-8">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between py-2 border-b border-slate-600">
                <span className="text-slate-400">Average Marks Awarded</span>
                <span className="text-white font-medium">{stats.avgMarks} / 20</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-600">
                <span className="text-slate-400">Average Time per Answer</span>
                <span className="text-white font-medium">4.8 minutes</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Rubric Compliance</span>
                <span className="text-emerald-400 font-medium">Excellent</span>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={() => navigate('/evaluator-portal')}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
            >
              <Home className="h-4 w-4 mr-2" />
              Return to Dashboard
            </Button>
            <Button
              onClick={() => navigate('/evaluator-portal/reports')}
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              View Results Summary
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>

          {/* Continue to Next */}
          <div className="mt-6 text-center">
            <Button
              onClick={() => navigate('/evaluator-portal/queue')}
              variant="link"
              className="text-emerald-400 hover:text-emerald-300"
            >
              Continue to Next Exam
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
