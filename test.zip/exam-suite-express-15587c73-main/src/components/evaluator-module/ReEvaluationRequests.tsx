import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  CheckCircle,
  XCircle,
  Eye,
  X,
  FileText,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ReEvaluationRequest, AssignedExam } from "@/types/evaluatorModule";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

export function ReEvaluationRequests() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [requests, setRequests] = useState<ReEvaluationRequest[]>([]);
  const [assignedExams, setAssignedExams] = useState<AssignedExam[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<ReEvaluationRequest | null>(null);
  const [filters, setFilters] = useState({
    search: '',
    exam: 'all',
    status: 'all',
  });

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      const { data: exams } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (exams) {
        const mappedExams: AssignedExam[] = exams.map(exam => ({
          id: exam.id,
          name: exam.title,
          subject: exam.course || 'General',
          section: exam.department,
          totalSheets: 45,
          pendingSheets: 28,
          completedSheets: 17,
          deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          priority: 'normal' as const,
        }));
        setAssignedExams(mappedExams);
      }
      
      // Demo re-evaluation request
      const demoRequest: ReEvaluationRequest = {
        id: 'RE001',
        candidateId: 'C005',
        candidateName: 'Demo Student',
        rollNumber: 'CS2021005',
        examId: exams?.[0]?.id || 'EX001',
        examName: exams?.[0]?.title || 'Sample Exam',
        questionId: 'Q1',
        questionNumber: 1,
        originalMarks: 5,
        requestedMarks: 8,
        maxMarks: 10,
        reason: 'I believe my answer covered all required points.',
        status: 'pending',
        studentRemarks: 'I provided detailed examples for both concepts.',
        previousComment: 'Good attempt but examples could be more detailed.',
        createdAt: new Date().toISOString(),
      };
      setRequests([demoRequest]);
      setIsLoading(false);
    };
    
    fetchData();
  }, []);

  const filteredRequests = requests.filter(request => {
    const matchesSearch = request.candidateName.toLowerCase().includes(filters.search.toLowerCase()) ||
                         request.rollNumber.toLowerCase().includes(filters.search.toLowerCase());
    const matchesExam = filters.exam === 'all' || request.examId === filters.exam;
    const matchesStatus = filters.status === 'all' || request.status === filters.status;
    return matchesSearch && matchesExam && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Rejected</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Completed</Badge>;
      default:
        return null;
    }
  };

  const handleApprove = (requestId: string) => {
    setRequests(prev => prev.map(r => 
      r.id === requestId ? { ...r, status: 'approved' as const } : r
    ));
    toast.success("Request approved");
    setSelectedRequest(null);
  };

  const handleReject = (requestId: string) => {
    setRequests(prev => prev.map(r => 
      r.id === requestId ? { ...r, status: 'rejected' as const } : r
    ));
    toast.success("Request rejected");
    setSelectedRequest(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Re-evaluation Requests</h1>
        <p className="text-slate-400">Review and manage student re-evaluation requests</p>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search by name or roll number..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-9 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>
            <Select 
              value={filters.exam} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, exam: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Exam" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Exams</SelectItem>
                {assignedExams.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>{exam.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select 
              value={filters.status} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Requests Table */}
        <Card className="bg-slate-800/50 border-slate-700 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white">Requests ({filteredRequests.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRequests.length === 0 ? (
              <p className="text-center text-slate-400 py-8">No re-evaluation requests.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-transparent">
                    <TableHead className="text-slate-400">Candidate</TableHead>
                    <TableHead className="text-slate-400">Question</TableHead>
                    <TableHead className="text-slate-400">Marks</TableHead>
                    <TableHead className="text-slate-400">Status</TableHead>
                    <TableHead className="text-slate-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRequests.map((request) => (
                    <TableRow 
                      key={request.id} 
                      className={cn(
                        "border-slate-700 cursor-pointer",
                        selectedRequest?.id === request.id && "bg-slate-700/50"
                      )}
                      onClick={() => setSelectedRequest(request)}
                    >
                      <TableCell>
                        <div>
                          <p className="text-white font-medium">{request.candidateName}</p>
                          <p className="text-sm text-slate-400">{request.rollNumber}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-slate-300">Q{request.questionNumber}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <span className="text-red-400">{request.originalMarks}</span>
                          <span className="text-slate-500 mx-1">→</span>
                          <span className="text-emerald-400">{request.requestedMarks}</span>
                          <span className="text-slate-500">/{request.maxMarks}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(request.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {request.status === 'pending' && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-emerald-400 hover:text-emerald-300 hover:bg-slate-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleApprove(request.id);
                                }}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-slate-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleReject(request.id);
                                }}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Detail Panel */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Request Details</CardTitle>
            {selectedRequest && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-slate-400 hover:text-white"
                onClick={() => setSelectedRequest(null)}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {selectedRequest ? (
              <div className="space-y-4">
                {/* Student Info */}
                <div>
                  <p className="text-sm text-slate-400">Student</p>
                  <p className="text-white font-medium">{selectedRequest.candidateName}</p>
                  <p className="text-sm text-slate-400">{selectedRequest.rollNumber}</p>
                </div>

                {/* Marks Comparison */}
                <div className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-xs text-slate-400">Original</p>
                      <p className="text-2xl font-bold text-red-400">{selectedRequest.originalMarks}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Requested</p>
                      <p className="text-2xl font-bold text-emerald-400">{selectedRequest.requestedMarks}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Max</p>
                      <p className="text-2xl font-bold text-white">{selectedRequest.maxMarks}</p>
                    </div>
                  </div>
                </div>

                {/* Student Remarks */}
                <div>
                  <p className="text-sm text-slate-400 mb-2">Student's Reason</p>
                  <p className="text-slate-300 text-sm bg-slate-700/50 p-3 rounded-lg">
                    {selectedRequest.studentRemarks}
                  </p>
                </div>

                {/* Previous Comment */}
                <div>
                  <p className="text-sm text-slate-400 mb-2">Previous Evaluation Comment</p>
                  <p className="text-slate-300 text-sm bg-slate-700/50 p-3 rounded-lg">
                    {selectedRequest.previousComment}
                  </p>
                </div>

                {/* Evidence */}
                {selectedRequest.evidence && (
                  <div>
                    <p className="text-sm text-slate-400 mb-2">Evidence Attached</p>
                    <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">
                      <FileText className="h-4 w-4 mr-2" />
                      View Evidence
                    </Button>
                  </div>
                )}

                {/* Actions */}
                {selectedRequest.status === 'pending' && (
                  <div className="flex gap-2 pt-4 border-t border-slate-700">
                    <Button
                      onClick={() => navigate('/evaluator-portal/evaluate/1')}
                      variant="outline"
                      className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Re-evaluate
                    </Button>
                    <Button
                      onClick={() => handleApprove(selectedRequest.id)}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      onClick={() => handleReject(selectedRequest.id)}
                      variant="destructive"
                      className="flex-1"
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">
                <Eye className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>Select a request to view details</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
