import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  FileText,
  Code,
  Image,
  File,
  Play,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { AnswerSheet, AssignedExam } from "@/types/evaluatorModule";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

export function EvaluationQueue() {
  const navigate = useNavigate();
  const [selectedSheets, setSelectedSheets] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [answerSheets, setAnswerSheets] = useState<AnswerSheet[]>([]);
  const [assignedExams, setAssignedExams] = useState<AssignedExam[]>([]);
  const [filters, setFilters] = useState({
    search: '',
    exam: 'all',
    status: 'all',
    priority: 'all',
  });

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      // Fetch exams
      const { data: exams } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (exams) {
        const mappedExams: AssignedExam[] = exams.map(exam => ({
          id: exam.id,
          name: exam.title,
          subject: exam.course || 'General',
          section: exam.department,
          totalSheets: 45,
          pendingSheets: 28,
          completedSheets: 17,
          deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          priority: 'normal' as const,
        }));
        setAssignedExams(mappedExams);
      }
      
      // Create placeholder answer sheets for demo
      const placeholderSheets: AnswerSheet[] = [
        {
          id: 'AS001',
          candidateId: 'C001',
          candidateName: 'Sample Student',
          rollNumber: 'CS2021001',
          examId: exams?.[0]?.id || 'EX001',
          examName: exams?.[0]?.title || 'Sample Exam',
          questionId: 'Q1',
          questionNumber: 1,
          questionText: 'Explain the concept in detail.',
          questionType: 'long',
          maxMarks: 10,
          submissionType: 'text',
          answer: 'Sample answer text...',
          status: 'pending',
          priority: 'normal',
        }
      ];
      setAnswerSheets(placeholderSheets);
      setIsLoading(false);
    };
    
    fetchData();
  }, []);

  const filteredSheets = answerSheets.filter(sheet => {
    const matchesSearch = sheet.candidateName.toLowerCase().includes(filters.search.toLowerCase()) ||
                         sheet.rollNumber.toLowerCase().includes(filters.search.toLowerCase());
    const matchesExam = filters.exam === 'all' || sheet.examId === filters.exam;
    const matchesStatus = filters.status === 'all' || sheet.status === filters.status;
    const matchesPriority = filters.priority === 'all' || sheet.priority === filters.priority;
    return matchesSearch && matchesExam && matchesStatus && matchesPriority;
  });

  const getSubmissionIcon = (type: string) => {
    switch (type) {
      case 'text': return <FileText className="h-4 w-4 text-blue-400" />;
      case 'code': return <Code className="h-4 w-4 text-purple-400" />;
      case 'image': return <Image className="h-4 w-4 text-green-400" />;
      case 'file': return <File className="h-4 w-4 text-amber-400" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Pending</Badge>;
      case 'in-progress':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">In Progress</Badge>;
      case 'completed':
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Completed</Badge>;
      default:
        return null;
    }
  };

  const toggleSelectAll = () => {
    if (selectedSheets.length === filteredSheets.length) {
      setSelectedSheets([]);
    } else {
      setSelectedSheets(filteredSheets.map(s => s.id));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedSheets(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Evaluation Queue</h1>
        <p className="text-slate-400">Review and evaluate pending answer sheets</p>
      </div>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search by name or roll number..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-9 bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
            </div>
            <Select 
              value={filters.exam} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, exam: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Exam" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Exams</SelectItem>
                {assignedExams.map((exam) => (
                  <SelectItem key={exam.id} value={exam.id}>{exam.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select 
              value={filters.status} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.priority} 
              onValueChange={(value) => setFilters(prev => ({ ...prev, priority: value }))}
            >
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Bulk Actions */}
      {selectedSheets.length > 0 && (
        <div className="flex items-center gap-4 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg">
          <span className="text-sm text-emerald-400">{selectedSheets.length} selected</span>
          <Button size="sm" variant="outline" className="border-emerald-500 text-emerald-400 hover:bg-emerald-500/20">
            Mark as Completed
          </Button>
          <Button size="sm" variant="outline" className="border-slate-500 text-slate-300 hover:bg-slate-700">
            Assign to Another
          </Button>
        </div>
      )}

      {/* Queue Table */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Answer Sheets ({filteredSheets.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredSheets.length === 0 ? (
            <p className="text-center text-slate-400 py-8">No answer sheets to evaluate.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-transparent">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedSheets.length === filteredSheets.length && filteredSheets.length > 0}
                      onCheckedChange={toggleSelectAll}
                      className="border-slate-500"
                    />
                  </TableHead>
                  <TableHead className="text-slate-400">Candidate</TableHead>
                  <TableHead className="text-slate-400">Question</TableHead>
                  <TableHead className="text-slate-400">Type</TableHead>
                  <TableHead className="text-slate-400">Priority</TableHead>
                  <TableHead className="text-slate-400">Status</TableHead>
                  <TableHead className="text-slate-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSheets.map((sheet) => (
                  <TableRow key={sheet.id} className="border-slate-700">
                    <TableCell>
                      <Checkbox
                        checked={selectedSheets.includes(sheet.id)}
                        onCheckedChange={() => toggleSelect(sheet.id)}
                        className="border-slate-500"
                      />
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-white font-medium">{sheet.candidateName}</p>
                        <p className="text-sm text-slate-400">{sheet.rollNumber}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-white">Q{sheet.questionNumber}</p>
                        <p className="text-xs text-slate-400 truncate max-w-[200px]">
                          {sheet.questionText}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getSubmissionIcon(sheet.submissionType)}
                        <span className="text-slate-300 capitalize">{sheet.submissionType}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {sheet.priority === 'high' ? (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High</Badge>
                      ) : (
                        <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">Normal</Badge>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(sheet.status)}</TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        onClick={() => navigate(`/evaluator-portal/evaluate/${sheet.id}`)}
                        className={cn(
                          sheet.status === 'completed'
                            ? "bg-slate-600 hover:bg-slate-500"
                            : "bg-emerald-600 hover:bg-emerald-700"
                        )}
                      >
                        <Play className="h-4 w-4 mr-1" />
                        {sheet.status === 'completed' ? 'Review' : 'Evaluate'}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
