import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ClipboardList,
  CheckCircle,
  Clock,
  RefreshCw,
  Calendar,
  ArrowRight,
  TrendingUp,
  Loader2,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface AssignedExam {
  id: string;
  name: string;
  subject: string;
  section: string;
  totalSheets: number;
  pendingSheets: number;
  completedSheets: number;
  deadline: string;
  priority: 'high' | 'normal';
}

export function EvaluatorDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [assignedExams, setAssignedExams] = useState<AssignedExam[]>([]);
  const [stats, setStats] = useState({
    pending: 0,
    completed: 0,
    avgTime: '4.5 min',
    reEvalRequests: 0,
  });

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      // Fetch exams from database
      const { data: exams } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (exams) {
        const mappedExams: AssignedExam[] = exams.map(exam => ({
          id: exam.id,
          name: exam.title,
          subject: exam.course || 'General',
          section: exam.department,
          totalSheets: 45,
          pendingSheets: Math.floor(Math.random() * 30),
          completedSheets: Math.floor(Math.random() * 20),
          deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          priority: Math.random() > 0.5 ? 'high' : 'normal',
        }));
        setAssignedExams(mappedExams);
        
        const pending = mappedExams.reduce((acc, e) => acc + e.pendingSheets, 0);
        const completed = mappedExams.reduce((acc, e) => acc + e.completedSheets, 0);
        setStats(prev => ({ ...prev, pending, completed }));
      }
      
      setIsLoading(false);
    };
    
    fetchData();
  }, [user]);

  const dailyEvaluations = [
    { day: 'Mon', count: 12 },
    { day: 'Tue', count: 18 },
    { day: 'Wed', count: 15 },
    { day: 'Thu', count: 22 },
    { day: 'Fri', count: 8 },
  ];

  const questionTypes = [
    { type: 'Short Answer', count: 45, color: 'bg-blue-500' },
    { type: 'Long Answer', count: 30, color: 'bg-emerald-500' },
    { type: 'File Upload', count: 15, color: 'bg-purple-500' },
    { type: 'Code', count: 10, color: 'bg-amber-500' },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Evaluator Dashboard</h1>
        <p className="text-slate-400">Manage and evaluate assigned answer sheets</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Pending Evaluations</p>
                <p className="text-3xl font-bold text-white">{stats.pending}</p>
              </div>
              <div className="h-12 w-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                <ClipboardList className="h-6 w-6 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Completed</p>
                <p className="text-3xl font-bold text-white">{stats.completed}</p>
              </div>
              <div className="h-12 w-12 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Avg. Scoring Time</p>
                <p className="text-3xl font-bold text-white">{stats.avgTime}</p>
              </div>
              <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Re-evaluation Requests</p>
                <p className="text-3xl font-bold text-white">{stats.reEvalRequests}</p>
              </div>
              <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                <RefreshCw className="h-6 w-6 text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Assigned Exams */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-semibold text-white">Assigned Exams</h2>
          {assignedExams.length === 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6 text-center text-slate-400">
                No exams assigned yet.
              </CardContent>
            </Card>
          ) : (
            assignedExams.map((exam) => (
              <Card key={exam.id} className="bg-slate-800/50 border-slate-700">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-white">{exam.name}</h3>
                        {exam.priority === 'high' && (
                          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High Priority</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-400 mb-3">
                        {exam.subject} • {exam.section}
                      </p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-slate-400">
                          <span className="text-emerald-400 font-medium">{exam.completedSheets}</span>/{exam.totalSheets} completed
                        </span>
                        <span className="flex items-center gap-1 text-slate-400">
                          <Calendar className="h-4 w-4" />
                          Due: {exam.deadline}
                        </span>
                      </div>
                      <Progress 
                        value={(exam.completedSheets / exam.totalSheets) * 100} 
                        className="mt-3 h-2"
                      />
                    </div>
                    <Button 
                      onClick={() => navigate('/evaluator-portal/queue')}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      Open Queue
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Quick Stats */}
        <div className="space-y-4">
          {/* Daily Evaluations */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
                Daily Evaluations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between h-24 gap-2">
                {dailyEvaluations.map((item) => (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-1">
                    <div 
                      className="w-full bg-emerald-500 rounded-t transition-all"
                      style={{ height: `${(item.count / 25) * 100}%` }}
                    />
                    <span className="text-xs text-slate-400">{item.day}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Question Types */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">Question Types Evaluated</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {questionTypes.map((item) => (
                  <div key={item.type} className="flex items-center gap-3">
                    <div className={`h-3 w-3 rounded-full ${item.color}`} />
                    <span className="flex-1 text-sm text-slate-300">{item.type}</span>
                    <span className="text-sm text-white font-medium">{item.count}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-sm">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button 
                variant="outline" 
                className="w-full justify-start border-slate-600 text-slate-300 hover:bg-slate-700"
                onClick={() => navigate('/evaluator-portal/queue')}
              >
                <ClipboardList className="h-4 w-4 mr-2" />
                Start Evaluating
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start border-slate-600 text-slate-300 hover:bg-slate-700"
                onClick={() => navigate('/evaluator-portal/reevaluation')}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                View Re-evaluation Requests
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
