import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Mail, Phone, Calendar, Briefcase, Clock, Star, Shield, Activity, BarChart3, Loader2, KeyRound, Trash2 } from 'lucide-react';
import {
  Proctor,
  ProctorActivityLog,
  ProctorPerformanceData,
  IncidentCategoryData,
} from '@/types/proctor';

// Placeholder data for activity and performance (still mock)
const mockActivityLogs: ProctorActivityLog[] = [];
const mockPerformanceData: ProctorPerformanceData[] = [];
const mockIncidentCategories: IncidentCategoryData[] = [];

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AssignedExam {
  id: string;
  examName: string;
  examDate: string | null;
  role: 'lead' | 'support';
  status: 'upcoming' | 'ongoing' | 'completed';
}

interface ProctorProfileModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  proctor: Proctor | null;
  onToggleStatus: (proctor: Proctor) => void;
  onAssignExam: () => void;
}

const COLORS = ['hsl(var(--primary))', 'hsl(var(--destructive))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

export function ProctorProfileModal({ open, onOpenChange, proctor, onToggleStatus, onAssignExam }: ProctorProfileModalProps) {
  const [assignments, setAssignments] = useState<AssignedExam[]>([]);
  const [isLoadingAssignments, setIsLoadingAssignments] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [assignmentToRemove, setAssignmentToRemove] = useState<AssignedExam | null>(null);
  const [isRemoving, setIsRemoving] = useState(false);

  const handleResetPassword = async () => {
    if (!proctor?.email) return;
    
    setIsResettingPassword(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(proctor.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        toast.error(`Failed to send reset email: ${error.message}`);
      } else {
        toast.success(`Password reset email sent to ${proctor.email}`);
      }
    } catch (err) {
      toast.error('An error occurred while sending reset email');
    } finally {
      setIsResettingPassword(false);
    }
  };

  const handleRemoveAssignment = async () => {
    if (!assignmentToRemove) return;
    
    setIsRemoving(true);
    try {
      const { error } = await supabase
        .from('proctor_exam_assignments')
        .delete()
        .eq('id', assignmentToRemove.id);

      if (error) {
        toast.error('Failed to remove assignment');
        console.error('Error removing assignment:', error);
      } else {
        setAssignments((prev) => prev.filter((a) => a.id !== assignmentToRemove.id));
        toast.success(`Removed from ${assignmentToRemove.examName}`);
      }
    } catch (err) {
      toast.error('An error occurred');
    } finally {
      setIsRemoving(false);
      setAssignmentToRemove(null);
    }
  };

  // Fetch assignments when modal opens
  useEffect(() => {
    const fetchAssignments = async () => {
      if (!open || !proctor) return;
      
      setIsLoadingAssignments(true);
      try {
        const { data, error } = await supabase
          .from('proctor_exam_assignments')
          .select(`
            id,
            role,
            assigned_at,
            exams:exam_id (
              id,
              title,
              start_date,
              end_date,
              status
            )
          `)
          .eq('proctor_id', proctor.id)
          .order('assigned_at', { ascending: false });

        if (error) {
          console.error('Error fetching proctor assignments:', error);
          return;
        }

        const now = new Date();
        const formattedAssignments: AssignedExam[] = (data || []).map((item: any) => {
          const exam = item.exams;
          let status: 'upcoming' | 'ongoing' | 'completed' = 'upcoming';
          
          if (exam) {
            const startDate = exam.start_date ? new Date(exam.start_date) : null;
            const endDate = exam.end_date ? new Date(exam.end_date) : null;
            
            if (exam.status === 'completed' || (endDate && now > endDate)) {
              status = 'completed';
            } else if (startDate && now >= startDate && (!endDate || now <= endDate)) {
              status = 'ongoing';
            } else {
              status = 'upcoming';
            }
          }

          return {
            id: item.id,
            examName: exam?.title || 'Unknown Exam',
            examDate: exam?.start_date,
            role: item.role as 'lead' | 'support',
            status,
          };
        });

        setAssignments(formattedAssignments);
      } catch (err) {
        console.error('Error fetching assignments:', err);
      } finally {
        setIsLoadingAssignments(false);
      }
    };

    fetchAssignments();
  }, [open, proctor]);

  if (!proctor) return null;

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const getRoleBadge = (role: 'lead' | 'support') => {
    return (
      <Badge variant={role === 'lead' ? 'default' : 'secondary'}>
        {role === 'lead' ? 'Lead Proctor' : 'Support Proctor'}
      </Badge>
    );
  };

  const getStatusBadge = (status: 'upcoming' | 'ongoing' | 'completed') => {
    const variants: Record<string, 'default' | 'secondary' | 'outline'> = {
      upcoming: 'secondary',
      ongoing: 'default',
      completed: 'outline',
    };
    const labels: Record<string, string> = {
      upcoming: 'Upcoming',
      ongoing: 'Ongoing',
      completed: 'Completed',
    };
    return <Badge variant={variants[status]}>{labels[status]}</Badge>;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Proctor Profile</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="assignments">Assigned Exams</TabsTrigger>
            <TabsTrigger value="activity">Activity Logs</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="flex items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={proctor.photoUrl} />
                <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                  {getInitials(proctor.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-semibold">{proctor.name}</h2>
                    <p className="text-muted-foreground font-mono">{proctor.proctorId}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleResetPassword}
                      disabled={isResettingPassword}
                    >
                      {isResettingPassword ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <KeyRound className="h-4 w-4 mr-2" />
                      )}
                      Reset Password
                    </Button>
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Switch
                      checked={proctor.status === 'active'}
                      onCheckedChange={() => onToggleStatus(proctor)}
                    />
                    <Badge variant={proctor.status === 'active' ? 'default' : 'destructive'}>
                      {proctor.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{proctor.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{proctor.mobile}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span>{proctor.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{proctor.experience} years experience</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Shield className="h-4 w-4" /> Total Exams Proctored
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{proctor.totalExamsProctored}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Clock className="h-4 w-4" /> Avg Response Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{proctor.avgResponseTime}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Star className="h-4 w-4" /> Rating
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{proctor.rating}/5.0</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Activity className="h-4 w-4" /> Assigned Exams
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{assignments.length || proctor.assignedExamsCount}</p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-6">
              <h4 className="font-medium mb-3">Permissions</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(proctor.permissions).map(([key, value]) => (
                  <Badge key={key} variant={value ? 'default' : 'outline'} className="capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </Badge>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="assignments" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">Assigned Exams</h3>
              <Button size="sm" onClick={onAssignExam}>+ Assign to Exam</Button>
            </div>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAssignments ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin mx-auto text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  ) : assignments.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No exams assigned yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    assignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell className="font-medium">{assignment.examName}</TableCell>
                        <TableCell>
                          {assignment.examDate 
                            ? format(new Date(assignment.examDate), 'MMM d, yyyy h:mm a')
                            : 'Not scheduled'
                          }
                        </TableCell>
                        <TableCell>{getRoleBadge(assignment.role)}</TableCell>
                        <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={() => setAssignmentToRemove(assignment)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <h3 className="font-semibold mb-4">Activity Logs</h3>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Candidate</TableHead>
                    <TableHead>Exam</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockActivityLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No activity logs yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    mockActivityLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(log.timestamp), 'MMM d, h:mm a')}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{log.action}</Badge>
                        </TableCell>
                        <TableCell>{log.description}</TableCell>
                        <TableCell>{log.candidateName || '-'}</TableCell>
                        <TableCell>{log.examName}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="mt-6">
            <h3 className="font-semibold mb-4">Proctoring Performance Analytics</h3>
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" /> Incidents Handled Per Exam
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    {mockPerformanceData.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        No performance data available
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={mockPerformanceData}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis dataKey="examName" className="text-xs" />
                          <YAxis className="text-xs" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                            }}
                          />
                          <Bar dataKey="incidentsHandled" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Incident Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    {mockIncidentCategories.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        No incident data available
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={mockIncidentCategories}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="count"
                            nameKey="category"
                            label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                            labelLine={false}
                          >
                            {mockIncidentCategories.map((_, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                            }}
                          />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>

      <AlertDialog open={!!assignmentToRemove} onOpenChange={(open) => !open && setAssignmentToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Assignment</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove {proctor?.name} from "{assignmentToRemove?.examName}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isRemoving}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRemoveAssignment}
              disabled={isRemoving}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isRemoving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}
