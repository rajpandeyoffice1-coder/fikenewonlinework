import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ProctorFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  status: string;
  onStatusChange: (value: string) => void;
  department: string;
  onDepartmentChange: (value: string) => void;
  assignedExam: string;
  onAssignedExamChange: (value: string) => void;
}

const departments = ['All Departments', 'Computer Science', 'Electrical Engineering', 'Mathematics', 'Physics', 'Chemistry'];
const statuses = ['All Status', 'Active', 'Inactive'];
const exams = ['All Exams', 'Data Structures Mid-Term', 'Database Systems Final', 'Computer Networks Quiz', 'Operating Systems Lab'];

export function ProctorFilters({
  searchQuery,
  onSearchChange,
  status,
  onStatusChange,
  department,
  onDepartmentChange,
  assignedExam,
  onAssignedExamChange,
}: ProctorFiltersProps) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, email, or proctor ID..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>
      <div className="flex flex-wrap gap-3">
        <Select value={status} onValueChange={onStatusChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {statuses.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={department} onValueChange={onDepartmentChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Department" />
          </SelectTrigger>
          <SelectContent>
            {departments.map((dept) => (
              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={assignedExam} onValueChange={onAssignedExamChange}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Assigned Exam" />
          </SelectTrigger>
          <SelectContent>
            {exams.map((exam) => (
              <SelectItem key={exam} value={exam}>{exam}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
