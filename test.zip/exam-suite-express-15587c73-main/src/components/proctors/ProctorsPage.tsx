import { useState, useMemo, useEffect } from 'react';
import { Plus, UserCheck, UserX, ClipboardList, UserMinus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { ProctorFilters } from './ProctorFilters';
import { ProctorsTable } from './ProctorsTable';
import { AddProctorModal } from './AddProctorModal';
import { ProctorProfileModal } from './ProctorProfileModal';
import { AssignExamModal } from './AssignExamModal';

interface Proctor {
  id: string;
  name: string;
  proctorId: string;
  email: string;
  mobile: string;
  department: string;
  experience: number;
  photoUrl?: string;
  status: 'active' | 'inactive';
  permissions: {
    viewCandidates: boolean;
    sendWarnings: boolean;
    muteCandidate: boolean;
    pauseExam: boolean;
    endExam: boolean;
    viewEvidenceReplay: boolean;
  };
  assignedExamsCount: number;
  createdAt: string;
  totalExamsProctored: number;
  avgResponseTime: string;
  rating: number;
}

// Convert DB row to Proctor type
const dbToProctor = (row: any): Proctor => ({
  id: row.id,
  name: row.name,
  proctorId: `PROC${row.id.slice(0, 6).toUpperCase()}`,
  email: row.email,
  mobile: row.mobile || '',
  department: row.department || '',
  experience: row.experience || 0,
  photoUrl: undefined,
  status: row.status,
  permissions: row.permissions || {
    viewCandidates: true,
    sendWarnings: true,
    muteCandidate: false,
    pauseExam: false,
    endExam: false,
    viewEvidenceReplay: false,
  },
  assignedExamsCount: row.assigned_exams_count || 0,
  createdAt: row.created_at,
  totalExamsProctored: row.assigned_exams_count || 0,
  avgResponseTime: '0 min',
  rating: 0,
});

export function ProctorsPage() {
  const [proctors, setProctors] = useState<Proctor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [status, setStatus] = useState('All Status');
  const [department, setDepartment] = useState('All Departments');
  const [assignedExam, setAssignedExam] = useState('All Exams');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const [addModalOpen, setAddModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [editingProctor, setEditingProctor] = useState<Proctor | null>(null);
  const [viewingProctor, setViewingProctor] = useState<Proctor | null>(null);
  const [assigningProctor, setAssigningProctor] = useState<Proctor | null>(null);

  // Fetch proctors from database
  useEffect(() => {
    const fetchProctors = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('proctors')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching proctors:', error);
        toast.error('Failed to load proctors');
      } else {
        setProctors((data || []).map(dbToProctor));
      }
      setIsLoading(false);
    };

    fetchProctors();
  }, []);

  const filteredProctors = useMemo(() => {
    return proctors.filter((proctor) => {
      const matchesSearch =
        searchQuery === '' ||
        proctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proctor.proctorId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        proctor.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = status === 'All Status' || proctor.status === status.toLowerCase();
      const matchesDept = department === 'All Departments' || proctor.department === department;
      return matchesSearch && matchesStatus && matchesDept;
    });
  }, [proctors, searchQuery, status, department]);

  const handleAddProctor = () => {
    setEditingProctor(null);
    setAddModalOpen(true);
  };

  const handleEditProctor = (proctor: Proctor) => {
    setEditingProctor(proctor);
    setAddModalOpen(true);
  };

  const handleViewProctor = (proctor: Proctor) => {
    setViewingProctor(proctor);
    setProfileModalOpen(true);
  };

  const handleSaveProctor = async (data: Partial<Proctor> & { password?: string }) => {
    const dbData = {
      name: data.name || '',
      email: data.email || '',
      mobile: data.mobile || '',
      department: data.department || '',
      experience: data.experience || 0,
      status: data.status || 'active',
      permissions: data.permissions || {
        liveMonitoring: true,
        viewRecordings: true,
        flagIncidents: true,
        pauseExams: false,
        terminateExams: false,
      },
    };

    if (editingProctor) {
      const { error } = await supabase
        .from('proctors')
        .update(dbData)
        .eq('id', editingProctor.id);

      if (error) {
        console.error('Error updating proctor:', error);
        toast.error('Failed to update proctor');
        return;
      }

      setProctors((prev) =>
        prev.map((p) => (p.id === editingProctor.id ? { ...p, ...data } : p))
      );
      toast.success('Proctor updated successfully');
    } else {
      // Use edge function to create user (avoids logging out current admin)
      const { data: result, error: fnError } = await supabase.functions.invoke('staff-management', {
        body: {
          action: 'create-proctor',
          email: data.email || '',
          password: data.password || '',
          name: data.name || '',
          mobile: data.mobile || '',
          department: data.department || '',
          experience: data.experience || 0,
          permissions: data.permissions || {
            viewCandidates: true,
            sendWarnings: true,
            muteCandidate: false,
            pauseExam: false,
            endExam: false,
            viewEvidenceReplay: false,
          },
        },
      });

      if (fnError || !result?.success) {
        console.error('Error creating proctor:', fnError || result?.error);
        toast.error(`Failed to create proctor: ${result?.error || fnError?.message}`);
        return;
      }

      setProctors((prev) => [dbToProctor(result.data), ...prev]);
      toast.success(
        `Proctor added successfully!\n\nLogin credentials:\nEmail: ${result.credentials.email}\nPassword: ${result.credentials.password}`,
        { duration: 8000 }
      );
    }
  };

  const handleToggleStatus = async (proctor: Proctor) => {
    const newStatus = proctor.status === 'active' ? 'inactive' : 'active';

    const { error } = await supabase
      .from('proctors')
      .update({ status: newStatus })
      .eq('id', proctor.id);

    if (error) {
      console.error('Error toggling status:', error);
      toast.error('Failed to update status');
      return;
    }

    setProctors((prev) =>
      prev.map((p) =>
        p.id === proctor.id ? { ...p, status: newStatus } : p
      )
    );
    toast.success(`Proctor ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
  };

  const handleBulkAction = async (action: string) => {
    if (selectedIds.length === 0) {
      toast.error('Please select proctors first');
      return;
    }

    switch (action) {
      case 'activate':
      case 'deactivate':
        const newStatus = action === 'activate' ? 'active' : 'inactive';
        const { error } = await supabase
          .from('proctors')
          .update({ status: newStatus })
          .in('id', selectedIds);

        if (error) {
          toast.error(`Failed to ${action} proctors`);
          return;
        }

        setProctors((prev) =>
          prev.map((p) => (selectedIds.includes(p.id) ? { ...p, status: newStatus } : p))
        );
        toast.success(`${selectedIds.length} proctors ${action}d`);
        break;
      case 'assign':
        setAssigningProctor(null);
        setAssignModalOpen(true);
        break;
      case 'remove':
        toast.info('Remove from exam feature coming soon');
        break;
    }
    setSelectedIds([]);
  };

  const handleAssignToExam = () => {
    setAssigningProctor(null);
    setAssignModalOpen(true);
  };

  const handleAssignExam = async (examIds: string[], role: string) => {
    const proctorIdsToAssign = assigningProctor ? [assigningProctor.id] : selectedIds;
    
    if (proctorIdsToAssign.length === 0) {
      toast.error('No proctors selected');
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    
    // Create assignments for each proctor and each exam
    const assignments = proctorIdsToAssign.flatMap(proctorId =>
      examIds.map(examId => ({
        proctor_id: proctorId,
        exam_id: examId,
        role: role,
        assigned_by: user?.id,
      }))
    );

    const { error } = await supabase
      .from('proctor_exam_assignments')
      .upsert(assignments, { onConflict: 'proctor_id,exam_id' });

    if (error) {
      console.error('Error assigning proctors:', error);
      toast.error('Failed to assign proctor(s) to exam(s)');
      throw error;
    }

    // Update local state - increment assigned exams count by number of exams
    setProctors((prev) =>
      prev.map((p) =>
        proctorIdsToAssign.includes(p.id)
          ? { ...p, assignedExamsCount: p.assignedExamsCount + examIds.length }
          : p
      )
    );

    toast.success(`Assigned ${proctorIdsToAssign.length} proctor(s) to ${examIds.length} exam(s)`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Proctors</h1>
          <p className="text-muted-foreground">Manage proctors and exam assignments ({proctors.length} total)</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleAssignToExam}>
            <ClipboardList className="h-4 w-4 mr-2" /> Assign to Exam
          </Button>
          <Button onClick={handleAddProctor}>
            <Plus className="h-4 w-4 mr-2" /> Add Proctor
          </Button>
        </div>
      </div>

      <ProctorFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        status={status}
        onStatusChange={setStatus}
        department={department}
        onDepartmentChange={setDepartment}
        assignedExam={assignedExam}
        onAssignedExamChange={setAssignedExam}
      />

      {selectedIds.length > 0 && (
        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
          <span className="text-sm font-medium">{selectedIds.length} selected</span>
          <div className="flex-1" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                Bulk Actions
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover">
              <DropdownMenuItem onClick={() => handleBulkAction('activate')}>
                <UserCheck className="h-4 w-4 mr-2" /> Activate Selected
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleBulkAction('deactivate')}>
                <UserX className="h-4 w-4 mr-2" /> Deactivate Selected
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleBulkAction('assign')}>
                <ClipboardList className="h-4 w-4 mr-2" /> Assign to Exam
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleBulkAction('remove')}>
                <UserMinus className="h-4 w-4 mr-2" /> Remove from Exam
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      <ProctorsTable
        proctors={filteredProctors}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
        onView={handleViewProctor}
        onEdit={handleEditProctor}
        onToggleStatus={handleToggleStatus}
      />

      <AddProctorModal
        open={addModalOpen}
        onOpenChange={setAddModalOpen}
        proctor={editingProctor}
        onSave={handleSaveProctor}
      />

      <ProctorProfileModal
        open={profileModalOpen}
        onOpenChange={setProfileModalOpen}
        proctor={viewingProctor}
        onToggleStatus={handleToggleStatus}
        onAssignExam={() => {
          setAssigningProctor(viewingProctor);
          setAssignModalOpen(true);
        }}
      />

      <AssignExamModal
        open={assignModalOpen}
        onOpenChange={setAssignModalOpen}
        proctorId={assigningProctor?.id}
        proctorName={assigningProctor?.name}
        proctorIds={!assigningProctor && selectedIds.length > 0 ? selectedIds : undefined}
        onAssign={handleAssignExam}
      />
    </div>
  );
}