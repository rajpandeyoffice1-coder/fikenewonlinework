import { useState, useEffect } from 'react';
import { Upload } from 'lucide-react';
import { Proctor, ProctorPermissions } from '@/types/proctor';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';

interface AddProctorModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  proctor?: Proctor | null;
  onSave: (proctor: Partial<Proctor>) => void;
}

const departments = ['Computer Science', 'Electrical Engineering', 'Mathematics', 'Physics', 'Chemistry', 'Mechanical Engineering'];

const defaultPermissions: ProctorPermissions = {
  viewCandidates: true,
  sendWarnings: true,
  muteCandidate: false,
  pauseExam: false,
  endExam: false,
  viewEvidenceReplay: false,
};

export function AddProctorModal({ open, onOpenChange, proctor, onSave }: AddProctorModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    proctorId: '',
    email: '',
    mobile: '',
    department: '',
    experience: 0,
    photoUrl: '',
    status: 'active' as 'active' | 'inactive',
    permissions: defaultPermissions,
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (proctor) {
      setFormData({
        name: proctor.name,
        proctorId: proctor.proctorId,
        email: proctor.email,
        mobile: proctor.mobile,
        department: proctor.department,
        experience: proctor.experience,
        photoUrl: proctor.photoUrl || '',
        status: proctor.status,
        permissions: proctor.permissions,
        password: '',
        confirmPassword: '',
      });
    } else {
      setFormData({
        name: '',
        proctorId: '',
        email: '',
        mobile: '',
        department: '',
        experience: 0,
        photoUrl: '',
        status: 'active',
        permissions: defaultPermissions,
        password: '',
        confirmPassword: '',
      });
    }
    setErrors({});
  }, [proctor, open]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.proctorId.trim()) newErrors.proctorId = 'Proctor ID is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Invalid email format';
    if (!formData.mobile.trim()) newErrors.mobile = 'Mobile is required';
    if (!formData.department) newErrors.department = 'Department is required';
    
    // Password validation only for new proctors
    if (!proctor) {
      if (!formData.password) newErrors.password = 'Password is required';
      else if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
      if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave(formData);
    toast.success(proctor ? 'Proctor updated successfully' : 'Proctor added successfully');
    onOpenChange(false);
  };

  const updatePermission = (key: keyof ProctorPermissions, value: boolean) => {
    setFormData({
      ...formData,
      permissions: { ...formData.permissions, [key]: value },
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const permissionLabels: { key: keyof ProctorPermissions; label: string }[] = [
    { key: 'viewCandidates', label: 'View Candidates' },
    { key: 'sendWarnings', label: 'Send Warnings' },
    { key: 'muteCandidate', label: 'Mute Candidate' },
    { key: 'pauseExam', label: 'Pause Exam' },
    { key: 'endExam', label: 'End Exam' },
    { key: 'viewEvidenceReplay', label: 'View Evidence Replay' },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{proctor ? 'Edit Proctor' : 'Add New Proctor'}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={formData.photoUrl} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {formData.name ? getInitials(formData.name) : 'PR'}
              </AvatarFallback>
            </Avatar>
            <div>
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" /> Upload Photo
              </Button>
              <p className="text-xs text-muted-foreground mt-1">JPG, PNG. Max 2MB.</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className={errors.name ? 'border-destructive' : ''}
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="proctorId">Proctor ID / Employee ID *</Label>
              <Input
                id="proctorId"
                value={formData.proctorId}
                onChange={(e) => setFormData({ ...formData, proctorId: e.target.value })}
                className={errors.proctorId ? 'border-destructive' : ''}
              />
              {errors.proctorId && <p className="text-xs text-destructive">{errors.proctorId}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={errors.email ? 'border-destructive' : ''}
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="mobile">Mobile Number *</Label>
              <Input
                id="mobile"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                className={errors.mobile ? 'border-destructive' : ''}
              />
              {errors.mobile && <p className="text-xs text-destructive">{errors.mobile}</p>}
            </div>

            <div className="space-y-2">
              <Label>Department *</Label>
              <Select value={formData.department} onValueChange={(v) => setFormData({ ...formData, department: v })}>
                <SelectTrigger className={errors.department ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.department && <p className="text-xs text-destructive">{errors.department}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="experience">Experience (Years)</Label>
              <Input
                id="experience"
                type="number"
                min="0"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: parseInt(e.target.value) || 0 })}
              />
            </div>

            {!proctor && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={errors.password ? 'border-destructive' : ''}
                    placeholder="Min 8 characters"
                  />
                  {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className={errors.confirmPassword ? 'border-destructive' : ''}
                  />
                  {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword}</p>}
                </div>
              </>
            )}
          </div>

          <div className="space-y-3">
            <Label>Permissions</Label>
            <div className="grid grid-cols-2 gap-3">
              {permissionLabels.map(({ key, label }) => (
                <div key={key} className="flex items-center gap-2">
                  <Checkbox
                    id={key}
                    checked={formData.permissions[key]}
                    onCheckedChange={(checked) => updatePermission(key, !!checked)}
                  />
                  <Label htmlFor={key} className="font-normal cursor-pointer">{label}</Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <div className="flex items-center gap-3 pt-1">
              <Switch
                checked={formData.status === 'active'}
                onCheckedChange={(checked) => setFormData({ ...formData, status: checked ? 'active' : 'inactive' })}
              />
              <span className="text-sm">{formData.status === 'active' ? 'Active' : 'Inactive'}</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit}>{proctor ? 'Update Proctor' : 'Add Proctor'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
