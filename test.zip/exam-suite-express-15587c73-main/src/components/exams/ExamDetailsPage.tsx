import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Calendar, Clock, Users, FileText, Settings, Pencil, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ExamData {
  id: string;
  title: string;
  code: string;
  department: string;
  course: string | null;
  description: string | null;
  duration: number;
  total_marks: number;
  passing_marks: number | null;
  start_date: string | null;
  end_date: string | null;
  status: string;
  settings: any;
  created_at: string;
}

interface Question {
  id: string;
  question_text: string;
  type: string;
  marks: number;
  difficulty: string;
}

interface Enrollment {
  id: string;
  student: {
    id: string;
    full_name: string;
    roll_no: string;
    email: string;
  };
  status: string;
}

export function ExamDetailsPage() {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState<ExamData | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchExamDetails = async () => {
      if (!examId) return;

      setIsLoading(true);

      // Fetch exam details
      const { data: examData, error: examError } = await supabase
        .from('exams')
        .select('*')
        .eq('id', examId)
        .maybeSingle();

      if (examError || !examData) {
        toast.error('Failed to load exam details');
        navigate('/exams');
        return;
      }

      setExam(examData);

      // Fetch exam questions
      const { data: questionsData } = await supabase
        .from('exam_questions')
        .select(`
          id,
          marks,
          question:questions(id, question_text, type, difficulty)
        `)
        .eq('exam_id', examId);

      if (questionsData) {
        setQuestions(questionsData.map((q: any) => ({
          id: q.question?.id || q.id,
          question_text: q.question?.question_text || '',
          type: q.question?.type || '',
          marks: q.marks || q.question?.marks || 0,
          difficulty: q.question?.difficulty || '',
        })));
      }

      // Fetch enrollments
      const { data: enrollmentData } = await supabase
        .from('exam_enrollments')
        .select(`
          id,
          status,
          student:students(id, full_name, roll_no, email)
        `)
        .eq('exam_id', examId);

      if (enrollmentData) {
        setEnrollments(enrollmentData.map((e: any) => ({
          id: e.id,
          student: e.student,
          status: e.status,
        })));
      }

      setIsLoading(false);
    };

    fetchExamDetails();
  }, [examId, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Exam not found</p>
        <Button variant="link" onClick={() => navigate('/exams')}>
          Back to Exams
        </Button>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    draft: "bg-muted text-muted-foreground",
    scheduled: "bg-primary/10 text-primary",
    live: "bg-green-100 text-green-800",
    completed: "bg-amber-100 text-amber-800",
    cancelled: "bg-red-100 text-red-800",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/exams')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{exam.title}</h1>
              <Badge className={statusColors[exam.status] || "bg-muted"}>
                {exam.status}
              </Badge>
            </div>
            <p className="text-muted-foreground">{exam.code} • {exam.department}</p>
          </div>
        </div>
        <Button onClick={() => navigate(`/exams/${examId}/edit`)}>
          <Pencil className="h-4 w-4 mr-2" />
          Edit Exam
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{exam.duration}</p>
                <p className="text-sm text-muted-foreground">Minutes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <FileText className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{questions.length}</p>
                <p className="text-sm text-muted-foreground">Questions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{enrollments.length}</p>
                <p className="text-sm text-muted-foreground">Enrolled</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <Settings className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{exam.total_marks}</p>
                <p className="text-sm text-muted-foreground">Total Marks</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="questions">Questions ({questions.length})</TabsTrigger>
          <TabsTrigger value="candidates">Candidates ({enrollments.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Exam Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Course</p>
                  <p className="font-medium">{exam.course || 'Not specified'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Department</p>
                  <p className="font-medium">{exam.department}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Start Date</p>
                  <p className="font-medium">
                    {exam.start_date ? new Date(exam.start_date).toLocaleString() : 'Not scheduled'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">End Date</p>
                  <p className="font-medium">
                    {exam.end_date ? new Date(exam.end_date).toLocaleString() : 'Not scheduled'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Passing Marks</p>
                  <p className="font-medium">{exam.passing_marks || 'Not set'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Created</p>
                  <p className="font-medium">{new Date(exam.created_at).toLocaleDateString()}</p>
                </div>
              </div>
              {exam.description && (
                <div>
                  <p className="text-sm text-muted-foreground">Description</p>
                  <p className="font-medium">{exam.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="questions">
          <Card>
            <CardHeader>
              <CardTitle>Exam Questions</CardTitle>
            </CardHeader>
            <CardContent>
              {questions.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No questions added yet</p>
              ) : (
                <div className="space-y-3">
                  {questions.map((q, index) => (
                    <div key={q.id} className="flex items-start gap-4 p-4 border rounded-lg">
                      <span className="font-bold text-primary">{index + 1}.</span>
                      <div className="flex-1">
                        <p className="font-medium">{q.question_text}</p>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="outline">{q.type}</Badge>
                          <Badge variant="outline">{q.difficulty}</Badge>
                          <Badge variant="outline">{q.marks} marks</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="candidates">
          <Card>
            <CardHeader>
              <CardTitle>Enrolled Candidates</CardTitle>
            </CardHeader>
            <CardContent>
              {enrollments.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No candidates enrolled yet</p>
              ) : (
                <div className="space-y-3">
                  {enrollments.map((e) => (
                    <div key={e.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">{e.student?.full_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {e.student?.roll_no} • {e.student?.email}
                        </p>
                      </div>
                      <Badge variant="outline">{e.status}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
