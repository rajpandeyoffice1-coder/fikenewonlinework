import {
  Settings,
  Users,
  Shield,
  Video,
  FileText,
  Bell,
  Plug,
  Database,
  ScrollText,
  HardDrive,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { SettingsSection } from '@/types/settings';

interface SettingsSidebarProps {
  activeSection: SettingsSection;
  onSectionChange: (section: SettingsSection) => void;
}

const menuItems: { id: SettingsSection; label: string; icon: React.ElementType }[] = [
  { id: 'general', label: 'General Settings', icon: Settings },
  { id: 'users', label: 'User & Role Management', icon: Users },
  { id: 'security', label: 'Security Settings', icon: Shield },
  { id: 'proctoring', label: 'Proctoring Settings', icon: Video },
  { id: 'exam-defaults', label: 'Exam Defaults', icon: FileText },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'integrations', label: 'Integrations', icon: Plug },
  { id: 'data-retention', label: 'Data Retention & Compliance', icon: Database },
  { id: 'system-logs', label: 'System Logs', icon: ScrollText },
  { id: 'backup', label: 'Backup & Restore', icon: HardDrive },
];

export function SettingsSidebar({ activeSection, onSectionChange }: SettingsSidebarProps) {
  return (
    <nav className="w-64 bg-card border-r border-border p-4 space-y-1 min-h-[calc(100vh-8rem)]">
      {menuItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeSection === item.id;

        return (
          <button
            key={item.id}
            onClick={() => onSectionChange(item.id)}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left',
              isActive
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="truncate">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
