import { useState } from 'react';
import { Plus, Trash2, Save, Shield } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export function SecuritySettings() {
  const [settings, setSettings] = useState({
    passwordPolicy: {
      minLength: 8,
      requireSpecialChars: true,
      requireNumbers: true,
      maxPasswordAge: 90,
    },
    twoFactorAuth: {
      enableForAdmins: true,
      enableForStudents: false,
    },
    accountLockout: {
      failedAttemptsLimit: 5,
      lockoutDuration: 30,
    },
    allowedIPs: ['192.168.1.0/24', '10.0.0.0/8'],
  });

  const [newIP, setNewIP] = useState('');

  const handleSave = () => {
    toast.success('Security settings saved successfully');
  };

  const addIP = () => {
    if (newIP.trim() && !settings.allowedIPs.includes(newIP.trim())) {
      setSettings({
        ...settings,
        allowedIPs: [...settings.allowedIPs, newIP.trim()],
      });
      setNewIP('');
    }
  };

  const removeIP = (ip: string) => {
    setSettings({
      ...settings,
      allowedIPs: settings.allowedIPs.filter((i) => i !== ip),
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Security Settings</h2>
        <p className="text-muted-foreground">Configure security policies and access controls</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Password Policy
          </CardTitle>
          <CardDescription>Set requirements for user passwords</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="minLength">Minimum Length</Label>
              <Input
                id="minLength"
                type="number"
                min={6}
                max={32}
                value={settings.passwordPolicy.minLength}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    passwordPolicy: {
                      ...settings.passwordPolicy,
                      minLength: parseInt(e.target.value),
                    },
                  })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxAge">Max Password Age (days)</Label>
              <Input
                id="maxAge"
                type="number"
                min={30}
                max={365}
                value={settings.passwordPolicy.maxPasswordAge}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    passwordPolicy: {
                      ...settings.passwordPolicy,
                      maxPasswordAge: parseInt(e.target.value),
                    },
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="specialChars">Require Special Characters</Label>
              <Switch
                id="specialChars"
                checked={settings.passwordPolicy.requireSpecialChars}
                onCheckedChange={(checked) =>
                  setSettings({
                    ...settings,
                    passwordPolicy: {
                      ...settings.passwordPolicy,
                      requireSpecialChars: checked,
                    },
                  })
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="requireNumbers">Require Numbers</Label>
              <Switch
                id="requireNumbers"
                checked={settings.passwordPolicy.requireNumbers}
                onCheckedChange={(checked) =>
                  setSettings({
                    ...settings,
                    passwordPolicy: {
                      ...settings.passwordPolicy,
                      requireNumbers: checked,
                    },
                  })
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Two-Factor Authentication</CardTitle>
          <CardDescription>Enable 2FA for additional security</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable 2FA for Admins</Label>
              <p className="text-xs text-muted-foreground">
                Require two-factor authentication for admin accounts
              </p>
            </div>
            <Switch
              checked={settings.twoFactorAuth.enableForAdmins}
              onCheckedChange={(checked) =>
                setSettings({
                  ...settings,
                  twoFactorAuth: { ...settings.twoFactorAuth, enableForAdmins: checked },
                })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Enable 2FA for Students</Label>
              <p className="text-xs text-muted-foreground">
                Require two-factor authentication for student accounts
              </p>
            </div>
            <Switch
              checked={settings.twoFactorAuth.enableForStudents}
              onCheckedChange={(checked) =>
                setSettings({
                  ...settings,
                  twoFactorAuth: { ...settings.twoFactorAuth, enableForStudents: checked },
                })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Account Lockout</CardTitle>
          <CardDescription>Configure automatic account lockout settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="failedAttempts">Failed Attempts Limit</Label>
              <Input
                id="failedAttempts"
                type="number"
                min={3}
                max={10}
                value={settings.accountLockout.failedAttemptsLimit}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    accountLockout: {
                      ...settings.accountLockout,
                      failedAttemptsLimit: parseInt(e.target.value),
                    },
                  })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lockoutDuration">Lockout Duration (minutes)</Label>
              <Input
                id="lockoutDuration"
                type="number"
                min={5}
                max={120}
                value={settings.accountLockout.lockoutDuration}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    accountLockout: {
                      ...settings.accountLockout,
                      lockoutDuration: parseInt(e.target.value),
                    },
                  })
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>IP Allowlist</CardTitle>
          <CardDescription>Restrict access to specific IP addresses or ranges</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter IP address or CIDR range"
              value={newIP}
              onChange={(e) => setNewIP(e.target.value)}
              className="flex-1"
            />
            <Button onClick={addIP}>
              <Plus className="h-4 w-4 mr-2" />
              Add
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            {settings.allowedIPs.map((ip) => (
              <Badge key={ip} variant="secondary" className="gap-1">
                {ip}
                <button onClick={() => removeIP(ip)} className="ml-1 hover:text-destructive">
                  <Trash2 className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Security Settings
        </Button>
      </div>
    </div>
  );
}
