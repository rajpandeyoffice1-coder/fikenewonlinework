import { useState } from 'react';
import { Edit, Trash2, Plus, Save } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Role, RolePermissions } from '@/types/settings';
import { toast } from 'sonner';

const initialRoles: Role[] = [
  {
    id: '1',
    name: 'Admin',
    permissions: {
      manageExams: true,
      manageQuestions: true,
      manageStudents: true,
      accessReports: true,
      proctorLiveSessions: true,
      evaluateAnswers: true,
      manageSystemSettings: true,
    },
    memberCount: 5,
  },
  {
    id: '2',
    name: 'Proctor',
    permissions: {
      manageExams: false,
      manageQuestions: false,
      manageStudents: false,
      accessReports: true,
      proctorLiveSessions: true,
      evaluateAnswers: false,
      manageSystemSettings: false,
    },
    memberCount: 12,
  },
  {
    id: '3',
    name: 'Evaluator',
    permissions: {
      manageExams: false,
      manageQuestions: true,
      manageStudents: false,
      accessReports: true,
      proctorLiveSessions: false,
      evaluateAnswers: true,
      manageSystemSettings: false,
    },
    memberCount: 8,
  },
  {
    id: '4',
    name: 'Student Manager',
    permissions: {
      manageExams: false,
      manageQuestions: false,
      manageStudents: true,
      accessReports: true,
      proctorLiveSessions: false,
      evaluateAnswers: false,
      manageSystemSettings: false,
    },
    memberCount: 3,
  },
];

const permissionLabels: Record<keyof RolePermissions, string> = {
  manageExams: 'Manage Exams',
  manageQuestions: 'Manage Questions',
  manageStudents: 'Manage Students',
  accessReports: 'Access Reports',
  proctorLiveSessions: 'Proctor Live Sessions',
  evaluateAnswers: 'Evaluate Answers',
  manageSystemSettings: 'Manage System Settings',
};

export function UserRoleSettings() {
  const [roles, setRoles] = useState<Role[]>(initialRoles);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [roleToDelete, setRoleToDelete] = useState<Role | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');

  const handleEditRole = (role: Role) => {
    setEditingRole({ ...role });
    setIsEditModalOpen(true);
  };

  const handleSaveRole = () => {
    if (editingRole) {
      setRoles(roles.map((r) => (r.id === editingRole.id ? editingRole : r)));
      toast.success('Role permissions updated');
      setIsEditModalOpen(false);
    }
  };

  const handleDeleteRole = () => {
    if (roleToDelete) {
      setRoles(roles.filter((r) => r.id !== roleToDelete.id));
      toast.success('Role deleted successfully');
      setIsDeleteDialogOpen(false);
      setRoleToDelete(null);
    }
  };

  const handleAddRole = () => {
    if (newRoleName.trim()) {
      const newRole: Role = {
        id: Date.now().toString(),
        name: newRoleName,
        permissions: {
          manageExams: false,
          manageQuestions: false,
          manageStudents: false,
          accessReports: false,
          proctorLiveSessions: false,
          evaluateAnswers: false,
          manageSystemSettings: false,
        },
        memberCount: 0,
      };
      setRoles([...roles, newRole]);
      toast.success('Role created successfully');
      setIsAddModalOpen(false);
      setNewRoleName('');
    }
  };

  const togglePermission = (key: keyof RolePermissions) => {
    if (editingRole) {
      setEditingRole({
        ...editingRole,
        permissions: {
          ...editingRole.permissions,
          [key]: !editingRole.permissions[key],
        },
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">User & Role Management</h2>
          <p className="text-muted-foreground">Manage user roles and permissions</p>
        </div>
        <Button onClick={() => setIsAddModalOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Role
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Roles</CardTitle>
          <CardDescription>Configure role-based access control</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Role Name</TableHead>
                <TableHead>Permissions</TableHead>
                <TableHead>Members</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {roles.map((role) => {
                const activePermissions = Object.entries(role.permissions)
                  .filter(([_, value]) => value)
                  .map(([key]) => key as keyof RolePermissions);

                return (
                  <TableRow key={role.id}>
                    <TableCell className="font-medium">{role.name}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {activePermissions.slice(0, 3).map((perm) => (
                          <Badge key={perm} variant="secondary" className="text-xs">
                            {permissionLabels[perm]}
                          </Badge>
                        ))}
                        {activePermissions.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{activePermissions.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{role.memberCount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditRole(role)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setRoleToDelete(role);
                            setIsDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Role Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Role: {editingRole?.name}</DialogTitle>
            <DialogDescription>
              Configure permissions for this role
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {editingRole &&
              Object.entries(permissionLabels).map(([key, label]) => (
                <div key={key} className="flex items-center justify-between">
                  <Label htmlFor={key}>{label}</Label>
                  <Switch
                    id={key}
                    checked={editingRole.permissions[key as keyof RolePermissions]}
                    onCheckedChange={() => togglePermission(key as keyof RolePermissions)}
                  />
                </div>
              ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveRole}>
              <Save className="h-4 w-4 mr-2" />
              Save Permissions
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Role Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Role</DialogTitle>
            <DialogDescription>Create a new role for your organization</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="roleName">Role Name</Label>
            <Input
              id="roleName"
              value={newRoleName}
              onChange={(e) => setNewRoleName(e.target.value)}
              placeholder="Enter role name"
              className="mt-2"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddRole}>Create Role</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Role</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the "{roleToDelete?.name}" role? This action
              cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteRole}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
