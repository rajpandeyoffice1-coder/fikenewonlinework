import { useState } from 'react';
import { Save, ExternalLink, CheckCircle, XCircle, KeyRound, Link2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface IntegrationCardProps {
  title: string;
  description: string;
  enabled: boolean;
  onToggle: (enabled: boolean) => void;
  children: React.ReactNode;
  status?: 'connected' | 'disconnected' | 'error';
}

function IntegrationCard({
  title,
  description,
  enabled,
  onToggle,
  children,
  status = 'disconnected',
}: IntegrationCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-base">{title}</CardTitle>
            <Badge
              variant={status === 'connected' ? 'default' : 'secondary'}
              className={
                status === 'connected'
                  ? 'bg-green-100 text-green-700'
                  : status === 'error'
                  ? 'bg-red-100 text-red-700'
                  : ''
              }
            >
              {status === 'connected' && <CheckCircle className="h-3 w-3 mr-1" />}
              {status === 'error' && <XCircle className="h-3 w-3 mr-1" />}
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </Badge>
          </div>
          <Switch checked={enabled} onCheckedChange={onToggle} />
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className={!enabled ? 'opacity-50 pointer-events-none' : ''}>
        {children}
      </CardContent>
    </Card>
  );
}

export function IntegrationsSettings() {
  const [integrations, setIntegrations] = useState({
    sso: {
      enabled: false,
      metadataUrl: '',
      callbackUrl: 'https://exam.university.edu/auth/callback',
    },
    lms: {
      enabled: true,
      apiKey: 'moodle_api_key_xxxxx',
      endpointUrl: 'https://moodle.university.edu/api',
    },
    payment: {
      enabled: false,
      merchantId: '',
      secretKey: '',
    },
    plagiarism: {
      enabled: false,
      apiKey: '',
    },
  });

  const handleSave = (section: string) => {
    toast.success(`${section} integration saved successfully`);
  };

  const handleTestConnection = (section: string) => {
    toast.success(`Testing ${section} connection...`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Integrations</h2>
        <p className="text-muted-foreground">Connect with external services and platforms</p>
      </div>

      <IntegrationCard
        title="SSO (SAML/OAuth)"
        description="Single Sign-On integration for enterprise authentication"
        enabled={integrations.sso.enabled}
        onToggle={(enabled) =>
          setIntegrations({ ...integrations, sso: { ...integrations.sso, enabled } })
        }
        status={integrations.sso.enabled && integrations.sso.metadataUrl ? 'connected' : 'disconnected'}
      >
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="metadataUrl">Metadata URL</Label>
            <Input
              id="metadataUrl"
              placeholder="https://idp.example.com/metadata"
              value={integrations.sso.metadataUrl}
              onChange={(e) =>
                setIntegrations({
                  ...integrations,
                  sso: { ...integrations.sso, metadataUrl: e.target.value },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label>Callback URL</Label>
            <div className="flex gap-2">
              <Input value={integrations.sso.callbackUrl} readOnly className="bg-muted" />
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  navigator.clipboard.writeText(integrations.sso.callbackUrl);
                  toast.success('Callback URL copied');
                }}
              >
                <Link2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleTestConnection('SSO')}>
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Connection
            </Button>
            <Button onClick={() => handleSave('SSO')}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
      </IntegrationCard>

      <IntegrationCard
        title="LMS Integration"
        description="Connect with Moodle or other Learning Management Systems"
        enabled={integrations.lms.enabled}
        onToggle={(enabled) =>
          setIntegrations({ ...integrations, lms: { ...integrations.lms, enabled } })
        }
        status={integrations.lms.enabled ? 'connected' : 'disconnected'}
      >
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="lmsApiKey">API Key</Label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="lmsApiKey"
                type="password"
                className="pl-10"
                value={integrations.lms.apiKey}
                onChange={(e) =>
                  setIntegrations({
                    ...integrations,
                    lms: { ...integrations.lms, apiKey: e.target.value },
                  })
                }
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="lmsEndpoint">Endpoint URL</Label>
            <Input
              id="lmsEndpoint"
              placeholder="https://moodle.example.com/api"
              value={integrations.lms.endpointUrl}
              onChange={(e) =>
                setIntegrations({
                  ...integrations,
                  lms: { ...integrations.lms, endpointUrl: e.target.value },
                })
              }
            />
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleTestConnection('LMS')}>
              <ExternalLink className="h-4 w-4 mr-2" />
              Test Connection
            </Button>
            <Button onClick={() => handleSave('LMS')}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
      </IntegrationCard>

      <IntegrationCard
        title="Payment Gateway"
        description="Accept payments for paid exams"
        enabled={integrations.payment.enabled}
        onToggle={(enabled) =>
          setIntegrations({ ...integrations, payment: { ...integrations.payment, enabled } })
        }
      >
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="merchantId">Merchant ID</Label>
            <Input
              id="merchantId"
              placeholder="Enter merchant ID"
              value={integrations.payment.merchantId}
              onChange={(e) =>
                setIntegrations({
                  ...integrations,
                  payment: { ...integrations.payment, merchantId: e.target.value },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="secretKey">Secret Key</Label>
            <Input
              id="secretKey"
              type="password"
              placeholder="Enter secret key"
              value={integrations.payment.secretKey}
              onChange={(e) =>
                setIntegrations({
                  ...integrations,
                  payment: { ...integrations.payment, secretKey: e.target.value },
                })
              }
            />
          </div>

          <Button onClick={() => handleSave('Payment')}>
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
        </div>
      </IntegrationCard>

      <IntegrationCard
        title="Plagiarism Detection"
        description="Integrate with plagiarism detection tools"
        enabled={integrations.plagiarism.enabled}
        onToggle={(enabled) =>
          setIntegrations({ ...integrations, plagiarism: { ...integrations.plagiarism, enabled } })
        }
      >
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="plagiarismApiKey">API Key</Label>
            <Input
              id="plagiarismApiKey"
              type="password"
              placeholder="Enter API key"
              value={integrations.plagiarism.apiKey}
              onChange={(e) =>
                setIntegrations({
                  ...integrations,
                  plagiarism: { ...integrations.plagiarism, apiKey: e.target.value },
                })
              }
            />
          </div>

          <Button onClick={() => handleSave('Plagiarism')}>
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
        </div>
      </IntegrationCard>
    </div>
  );
}
