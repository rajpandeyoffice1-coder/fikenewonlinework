import { useState } from 'react';
import { Save, Video, Mic, Monitor, Eye } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

export function ProctoringSettings() {
  const [settings, setSettings] = useState({
    enableProctoring: true,
    webcamRequired: true,
    microphoneRequired: true,
    screenShareRequired: false,
    tabSwitchDetection: true,
    audioLevelAlerts: true,
    faceVerification: true,
    liveProctoringAccess: true,
    faceMismatchThreshold: 80,
    multipleFaceSensitivity: 70,
  });

  const handleSave = () => {
    toast.success('Proctoring settings saved successfully');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Proctoring Settings</h2>
        <p className="text-muted-foreground">Configure exam proctoring requirements</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Global Proctoring
          </CardTitle>
          <CardDescription>Enable or disable proctoring for all exams</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Proctoring (Global)</Label>
              <p className="text-xs text-muted-foreground">
                Master switch for all proctoring features
              </p>
            </div>
            <Switch
              checked={settings.enableProctoring}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, enableProctoring: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Device Requirements</CardTitle>
          <CardDescription>Configure required devices for proctored exams</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Video className="h-5 w-5 text-muted-foreground" />
              <div>
                <Label>Webcam Required</Label>
                <p className="text-xs text-muted-foreground">
                  Students must have an active webcam
                </p>
              </div>
            </div>
            <Switch
              checked={settings.webcamRequired}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, webcamRequired: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Mic className="h-5 w-5 text-muted-foreground" />
              <div>
                <Label>Microphone Required</Label>
                <p className="text-xs text-muted-foreground">
                  Students must have an active microphone
                </p>
              </div>
            </div>
            <Switch
              checked={settings.microphoneRequired}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, microphoneRequired: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Monitor className="h-5 w-5 text-muted-foreground" />
              <div>
                <Label>Screen Share Required</Label>
                <p className="text-xs text-muted-foreground">
                  Students must share their screen
                </p>
              </div>
            </div>
            <Switch
              checked={settings.screenShareRequired}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, screenShareRequired: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detection Features</CardTitle>
          <CardDescription>Configure automated detection and alerts</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Tab Switch Detection</Label>
              <p className="text-xs text-muted-foreground">
                Detect when students switch browser tabs
              </p>
            </div>
            <Switch
              checked={settings.tabSwitchDetection}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, tabSwitchDetection: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Audio Level Alerts</Label>
              <p className="text-xs text-muted-foreground">
                Alert when unusual audio is detected
              </p>
            </div>
            <Switch
              checked={settings.audioLevelAlerts}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, audioLevelAlerts: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Face Verification at Start</Label>
              <p className="text-xs text-muted-foreground">
                Verify student identity before exam starts
              </p>
            </div>
            <Switch
              checked={settings.faceVerification}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, faceVerification: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Live Proctoring Dashboard Access</Label>
              <p className="text-xs text-muted-foreground">
                Allow proctors to view live sessions
              </p>
            </div>
            <Switch
              checked={settings.liveProctoringAccess}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, liveProctoringAccess: checked })
              }
              disabled={!settings.enableProctoring}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detection Thresholds</CardTitle>
          <CardDescription>Adjust sensitivity for face detection algorithms</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Face Mismatch Threshold</Label>
              <span className="text-sm font-medium">{settings.faceMismatchThreshold}%</span>
            </div>
            <Slider
              value={[settings.faceMismatchThreshold]}
              onValueChange={([value]) =>
                setSettings({ ...settings, faceMismatchThreshold: value })
              }
              min={50}
              max={100}
              step={5}
              disabled={!settings.enableProctoring}
            />
            <p className="text-xs text-muted-foreground">
              Lower values increase sensitivity (more false positives)
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Multiple Face Detection Sensitivity</Label>
              <span className="text-sm font-medium">{settings.multipleFaceSensitivity}%</span>
            </div>
            <Slider
              value={[settings.multipleFaceSensitivity]}
              onValueChange={([value]) =>
                setSettings({ ...settings, multipleFaceSensitivity: value })
              }
              min={50}
              max={100}
              step={5}
              disabled={!settings.enableProctoring}
            />
            <p className="text-xs text-muted-foreground">
              Higher values increase detection accuracy
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Proctoring Settings
        </Button>
      </div>
    </div>
  );
}
