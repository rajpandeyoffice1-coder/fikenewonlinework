import { useState } from 'react';
import { Save, Shield, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';

export function DataRetentionSettings() {
  const [settings, setSettings] = useState({
    enableRetentionPolicy: true,
    deleteVideosAfterDays: 90,
    deleteLogsAfterDays: 365,
    deleteAttemptsAfterYears: 5,
    allowDataDownloadRequest: true,
    allowDataDeleteRequest: true,
  });

  const handleSave = () => {
    toast.success('Data retention settings saved successfully');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Data Retention & Compliance</h2>
        <p className="text-muted-foreground">Configure data retention policies and GDPR compliance</p>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Changes to data retention policies may affect historical data. Please review carefully
          before saving.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Data Retention Policy</CardTitle>
          <CardDescription>Configure automatic data cleanup settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Data Retention Policy</Label>
              <p className="text-xs text-muted-foreground">
                Automatically delete data after specified periods
              </p>
            </div>
            <Switch
              checked={settings.enableRetentionPolicy}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, enableRetentionPolicy: checked })
              }
            />
          </div>

          <div className={!settings.enableRetentionPolicy ? 'opacity-50 pointer-events-none' : ''}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="deleteVideos">Delete Proctoring Videos After (days)</Label>
                <Input
                  id="deleteVideos"
                  type="number"
                  min={30}
                  max={365}
                  value={settings.deleteVideosAfterDays}
                  onChange={(e) =>
                    setSettings({ ...settings, deleteVideosAfterDays: parseInt(e.target.value) })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deleteLogs">Delete Question Logs After (days)</Label>
                <Input
                  id="deleteLogs"
                  type="number"
                  min={90}
                  max={730}
                  value={settings.deleteLogsAfterDays}
                  onChange={(e) =>
                    setSettings({ ...settings, deleteLogsAfterDays: parseInt(e.target.value) })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deleteAttempts">Delete Student Attempts After (years)</Label>
                <Input
                  id="deleteAttempts"
                  type="number"
                  min={1}
                  max={10}
                  value={settings.deleteAttemptsAfterYears}
                  onChange={(e) =>
                    setSettings({ ...settings, deleteAttemptsAfterYears: parseInt(e.target.value) })
                  }
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            GDPR Compliance
          </CardTitle>
          <CardDescription>Configure user data rights settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Allow Data Download Request</Label>
              <p className="text-xs text-muted-foreground">
                Users can request a copy of their personal data
              </p>
            </div>
            <Switch
              checked={settings.allowDataDownloadRequest}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, allowDataDownloadRequest: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Allow Data Delete Request</Label>
              <p className="text-xs text-muted-foreground">
                Users can request deletion of their personal data
              </p>
            </div>
            <Switch
              checked={settings.allowDataDeleteRequest}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, allowDataDeleteRequest: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Policy
        </Button>
      </div>
    </div>
  );
}
