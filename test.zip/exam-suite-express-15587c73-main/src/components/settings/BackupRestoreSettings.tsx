import { useState } from 'react';
import { HardDrive, Upload, Download, Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface BackupEntry {
  id: string;
  timestamp: string;
  size: string;
  type: 'manual' | 'scheduled';
  status: 'completed' | 'failed';
}

const mockBackups: BackupEntry[] = [
  { id: '1', timestamp: '2024-01-15T02:00:00Z', size: '2.3 GB', type: 'scheduled', status: 'completed' },
  { id: '2', timestamp: '2024-01-14T02:00:00Z', size: '2.2 GB', type: 'scheduled', status: 'completed' },
  { id: '3', timestamp: '2024-01-13T14:30:00Z', size: '2.1 GB', type: 'manual', status: 'completed' },
  { id: '4', timestamp: '2024-01-13T02:00:00Z', size: '2.1 GB', type: 'scheduled', status: 'failed' },
  { id: '5', timestamp: '2024-01-12T02:00:00Z', size: '2.0 GB', type: 'scheduled', status: 'completed' },
];

export function BackupRestoreSettings() {
  const [backups] = useState<BackupEntry[]>(mockBackups);
  const [backupSchedule, setBackupSchedule] = useState('daily');
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);

  const handleManualBackup = () => {
    setIsCreatingBackup(true);
    setTimeout(() => {
      setIsCreatingBackup(false);
      toast.success('Backup created successfully');
    }, 2000);
  };

  const handleRestore = (backupId: string) => {
    toast.success('Restore initiated. This may take several minutes.');
  };

  const handleDownload = (backupId: string) => {
    toast.success('Download started');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Backup & Restore</h2>
        <p className="text-muted-foreground">Manage database backups and restore points</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HardDrive className="h-5 w-5" />
              Manual Backup
            </CardTitle>
            <CardDescription>Create a backup of the current database state</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={handleManualBackup} disabled={isCreatingBackup} className="w-full">
              {isCreatingBackup ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Creating Backup...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Create Backup Now
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Scheduled Backup
            </CardTitle>
            <CardDescription>Configure automatic backup schedule</CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={backupSchedule} onValueChange={setBackupSchedule}>
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-background border">
                <SelectItem value="daily">Daily (2:00 AM)</SelectItem>
                <SelectItem value="weekly">Weekly (Sunday 2:00 AM)</SelectItem>
                <SelectItem value="monthly">Monthly (1st day 2:00 AM)</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Restore from Backup
          </CardTitle>
          <CardDescription>Upload a backup file to restore the database</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Restoring from a backup will overwrite all current data. This action cannot be undone.
            </AlertDescription>
          </Alert>

          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
            <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-2">
              Drag and drop a backup file here, or click to browse
            </p>
            <Button variant="outline" size="sm">
              Browse Files
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Backup History</CardTitle>
          <CardDescription>View and manage previous backups</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[150px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {backups.map((backup) => (
                <TableRow key={backup.id}>
                  <TableCell className="font-mono text-sm">
                    {format(new Date(backup.timestamp), 'MMM dd, yyyy HH:mm')}
                  </TableCell>
                  <TableCell>{backup.size}</TableCell>
                  <TableCell>
                    <Badge variant="secondary">
                      {backup.type === 'scheduled' ? 'Scheduled' : 'Manual'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={backup.status === 'completed' ? 'default' : 'destructive'}
                      className={
                        backup.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }
                    >
                      {backup.status === 'completed' ? (
                        <CheckCircle className="h-3 w-3 mr-1" />
                      ) : (
                        <XCircle className="h-3 w-3 mr-1" />
                      )}
                      {backup.status.charAt(0).toUpperCase() + backup.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownload(backup.id)}
                        disabled={backup.status === 'failed'}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={backup.status === 'failed'}
                          >
                            Restore
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Restore from Backup</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to restore from this backup? This will overwrite
                              all current data and cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleRestore(backup.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Restore
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
