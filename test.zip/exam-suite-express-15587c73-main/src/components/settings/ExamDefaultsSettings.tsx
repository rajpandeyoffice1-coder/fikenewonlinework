import { useState } from 'react';
import { Save } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

export function ExamDefaultsSettings() {
  const [settings, setSettings] = useState({
    defaultDuration: 120,
    defaultPassingMarks: 40,
    questionShuffle: true,
    negativeMarking: false,
    negativeMarkingValue: 0.25,
    browserLockdown: true,
  });

  const handleSave = () => {
    toast.success('Exam defaults saved successfully');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Exam Defaults</h2>
        <p className="text-muted-foreground">Set default values for new exams</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Duration & Scoring</CardTitle>
          <CardDescription>Default time and marking settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="duration">Default Exam Duration (minutes)</Label>
              <Input
                id="duration"
                type="number"
                min={15}
                max={480}
                value={settings.defaultDuration}
                onChange={(e) =>
                  setSettings({ ...settings, defaultDuration: parseInt(e.target.value) })
                }
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="passingMarks">Default Passing Marks (%)</Label>
              <Input
                id="passingMarks"
                type="number"
                min={0}
                max={100}
                value={settings.defaultPassingMarks}
                onChange={(e) =>
                  setSettings({ ...settings, defaultPassingMarks: parseInt(e.target.value) })
                }
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Question Settings</CardTitle>
          <CardDescription>Default question display options</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Question Shuffle</Label>
              <p className="text-xs text-muted-foreground">
                Randomize question order for each student
              </p>
            </div>
            <Switch
              checked={settings.questionShuffle}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, questionShuffle: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Negative Marking</CardTitle>
          <CardDescription>Configure default negative marking settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Negative Marking</Label>
              <p className="text-xs text-muted-foreground">
                Deduct marks for incorrect answers
              </p>
            </div>
            <Switch
              checked={settings.negativeMarking}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, negativeMarking: checked })
              }
            />
          </div>

          {settings.negativeMarking && (
            <div className="space-y-2">
              <Label htmlFor="negativeValue">Negative Marking Value (per wrong answer)</Label>
              <Input
                id="negativeValue"
                type="number"
                min={0}
                max={1}
                step={0.05}
                value={settings.negativeMarkingValue}
                onChange={(e) =>
                  setSettings({ ...settings, negativeMarkingValue: parseFloat(e.target.value) })
                }
              />
              <p className="text-xs text-muted-foreground">
                Enter as a fraction of the correct answer marks (e.g., 0.25 = 25%)
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Browser Settings</CardTitle>
          <CardDescription>Default browser security settings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label>Browser Lockdown Mode</Label>
              <p className="text-xs text-muted-foreground">
                Prevent students from navigating away during exams
              </p>
            </div>
            <Switch
              checked={settings.browserLockdown}
              onCheckedChange={(checked) =>
                setSettings({ ...settings, browserLockdown: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="h-4 w-4 mr-2" />
          Save Defaults
        </Button>
      </div>
    </div>
  );
}
