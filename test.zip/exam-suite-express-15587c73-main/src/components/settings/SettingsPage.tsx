import { useState } from 'react';
import { SettingsSidebar } from './SettingsSidebar';
import { GeneralSettings } from './GeneralSettings';
import { UserRoleSettings } from './UserRoleSettings';
import { SecuritySettings } from './SecuritySettings';
import { ProctoringSettings } from './ProctoringSettings';
import { ExamDefaultsSettings } from './ExamDefaultsSettings';
import { NotificationsSettings } from './NotificationsSettings';
import { IntegrationsSettings } from './IntegrationsSettings';
import { DataRetentionSettings } from './DataRetentionSettings';
import { SystemLogsSettings } from './SystemLogsSettings';
import { BackupRestoreSettings } from './BackupRestoreSettings';
import { SettingsSection } from '@/types/settings';

export function SettingsPage() {
  const [activeSection, setActiveSection] = useState<SettingsSection>('general');

  const renderContent = () => {
    switch (activeSection) {
      case 'general':
        return <GeneralSettings />;
      case 'users':
        return <UserRoleSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'proctoring':
        return <ProctoringSettings />;
      case 'exam-defaults':
        return <ExamDefaultsSettings />;
      case 'notifications':
        return <NotificationsSettings />;
      case 'integrations':
        return <IntegrationsSettings />;
      case 'data-retention':
        return <DataRetentionSettings />;
      case 'system-logs':
        return <SystemLogsSettings />;
      case 'backup':
        return <BackupRestoreSettings />;
      default:
        return <GeneralSettings />;
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-4rem)]">
      <SettingsSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <div className="flex-1 p-6 overflow-auto">
        {renderContent()}
      </div>
    </div>
  );
}
