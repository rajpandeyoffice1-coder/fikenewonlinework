import { useEffect, useState } from "react";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Subject, SubjectFormData } from "@/types/subject";
import { Loader2 } from "lucide-react";

const subjectSchema = z.object({
  name: z.string().min(3, "Subject name must be at least 3 characters"),
  code: z.string().regex(/^[A-Za-z0-9]+$/, "Subject code must be alphanumeric only"),
  department: z.string().min(1, "Department is required"),
  semester: z.number().min(1).max(12, "Semester must be between 1 and 12"),
  status: z.enum(["active", "inactive"]),
});

interface SubjectModalProps {
  open: boolean;
  onClose: () => void;
  subject: Subject | null;
  onSave: (data: SubjectFormData) => Promise<void>;
  departments: string[];
}

export function SubjectModal({
  open,
  onClose,
  subject,
  onSave,
  departments,
}: SubjectModalProps) {
  const [formData, setFormData] = useState<SubjectFormData>({
    name: "",
    code: "",
    department: "",
    semester: 1,
    status: "active",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when modal opens/closes or subject changes
  useEffect(() => {
    if (subject) {
      setFormData({
        name: subject.name,
        code: subject.code,
        department: subject.department,
        semester: subject.semester,
        status: subject.status,
      });
    } else {
      setFormData({
        name: "",
        code: "",
        department: "",
        semester: 1,
        status: "active",
      });
    }
    setErrors({});
  }, [subject, open]);

  const handleSubmit = async () => {
    const result = subjectSchema.safeParse(formData);

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) {
          fieldErrors[err.path[0] as string] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setIsSubmitting(true);
    await onSave(formData);
    setIsSubmitting(false);
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {subject ? "Edit Subject" : "Add New Subject"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Subject Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Subject Name *</Label>
            <Input
              id="name"
              placeholder="e.g., Data Structures"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name}</p>
            )}
          </div>

          {/* Subject Code */}
          <div className="space-y-2">
            <Label htmlFor="code">Subject Code *</Label>
            <Input
              id="code"
              placeholder="e.g., CS201"
              value={formData.code}
              onChange={(e) =>
                setFormData({ ...formData, code: e.target.value.toUpperCase() })
              }
            />
            {errors.code && (
              <p className="text-sm text-destructive">{errors.code}</p>
            )}
          </div>

          {/* Department */}
          <div className="space-y-2">
            <Label>Department *</Label>
            <Select
              value={formData.department}
              onValueChange={(value) =>
                setFormData({ ...formData, department: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Department" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.department && (
              <p className="text-sm text-destructive">{errors.department}</p>
            )}
          </div>

          {/* Semester */}
          <div className="space-y-2">
            <Label>Semester *</Label>
            <Select
              value={String(formData.semester)}
              onValueChange={(value) =>
                setFormData({ ...formData, semester: parseInt(value) })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Semester" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 12 }, (_, i) => i + 1).map((sem) => (
                  <SelectItem key={sem} value={String(sem)}>
                    Semester {sem}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.semester && (
              <p className="text-sm text-destructive">{errors.semester}</p>
            )}
          </div>

          {/* Status */}
          <div className="flex items-center justify-between">
            <Label htmlFor="status">Active Status</Label>
            <Switch
              id="status"
              checked={formData.status === "active"}
              onCheckedChange={(checked) =>
                setFormData({
                  ...formData,
                  status: checked ? "active" : "inactive",
                })
              }
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {subject ? "Update Subject" : "Save Subject"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
