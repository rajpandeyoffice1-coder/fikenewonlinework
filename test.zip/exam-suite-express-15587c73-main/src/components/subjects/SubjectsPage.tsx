import { useState, useEffect, useMemo } from "react";
import { Plus, Search, BookOpen, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Subject, SubjectFormData } from "@/types/subject";
import { SubjectsTable } from "./SubjectsTable";
import { SubjectModal } from "./SubjectModal";
import { DeleteSubjectDialog } from "./DeleteSubjectDialog";

const departments = ["CSE", "ECE", "EE", "ME", "CE", "BBA", "MBA", "IT", "CIVIL", "OTHER"];

export function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [deletingSubject, setDeletingSubject] = useState<Subject | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Fetch subjects from database
  useEffect(() => {
    fetchSubjects();
  }, []);

  const fetchSubjects = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("subjects")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching subjects:", error);
      toast({ title: "Error", description: "Failed to load subjects", variant: "destructive" });
    } else {
      setSubjects((data || []) as Subject[]);
    }
    setIsLoading(false);
  };

  // Filter subjects
  const filteredSubjects = useMemo(() => {
    return subjects.filter((subject) => {
      const matchesSearch =
        searchQuery === "" ||
        subject.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        subject.code.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDepartment =
        departmentFilter === "all" || subject.department === departmentFilter;
      return matchesSearch && matchesDepartment;
    });
  }, [subjects, searchQuery, departmentFilter]);

  // Paginated subjects
  const paginatedSubjects = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredSubjects.slice(start, start + itemsPerPage);
  }, [filteredSubjects, currentPage]);

  const totalPages = Math.ceil(filteredSubjects.length / itemsPerPage);

  // Create subject
  const handleCreate = async (formData: SubjectFormData) => {
    const { data, error } = await supabase
      .from("subjects")
      .insert([formData])
      .select()
      .single();

    if (error) {
      console.error("Error creating subject:", error);
      if (error.code === "23505") {
        toast({ title: "Error", description: "Subject code already exists", variant: "destructive" });
      } else {
        toast({ title: "Error", description: "Failed to create subject", variant: "destructive" });
      }
      return false;
    }

    setSubjects([data as Subject, ...subjects]);
    toast({ title: "Success", description: "Subject created successfully" });
    return true;
  };

  // Update subject
  const handleUpdate = async (id: string, formData: SubjectFormData) => {
    const { data, error } = await supabase
      .from("subjects")
      .update(formData)
      .eq("id", id)
      .select()
      .single();

    if (error) {
      console.error("Error updating subject:", error);
      if (error.code === "23505") {
        toast({ title: "Error", description: "Subject code already exists", variant: "destructive" });
      } else {
        toast({ title: "Error", description: "Failed to update subject", variant: "destructive" });
      }
      return false;
    }

    setSubjects(subjects.map((s) => (s.id === id ? (data as Subject) : s)));
    toast({ title: "Success", description: "Subject updated successfully" });
    return true;
  };

  // Delete subject
  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("subjects").delete().eq("id", id);

    if (error) {
      console.error("Error deleting subject:", error);
      toast({ title: "Error", description: "Failed to delete subject", variant: "destructive" });
      return;
    }

    setSubjects(subjects.filter((s) => s.id !== id));
    setDeletingSubject(null);
    toast({ title: "Success", description: "Subject deleted successfully" });
  };

  // Handle save (create or update)
  const handleSave = async (formData: SubjectFormData) => {
    let success: boolean;
    if (editingSubject) {
      success = await handleUpdate(editingSubject.id, formData);
    } else {
      success = await handleCreate(formData);
    }

    if (success) {
      setIsModalOpen(false);
      setEditingSubject(null);
    }
  };

  const openEditModal = (subject: Subject) => {
    setEditingSubject(subject);
    setIsModalOpen(true);
  };

  const openAddModal = () => {
    setEditingSubject(null);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <BookOpen className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Subject Management</h1>
            <p className="text-muted-foreground text-sm">
              Add, edit and manage all subjects for different departments.
            </p>
          </div>
        </div>
        <Button onClick={openAddModal}>
          <Plus className="h-4 w-4 mr-2" />
          Add Subject
        </Button>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by Subject Name or Code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {departments.map((dept) => (
                <SelectItem key={dept} value={dept}>
                  {dept}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Table */}
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredSubjects.length === 0 ? (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="font-medium text-lg">No subjects found</p>
            <p className="text-sm mt-1">
              {searchQuery || departmentFilter !== "all"
                ? "Try adjusting your filters"
                : "Add your first subject to get started"}
            </p>
            {!searchQuery && departmentFilter === "all" && (
              <Button className="mt-4" onClick={openAddModal}>
                <Plus className="h-4 w-4 mr-2" />
                Add Subject
              </Button>
            )}
          </div>
        </Card>
      ) : (
        <>
          <SubjectsTable
            subjects={paginatedSubjects}
            onEdit={openEditModal}
            onDelete={setDeletingSubject}
          />

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                {Math.min(currentPage * itemsPerPage, filteredSubjects.length)} of{" "}
                {filteredSubjects.length} subjects
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Modals */}
      <SubjectModal
        open={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSubject(null);
        }}
        subject={editingSubject}
        onSave={handleSave}
        departments={departments}
      />

      <DeleteSubjectDialog
        open={!!deletingSubject}
        onClose={() => setDeletingSubject(null)}
        onConfirm={() => deletingSubject && handleDelete(deletingSubject.id)}
        subjectName={deletingSubject?.name || ""}
      />
    </div>
  );
}
