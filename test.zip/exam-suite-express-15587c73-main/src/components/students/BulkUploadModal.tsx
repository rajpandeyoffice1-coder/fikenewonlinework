import { useState } from 'react';
import { Upload, FileSpreadsheet, CheckCircle, AlertCircle, Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { bulkUploadStudents, generateFailedRowsCsv, downloadCsv } from '@/services/studentService';

interface BulkUploadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (students: any[]) => void;
}

type UploadStep = 'upload' | 'preview' | 'importing' | 'complete';

interface ParsedRow {
  full_name: string;
  roll_no: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: string;
  password?: string;
  status: 'valid' | 'error';
  error?: string;
}

// Valid departments
const VALID_DEPARTMENTS = ['CSE', 'ECE', 'EE', 'ME', 'CE', 'BBA', 'MBA', 'IT', 'CIVIL', 'OTHER'];

// Parse CSV row handling quoted values
const parseCSVRow = (row: string): string[] => {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
};

// Validate a single row
const validateRow = (row: ParsedRow): { isValid: boolean; error?: string } => {
  if (!row.full_name || row.full_name.length < 3) {
    return { isValid: false, error: 'Name must be at least 3 characters' };
  }
  if (!row.roll_no || row.roll_no.length < 4) {
    return { isValid: false, error: 'Roll number must be at least 4 characters' };
  }
  if (!row.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.email)) {
    return { isValid: false, error: 'Invalid email format' };
  }
  if (!row.mobile || !/^[6-9][0-9]{9}$/.test(row.mobile.replace(/[\s\-\(\)\+]/g, ''))) {
    return { isValid: false, error: 'Invalid mobile (10-digit starting with 6-9)' };
  }
  if (!row.department || !VALID_DEPARTMENTS.includes(row.department.toUpperCase())) {
    return { isValid: false, error: `Invalid department. Use: ${VALID_DEPARTMENTS.join(', ')}` };
  }
  if (!row.course || row.course.length < 2) {
    return { isValid: false, error: 'Course is required' };
  }
  const sem = parseInt(row.semester);
  if (isNaN(sem) || sem < 1 || sem > 12) {
    return { isValid: false, error: 'Semester must be 1-12' };
  }
  return { isValid: true };
};

export function BulkUploadModal({ open, onOpenChange, onImport }: BulkUploadModalProps) {
  const [step, setStep] = useState<UploadStep>('upload');
  const [parsedData, setParsedData] = useState<ParsedRow[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importResult, setImportResult] = useState<{ success: number; failed: number; failedRows: any[]; authAccountsCreated: number }>({ success: 0, failed: 0, failedRows: [], authAccountsCreated: 0 });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setUploadProgress(0);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').map(line => line.trim()).filter(line => line);
        
        if (lines.length < 2) {
          toast.error('CSV file must have a header row and at least one data row');
          setIsProcessing(false);
          return;
        }

        // Parse header
        const headers = parseCSVRow(lines[0]).map(h => 
          h.toLowerCase()
            .replace(/[^a-z0-9_]/g, '_')
            .replace(/_+/g, '_')
            .replace(/^_|_$/g, '')
        );
        
        console.log('CSV Headers:', headers);

        // Create column mapping
        const columnMap: Record<string, number> = {};
        const fieldMappings: Record<string, string[]> = {
          full_name: ['full_name', 'name', 'student_name', 'fullname'],
          roll_no: ['roll_no', 'roll_number', 'rollno', 'rollnumber', 'roll'],
          email: ['email', 'email_address', 'emailaddress', 'mail'],
          mobile: ['mobile', 'phone', 'mobile_number', 'phone_number', 'contact'],
          department: ['department', 'dept', 'branch'],
          course: ['course', 'program', 'degree'],
          semester: ['semester', 'sem'],
          password: ['password', 'pass', 'pwd'],
        };

        // Map headers to fields
        headers.forEach((header, idx) => {
          for (const [field, aliases] of Object.entries(fieldMappings)) {
            if (aliases.includes(header) && columnMap[field] === undefined) {
              columnMap[field] = idx;
            }
          }
        });

        console.log('Column mapping:', columnMap);

        // Parse data rows
        const parsed: ParsedRow[] = [];
        const seenRollNos = new Set<string>();
        const seenEmails = new Set<string>();

        for (let i = 1; i < lines.length; i++) {
          setUploadProgress(Math.round((i / lines.length) * 100));
          
          const values = parseCSVRow(lines[i]);
          if (values.length === 0 || (values.length === 1 && !values[0])) continue;

          const row: ParsedRow = {
            full_name: values[columnMap.full_name] || '',
            roll_no: values[columnMap.roll_no] || '',
            email: (values[columnMap.email] || '').toLowerCase(),
            mobile: values[columnMap.mobile] || '',
            department: (values[columnMap.department] || '').toUpperCase(),
            course: values[columnMap.course] || '',
            semester: values[columnMap.semester] || '',
            password: columnMap.password !== undefined ? values[columnMap.password] : undefined,
            status: 'valid',
          };

          // Validate row
          const validation = validateRow(row);
          if (!validation.isValid) {
            row.status = 'error';
            row.error = validation.error;
          } else {
            // Check for duplicates
            const rollLower = row.roll_no.toLowerCase();
            const emailLower = row.email.toLowerCase();
            
            if (seenRollNos.has(rollLower)) {
              row.status = 'error';
              row.error = 'Duplicate roll number in file';
            } else if (seenEmails.has(emailLower)) {
              row.status = 'error';
              row.error = 'Duplicate email in file';
            } else {
              seenRollNos.add(rollLower);
              seenEmails.add(emailLower);
            }
          }

          parsed.push(row);
        }

        setParsedData(parsed);
        setStep('preview');
        setUploadProgress(100);
      } catch (error) {
        console.error('Error parsing CSV:', error);
        toast.error('Failed to parse CSV file. Please check the format.');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.onerror = () => {
      toast.error('Failed to read file');
      setIsProcessing(false);
    };

    reader.readAsText(file);
    e.target.value = '';
  };

  const handleImport = async () => {
    const validRows = parsedData.filter((row) => row.status === 'valid');
    
    if (validRows.length === 0) {
      toast.error('No valid rows to import');
      return;
    }

    setStep('importing');
    setIsProcessing(true);

    try {
      // Format data for API with proper typing
      type DepartmentType = 'CSE' | 'ECE' | 'EE' | 'ME' | 'CE' | 'BBA' | 'MBA' | 'IT' | 'CIVIL' | 'OTHER';
      
      const studentsToUpload = validRows.map(row => ({
        full_name: row.full_name,
        roll_no: row.roll_no,
        email: row.email,
        mobile: row.mobile,
        department: row.department as DepartmentType,
        course: row.course,
        semester: parseInt(row.semester),
        status: 'active' as const,
        ...(row.password && { password: row.password }),
      }));

      const response = await bulkUploadStudents(studentsToUpload);
      
      console.log('Bulk upload response:', response);

      if (response.status === 'success') {
        const authCount = response.auth_accounts_created || 0;
        setImportResult({
          success: response.success_count || 0,
          failed: response.failed_count || 0,
          failedRows: response.failed_rows || [],
          authAccountsCreated: authCount,
        });
        
        if (response.success_rows && response.success_rows.length > 0) {
          onImport(response.success_rows);
        }
        
        toast.success(`Imported ${response.success_count} students with ${authCount} login accounts created`);
        setStep('complete');
      } else {
        toast.error(response.message || 'Failed to import students');
        setStep('preview');
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import students. Please try again.');
      setStep('preview');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadSampleCSV = () => {
    const sampleCSV = `full_name,roll_no,email,mobile,department,course,semester,password
"John Doe",CS2024001,john.doe@university.edu,9876543210,CSE,B.Tech,4,MyPass123
"Jane Smith",CS2024002,jane.smith@university.edu,9876543211,CSE,B.Tech,4,SecureP@ss
"Bob Wilson",EE2024001,bob.wilson@university.edu,9876543212,EE,B.Tech,3,
"Alice Brown",ME2024001,alice.brown@university.edu,9876543213,ME,B.Tech,2,Custom456`;

    const blob = new Blob([sampleCSV], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students_sample_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Sample CSV downloaded');
  };

  const handleDownloadErrorReport = () => {
    if (importResult.failedRows.length > 0) {
      const csv = generateFailedRowsCsv(importResult.failedRows);
      downloadCsv(csv, 'failed_students_import.csv');
      toast.success('Error report downloaded');
    }
  };

  const handleClose = () => {
    setStep('upload');
    setParsedData([]);
    setUploadProgress(0);
    setImportResult({ success: 0, failed: 0, failedRows: [], authAccountsCreated: 0 });
    onOpenChange(false);
  };

  const validCount = parsedData.filter((r) => r.status === 'valid').length;
  const errorCount = parsedData.filter((r) => r.status === 'error').length;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk Upload Students</DialogTitle>
        </DialogHeader>

        {step === 'upload' && (
          <div className="py-8">
            <div className="border-2 border-dashed border-muted rounded-lg p-12 text-center">
              <FileSpreadsheet className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Upload CSV File</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Drag and drop your CSV file here, or click to browse
              </p>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                id="csv-upload"
                disabled={isProcessing}
              />
              <label htmlFor="csv-upload">
                <Button asChild disabled={isProcessing}>
                  <span>
                    {isProcessing ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4 mr-2" />
                    )}
                    Select File
                  </span>
                </Button>
              </label>
            </div>

            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="mt-6">
                <p className="text-sm text-muted-foreground mb-2">Processing file...</p>
                <Progress value={uploadProgress} />
              </div>
            )}

            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <h4 className="font-medium mb-2">CSV Format Requirements</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Required columns: <code className="text-xs bg-muted px-1 rounded">full_name</code>, <code className="text-xs bg-muted px-1 rounded">roll_no</code>, <code className="text-xs bg-muted px-1 rounded">email</code>, <code className="text-xs bg-muted px-1 rounded">mobile</code>, <code className="text-xs bg-muted px-1 rounded">department</code>, <code className="text-xs bg-muted px-1 rounded">course</code>, <code className="text-xs bg-muted px-1 rounded">semester</code></li>
                <li>• Optional: <code className="text-xs bg-muted px-1 rounded">password</code> (min 6 chars, defaults to Student@123 if empty)</li>
                <li>• Departments: CSE, ECE, EE, ME, CE, BBA, MBA, IT, CIVIL, OTHER</li>
                <li>• Mobile: 10-digit Indian number starting with 6-9</li>
                <li>• Semester: 1-12</li>
                <li>• First row should contain column headers</li>
              </ul>
              <Button variant="outline" size="sm" className="mt-3" onClick={handleDownloadSampleCSV}>
                <Download className="h-4 w-4 mr-2" /> Download Sample CSV
              </Button>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="py-4">
            <div className="flex items-center gap-4 mb-4">
              <Badge variant="default" className="gap-1">
                <CheckCircle className="h-3 w-3" /> {validCount} Valid
              </Badge>
              {errorCount > 0 && (
                <Badge variant="destructive" className="gap-1">
                  <AlertCircle className="h-3 w-3" /> {errorCount} Errors
                </Badge>
              )}
            </div>

            <div className="rounded-lg border max-h-[400px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Status</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Roll Number</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Mobile</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Error</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedData.map((row, idx) => (
                    <TableRow key={idx} className={row.status === 'error' ? 'bg-destructive/10' : ''}>
                      <TableCell>
                        {row.status === 'valid' ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-destructive" />
                        )}
                      </TableCell>
                      <TableCell className="font-medium">{row.full_name}</TableCell>
                      <TableCell>{row.roll_no}</TableCell>
                      <TableCell className="text-sm">{row.email}</TableCell>
                      <TableCell>{row.mobile}</TableCell>
                      <TableCell>{row.department}</TableCell>
                      <TableCell className="text-destructive text-sm max-w-[200px] truncate">{row.error}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {errorCount > 0 && (
              <div className="mt-4 p-3 bg-destructive/10 rounded-lg">
                <span className="text-sm text-destructive">
                  {errorCount} row(s) have errors and will be skipped during import
                </span>
              </div>
            )}
          </div>
        )}

        {step === 'importing' && (
          <div className="py-12 text-center">
            <Loader2 className="h-16 w-16 mx-auto text-primary mb-4 animate-spin" />
            <h3 className="text-xl font-medium mb-2">Importing Students...</h3>
            <p className="text-muted-foreground">
              Please wait while we create student accounts
            </p>
          </div>
        )}

        {step === 'complete' && (
          <div className="py-12 text-center">
            <CheckCircle className="h-16 w-16 mx-auto text-green-500 mb-4" />
            <h3 className="text-xl font-medium mb-2">Import Complete!</h3>
            <p className="text-muted-foreground mb-2">
              Successfully imported {importResult.success} students
              {importResult.failed > 0 && `, ${importResult.failed} failed`}
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              {importResult.authAccountsCreated} login accounts created (using custom or default password)
            </p>
            {importResult.failed > 0 && (
              <Button variant="outline" onClick={handleDownloadErrorReport}>
                <Download className="h-4 w-4 mr-2" /> Download Error Report
              </Button>
            )}
          </div>
        )}

        <DialogFooter>
          {step === 'upload' && (
            <Button variant="outline" onClick={handleClose}>Cancel</Button>
          )}
          {step === 'preview' && (
            <>
              <Button variant="outline" onClick={() => { setStep('upload'); setParsedData([]); }}>Back</Button>
              <Button onClick={handleImport} disabled={validCount === 0 || isProcessing}>
                {isProcessing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Import {validCount} Students
              </Button>
            </>
          )}
          {step === 'complete' && (
            <Button onClick={handleClose}>Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
