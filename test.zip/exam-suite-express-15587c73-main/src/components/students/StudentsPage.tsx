import { useState, useMemo, useEffect } from 'react';
import { Plus, Upload, Download, UserCheck, UserX, FileSpreadsheet, ClipboardList, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { StudentFilters } from './StudentFilters';
import { StudentsTable } from './StudentsTable';
import { AddStudentModal } from './AddStudentModal';
import { BulkUploadModal } from './BulkUploadModal';
import { StudentProfileModal } from './StudentProfileModal';

interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: string;
  photoUrl?: string;
  status: 'active' | 'inactive';
  registeredExamsCount: number;
  lastLogin?: string;
  createdAt: string;
}

// Convert DB row to Student type
const dbToStudent = (row: any): Student => ({
  id: row.id,
  name: row.full_name,
  rollNumber: row.roll_no,
  email: row.email,
  mobile: row.mobile || '',
  department: row.department,
  course: row.course,
  semester: String(row.semester),
  photoUrl: row.photo_url,
  status: row.status,
  registeredExamsCount: 0,
  lastLogin: row.last_login,
  createdAt: row.created_at,
});

export function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [department, setDepartment] = useState('All Departments');
  const [course, setCourse] = useState('All Courses');
  const [semester, setSemester] = useState('All Semesters');
  const [status, setStatus] = useState('All Status');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [bulkUploadOpen, setBulkUploadOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);

  // Fetch students from database
  useEffect(() => {
    const fetchStudents = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching students:', error);
        toast.error('Failed to load students');
      } else {
        setStudents((data || []).map(dbToStudent));
      }
      setIsLoading(false);
    };

    fetchStudents();
  }, []);

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesSearch =
        searchQuery === '' ||
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.rollNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDept = department === 'All Departments' || student.department === department;
      const matchesCourse = course === 'All Courses' || student.course === course;
      const matchesSemester = semester === 'All Semesters' || student.semester === semester;
      const matchesStatus = status === 'All Status' || student.status === status.toLowerCase();
      return matchesSearch && matchesDept && matchesCourse && matchesSemester && matchesStatus;
    });
  }, [students, searchQuery, department, course, semester, status]);

  const handleAddStudent = () => {
    setEditingStudent(null);
    setAddModalOpen(true);
  };

  const handleEditStudent = (student: Student) => {
    setEditingStudent(student);
    setAddModalOpen(true);
  };

  const handleViewStudent = (student: Student) => {
    setViewingStudent(student);
    setProfileModalOpen(true);
  };

  const handleSaveStudent = async (data: Partial<Student>) => {
    // Note: The DB operations are handled by AddStudentModal via edge function
    // This function only updates local state
    
    if (editingStudent) {
      // Update existing student in local state
      setStudents((prev) =>
        prev.map((s) => (s.id === editingStudent.id ? { ...s, ...data } : s))
      );
    } else {
      // Add new student to local state (already saved to DB by edge function)
      const newStudent: Student = {
        id: data.id || crypto.randomUUID(),
        name: data.name || '',
        rollNumber: data.rollNumber || '',
        email: data.email || '',
        mobile: data.mobile || '',
        department: data.department || '',
        course: data.course || '',
        semester: data.semester || '1',
        photoUrl: data.photoUrl,
        status: (data.status as 'active' | 'inactive') || 'active',
        registeredExamsCount: 0,
        lastLogin: undefined,
        createdAt: new Date().toISOString(),
      };
      setStudents((prev) => [newStudent, ...prev]);
    }
  };

  const handleResetPassword = (student: Student) => {
    toast.success(`Password reset link sent to ${student.email}`);
  };

  const handleToggleStatus = async (student: Student) => {
    const newStatus = student.status === 'active' ? 'inactive' : 'active';
    
    const { error } = await supabase
      .from('students')
      .update({ status: newStatus })
      .eq('id', student.id);

    if (error) {
      console.error('Error toggling status:', error);
      toast.error('Failed to update status');
      return;
    }

    setStudents((prev) =>
      prev.map((s) =>
        s.id === student.id ? { ...s, status: newStatus } : s
      )
    );
    toast.success(`Student ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
  };

  const handleBulkAction = async (action: string) => {
    if (selectedIds.length === 0) {
      toast.error('Please select students first');
      return;
    }

    switch (action) {
      case 'activate':
      case 'deactivate':
        const newStatus = action === 'activate' ? 'active' : 'inactive';
        const { error } = await supabase
          .from('students')
          .update({ status: newStatus })
          .in('id', selectedIds);

        if (error) {
          toast.error(`Failed to ${action} students`);
          return;
        }

        setStudents((prev) =>
          prev.map((s) => (selectedIds.includes(s.id) ? { ...s, status: newStatus } : s))
        );
        toast.success(`${selectedIds.length} students ${action}d`);
        break;
      case 'export':
        toast.success(`Exporting ${selectedIds.length} students...`);
        break;
      case 'enroll':
        toast.info('Enroll in exam feature coming soon');
        break;
    }
    setSelectedIds([]);
  };

  const handleBulkImport = async (importedStudents: any[]) => {
    const departmentMap: Record<string, 'CSE' | 'ECE' | 'EE' | 'ME' | 'CE' | 'BBA' | 'MBA' | 'IT' | 'CIVIL' | 'OTHER'> = {
      'Computer Science': 'CSE',
      'Electronics': 'ECE',
      'Electrical Engineering': 'EE',
      'Mechanical Engineering': 'ME',
      'CSE': 'CSE', 'ECE': 'ECE', 'EE': 'EE', 'ME': 'ME', 'CE': 'CE',
      'BBA': 'BBA', 'MBA': 'MBA', 'IT': 'IT', 'CIVIL': 'CIVIL',
    };

    const newStudents = importedStudents.map((s) => ({
      full_name: s.name,
      roll_no: s.rollNumber,
      email: s.email,
      mobile: s.mobile || '',
      department: departmentMap[s.department] || 'OTHER' as const,
      course: s.course,
      semester: parseInt(s.semester) || 1,
      status: 'active' as const,
    }));

    const { data, error } = await supabase
      .from('students')
      .insert(newStudents)
      .select();

    if (error) {
      console.error('Error importing students:', error);
      toast.error('Failed to import some students');
      return;
    }

    setStudents((prev) => [...(data || []).map(dbToStudent), ...prev]);
    toast.success(`${data?.length || 0} students imported successfully`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Students</h1>
          <p className="text-muted-foreground">Manage student records and enrollments ({students.length} total)</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => toast.success('Downloading sample CSV...')}>
            <Download className="h-4 w-4 mr-2" /> Sample CSV
          </Button>
          <Button variant="outline" onClick={() => setBulkUploadOpen(true)}>
            <Upload className="h-4 w-4 mr-2" /> Bulk Upload
          </Button>
          <Button onClick={handleAddStudent}>
            <Plus className="h-4 w-4 mr-2" /> Add Student
          </Button>
        </div>
      </div>

      <StudentFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        department={department}
        onDepartmentChange={setDepartment}
        course={course}
        onCourseChange={setCourse}
        semester={semester}
        onSemesterChange={setSemester}
        status={status}
        onStatusChange={setStatus}
      />

      {selectedIds.length > 0 && (
        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
          <span className="text-sm font-medium">{selectedIds.length} selected</span>
          <div className="flex-1" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                Bulk Actions
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover">
              <DropdownMenuItem onClick={() => handleBulkAction('activate')}>
                <UserCheck className="h-4 w-4 mr-2" /> Activate Selected
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleBulkAction('deactivate')}>
                <UserX className="h-4 w-4 mr-2" /> Deactivate Selected
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleBulkAction('enroll')}>
                <ClipboardList className="h-4 w-4 mr-2" /> Enroll in Exam
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleBulkAction('export')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" /> Export as CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      <StudentsTable
        students={filteredStudents}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
        onView={handleViewStudent}
        onEdit={handleEditStudent}
        onResetPassword={handleResetPassword}
        onToggleStatus={handleToggleStatus}
      />

      <AddStudentModal
        open={addModalOpen}
        onOpenChange={setAddModalOpen}
        student={editingStudent}
        onSave={handleSaveStudent}
      />

      <BulkUploadModal
        open={bulkUploadOpen}
        onOpenChange={setBulkUploadOpen}
        onImport={handleBulkImport}
      />

      <StudentProfileModal
        open={profileModalOpen}
        onOpenChange={setProfileModalOpen}
        student={viewingStudent}
        onToggleStatus={handleToggleStatus}
      />
    </div>
  );
}