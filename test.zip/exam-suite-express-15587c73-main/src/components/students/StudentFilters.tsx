import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useSubjects } from '@/hooks/useSubjects';

interface StudentFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  department: string;
  onDepartmentChange: (value: string) => void;
  course: string;
  onCourseChange: (value: string) => void;
  semester: string;
  onSemesterChange: (value: string) => void;
  status: string;
  onStatusChange: (value: string) => void;
}

const courses = ['All Courses', 'B.Tech', 'M.Tech', 'BCA', 'MCA', 'B.Sc', 'M.Sc', 'BBA', 'MBA', 'PhD'];
const semesters = ['All Semesters', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'];
const statuses = ['All Status', 'Active', 'Inactive'];

export function StudentFilters({
  searchQuery,
  onSearchChange,
  department,
  onDepartmentChange,
  course,
  onCourseChange,
  semester,
  onSemesterChange,
  status,
  onStatusChange,
}: StudentFiltersProps) {
  const { getDepartments, isLoading } = useSubjects();
  const departments = getDepartments();

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, roll number, or email..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>
      <div className="flex flex-wrap gap-3">
        <Select value={department} onValueChange={onDepartmentChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder={isLoading ? "Loading..." : "Department"} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="All Departments">All Departments</SelectItem>
            {departments.map((dept) => (
              <SelectItem key={dept.value} value={dept.label}>{dept.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={course} onValueChange={onCourseChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Course" />
          </SelectTrigger>
          <SelectContent>
            {courses.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={semester} onValueChange={onSemesterChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Semester" />
          </SelectTrigger>
          <SelectContent>
            {semesters.map((sem) => (
              <SelectItem key={sem} value={sem}>{sem}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={status} onValueChange={onStatusChange}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {statuses.map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
