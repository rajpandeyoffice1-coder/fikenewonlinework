import { format } from 'date-fns';
import { Mail, Phone, Calendar, MapPin, Clock, AlertTriangle, Shield, FileText } from 'lucide-react';
import {
  Student,
  ExamEnrollment,
  ExamAttempt,
  IncidentReport,
  AuditLog,
  mockEnrollments,
  mockAttempts,
  mockIncidents,
  mockAuditLogs,
} from '@/types/student';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface StudentProfileModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  student: Student | null;
  onToggleStatus: (student: Student) => void;
}

export function StudentProfileModal({ open, onOpenChange, student, onToggleStatus }: StudentProfileModalProps) {
  if (!student) return null;

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const getStatusBadge = (status: ExamEnrollment['status']) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      registered: 'secondary',
      completed: 'default',
      not_attempted: 'destructive',
    };
    const labels: Record<string, string> = {
      registered: 'Registered',
      completed: 'Completed',
      not_attempted: 'Not Attempted',
    };
    return <Badge variant={variants[status]}>{labels[status]}</Badge>;
  };

  const getResultBadge = (result: ExamAttempt['result']) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      pass: 'default',
      fail: 'destructive',
      na: 'secondary',
    };
    const labels: Record<string, string> = {
      pass: 'Pass',
      fail: 'Fail',
      na: 'N/A',
    };
    return <Badge variant={variants[result]}>{labels[result]}</Badge>;
  };

  const getIncidentIcon = (type: IncidentReport['type']) => {
    const icons: Record<string, string> = {
      face_mismatch: '👤',
      multiple_face: '👥',
      tab_switch: '🔄',
      audio_alert: '🔊',
    };
    return icons[type];
  };

  const getIncidentLabel = (type: IncidentReport['type']) => {
    const labels: Record<string, string> = {
      face_mismatch: 'Face Mismatch',
      multiple_face: 'Multiple Faces',
      tab_switch: 'Tab Switch',
      audio_alert: 'Audio Alert',
    };
    return labels[type];
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Student Profile</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="enrollments">Enrollments</TabsTrigger>
            <TabsTrigger value="attempts">Attempts</TabsTrigger>
            <TabsTrigger value="incidents">Incidents</TabsTrigger>
            <TabsTrigger value="audit">Audit Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="flex items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={student.photoUrl} />
                <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                  {getInitials(student.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-2xl font-semibold">{student.name}</h2>
                    <p className="text-muted-foreground font-mono">{student.rollNumber}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Switch
                      checked={student.status === 'active'}
                      onCheckedChange={() => onToggleStatus(student)}
                    />
                    <Badge variant={student.status === 'active' ? 'default' : 'destructive'}>
                      {student.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{student.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{student.mobile || 'Not provided'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{student.department}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span>{student.course} / {student.semester} Semester</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Joined: {format(new Date(student.createdAt), 'MMM d, yyyy')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Last login: {student.lastLogin ? format(new Date(student.lastLogin), 'MMM d, yyyy h:mm a') : 'Never'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Registered Exams</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{student.registeredExamsCount}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Completed</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{mockAttempts.length}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Flagged Incidents</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-orange-500">{mockIncidents.length}</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="enrollments" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">Exam Enrollments</h3>
              <Button size="sm">+ Enroll in Exam</Button>
            </div>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Score</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockEnrollments.map((enrollment) => (
                    <TableRow key={enrollment.id}>
                      <TableCell className="font-medium">{enrollment.examName}</TableCell>
                      <TableCell>{format(new Date(enrollment.examDate), 'MMM d, yyyy h:mm a')}</TableCell>
                      <TableCell>{getStatusBadge(enrollment.status)}</TableCell>
                      <TableCell>
                        {enrollment.score !== undefined ? `${enrollment.score}/${enrollment.totalMarks}` : '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="attempts" className="mt-6">
            <h3 className="font-semibold mb-4">Exam Attempts</h3>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Attempt ID</TableHead>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Incidents</TableHead>
                    <TableHead>Result</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockAttempts.map((attempt) => (
                    <TableRow key={attempt.id}>
                      <TableCell className="font-mono text-sm">{attempt.attemptId}</TableCell>
                      <TableCell className="font-medium">{attempt.examName}</TableCell>
                      <TableCell>{format(new Date(attempt.startTime), 'MMM d, yyyy h:mm a')}</TableCell>
                      <TableCell>{attempt.duration}</TableCell>
                      <TableCell>
                        {attempt.flaggedIncidents > 0 ? (
                          <Badge variant="destructive">{attempt.flaggedIncidents}</Badge>
                        ) : (
                          <Badge variant="secondary">0</Badge>
                        )}
                      </TableCell>
                      <TableCell>{getResultBadge(attempt.result)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="incidents" className="mt-6">
            <h3 className="font-semibold mb-4">Incident Reports</h3>
            {mockIncidents.length > 0 ? (
              <div className="space-y-3">
                {mockIncidents.map((incident) => (
                  <Card key={incident.id}>
                    <CardContent className="flex items-center justify-between py-4">
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center text-xl">
                          {getIncidentIcon(incident.type)}
                        </div>
                        <div>
                          <p className="font-medium">{getIncidentLabel(incident.type)}</p>
                          <p className="text-sm text-muted-foreground">{incident.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">{format(new Date(incident.timestamp), 'MMM d, yyyy')}</p>
                        <p className="text-xs text-muted-foreground">{format(new Date(incident.timestamp), 'h:mm a')}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Shield className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No incidents reported</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="audit" className="mt-6">
            <h3 className="font-semibold mb-4">Audit Logs</h3>
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Action</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Performed By</TableHead>
                    <TableHead>Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockAuditLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-medium">{log.action}</TableCell>
                      <TableCell>{format(new Date(log.timestamp), 'MMM d, yyyy h:mm a')}</TableCell>
                      <TableCell className="font-mono text-sm">{log.ipAddress}</TableCell>
                      <TableCell>{log.performedBy}</TableCell>
                      <TableCell className="text-muted-foreground">{log.details}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
