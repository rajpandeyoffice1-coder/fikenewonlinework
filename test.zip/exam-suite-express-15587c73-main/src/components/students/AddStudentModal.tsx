import { useState, useEffect } from 'react';
import { Upload, Loader2 } from 'lucide-react';
import { Student } from '@/types/student';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { 
  VALID_DEPARTMENTS, 
  DEPARTMENT_LABELS, 
  validateStudent,
  validatePhotoFile,
  type ValidationError 
} from '@/lib/studentValidation';
import { addStudent, updateStudent, apiErrorsToFormErrors } from '@/services/studentService';

interface AddStudentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  student?: Student | null;
  onSave: (student: Partial<Student>) => void;
}

const courses = ['B.Tech', 'M.Tech', 'BCA', 'MCA', 'B.Sc', 'M.Sc', 'BBA', 'MBA', 'PhD'];
const semesters = Array.from({ length: 12 }, (_, i) => i + 1);

export function AddStudentModal({ open, onOpenChange, student, onSave }: AddStudentModalProps) {
  const [formData, setFormData] = useState({
    full_name: '',
    roll_no: '',
    email: '',
    mobile: '',
    department: '' as typeof VALID_DEPARTMENTS[number] | '',
    course: '',
    semester: 1,
    photo_url: '',
    status: 'active' as 'active' | 'inactive',
    password: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (student) {
      // Map from Student type to form data
      const deptMapping: Record<string, typeof VALID_DEPARTMENTS[number]> = {
        'Computer Science': 'CSE',
        'Computer Science & Engineering': 'CSE',
        'Electrical Engineering': 'EE',
        'Electronics & Communication': 'ECE',
        'Mechanical Engineering': 'ME',
        'Civil Engineering': 'CIVIL',
        'Chemical Engineering': 'CE',
        'Information Technology': 'IT',
      };
      
      const semesterNum = parseInt(student.semester?.replace(/\D/g, '') || '1', 10);
      
      setFormData({
        full_name: student.name,
        roll_no: student.rollNumber,
        email: student.email,
        mobile: student.mobile.replace(/[\s\-\(\)\+]/g, '').slice(-10),
        department: deptMapping[student.department] || 'OTHER',
        course: student.course,
        semester: semesterNum || 1,
        photo_url: student.photoUrl || '',
        status: student.status,
        password: '',
      });
    } else {
      setFormData({
        full_name: '',
        roll_no: '',
        email: '',
        mobile: '',
        department: '',
        course: '',
        semester: 1,
        photo_url: '',
        status: 'active',
        password: '',
      });
    }
    setErrors({});
  }, [student, open]);

  const handleSubmit = async () => {
    // Clear previous errors
    setErrors({});

    // Client-side validation
    const validationData = {
      ...formData,
      department: formData.department || undefined,
    };

    const validation = validateStudent(validationData);
    if (!validation.success) {
      const formErrors = apiErrorsToFormErrors((validation as { success: false; errors: ValidationError[] }).errors);
      setErrors(formErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      // Call backend API
      const apiData = {
        full_name: formData.full_name.trim(),
        roll_no: formData.roll_no.trim(),
        email: formData.email.trim().toLowerCase(),
        mobile: formData.mobile.replace(/[\s\-\(\)\+]/g, ''),
        department: formData.department as typeof VALID_DEPARTMENTS[number],
        course: formData.course.trim(),
        semester: formData.semester,
        status: formData.status,
        photo_url: formData.photo_url || undefined,
        password: formData.password || undefined,
      };

      let response;
      if (student) {
        response = await updateStudent(student.id, apiData);
      } else {
        response = await addStudent(apiData);
      }

      if (response.status === 'validation_error' && response.errors) {
        setErrors(apiErrorsToFormErrors(response.errors));
        toast.error('Validation failed', {
          description: response.errors[0]?.message || 'Please check the form for errors.',
        });
        return;
      }

      if (response.status === 'error') {
        toast.error('Error', { description: response.message || 'An error occurred.' });
        return;
      }

      // Success - call the parent onSave callback
      const savedData: Partial<Student> = {
        id: response.data?.id,
        name: formData.full_name,
        rollNumber: formData.roll_no,
        email: formData.email,
        mobile: formData.mobile,
        department: DEPARTMENT_LABELS[formData.department] || formData.department,
        course: formData.course,
        semester: `${formData.semester}${getSemesterSuffix(formData.semester)}`,
        photoUrl: formData.photo_url,
        status: formData.status,
      };

      onSave(savedData);
      
      if (student) {
        toast.success('Student updated successfully');
      } else {
        const authMsg = response.authCreated 
          ? ` Login: ${formData.email} / ${formData.password || 'Student@123'}`
          : '';
        toast.success('Student added successfully', {
          description: authMsg ? `Login account created.${authMsg}` : undefined,
          duration: authMsg ? 8000 : 3000,
        });
      }
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving student:', error);
      toast.error('Error', { description: 'Failed to save student. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getSemesterSuffix = (sem: number): string => {
    if (sem === 1 || sem === 21) return 'st';
    if (sem === 2 || sem === 22) return 'nd';
    if (sem === 3 || sem === 23) return 'rd';
    return 'th';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const error = validatePhotoFile(file);
    if (error) {
      setErrors((prev) => ({ ...prev, photo_file: error.message }));
      return;
    }

    // For now, create a local URL. In production, upload to storage
    const url = URL.createObjectURL(file);
    setFormData((prev) => ({ ...prev, photo_url: url }));
    setErrors((prev) => {
      const { photo_file, ...rest } = prev;
      return rest;
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{student ? 'Edit Student' : 'Add New Student'}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={formData.photo_url} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {formData.full_name ? getInitials(formData.full_name) : 'ST'}
              </AvatarFallback>
            </Avatar>
            <div>
              <Label htmlFor="photo-upload" className="cursor-pointer">
                <Button variant="outline" size="sm" asChild>
                  <span>
                    <Upload className="h-4 w-4 mr-2" /> Upload Photo
                  </span>
                </Button>
              </Label>
              <input
                id="photo-upload"
                type="file"
                accept="image/jpeg,image/jpg,image/png"
                className="hidden"
                onChange={handleFileUpload}
              />
              <p className="text-xs text-muted-foreground mt-1">JPG, PNG. Max 2MB.</p>
              {errors.photo_file && <p className="text-xs text-destructive">{errors.photo_file}</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="full_name">Full Name *</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                className={errors.full_name ? 'border-destructive' : ''}
                placeholder="Enter full name (alphabets only)"
              />
              {errors.full_name && <p className="text-xs text-destructive">{errors.full_name}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="roll_no">Roll Number *</Label>
              <Input
                id="roll_no"
                value={formData.roll_no}
                onChange={(e) => setFormData({ ...formData, roll_no: e.target.value })}
                className={errors.roll_no ? 'border-destructive' : ''}
                placeholder="Alphanumeric (4-15 chars)"
                disabled={!!student}
              />
              {errors.roll_no && <p className="text-xs text-destructive">{errors.roll_no}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={errors.email ? 'border-destructive' : ''}
                placeholder="student@university.edu"
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="mobile">Mobile Number *</Label>
              <Input
                id="mobile"
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                className={errors.mobile ? 'border-destructive' : ''}
                placeholder="10-digit Indian number"
                maxLength={10}
              />
              {errors.mobile && <p className="text-xs text-destructive">{errors.mobile}</p>}
            </div>

            <div className="space-y-2">
              <Label>Department *</Label>
              <Select 
                value={formData.department} 
                onValueChange={(v) => setFormData({ ...formData, department: v as typeof VALID_DEPARTMENTS[number] })}
              >
                <SelectTrigger className={errors.department ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {VALID_DEPARTMENTS.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {DEPARTMENT_LABELS[dept]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.department && <p className="text-xs text-destructive">{errors.department}</p>}
            </div>

            <div className="space-y-2">
              <Label>Course *</Label>
              <Select value={formData.course} onValueChange={(v) => setFormData({ ...formData, course: v })}>
                <SelectTrigger className={errors.course ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.course && <p className="text-xs text-destructive">{errors.course}</p>}
            </div>

            <div className="space-y-2">
              <Label>Semester *</Label>
              <Select 
                value={String(formData.semester)} 
                onValueChange={(v) => setFormData({ ...formData, semester: parseInt(v, 10) })}
              >
                <SelectTrigger className={errors.semester ? 'border-destructive' : ''}>
                  <SelectValue placeholder="Select semester" />
                </SelectTrigger>
                <SelectContent>
                  {semesters.map((sem) => (
                    <SelectItem key={sem} value={String(sem)}>
                      {sem}{getSemesterSuffix(sem)} Semester
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.semester && <p className="text-xs text-destructive">{errors.semester}</p>}
            </div>

            {!student && (
              <div className="space-y-2">
                <Label htmlFor="password">Password (Optional)</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className={errors.password ? 'border-destructive' : ''}
                  placeholder="Min 6 characters"
                />
                {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
              </div>
            )}

            <div className="space-y-2">
              <Label>Status</Label>
              <div className="flex items-center gap-3 pt-2">
                <Switch
                  checked={formData.status === 'active'}
                  onCheckedChange={(checked) => setFormData({ ...formData, status: checked ? 'active' : 'inactive' })}
                />
                <span className="text-sm">{formData.status === 'active' ? 'Active' : 'Inactive'}</span>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {student ? 'Update Student' : 'Add Student'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
