import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface Step {
  id: number;
  title: string;
  shortTitle: string;
}

interface WizardProgressProps {
  steps: Step[];
  currentStep: number;
  onStepClick: (step: number) => void;
  completedSteps: number[];
}

export function WizardProgress({ steps, currentStep, onStepClick, completedSteps }: WizardProgressProps) {
  return (
    <div className="w-full bg-card border-b border-border px-6 py-4">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between relative">
          {/* Progress line */}
          <div className="absolute top-5 left-0 right-0 h-0.5 bg-border" />
          <div 
            className="absolute top-5 left-0 h-0.5 bg-primary transition-all duration-500"
            style={{ width: `${((currentStep - 1) / (steps.length - 1)) * 100}%` }}
          />

          {steps.map((step) => {
            const isCompleted = completedSteps.includes(step.id);
            const isCurrent = currentStep === step.id;
            const isPast = step.id < currentStep;

            return (
              <button
                key={step.id}
                onClick={() => onStepClick(step.id)}
                className={cn(
                  "relative z-10 flex flex-col items-center gap-2 group",
                  (isCompleted || isPast) && "cursor-pointer"
                )}
              >
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 border-2",
                    isCurrent && "bg-primary text-primary-foreground border-primary scale-110 shadow-lg shadow-primary/30",
                    isCompleted && !isCurrent && "bg-primary text-primary-foreground border-primary",
                    isPast && !isCompleted && "bg-primary/20 text-primary border-primary/50",
                    !isCurrent && !isCompleted && !isPast && "bg-muted text-muted-foreground border-border"
                  )}
                >
                  {isCompleted && !isCurrent ? (
                    <Check className="h-5 w-5" />
                  ) : (
                    step.id
                  )}
                </div>
                <span
                  className={cn(
                    "text-xs font-medium transition-colors hidden sm:block",
                    isCurrent && "text-primary",
                    !isCurrent && "text-muted-foreground group-hover:text-foreground"
                  )}
                >
                  {step.shortTitle}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
