import { Eye, Video, Mic, Monitor, Lock, Users } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ExamProctoring } from "@/types/exam";

interface ProctoringStepProps {
  data: ExamProctoring;
  onChange: (data: ExamProctoring) => void;
}

interface ToggleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
}

function ToggleCard({ icon, title, description, checked, onCheckedChange, disabled }: ToggleCardProps) {
  return (
    <Card className={`transition-colors ${checked ? "border-primary/50 bg-primary/5" : ""} ${disabled ? "opacity-50" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-muted shrink-0">
              {icon}
            </div>
            <div>
              <h4 className="font-medium text-foreground">{title}</h4>
              <p className="text-sm text-muted-foreground mt-0.5">{description}</p>
            </div>
          </div>
          <Switch checked={checked} onCheckedChange={onCheckedChange} disabled={disabled} />
        </div>
      </CardContent>
    </Card>
  );
}

export function ProctoringStep({ data, onChange }: ProctoringStepProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <Eye className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Proctoring Settings</h2>
          <p className="text-sm text-muted-foreground">Configure remote proctoring and monitoring</p>
        </div>
      </div>

      <div className="space-y-4">
        <ToggleCard
          icon={<Eye className="h-5 w-5 text-muted-foreground" />}
          title="Enable Remote Proctoring"
          description="Monitor candidates through live video feed and AI-based behavior analysis"
          checked={data.enableRemoteProctoring}
          onCheckedChange={(checked) => onChange({ ...data, enableRemoteProctoring: checked })}
        />

        <div className="grid sm:grid-cols-2 gap-4">
          <ToggleCard
            icon={<Video className="h-5 w-5 text-muted-foreground" />}
            title="Require Webcam"
            description="Candidates must enable webcam during exam"
            checked={data.requireWebcam}
            onCheckedChange={(checked) => onChange({ ...data, requireWebcam: checked })}
            disabled={!data.enableRemoteProctoring}
          />

          <ToggleCard
            icon={<Mic className="h-5 w-5 text-muted-foreground" />}
            title="Require Microphone"
            description="Record audio during the exam session"
            checked={data.requireMicrophone}
            onCheckedChange={(checked) => onChange({ ...data, requireMicrophone: checked })}
            disabled={!data.enableRemoteProctoring}
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <ToggleCard
            icon={<Monitor className="h-5 w-5 text-muted-foreground" />}
            title="Screen Share Required"
            description="Candidates must share their screen throughout the exam"
            checked={data.screenShareRequired}
            onCheckedChange={(checked) => onChange({ ...data, screenShareRequired: checked })}
            disabled={!data.enableRemoteProctoring}
          />

          <ToggleCard
            icon={<Lock className="h-5 w-5 text-muted-foreground" />}
            title="Full Browser Lockdown"
            description="Prevent access to other applications and tabs"
            checked={data.fullBrowserLockdown}
            onCheckedChange={(checked) => onChange({ ...data, fullBrowserLockdown: checked })}
          />
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            Proctor Assignment
          </CardTitle>
          <CardDescription>Choose how proctors are assigned to this exam</CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={data.proctorAssignment}
            onValueChange={(value) => onChange({ ...data, proctorAssignment: value })}
            disabled={!data.enableRemoteProctoring}
          >
            <SelectTrigger className="w-full sm:w-1/2">
              <SelectValue placeholder="Select assignment method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto-assign (AI + Available Proctors)</SelectItem>
              <SelectItem value="single">Single Proctor</SelectItem>
              <SelectItem value="multiple">Multiple Proctors (Team)</SelectItem>
              <SelectItem value="ai-only">AI Proctoring Only</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>
    </div>
  );
}
