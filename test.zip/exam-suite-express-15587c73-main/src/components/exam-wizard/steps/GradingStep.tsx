import { Award, Calculator, FileText, CheckCircle } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ExamGrading, ExamQuestionPaper } from "@/types/exam";

interface GradingStepProps {
  data: ExamGrading;
  onChange: (data: ExamGrading) => void;
  questionPaper: ExamQuestionPaper;
}

const rubricTemplates = [
  { value: "standard", label: "Standard (Full/Partial/None)" },
  { value: "detailed", label: "Detailed (10-point scale)" },
  { value: "simple", label: "Simple (Pass/Fail)" },
  { value: "custom", label: "Custom Rubric" },
];

interface ToggleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}

function ToggleCard({ icon, title, description, checked, onCheckedChange }: ToggleCardProps) {
  return (
    <Card className={`transition-colors ${checked ? "border-primary/50 bg-primary/5" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-muted shrink-0">
              {icon}
            </div>
            <div>
              <h4 className="font-medium text-foreground">{title}</h4>
              <p className="text-sm text-muted-foreground mt-0.5">{description}</p>
            </div>
          </div>
          <Switch checked={checked} onCheckedChange={onCheckedChange} />
        </div>
      </CardContent>
    </Card>
  );
}

export function GradingStep({ data, onChange, questionPaper }: GradingStepProps) {
  const totalMarks = questionPaper.questions.reduce((sum, q) => sum + q.marks, 0);
  const mcqMarks = questionPaper.questions.filter((q) => q.type === "mcq" || q.type === "true-false").reduce((sum, q) => sum + q.marks, 0);
  const subjectiveMarks = questionPaper.questions.filter((q) => q.type === "subjective").reduce((sum, q) => sum + q.marks, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <Award className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Grading Setup</h2>
          <p className="text-sm text-muted-foreground">Configure how the exam will be evaluated</p>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <ToggleCard
          icon={<Calculator className="h-5 w-5 text-muted-foreground" />}
          title="Auto-grade MCQs"
          description="Automatically evaluate multiple choice and true/false questions"
          checked={data.autoGradeMcqs}
          onCheckedChange={(checked) => onChange({ ...data, autoGradeMcqs: checked })}
        />

        <ToggleCard
          icon={<FileText className="h-5 w-5 text-muted-foreground" />}
          title="Manual Grading for Subjective"
          description="Require manual evaluation for essay and subjective answers"
          checked={data.manualGradingSubjective}
          onCheckedChange={(checked) => onChange({ ...data, manualGradingSubjective: checked })}
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Rubric Template</CardTitle>
            <CardDescription>Evaluation criteria for subjective questions</CardDescription>
          </CardHeader>
          <CardContent>
            <Select
              value={data.rubricTemplate}
              onValueChange={(value) => onChange({ ...data, rubricTemplate: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select template" />
              </SelectTrigger>
              <SelectContent>
                {rubricTemplates.map((template) => (
                  <SelectItem key={template.value} value={template.value}>
                    {template.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Passing Marks</CardTitle>
            <CardDescription>Minimum marks required to pass</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min={0}
                max={totalMarks}
                value={data.passingMarks}
                onChange={(e) => onChange({ ...data, passingMarks: parseInt(e.target.value) || 0 })}
                className="w-24"
              />
              <span className="text-muted-foreground">/ {totalMarks || "—"} marks</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-primary" />
            Grading Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-muted/50 rounded-lg">
              <div className="text-2xl font-bold text-foreground">{totalMarks}</div>
              <div className="text-sm text-muted-foreground">Total Marks</div>
            </div>
            <div className="text-center p-4 bg-muted/50 rounded-lg">
              <div className="text-2xl font-bold text-foreground">{data.passingMarks}</div>
              <div className="text-sm text-muted-foreground">Passing Marks</div>
            </div>
            <div className="text-center p-4 bg-muted/50 rounded-lg">
              <div className="text-2xl font-bold text-success">{mcqMarks}</div>
              <div className="text-sm text-muted-foreground">Auto-graded</div>
            </div>
            <div className="text-center p-4 bg-muted/50 rounded-lg">
              <div className="text-2xl font-bold text-warning">{subjectiveMarks}</div>
              <div className="text-sm text-muted-foreground">Manual Review</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
