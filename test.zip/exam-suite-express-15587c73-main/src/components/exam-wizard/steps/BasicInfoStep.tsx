import { useEffect } from "react";
import { FileText, RefreshCw, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ExamBasicInfo } from "@/types/exam";
import { useSubjects } from "@/hooks/useSubjects";
import { useStudentGroups } from "@/hooks/useStudentGroups";

interface BasicInfoStepProps {
  data: ExamBasicInfo;
  onChange: (data: ExamBasicInfo) => void;
}

const semesters = [
  { value: "1", label: "Semester 1" },
  { value: "2", label: "Semester 2" },
  { value: "3", label: "Semester 3" },
  { value: "4", label: "Semester 4" },
  { value: "5", label: "Semester 5" },
  { value: "6", label: "Semester 6" },
  { value: "7", label: "Semester 7" },
  { value: "8", label: "Semester 8" },
];

function generateExamCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "EX-";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export function BasicInfoStep({ data, onChange }: BasicInfoStepProps) {
  const { subjects, isLoading, getDepartments, getSubjectsByDepartment } = useSubjects();
  const { groups, loading: groupsLoading } = useStudentGroups();

  useEffect(() => {
    if (data.autoGenerateCode && !data.code) {
      onChange({ ...data, code: generateExamCode() });
    }
  }, []);

  const handleRegenerateCode = () => {
    onChange({ ...data, code: generateExamCode() });
  };

  const departments = getDepartments();
  const availableSubjects = getSubjectsByDepartment(data.department);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <FileText className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Basic Information</h2>
          <p className="text-sm text-muted-foreground">Enter the fundamental details of your exam</p>
        </div>
      </div>

      <div className="grid gap-6">
        <div className="space-y-2">
          <Label htmlFor="title">
            Exam Title <span className="text-destructive">*</span>
          </Label>
          <Input
            id="title"
            placeholder="e.g., Data Structures Final Examination"
            value={data.title}
            onChange={(e) => onChange({ ...data, title: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="code">
            Exam Code <span className="text-destructive">*</span>
          </Label>
          <div className="flex gap-2">
            <Input
              id="code"
              placeholder="EX-XXXXXX"
              value={data.code}
              onChange={(e) => onChange({ ...data, code: e.target.value })}
              disabled={data.autoGenerateCode}
              className="flex-1"
            />
            {data.autoGenerateCode && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleRegenerateCode}
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2 mt-2">
            <Switch
              id="autoGenerate"
              checked={data.autoGenerateCode}
              onCheckedChange={(checked) =>
                onChange({ ...data, autoGenerateCode: checked })
              }
            />
            <Label htmlFor="autoGenerate" className="text-sm text-muted-foreground cursor-pointer">
              Auto-generate exam code
            </Label>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="department">
              Department <span className="text-destructive">*</span>
            </Label>
            <Select
              value={data.department}
              onValueChange={(value) =>
                onChange({ ...data, department: value, course: "" })
              }
            >
              <SelectTrigger id="department">
                <SelectValue placeholder={isLoading ? "Loading..." : "Select department"} />
              </SelectTrigger>
              <SelectContent>
                {isLoading ? (
                  <div className="flex items-center justify-center p-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                ) : departments.length > 0 ? (
                  departments.map((dept) => (
                    <SelectItem key={dept.value} value={dept.value}>
                      {dept.label}
                    </SelectItem>
                  ))
                ) : (
                  <div className="p-2 text-sm text-muted-foreground">No departments found</div>
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="course">
              Course / Subject <span className="text-destructive">*</span>
            </Label>
            <Select
              value={data.course}
              onValueChange={(value) => onChange({ ...data, course: value })}
              disabled={!data.department || isLoading}
            >
              <SelectTrigger id="course">
                <SelectValue placeholder={data.department ? "Select subject" : "Select department first"} />
              </SelectTrigger>
              <SelectContent>
                {isLoading ? (
                  <div className="flex items-center justify-center p-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                ) : availableSubjects.length > 0 ? (
                  availableSubjects.map((subject) => (
                    <SelectItem key={subject.id} value={subject.name}>
                      {subject.code} - {subject.name}
                    </SelectItem>
                  ))
                ) : (
                  <div className="p-2 text-sm text-muted-foreground">No subjects found for this department</div>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="semester">
            Semester <span className="text-destructive">*</span>
          </Label>
          <Select
            value={data.semester}
            onValueChange={(value) => onChange({ ...data, semester: value })}
          >
            <SelectTrigger id="semester" className="sm:w-1/2">
              <SelectValue placeholder="Select semester" />
            </SelectTrigger>
            <SelectContent>
              {semesters.map((sem) => (
                <SelectItem key={sem.value} value={sem.value}>
                  {sem.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="groupId">
            Student Group <span className="text-destructive">*</span>
          </Label>
          <Select
            value={data.groupId}
            onValueChange={(value) => onChange({ ...data, groupId: value })}
          >
            <SelectTrigger id="groupId">
              <SelectValue placeholder={groupsLoading ? "Loading..." : "Select student group"} />
            </SelectTrigger>
            <SelectContent>
              {groupsLoading ? (
                <div className="flex items-center justify-center p-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              ) : groups.length > 0 ? (
                groups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.group_code} - {group.group_name} ({group.member_count || 0} students)
                  </SelectItem>
                ))
              ) : (
                <div className="p-2 text-sm text-muted-foreground">No student groups found</div>
              )}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Only students in this group will be eligible for this exam
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Enter exam description, instructions, or notes for students..."
            value={data.description}
            onChange={(e) => onChange({ ...data, description: e.target.value })}
            rows={4}
          />
        </div>
      </div>
    </div>
  );
}
