import { format } from "date-fns";
import {
  FileText,
  Calendar,
  Users,
  FileQuestion,
  Eye,
  Shield,
  Award,
  Bell,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExamData } from "@/types/exam";

interface ReviewStepProps {
  data: ExamData;
  onEdit: (step: number) => void;
}

interface SectionCardProps {
  icon: React.ReactNode;
  title: string;
  step: number;
  onEdit: () => void;
  children: React.ReactNode;
  status?: "complete" | "incomplete" | "warning";
}

function SectionCard({ icon, title, step, onEdit, children, status = "complete" }: SectionCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3 bg-muted/30">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            {icon}
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            {status === "complete" && <CheckCircle className="h-4 w-4 text-success" />}
            {status === "incomplete" && <AlertCircle className="h-4 w-4 text-destructive" />}
            {status === "warning" && <AlertCircle className="h-4 w-4 text-warning" />}
            <button
              onClick={onEdit}
              className="text-xs text-primary hover:underline font-medium"
            >
              Edit
            </button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-4">{children}</CardContent>
    </Card>
  );
}

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border last:border-0">
      <span className="text-muted-foreground text-sm">{label}</span>
      <span className="font-medium text-sm text-right">{value}</span>
    </div>
  );
}

export function ReviewStep({ data, onEdit }: ReviewStepProps) {
  const totalMarks = data.questionPaper.questions.reduce((sum, q) => sum + q.marks, 0);
  const mcqCount = data.questionPaper.questions.filter(
    (q) => q.type === "mcq" || q.type === "true-false"
  ).length;
  const subjectiveCount = data.questionPaper.questions.filter(
    (q) => q.type === "subjective"
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <CheckCircle className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Review & Publish</h2>
          <p className="text-sm text-muted-foreground">
            Review all settings before publishing the exam
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <SectionCard
          icon={<FileText className="h-4 w-4 text-primary" />}
          title="Basic Information"
          step={1}
          onEdit={() => onEdit(1)}
          status={data.basicInfo.title && data.basicInfo.department ? "complete" : "incomplete"}
        >
          <div className="space-y-1">
            <InfoRow label="Title" value={data.basicInfo.title || "—"} />
            <InfoRow label="Code" value={data.basicInfo.code || "—"} />
            <InfoRow label="Department" value={data.basicInfo.department?.toUpperCase() || "—"} />
            <InfoRow label="Course" value={data.basicInfo.course?.toUpperCase() || "—"} />
            <InfoRow label="Semester" value={data.basicInfo.semester ? `Semester ${data.basicInfo.semester}` : "—"} />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Calendar className="h-4 w-4 text-primary" />}
          title="Schedule"
          step={2}
          onEdit={() => onEdit(2)}
          status={data.schedule.startDate && data.schedule.endDate ? "complete" : "incomplete"}
        >
          <div className="space-y-1">
            <InfoRow
              label="Start"
              value={data.schedule.startDate ? format(data.schedule.startDate, "PPP p") : "—"}
            />
            <InfoRow
              label="End"
              value={data.schedule.endDate ? format(data.schedule.endDate, "PPP p") : "—"}
            />
            <InfoRow label="Duration" value={`${data.schedule.duration} minutes`} />
            <InfoRow label="Late Entry" value={`${data.schedule.lateEntryBuffer} minutes`} />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Users className="h-4 w-4 text-primary" />}
          title="Eligibility"
          step={3}
          onEdit={() => onEdit(3)}
          status={data.eligibility.students.length > 0 ? "complete" : "warning"}
        >
          <div className="space-y-1">
            <InfoRow
              label="Students Enrolled"
              value={
                <Badge variant={data.eligibility.students.length > 0 ? "default" : "secondary"}>
                  {data.eligibility.students.length} students
                </Badge>
              }
            />
            {data.eligibility.studentGroup && (
              <InfoRow label="Student Group" value={data.eligibility.studentGroup} />
            )}
          </div>
        </SectionCard>

        <SectionCard
          icon={<FileQuestion className="h-4 w-4 text-primary" />}
          title="Question Paper"
          step={4}
          onEdit={() => onEdit(4)}
          status={data.questionPaper.questions.length > 0 ? "complete" : "warning"}
        >
          <div className="space-y-1">
            <InfoRow
              label="Total Questions"
              value={
                <Badge variant={data.questionPaper.questions.length > 0 ? "default" : "secondary"}>
                  {data.questionPaper.questions.length} questions
                </Badge>
              }
            />
            <InfoRow label="MCQ / T-F" value={`${mcqCount} questions`} />
            <InfoRow label="Subjective" value={`${subjectiveCount} questions`} />
            <InfoRow label="Total Marks" value={`${totalMarks} marks`} />
            <InfoRow
              label="Shuffle"
              value={
                <span className="flex gap-1">
                  {data.questionPaper.shuffleQuestions && (
                    <Badge variant="outline" className="text-xs">Questions</Badge>
                  )}
                  {data.questionPaper.shuffleOptions && (
                    <Badge variant="outline" className="text-xs">Options</Badge>
                  )}
                </span>
              }
            />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Eye className="h-4 w-4 text-primary" />}
          title="Proctoring"
          step={5}
          onEdit={() => onEdit(5)}
        >
          <div className="space-y-1">
            <InfoRow
              label="Remote Proctoring"
              value={data.proctoring.enableRemoteProctoring ? "Enabled" : "Disabled"}
            />
            <InfoRow
              label="Webcam"
              value={data.proctoring.requireWebcam ? "Required" : "Not Required"}
            />
            <InfoRow
              label="Screen Share"
              value={data.proctoring.screenShareRequired ? "Required" : "Not Required"}
            />
            <InfoRow
              label="Browser Lockdown"
              value={data.proctoring.fullBrowserLockdown ? "Enabled" : "Disabled"}
            />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Shield className="h-4 w-4 text-primary" />}
          title="Anti-Cheating"
          step={6}
          onEdit={() => onEdit(6)}
        >
          <div className="space-y-1">
            <InfoRow
              label="Face Match"
              value={data.antiCheating.faceMatchRequired ? "Required" : "Not Required"}
            />
            <InfoRow
              label="Tab Switch Block"
              value={data.antiCheating.tabSwitchBlocking ? "Enabled" : "Disabled"}
            />
            <InfoRow
              label="Copy/Paste Block"
              value={data.antiCheating.copyPasteBlocking ? "Enabled" : "Disabled"}
            />
            <InfoRow label="Allowed Devices" value={data.antiCheating.allowedDeviceCount} />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Award className="h-4 w-4 text-primary" />}
          title="Grading"
          step={7}
          onEdit={() => onEdit(7)}
        >
          <div className="space-y-1">
            <InfoRow
              label="Auto-grade MCQs"
              value={data.grading.autoGradeMcqs ? "Yes" : "No"}
            />
            <InfoRow
              label="Manual Subjective"
              value={data.grading.manualGradingSubjective ? "Yes" : "No"}
            />
            <InfoRow label="Passing Marks" value={`${data.grading.passingMarks} / ${totalMarks}`} />
            <InfoRow label="Rubric" value={data.grading.rubricTemplate || "Not Set"} />
          </div>
        </SectionCard>

        <SectionCard
          icon={<Bell className="h-4 w-4 text-primary" />}
          title="Notifications"
          step={8}
          onEdit={() => onEdit(8)}
        >
          <div className="space-y-1">
            <InfoRow
              label="Notify Students"
              value={data.notifications.notifyStudentsOnPublish ? "On Publish" : "No"}
            />
            <InfoRow
              label="Notify Proctors"
              value={data.notifications.notifyProctorsOnPublish ? "On Publish" : "No"}
            />
            <InfoRow
              label="Email Template"
              value={data.notifications.emailTemplate ? "Configured" : "Default"}
            />
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
