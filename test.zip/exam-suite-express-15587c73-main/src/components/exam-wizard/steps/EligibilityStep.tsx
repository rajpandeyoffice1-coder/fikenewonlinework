import { useState, useEffect } from "react";
import { Users, Plus, Upload, Trash2, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { ExamEligibility, Student } from "@/types/exam";
import { useStudentGroups } from "@/hooks/useStudentGroups";

interface EligibilityStepProps {
  data: ExamEligibility;
  onChange: (data: ExamEligibility) => void;
}

export function EligibilityStep({ data, onChange }: EligibilityStepProps) {
  const { groups, loading: groupsLoading, getGroupMembers } = useStudentGroups();
  const [rollNumber, setRollNumber] = useState("");
  const [loadingMembers, setLoadingMembers] = useState(false);

  const handleAddRollNumber = () => {
    if (!rollNumber.trim()) return;

    const newStudent: Student = {
      id: Date.now().toString(),
      rollNumber: rollNumber.trim().toUpperCase(),
      name: `Student ${rollNumber}`,
      email: `${rollNumber.toLowerCase()}@university.edu`,
    };

    if (!data.students.some((s) => s.rollNumber === newStudent.rollNumber)) {
      onChange({ ...data, students: [...data.students, newStudent] });
    }
    setRollNumber("");
  };

  const handleRemoveStudent = (id: string) => {
    onChange({ ...data, students: data.students.filter((s) => s.id !== id) });
  };

  const handleGroupSelect = async (groupId: string) => {
    setLoadingMembers(true);
    try {
      const members = await getGroupMembers(groupId);
      const groupStudents: Student[] = members
        .filter((m) => m.student)
        .map((m) => ({
          id: m.student!.id,
          rollNumber: m.student!.roll_no,
          name: m.student!.full_name,
          email: m.student!.email,
        }));

      const newStudents = groupStudents.filter(
        (gs) => !data.students.some((s) => s.rollNumber === gs.rollNumber)
      );
      onChange({
        ...data,
        studentGroup: groupId,
        students: [...data.students, ...newStudents],
      });
    } catch (error) {
      console.error("Error loading group members:", error);
    } finally {
      setLoadingMembers(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Parse CSV file
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split("\n").filter((line) => line.trim());
      
      // Skip header if present
      const startIndex = lines[0]?.toLowerCase().includes("roll") ? 1 : 0;
      
      const uploadedStudents: Student[] = [];
      for (let i = startIndex; i < lines.length; i++) {
        const parts = lines[i].split(",").map((p) => p.trim());
        if (parts[0]) {
          uploadedStudents.push({
            id: Date.now().toString() + i,
            rollNumber: parts[0].toUpperCase(),
            name: parts[1] || `Student ${parts[0]}`,
            email: parts[2] || `${parts[0].toLowerCase()}@university.edu`,
          });
        }
      }

      const newStudents = uploadedStudents.filter(
        (us) => !data.students.some((s) => s.rollNumber === us.rollNumber)
      );
      onChange({ ...data, students: [...data.students, ...newStudents] });
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleClearAll = () => {
    onChange({ ...data, students: [], studentGroup: "" });
  };

  const selectedGroup = groups.find((g) => g.id === data.studentGroup);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <Users className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Student Eligibility</h2>
          <p className="text-sm text-muted-foreground">Select students who can take this exam</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4">
          <h3 className="font-medium mb-3 text-sm">Add by Roll Number</h3>
          <div className="flex gap-2">
            <Input
              placeholder="Enter roll number"
              value={rollNumber}
              onChange={(e) => setRollNumber(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddRollNumber()}
            />
            <Button size="icon" onClick={handleAddRollNumber}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-medium mb-3 text-sm">Upload CSV</h3>
          <Label
            htmlFor="csvUpload"
            className="flex items-center justify-center gap-2 border-2 border-dashed border-border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <Upload className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Click to upload</span>
          </Label>
          <Input
            id="csvUpload"
            type="file"
            accept=".csv"
            className="hidden"
            onChange={handleFileUpload}
          />
        </Card>

        <Card className="p-4">
          <h3 className="font-medium mb-3 text-sm">Select Student Group</h3>
          <Select value={data.studentGroup} onValueChange={handleGroupSelect} disabled={loadingMembers}>
            <SelectTrigger>
              {loadingMembers ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Loading...</span>
                </div>
              ) : (
                <SelectValue placeholder={groupsLoading ? "Loading groups..." : "Choose group"} />
              )}
            </SelectTrigger>
            <SelectContent>
              {groupsLoading ? (
                <div className="flex items-center justify-center p-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              ) : groups.length > 0 ? (
                groups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.group_code} - {group.group_name} ({group.member_count || 0})
                  </SelectItem>
                ))
              ) : (
                <div className="p-2 text-sm text-muted-foreground">No groups found</div>
              )}
            </SelectContent>
          </Select>
          {selectedGroup && (
            <p className="text-xs text-muted-foreground mt-2">
              Selected: {selectedGroup.group_name}
            </p>
          )}
        </Card>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">
            Selected Students{" "}
            <span className="text-muted-foreground font-normal">
              ({data.students.length})
            </span>
          </h3>
          {data.students.length > 0 && (
            <Button variant="ghost" size="sm" onClick={handleClearAll} className="text-destructive hover:text-destructive">
              <Trash2 className="h-4 w-4 mr-1" />
              Clear All
            </Button>
          )}
        </div>

        {data.students.length === 0 ? (
          <Card className="p-8">
            <div className="text-center text-muted-foreground">
              <Users className="h-10 w-10 mx-auto mb-3 opacity-50" />
              <p className="font-medium">No students added yet</p>
              <p className="text-sm mt-1">Add students using the options above</p>
            </div>
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll Number</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.students.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">{student.rollNumber}</TableCell>
                    <TableCell>{student.name}</TableCell>
                    <TableCell className="text-muted-foreground">{student.email}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => handleRemoveStudent(student.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        )}
      </div>
    </div>
  );
}
