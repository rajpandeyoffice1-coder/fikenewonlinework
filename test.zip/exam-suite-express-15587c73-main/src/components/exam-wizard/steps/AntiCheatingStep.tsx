import { Shield, Scan, Users, AppWindow, Copy, Monitor, Globe } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ExamAntiCheating } from "@/types/exam";

interface AntiCheatingStepProps {
  data: ExamAntiCheating;
  onChange: (data: ExamAntiCheating) => void;
}

interface ToggleRowProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}

function ToggleRow({ icon, title, description, checked, onCheckedChange }: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-border last:border-0">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-muted shrink-0">
          {icon}
        </div>
        <div>
          <h4 className="font-medium text-foreground">{title}</h4>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

export function AntiCheatingStep({ data, onChange }: AntiCheatingStepProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <Shield className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Anti-Cheating Rules</h2>
          <p className="text-sm text-muted-foreground">Configure security measures to prevent cheating</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-0 divide-y divide-border">
          <div className="px-4">
            <ToggleRow
              icon={<Scan className="h-5 w-5 text-muted-foreground" />}
              title="Face Match Required"
              description="Verify candidate identity using facial recognition before exam starts"
              checked={data.faceMatchRequired}
              onCheckedChange={(checked) => onChange({ ...data, faceMatchRequired: checked })}
            />
          </div>

          <div className="px-4">
            <ToggleRow
              icon={<Users className="h-5 w-5 text-muted-foreground" />}
              title="Multiple Face Detection"
              description="Alert if more than one face is detected in the webcam feed"
              checked={data.multipleFaceDetection}
              onCheckedChange={(checked) => onChange({ ...data, multipleFaceDetection: checked })}
            />
          </div>

          <div className="px-4">
            <ToggleRow
              icon={<AppWindow className="h-5 w-5 text-muted-foreground" />}
              title="Tab Switch Blocking"
              description="Prevent or flag when candidate switches browser tabs"
              checked={data.tabSwitchBlocking}
              onCheckedChange={(checked) => onChange({ ...data, tabSwitchBlocking: checked })}
            />
          </div>

          <div className="px-4">
            <ToggleRow
              icon={<Copy className="h-5 w-5 text-muted-foreground" />}
              title="Copy/Paste Blocking"
              description="Disable copy and paste functionality during the exam"
              checked={data.copyPasteBlocking}
              onCheckedChange={(checked) => onChange({ ...data, copyPasteBlocking: checked })}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Monitor className="h-4 w-4 text-primary" />
              Allowed Device Count
            </CardTitle>
            <CardDescription>Maximum devices per candidate</CardDescription>
          </CardHeader>
          <CardContent>
            <Select
              value={data.allowedDeviceCount.toString()}
              onValueChange={(value) => onChange({ ...data, allowedDeviceCount: parseInt(value) })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 Device Only</SelectItem>
                <SelectItem value="2">Up to 2 Devices</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              IP Range Restriction
            </CardTitle>
            <CardDescription>Limit access to specific IP ranges (optional)</CardDescription>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="e.g., 192.168.1.0/24"
              value={data.ipRangeRestriction}
              onChange={(e) => onChange({ ...data, ipRangeRestriction: e.target.value })}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
