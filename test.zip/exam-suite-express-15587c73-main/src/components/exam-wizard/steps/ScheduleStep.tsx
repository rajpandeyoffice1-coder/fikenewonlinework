import { useState, useEffect } from "react";
import { Calendar, Clock, Globe, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";
import { ExamSchedule } from "@/types/exam";

interface ScheduleStepProps {
  data: ExamSchedule;
  onChange: (data: ExamSchedule) => void;
}

const timezones = [
  { value: "Asia/Kolkata", label: "India Standard Time (IST)" },
  { value: "America/New_York", label: "Eastern Time (ET)" },
  { value: "America/Los_Angeles", label: "Pacific Time (PT)" },
  { value: "Europe/London", label: "Greenwich Mean Time (GMT)" },
  { value: "Asia/Singapore", label: "Singapore Time (SGT)" },
  { value: "Asia/Dubai", label: "Gulf Standard Time (GST)" },
];

export function ScheduleStep({ data, onChange }: ScheduleStepProps) {
  const [dateError, setDateError] = useState<string | null>(null);

  // Validate dates whenever they change
  useEffect(() => {
    if (data.startDate && data.endDate) {
      if (data.endDate < data.startDate) {
        setDateError("End date cannot be before Start date");
      } else {
        setDateError(null);
      }
    } else {
      setDateError(null);
    }
  }, [data.startDate, data.endDate]);

  const handleEndDateSelect = (date: Date | undefined) => {
    if (date && data.startDate && date < data.startDate) {
      setDateError("End date cannot be before Start date");
    }
    onChange({ ...data, endDate: date });
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="flex items-center gap-3 pb-4 border-b border-border">
          <div className="p-2 rounded-lg bg-primary/10">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Schedule & Timing</h2>
            <p className="text-sm text-muted-foreground">Set when the exam will be available</p>
          </div>
        </div>

        {dateError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{dateError}</AlertDescription>
          </Alert>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>
              Start Date & Time <span className="text-destructive">*</span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !data.startDate && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {data.startDate ? format(data.startDate, "PPP p") : "Select start date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={data.startDate}
                  onSelect={(date) => onChange({ ...data, startDate: date })}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
                <div className="p-3 border-t border-border">
                  <Label className="text-xs text-muted-foreground">Time</Label>
                  <Input
                    type="time"
                    className="mt-1"
                    value={data.startDate ? format(data.startDate, "HH:mm") : ""}
                    onChange={(e) => {
                      if (data.startDate) {
                        const [hours, minutes] = e.target.value.split(":");
                        const newDate = new Date(data.startDate);
                        newDate.setHours(parseInt(hours), parseInt(minutes));
                        onChange({ ...data, startDate: newDate });
                      }
                    }}
                  />
                </div>
              </PopoverContent>
            </Popover>
            <p className="text-xs text-muted-foreground">Past dates are allowed for backdated exams</p>
          </div>

          <div className="space-y-2">
            <Label>
              End Date & Time <span className="text-destructive">*</span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !data.endDate && "text-muted-foreground",
                    dateError && "border-destructive"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {data.endDate ? format(data.endDate, "PPP p") : "Select end date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={data.endDate}
                  onSelect={handleEndDateSelect}
                  disabled={(date) => data.startDate ? date < data.startDate : false}
                  initialFocus
                  className="p-3 pointer-events-auto"
                />
                <div className="p-3 border-t border-border">
                  <Label className="text-xs text-muted-foreground">Time</Label>
                  <Input
                    type="time"
                    className="mt-1"
                    value={data.endDate ? format(data.endDate, "HH:mm") : ""}
                    onChange={(e) => {
                      if (data.endDate) {
                        const [hours, minutes] = e.target.value.split(":");
                        const newDate = new Date(data.endDate);
                        newDate.setHours(parseInt(hours), parseInt(minutes));
                        handleEndDateSelect(newDate);
                      }
                    }}
                  />
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="duration">
              Exam Duration <span className="text-destructive">*</span>
            </Label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="duration"
                type="number"
                min={1}
                placeholder="60"
                value={data.duration}
                onChange={(e) =>
                  onChange({ ...data, duration: parseInt(e.target.value) || 0 })
                }
                className="pl-10"
              />
            </div>
            <p className="text-xs text-muted-foreground">Duration in minutes</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="lateEntry">Late Entry Buffer</Label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="lateEntry"
                type="number"
                min={0}
                placeholder="10"
                value={data.lateEntryBuffer}
                onChange={(e) =>
                  onChange({ ...data, lateEntryBuffer: parseInt(e.target.value) || 0 })
                }
                className="pl-10"
              />
            </div>
            <p className="text-xs text-muted-foreground">Minutes allowed for late entry</p>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="timezone">
            Timezone <span className="text-destructive">*</span>
          </Label>
          <Select
            value={data.timezone}
            onValueChange={(value) => onChange({ ...data, timezone: value })}
          >
            <SelectTrigger id="timezone" className="sm:w-2/3">
              <Globe className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Select timezone" />
            </SelectTrigger>
            <SelectContent>
              {timezones.map((tz) => (
                <SelectItem key={tz.value} value={tz.value}>
                  {tz.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="lg:col-span-1">
        <Card className="sticky top-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              Schedule Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Start</span>
              <span className="font-medium">
                {data.startDate ? format(data.startDate, "PPP p") : "Not set"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">End</span>
              <span className={cn("font-medium", dateError && "text-destructive")}>
                {data.endDate ? format(data.endDate, "PPP p") : "Not set"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Duration</span>
              <span className="font-medium">{data.duration} minutes</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Late Buffer</span>
              <span className="font-medium">{data.lateEntryBuffer} minutes</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Timezone</span>
              <span className="font-medium text-right text-xs">
                {timezones.find((tz) => tz.value === data.timezone)?.label || data.timezone}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
