import { Bell, Mail, MessageSquare, Send } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ExamNotifications } from "@/types/exam";

interface NotificationsStepProps {
  data: ExamNotifications;
  onChange: (data: ExamNotifications) => void;
}

export function NotificationsStep({ data, onChange }: NotificationsStepProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <Bell className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Notifications</h2>
          <p className="text-sm text-muted-foreground">Configure email and SMS notifications</p>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Mail className="h-4 w-4 text-primary" />
            Email Notification Template
          </CardTitle>
          <CardDescription>
            Use placeholders: {"{{exam_title}}"}, {"{{exam_date}}"}, {"{{duration}}"}, {"{{student_name}}"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={data.emailTemplate}
            onChange={(e) => onChange({ ...data, emailTemplate: e.target.value })}
            rows={8}
            className="font-mono text-sm"
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-primary" />
            SMS Notification Template
          </CardTitle>
          <CardDescription>
            Keep it brief (160 characters recommended). Same placeholders available.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={data.smsTemplate}
            onChange={(e) => onChange({ ...data, smsTemplate: e.target.value })}
            rows={3}
            className="font-mono text-sm"
          />
          <p className="text-xs text-muted-foreground mt-2">
            {data.smsTemplate.length} / 160 characters
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Send className="h-4 w-4 text-primary" />
            Auto-send on Publish
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="notifyStudents" className="font-medium cursor-pointer">
                Notify Students
              </Label>
              <p className="text-sm text-muted-foreground">
                Send email and SMS to all enrolled students when exam is published
              </p>
            </div>
            <Switch
              id="notifyStudents"
              checked={data.notifyStudentsOnPublish}
              onCheckedChange={(checked) => onChange({ ...data, notifyStudentsOnPublish: checked })}
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              <Label htmlFor="notifyProctors" className="font-medium cursor-pointer">
                Notify Proctors
              </Label>
              <p className="text-sm text-muted-foreground">
                Send notification to assigned proctors when exam is published
              </p>
            </div>
            <Switch
              id="notifyProctors"
              checked={data.notifyProctorsOnPublish}
              onCheckedChange={(checked) => onChange({ ...data, notifyProctorsOnPublish: checked })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
