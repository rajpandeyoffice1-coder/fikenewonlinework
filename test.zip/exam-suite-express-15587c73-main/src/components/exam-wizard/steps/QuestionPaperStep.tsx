import { useState, useEffect } from "react";
import { FileQuestion, Database, Upload, Shuffle, Pencil, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { ExamQuestionPaper, Question } from "@/types/exam";
import { useQuestionBank, QuestionFromDB } from "@/hooks/useQuestionBank";

interface QuestionPaperStepProps {
  data: ExamQuestionPaper;
  onChange: (data: ExamQuestionPaper) => void;
  selectedSubject?: string;
}

const difficultyColors: Record<string, string> = {
  easy: "text-green-600 bg-green-100",
  medium: "text-yellow-600 bg-yellow-100",
  hard: "text-red-600 bg-red-100",
};

const typeLabels: Record<string, string> = {
  mcq: "MCQ",
  mcq_single: "MCQ (Single)",
  mcq_multiple: "MCQ (Multiple)",
  true_false: "True/False",
  subjective: "Subjective",
  short_answer: "Short Answer",
  long_answer: "Long Answer",
  file_upload: "File Upload",
  coding: "Code",
  // DB format fallbacks
  "mcq-single": "MCQ (Single)",
  "mcq-multiple": "MCQ (Multiple)",
  "true-false": "True/False",
  "short-answer": "Short Answer",
  "long-answer": "Long Answer",
  "file-upload": "File Upload",
  code: "Code",
};

// Convert database question to exam question format
const mapDbQuestionToExamQuestion = (q: QuestionFromDB): Question => ({
  id: q.id,
  text: q.question_text,
  type: q.type as "mcq" | "true-false" | "subjective",
  marks: q.marks,
  difficulty: q.difficulty as "easy" | "medium" | "hard",
});

export function QuestionPaperStep({ data, onChange, selectedSubject }: QuestionPaperStepProps) {
  const [isQuestionBankOpen, setIsQuestionBankOpen] = useState(false);
  const { questions: dbQuestions, isLoading, refetch } = useQuestionBank(selectedSubject);

  // Refetch questions when subject changes
  useEffect(() => {
    if (selectedSubject) {
      refetch(selectedSubject);
    }
  }, [selectedSubject, refetch]);

  const totalMarks = data.questions.reduce((sum, q) => sum + q.marks, 0);

  const handleAddFromBank = (question: QuestionFromDB) => {
    const examQuestion = mapDbQuestionToExamQuestion(question);
    if (!data.questions.some((q) => q.id === examQuestion.id)) {
      onChange({ ...data, questions: [...data.questions, examQuestion] });
    }
  };

  const handleRemoveQuestion = (id: string) => {
    onChange({ ...data, questions: data.questions.filter((q) => q.id !== id) });
  };

  const handleImportQuestions = () => {
    // TODO: Implement file import
    console.log("Import questions feature coming soon");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-border">
        <div className="p-2 rounded-lg bg-primary/10">
          <FileQuestion className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-foreground">Question Paper</h2>
          <p className="text-sm text-muted-foreground">
            Configure questions for the exam
            {selectedSubject && (
              <span className="ml-1 text-primary">• Filtered by: {selectedSubject}</span>
            )}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <Dialog open={isQuestionBankOpen} onOpenChange={setIsQuestionBankOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Choose from Question Bank
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                Question Bank
                {selectedSubject && (
                  <span className="text-sm font-normal text-muted-foreground ml-2">
                    (Showing questions for: {selectedSubject})
                  </span>
                )}
              </DialogTitle>
            </DialogHeader>
            <div className="mt-4">
              {isLoading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  <span className="ml-2 text-muted-foreground">Loading questions...</span>
                </div>
              ) : dbQuestions.length === 0 ? (
                <div className="text-center p-8 text-muted-foreground">
                  <FileQuestion className="h-10 w-10 mx-auto mb-3 opacity-50" />
                  <p className="font-medium">No questions found</p>
                  <p className="text-sm mt-1">
                    {selectedSubject
                      ? `No questions available for "${selectedSubject}". Add questions in the Question Bank first.`
                      : "Add questions in the Question Bank first."}
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Question</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Marks</TableHead>
                      <TableHead>Difficulty</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dbQuestions.map((question) => {
                      const isAdded = data.questions.some((q) => q.id === question.id);
                      return (
                        <TableRow key={question.id}>
                          <TableCell className="max-w-[250px] truncate">{question.question_text}</TableCell>
                          <TableCell className="text-xs">{question.subject}</TableCell>
                          <TableCell>
                            <span className="px-2 py-1 rounded text-xs bg-primary/10 text-primary">
                              {typeLabels[question.type] || question.type}
                            </span>
                          </TableCell>
                          <TableCell>{question.marks}</TableCell>
                          <TableCell>
                            <span className={cn("px-2 py-1 rounded text-xs capitalize", difficultyColors[question.difficulty] || "bg-muted")}>
                              {question.difficulty}
                            </span>
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant={isAdded ? "secondary" : "default"}
                              disabled={isAdded}
                              onClick={() => handleAddFromBank(question)}
                            >
                              {isAdded ? "Added" : "Add"}
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </div>
          </DialogContent>
        </Dialog>

        <Button variant="outline" onClick={handleImportQuestions}>
          <Upload className="h-4 w-4 mr-2" />
          Import Questions (CSV/QTI)
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-3">
            <Switch
              id="shuffleQuestions"
              checked={data.shuffleQuestions}
              onCheckedChange={(checked) => onChange({ ...data, shuffleQuestions: checked })}
            />
            <Label htmlFor="shuffleQuestions" className="cursor-pointer flex items-center gap-2">
              <Shuffle className="h-4 w-4 text-muted-foreground" />
              Shuffle Questions Per Candidate
            </Label>
          </div>

          <div className="flex items-center gap-3">
            <Switch
              id="shuffleOptions"
              checked={data.shuffleOptions}
              onCheckedChange={(checked) => onChange({ ...data, shuffleOptions: checked })}
            />
            <Label htmlFor="shuffleOptions" className="cursor-pointer flex items-center gap-2">
              <Shuffle className="h-4 w-4 text-muted-foreground" />
              Shuffle Options
            </Label>
          </div>
        </div>
      </Card>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">
            Questions{" "}
            <span className="text-muted-foreground font-normal">
              ({data.questions.length} questions, {totalMarks} marks)
            </span>
          </h3>
        </div>

        {data.questions.length === 0 ? (
          <Card className="p-8">
            <div className="text-center text-muted-foreground">
              <FileQuestion className="h-10 w-10 mx-auto mb-3 opacity-50" />
              <p className="font-medium">No questions added yet</p>
              <p className="text-sm mt-1">Add questions from the question bank or import from file</p>
            </div>
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead>Question</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Marks</TableHead>
                  <TableHead>Difficulty</TableHead>
                  <TableHead className="w-24">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.questions.map((question, index) => (
                  <TableRow key={question.id}>
                    <TableCell className="text-muted-foreground">{index + 1}</TableCell>
                    <TableCell className="max-w-[300px] truncate font-medium">{question.text}</TableCell>
                    <TableCell>
                      <span className="px-2 py-1 rounded text-xs bg-primary/10 text-primary">
                        {typeLabels[question.type] || question.type}
                      </span>
                    </TableCell>
                    <TableCell>{question.marks}</TableCell>
                    <TableCell>
                      <span className={cn("px-2 py-1 rounded text-xs capitalize", difficultyColors[question.difficulty] || "bg-muted")}>
                        {question.difficulty}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => handleRemoveQuestion(question.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        )}
      </div>
    </div>
  );
}
