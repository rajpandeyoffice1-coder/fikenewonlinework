import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowRight, Save, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { WizardProgress } from "./WizardProgress";
import { BasicInfoStep } from "./steps/BasicInfoStep";
import { ScheduleStep } from "./steps/ScheduleStep";
import { EligibilityStep } from "./steps/EligibilityStep";
import { QuestionPaperStep } from "./steps/QuestionPaperStep";
import { ProctoringStep } from "./steps/ProctoringStep";
import { AntiCheatingStep } from "./steps/AntiCheatingStep";
import { GradingStep } from "./steps/GradingStep";
import { NotificationsStep } from "./steps/NotificationsStep";
import { ReviewStep } from "./steps/ReviewStep";
import { ExamData, initialExamData } from "@/types/exam";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { Json } from "@/integrations/supabase/types";

const steps = [
  { id: 1, title: "Basic Information", shortTitle: "Basic Info" },
  { id: 2, title: "Schedule & Timing", shortTitle: "Schedule" },
  { id: 3, title: "Student Eligibility", shortTitle: "Eligibility" },
  { id: 4, title: "Question Paper", shortTitle: "Questions" },
  { id: 5, title: "Proctoring Settings", shortTitle: "Proctoring" },
  { id: 6, title: "Anti-Cheating Rules", shortTitle: "Security" },
  { id: 7, title: "Grading Setup", shortTitle: "Grading" },
  { id: 8, title: "Notifications", shortTitle: "Notify" },
  { id: 9, title: "Review & Publish", shortTitle: "Review" },
];

export function ExamWizard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [examData, setExamData] = useState<ExamData>(initialExamData);
  const [isSaving, setIsSaving] = useState(false);
  const [publishProgress, setPublishProgress] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem("examDraft");
    if (saved) setExamData(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("examDraft", JSON.stringify(examData));
  }, [examData]);

  const handleNext = () => {
    if (!completedSteps.includes(currentStep)) {
      setCompletedSteps([...completedSteps, currentStep]);
    }
    if (currentStep < steps.length) setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  // Validate schedule dates
  const validateSchedule = () => {
    if (examData.schedule.startDate && examData.schedule.endDate) {
      if (examData.schedule.endDate < examData.schedule.startDate) {
        toast({ title: "Invalid Schedule", description: "End date cannot be before Start date.", variant: "destructive" });
        return false;
      }
    }
    return true;
  };

  // Helper to safely convert date to ISO string
  const toISOString = (date: Date | string | null | undefined): string | null => {
    if (!date) return null;
    if (typeof date === 'string') return date;
    if (date instanceof Date) return date.toISOString();
    return null;
  };

  // Map ExamData to database schema
  const mapExamToDb = (status: string) => {
    const totalMarks = examData.questionPaper.questions.reduce((sum, q) => sum + q.marks, 0) || examData.grading.totalMarks;
    
    // Settings object - cast to Json type for Supabase
    const settings: Json = {
      schedule: {
        lateEntryBuffer: examData.schedule.lateEntryBuffer,
        timezone: examData.schedule.timezone,
      },
      eligibility: {
        students: examData.eligibility.students.map(s => ({
          id: s.id,
          rollNumber: s.rollNumber,
          name: s.name,
          email: s.email,
        })),
        studentGroup: examData.eligibility.studentGroup,
      },
      questionPaper: {
        shuffleQuestions: examData.questionPaper.shuffleQuestions,
        shuffleOptions: examData.questionPaper.shuffleOptions,
      },
      proctoring: {
        enableRemoteProctoring: examData.proctoring.enableRemoteProctoring,
        requireWebcam: examData.proctoring.requireWebcam,
        requireMicrophone: examData.proctoring.requireMicrophone,
        screenShareRequired: examData.proctoring.screenShareRequired,
        fullBrowserLockdown: examData.proctoring.fullBrowserLockdown,
        proctorAssignment: examData.proctoring.proctorAssignment,
      },
      antiCheating: {
        faceMatchRequired: examData.antiCheating.faceMatchRequired,
        multipleFaceDetection: examData.antiCheating.multipleFaceDetection,
        tabSwitchBlocking: examData.antiCheating.tabSwitchBlocking,
        copyPasteBlocking: examData.antiCheating.copyPasteBlocking,
        allowedDeviceCount: examData.antiCheating.allowedDeviceCount,
        ipRangeRestriction: examData.antiCheating.ipRangeRestriction,
      },
      grading: {
        autoGradeMcqs: examData.grading.autoGradeMcqs,
        manualGradingSubjective: examData.grading.manualGradingSubjective,
        rubricTemplate: examData.grading.rubricTemplate,
      },
      notifications: {
        emailTemplate: examData.notifications.emailTemplate,
        smsTemplate: examData.notifications.smsTemplate,
        notifyStudentsOnPublish: examData.notifications.notifyStudentsOnPublish,
        notifyProctorsOnPublish: examData.notifications.notifyProctorsOnPublish,
      },
    };

    return {
      user_id: user?.id,
      code: examData.basicInfo.code,
      title: examData.basicInfo.title,
      department: examData.basicInfo.department,
      course: examData.basicInfo.course,
      semester: examData.basicInfo.semester,
      description: examData.basicInfo.description,
      group_id: examData.basicInfo.groupId || null,
      duration: examData.schedule.duration,
      start_date: toISOString(examData.schedule.startDate),
      end_date: toISOString(examData.schedule.endDate),
      total_marks: totalMarks,
      passing_marks: examData.grading.passingMarks,
      status,
      settings,
    };
  };

  // Save exam questions to exam_questions table
  const saveExamQuestions = async (examId: string) => {
    if (examData.questionPaper.questions.length === 0) return true;

    const examQuestions = examData.questionPaper.questions.map((q, index) => ({
      exam_id: examId,
      question_id: q.id,
      question_order: index + 1,
      marks: q.marks,
    }));

    const { error } = await supabase.from("exam_questions").insert(examQuestions);
    
    if (error) {
      console.error("Error saving exam questions:", error);
      return false;
    }
    return true;
  };

  // Auto-enroll students from the assigned group
  const enrollStudentsFromGroup = async (examId: string, groupId: string | null) => {
    if (!groupId) {
      console.log("No group assigned, skipping auto-enrollment");
      return { success: true, count: 0 };
    }

    // Fetch all students in the group
    const { data: groupMembers, error: fetchError } = await supabase
      .from("student_group_members")
      .select("student_id")
      .eq("group_id", groupId);

    if (fetchError) {
      console.error("Error fetching group members:", fetchError);
      return { success: false, count: 0 };
    }

    if (!groupMembers || groupMembers.length === 0) {
      console.log("No students in group to enroll");
      return { success: true, count: 0 };
    }

    // Create enrollment records for each student
    const enrollments = groupMembers.map((member) => ({
      exam_id: examId,
      student_id: member.student_id,
      status: "enrolled",
    }));

    const { error: enrollError } = await supabase
      .from("exam_enrollments")
      .insert(enrollments);

    if (enrollError) {
      console.error("Error enrolling students:", enrollError);
      return { success: false, count: 0 };
    }

    console.log(`Successfully enrolled ${enrollments.length} students`);
    return { success: true, count: enrollments.length };
  };

  const handleSaveDraft = async () => {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in to save.", variant: "destructive" });
      return;
    }

    if (!examData.basicInfo.title || !examData.basicInfo.code) {
      toast({ title: "Missing Info", description: "Please fill in exam title and code.", variant: "destructive" });
      return;
    }

    if (!validateSchedule()) return;

    setIsSaving(true);
    const dbData = mapExamToDb("draft");

    const { data: insertedExam, error } = await supabase.from("exams").insert([dbData]).select().single();

    if (error) {
      setIsSaving(false);
      console.error("Error saving draft:", error);
      toast({ title: "Error", description: "Failed to save draft. " + error.message, variant: "destructive" });
      return;
    }

    // Save exam questions
    if (insertedExam) {
      await saveExamQuestions(insertedExam.id);
    }

    setIsSaving(false);
    localStorage.removeItem("examDraft");
    toast({ title: "Draft Saved", description: "Your exam has been saved as a draft." });
    navigate("/exams");
  };

  const handlePublish = async () => {
    console.log("handlePublish called");
    if (!user) {
      toast({ title: "Error", description: "You must be logged in to publish.", variant: "destructive" });
      return;
    }

    if (!examData.basicInfo.title || !examData.basicInfo.code || !examData.basicInfo.department) {
      console.log("Missing required fields:", { 
        title: examData.basicInfo.title, 
        code: examData.basicInfo.code, 
        department: examData.basicInfo.department 
      });
      toast({ title: "Missing Info", description: "Please fill in all required exam details.", variant: "destructive" });
      return;
    }

    if (!validateSchedule()) return;

    setIsSaving(true);
    setPublishProgress("Saving exam details...");
    
    const dbData = mapExamToDb("scheduled");
    console.log("Publishing exam with data:", dbData);

    const { data: insertedExam, error } = await supabase.from("exams").insert([dbData]).select().single();

    if (error) {
      setIsSaving(false);
      setPublishProgress(null);
      console.error("Error publishing exam:", error);
      toast({ title: "Error", description: "Failed to publish exam. " + error.message, variant: "destructive" });
      return;
    }

    // Save exam questions
    if (insertedExam && examData.questionPaper.questions.length > 0) {
      setPublishProgress("Adding questions...");
      const questionsSuccess = await saveExamQuestions(insertedExam.id);
      if (!questionsSuccess) {
        toast({ title: "Warning", description: "Exam published but some questions may not have been saved.", variant: "destructive" });
      }
    }

    // Auto-enroll students from the assigned group
    if (insertedExam) {
      setPublishProgress("Enrolling students...");
      const groupId = examData.basicInfo.groupId || examData.eligibility.studentGroup;
      const enrollment = await enrollStudentsFromGroup(insertedExam.id, groupId);
      if (!enrollment.success) {
        toast({ title: "Warning", description: "Exam published but student enrollment may have failed.", variant: "destructive" });
      } else if (enrollment.count > 0) {
        console.log(`Enrolled ${enrollment.count} students from group`);
      }
    }

    setPublishProgress("Finalizing...");
    
    setIsSaving(false);
    setPublishProgress(null);
    localStorage.removeItem("examDraft");
    const groupId = examData.basicInfo.groupId || examData.eligibility.studentGroup;
    const enrollmentMsg = groupId ? " Students from the assigned group have been enrolled." : "";
    toast({ title: "Exam Published!", description: `The exam is now scheduled.${enrollmentMsg}` });
    navigate("/exams");
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1: return <BasicInfoStep data={examData.basicInfo} onChange={(d) => setExamData({ ...examData, basicInfo: d })} />;
      case 2: return <ScheduleStep data={examData.schedule} onChange={(d) => setExamData({ ...examData, schedule: d })} />;
      case 3: return <EligibilityStep data={examData.eligibility} onChange={(d) => setExamData({ ...examData, eligibility: d })} />;
      case 4: return <QuestionPaperStep data={examData.questionPaper} onChange={(d) => setExamData({ ...examData, questionPaper: d })} selectedSubject={examData.basicInfo.course} />;
      case 5: return <ProctoringStep data={examData.proctoring} onChange={(d) => setExamData({ ...examData, proctoring: d })} />;
      case 6: return <AntiCheatingStep data={examData.antiCheating} onChange={(d) => setExamData({ ...examData, antiCheating: d })} />;
      case 7: return <GradingStep data={examData.grading} onChange={(d) => setExamData({ ...examData, grading: d })} questionPaper={examData.questionPaper} />;
      case 8: return <NotificationsStep data={examData.notifications} onChange={(d) => setExamData({ ...examData, notifications: d })} />;
      case 9: return <ReviewStep data={examData} onEdit={setCurrentStep} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="h-16 border-b border-border bg-card px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">Create New Exam</h1>
        </div>
        <Button variant="outline" onClick={handleSaveDraft} disabled={isSaving}>
          {isSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          Save Draft
        </Button>
      </header>

      <WizardProgress steps={steps} currentStep={currentStep} onStepClick={setCurrentStep} completedSteps={completedSteps} />

      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-4xl mx-auto animate-fade-in">{renderStep()}</div>
      </main>

      <footer className="border-t border-border bg-card px-6 py-4 sticky bottom-0">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <Button variant="outline" onClick={handleBack} disabled={currentStep === 1 || isSaving}><ArrowLeft className="h-4 w-4 mr-2" />Back</Button>
          
          {publishProgress && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>{publishProgress}</span>
            </div>
          )}
          
          <div className="flex gap-3">
            {currentStep === 9 ? (
              <>
                <Button variant="outline" onClick={handleSaveDraft} disabled={isSaving}>
                  {isSaving && !publishProgress ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                  Save as Draft
                </Button>
                <Button onClick={handlePublish} disabled={isSaving}>
                  {isSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
                  {publishProgress || "Publish Exam"}
                </Button>
              </>
            ) : (
              <Button onClick={handleNext}>Next<ArrowRight className="h-4 w-4 ml-2" /></Button>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
