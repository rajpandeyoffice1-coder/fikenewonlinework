import { Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth, getRedirectPath } from '@/hooks/useAuth';

/**
 * Root redirect component that handles the base URL "/"
 * - Unauthenticated users → /login
 * - Authenticated users → role-based dashboard
 */
export function AuthRedirect() {
  const { isAuthenticated, role, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-teal-600 mx-auto mb-4" />
          <p className="text-slate-500">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Redirect to role-based dashboard
  const redirectPath = getRedirectPath(role);
  return <Navigate to={redirectPath} replace />;
}
