import { useState, useMemo, useEffect } from 'react';
import { DateRange } from 'react-day-picker';
import { Loader2 } from 'lucide-react';
import { AuditLogFilters } from './AuditLogFilters';
import { AuditLogInsights } from './AuditLogInsights';
import { SecurityInsights } from './SecurityInsights';
import { AuditLogTable } from './AuditLogTable';
import { AuditLogDetailModal } from './AuditLogDetailModal';
import { AuditLogEntry, AuditLogInsight, SecurityAlert } from '@/types/auditLog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function AuditLogPage() {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [userType, setUserType] = useState('all');
  const [actionType, setActionType] = useState('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [ipFilter, setIpFilter] = useState('');
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  // Fetch audit logs from database
  useEffect(() => {
    const fetchLogs = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(500);

      if (error) {
        console.error('Error fetching audit logs:', error);
        toast.error('Failed to load audit logs');
      } else {
        const formattedLogs: AuditLogEntry[] = (data || []).map((log: any) => ({
          id: log.id,
          timestamp: log.created_at,
          user: {
            id: log.user_id || 'unknown',
            name: log.user_name,
            email: log.user_email,
            role: log.user_role as any,
          },
          action: log.action as any,
          actionDescription: log.action_description,
          target: {
            type: log.target_type as any,
            id: log.target_id || '',
            name: log.target_name || '',
          },
          ipAddress: log.ip_address || 'Unknown',
          device: {
            browser: log.browser || 'Unknown',
            os: log.os || 'Unknown',
            deviceType: (log.device_type || 'Desktop') as any,
          },
          metadata: {
            sessionId: log.session_id || '',
            requestId: log.id,
          },
          changes: log.changes,
          rawLog: log.raw_log || {},
        }));
        setLogs(formattedLogs);
      }
      setIsLoading(false);
    };

    fetchLogs();
  }, []);

  // Calculate insights from actual data
  const insights: AuditLogInsight = useMemo(() => {
    const highRiskActions = logs.filter(
      (l) => l.action === 'Failed Login' || l.action === 'Role Update' || l.action === 'Settings Change'
    ).length;
    
    const userActionCounts: Record<string, { name: string; count: number }> = {};
    logs.forEach((log) => {
      if (!userActionCounts[log.user.id]) {
        userActionCounts[log.user.id] = { name: log.user.name, count: 0 };
      }
      userActionCounts[log.user.id].count++;
    });
    
    const mostActive = Object.values(userActionCounts).sort((a, b) => b.count - a.count)[0] || {
      name: 'N/A',
      count: 0,
    };

    const failedLogins = logs.filter((l) => l.action === 'Failed Login').length;

    return {
      totalLogs: logs.length,
      highRiskActions,
      mostActiveUser: { name: mostActive.name, actionCount: mostActive.count },
      failedLoginAttempts: failedLogins,
    };
  }, [logs]);

  // Generate security alerts from logs
  const securityAlerts: SecurityAlert[] = useMemo(() => {
    const alerts: SecurityAlert[] = [];
    
    // Find failed logins
    const failedLogins = logs.filter((l) => l.action === 'Failed Login');
    if (failedLogins.length > 0) {
      alerts.push({
        id: 'alert-failed-logins',
        type: 'failed_login',
        severity: failedLogins.length >= 5 ? 'high' : 'medium',
        description: `${failedLogins.length} failed login attempts detected`,
        timestamp: failedLogins[0]?.timestamp || new Date().toISOString(),
        userId: failedLogins[0]?.user.id || '',
        userName: failedLogins[0]?.user.name || 'Unknown',
        count: failedLogins.length,
      });
    }

    // Find role changes
    const roleChanges = logs.filter((l) => l.action === 'Role Update');
    roleChanges.slice(0, 3).forEach((log, i) => {
      alerts.push({
        id: `alert-role-${i}`,
        type: 'role_change',
        severity: 'high',
        description: log.actionDescription,
        timestamp: log.timestamp,
        userId: log.target.id,
        userName: log.target.name,
      });
    });

    return alerts;
  }, [logs]);

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch =
        searchQuery === '' ||
        log.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        log.user.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        log.user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        log.actionDescription.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesUserType =
        userType === 'all' || log.user.role === userType;

      const matchesActionType =
        actionType === 'all' || log.action === actionType;

      const matchesIp =
        ipFilter === '' || log.ipAddress.includes(ipFilter);

      const logDate = new Date(log.timestamp);
      const matchesDateRange =
        !dateRange?.from ||
        (logDate >= dateRange.from &&
          (!dateRange.to || logDate <= dateRange.to));

      return (
        matchesSearch &&
        matchesUserType &&
        matchesActionType &&
        matchesIp &&
        matchesDateRange
      );
    });
  }, [logs, searchQuery, userType, actionType, ipFilter, dateRange]);

  const handleExport = () => {
    const csvContent = [
      ['Timestamp', 'User', 'Role', 'Action', 'Description', 'IP Address'].join(','),
      ...filteredLogs.map((log) =>
        [
          log.timestamp,
          log.user.name,
          log.user.role,
          log.action,
          `"${log.actionDescription}"`,
          log.ipAddress,
        ].join(',')
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `audit-logs-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Audit logs exported successfully');
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setUserType('all');
    setActionType('all');
    setDateRange(undefined);
    setIpFilter('');
    toast.success('Filters cleared');
  };

  const handleViewLog = (log: AuditLogEntry) => {
    setSelectedLog(log);
    setDetailModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Audit Log</h1>
        <p className="text-muted-foreground">
          Track all system activities and user actions
        </p>
      </div>

      <AuditLogFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        userType={userType}
        onUserTypeChange={setUserType}
        actionType={actionType}
        onActionTypeChange={setActionType}
        dateRange={dateRange}
        onDateRangeChange={setDateRange}
        ipFilter={ipFilter}
        onIpFilterChange={setIpFilter}
        onExport={handleExport}
        onClearFilters={handleClearFilters}
      />

      <AuditLogInsights insights={insights} />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <AuditLogTable logs={filteredLogs} onViewLog={handleViewLog} />
        </div>
        <div className="lg:col-span-1">
          <SecurityInsights alerts={securityAlerts} />
        </div>
      </div>

      <AuditLogDetailModal
        log={selectedLog}
        open={detailModalOpen}
        onOpenChange={setDetailModalOpen}
      />
    </div>
  );
}
