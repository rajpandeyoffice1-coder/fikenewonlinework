import { Shield, AlertTriangle, Smartphone, MapPin, UserCog } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { SecurityAlert } from '@/types/auditLog';
import { format } from 'date-fns';

interface SecurityInsightsProps {
  alerts: SecurityAlert[];
}

const alertIcons = {
  failed_login: AlertTriangle,
  new_device: Smartphone,
  new_location: MapPin,
  role_change: UserCog,
};

const severityColors = {
  low: 'bg-blue-100 text-blue-700 border-blue-200',
  medium: 'bg-amber-100 text-amber-700 border-amber-200',
  high: 'bg-red-100 text-red-700 border-red-200',
};

export function SecurityInsights({ alerts }: SecurityInsightsProps) {
  return (
    <Card className="border-border/50 h-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Shield className="h-5 w-5 text-primary" />
          Security Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[360px]">
          <div className="space-y-3 px-6 pb-6">
            {alerts.map((alert) => {
              const Icon = alertIcons[alert.type];
              return (
                <div
                  key={alert.id}
                  className="p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${
                      alert.severity === 'high' ? 'bg-red-50' :
                      alert.severity === 'medium' ? 'bg-amber-50' : 'bg-blue-50'
                    }`}>
                      <Icon className={`h-4 w-4 ${
                        alert.severity === 'high' ? 'text-red-600' :
                        alert.severity === 'medium' ? 'text-amber-600' : 'text-blue-600'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge
                          variant="outline"
                          className={`text-xs ${severityColors[alert.severity]}`}
                        >
                          {alert.severity}
                        </Badge>
                        {alert.count && (
                          <span className="text-xs text-muted-foreground">
                            {alert.count} attempts
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-medium truncate">
                        {alert.description}
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <span>{alert.userName}</span>
                        <span>•</span>
                        <span>{format(new Date(alert.timestamp), 'MMM dd, HH:mm')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
