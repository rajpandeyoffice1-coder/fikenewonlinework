import { Copy, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { AuditLogEntry } from '@/types/auditLog';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface AuditLogDetailModalProps {
  log: AuditLogEntry | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const roleColors = {
  Admin: 'bg-purple-100 text-purple-700 border-purple-200',
  Proctor: 'bg-blue-100 text-blue-700 border-blue-200',
  Evaluator: 'bg-green-100 text-green-700 border-green-200',
  Student: 'bg-amber-100 text-amber-700 border-amber-200',
};

export function AuditLogDetailModal({
  log,
  open,
  onOpenChange,
}: AuditLogDetailModalProps) {
  if (!log) return null;

  const handleCopyLog = () => {
    navigator.clipboard.writeText(JSON.stringify(log.rawLog, null, 2));
    toast.success('Log data copied to clipboard');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="flex items-center justify-between">
            <span>Full Audit Log</span>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[70vh]">
          <div className="p-6 space-y-6">
            {/* Timestamp */}
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-1">
                Timestamp
              </h4>
              <p className="font-mono">
                {format(new Date(log.timestamp), 'MMMM dd, yyyy HH:mm:ss zzz')}
              </p>
            </div>

            <Separator />

            {/* User Info */}
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-3">
                User Information
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Name</p>
                  <p className="font-medium">{log.user.name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Role</p>
                  <Badge
                    variant="outline"
                    className={roleColors[log.user.role]}
                  >
                    {log.user.role}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="font-medium">{log.user.email}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">User ID</p>
                  <p className="font-mono text-sm">{log.user.id}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Action Details */}
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-3">
                Action Details
              </h4>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-xs text-muted-foreground">Action Type</p>
                  <p className="font-medium">{log.action}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Target</p>
                  <p className="font-medium">
                    {log.target.name}{' '}
                    <span className="text-muted-foreground">
                      ({log.target.type})
                    </span>
                  </p>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Description</p>
                <p className="text-sm">{log.actionDescription}</p>
              </div>
            </div>

            {log.changes && (
              <>
                <Separator />
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-3">
                    Data Changes
                  </h4>
                  <div className="bg-muted/50 rounded-lg p-4">
                    {Object.keys(log.changes.before).map((key) => (
                      <div key={key} className="flex items-center gap-4 py-2">
                        <span className="text-sm font-medium w-32">{key}:</span>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="px-2 py-1 bg-red-100 text-red-700 rounded line-through">
                            {String(log.changes!.before[key])}
                          </span>
                          <span className="text-muted-foreground">→</span>
                          <span className="px-2 py-1 bg-green-100 text-green-700 rounded">
                            {String(log.changes!.after[key])}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Separator />

            {/* Device & Location */}
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-3">
                Device & Location
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Browser</p>
                  <p className="font-medium">{log.device.browser}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Operating System</p>
                  <p className="font-medium">{log.device.os}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Device Type</p>
                  <p className="font-medium">{log.device.deviceType}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">IP Address</p>
                  <p className="font-mono text-sm">{log.ipAddress}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Session Info */}
            <div>
              <h4 className="text-sm font-semibold text-muted-foreground mb-3">
                Session Information
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Session ID</p>
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    {log.metadata.sessionId}
                  </code>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Request ID</p>
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    {log.metadata.requestId}
                  </code>
                </div>
              </div>
            </div>

            <Separator />

            {/* Raw Log */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-sm font-semibold text-muted-foreground">
                  Raw Log Data
                </h4>
                <Button variant="outline" size="sm" onClick={handleCopyLog}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              </div>
              <pre className="bg-muted rounded-lg p-4 text-xs overflow-x-auto font-mono">
                {JSON.stringify(log.rawLog, null, 2)}
              </pre>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
