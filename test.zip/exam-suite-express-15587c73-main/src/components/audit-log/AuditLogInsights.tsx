import { FileText, AlertTriangle, User, ShieldX } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { AuditLogInsight } from '@/types/auditLog';

interface AuditLogInsightsProps {
  insights: AuditLogInsight;
}

export function AuditLogInsights({ insights }: AuditLogInsightsProps) {
  const cards = [
    {
      title: 'Total Logs',
      value: insights.totalLogs.toLocaleString(),
      description: 'In selected range',
      icon: FileText,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'High-Risk Actions',
      value: insights.highRiskActions.toString(),
      description: 'Password/role changes',
      icon: AlertTriangle,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
    },
    {
      title: 'Most Active User',
      value: insights.mostActiveUser.name,
      description: `${insights.mostActiveUser.actionCount} actions`,
      icon: User,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Failed Login Attempts',
      value: insights.failedLoginAttempts.toString(),
      description: 'In selected range',
      icon: ShieldX,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => (
        <Card key={card.title} className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">
                  {card.title}
                </p>
                <p className="text-2xl font-bold">{card.value}</p>
                <p className="text-xs text-muted-foreground">
                  {card.description}
                </p>
              </div>
              <div className={`p-3 rounded-lg ${card.bgColor}`}>
                <card.icon className={`h-5 w-5 ${card.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
