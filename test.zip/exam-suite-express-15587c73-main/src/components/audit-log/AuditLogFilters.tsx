import { Search, Download, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { DateRange } from 'react-day-picker';
import { UserType, ActionType } from '@/types/auditLog';

interface AuditLogFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  userType: string;
  onUserTypeChange: (value: string) => void;
  actionType: string;
  onActionTypeChange: (value: string) => void;
  dateRange: DateRange | undefined;
  onDateRangeChange: (range: DateRange | undefined) => void;
  ipFilter: string;
  onIpFilterChange: (value: string) => void;
  onExport: () => void;
  onClearFilters: () => void;
}

const userTypes: UserType[] = ['Admin', 'Proctor', 'Evaluator', 'Student'];
const actionTypes: ActionType[] = [
  'Login',
  'Logout',
  'Exam Modify',
  'Student Modify',
  'Question Update',
  'Role Update',
  'Settings Change',
  'Proctor Action',
  'Evaluation Action',
  'Failed Login'
];

export function AuditLogFilters({
  searchQuery,
  onSearchChange,
  userType,
  onUserTypeChange,
  actionType,
  onActionTypeChange,
  dateRange,
  onDateRangeChange,
  ipFilter,
  onIpFilterChange,
  onExport,
  onClearFilters,
}: AuditLogFiltersProps) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4">
        <Select value={userType} onValueChange={onUserTypeChange}>
          <SelectTrigger className="w-[160px] bg-background">
            <SelectValue placeholder="User Type" />
          </SelectTrigger>
          <SelectContent className="bg-background border">
            <SelectItem value="all">All Users</SelectItem>
            {userTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={actionType} onValueChange={onActionTypeChange}>
          <SelectTrigger className="w-[180px] bg-background">
            <SelectValue placeholder="Action Type" />
          </SelectTrigger>
          <SelectContent className="bg-background border">
            <SelectItem value="all">All Actions</SelectItem>
            {actionTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                'w-[280px] justify-start text-left font-normal',
                !dateRange && 'text-muted-foreground'
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {dateRange?.from ? (
                dateRange.to ? (
                  <>
                    {format(dateRange.from, 'LLL dd, y')} -{' '}
                    {format(dateRange.to, 'LLL dd, y')}
                  </>
                ) : (
                  format(dateRange.from, 'LLL dd, y')
                )
              ) : (
                <span>Pick a date range</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 bg-background border" align="start">
            <Calendar
              initialFocus
              mode="range"
              defaultMonth={dateRange?.from}
              selected={dateRange}
              onSelect={onDateRangeChange}
              numberOfMonths={2}
            />
          </PopoverContent>
        </Popover>

        <Input
          placeholder="Filter by IP Address"
          value={ipFilter}
          onChange={(e) => onIpFilterChange(e.target.value)}
          className="w-[180px]"
        />

        <div className="flex-1" />

        <Button variant="outline" onClick={onClearFilters}>
          <X className="mr-2 h-4 w-4" />
          Clear Filters
        </Button>
        <Button onClick={onExport}>
          <Download className="mr-2 h-4 w-4" />
          Export Logs
        </Button>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by user name, ID, email, or action detail..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>
    </div>
  );
}
