import { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  ChevronDown,
  ChevronRight,
  Eye,
  Monitor,
  Smartphone,
  Tablet,
  LogIn,
  LogOut,
  Edit,
  UserCog,
  Settings,
  Video,
  ClipboardCheck,
  XCircle,
  HelpCircle,
} from 'lucide-react';
import { AuditLogEntry, ActionType } from '@/types/auditLog';
import { format } from 'date-fns';

interface AuditLogTableProps {
  logs: AuditLogEntry[];
  onViewLog: (log: AuditLogEntry) => void;
}

const roleColors = {
  Admin: 'bg-purple-100 text-purple-700 border-purple-200',
  Proctor: 'bg-blue-100 text-blue-700 border-blue-200',
  Evaluator: 'bg-green-100 text-green-700 border-green-200',
  Student: 'bg-amber-100 text-amber-700 border-amber-200',
};

const actionIcons: Record<ActionType, React.ElementType> = {
  'Login': LogIn,
  'Logout': LogOut,
  'Exam Modify': Edit,
  'Student Modify': Edit,
  'Question Update': Edit,
  'Role Update': UserCog,
  'Settings Change': Settings,
  'Proctor Action': Video,
  'Evaluation Action': ClipboardCheck,
  'Failed Login': XCircle,
};

const deviceIcons = {
  Desktop: Monitor,
  Mobile: Smartphone,
  Tablet: Tablet,
};

export function AuditLogTable({ logs, onViewLog }: AuditLogTableProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [rowsPerPage, setRowsPerPage] = useState('20');
  const [currentPage, setCurrentPage] = useState(1);

  const toggleRow = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  const totalPages = Math.ceil(logs.length / parseInt(rowsPerPage));
  const paginatedLogs = logs.slice(
    (currentPage - 1) * parseInt(rowsPerPage),
    currentPage * parseInt(rowsPerPage)
  );

  return (
    <div className="space-y-4">
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-8"></TableHead>
              <TableHead className="w-[180px]">Timestamp</TableHead>
              <TableHead className="w-[200px]">User</TableHead>
              <TableHead className="w-[160px]">Action</TableHead>
              <TableHead className="w-[200px]">Target</TableHead>
              <TableHead className="w-[130px]">IP Address</TableHead>
              <TableHead className="w-[80px]">Device</TableHead>
              <TableHead className="w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedLogs.map((log, index) => {
              const isExpanded = expandedRows.has(log.id);
              const ActionIcon = actionIcons[log.action] || HelpCircle;
              const DeviceIcon = deviceIcons[log.device.deviceType];

              return (
                <Collapsible key={log.id} asChild open={isExpanded}>
                  <>
                    <TableRow className={index % 2 === 0 ? 'bg-background' : 'bg-muted/30'}>
                      <TableCell>
                        <CollapsibleTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => toggleRow(log.id)}
                          >
                            {isExpanded ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </Button>
                        </CollapsibleTrigger>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {format(new Date(log.timestamp), 'MMM dd, yyyy HH:mm:ss')}
                      </TableCell>
                      <TableCell>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-2">
                                <span className="font-medium truncate max-w-[120px]">
                                  {log.user.name}
                                </span>
                                <Badge
                                  variant="outline"
                                  className={`text-xs ${roleColors[log.user.role]}`}
                                >
                                  {log.user.role}
                                </Badge>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{log.user.email}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <ActionIcon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{log.action}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <span className="font-medium">{log.target.name}</span>
                          <span className="text-muted-foreground text-xs ml-1">
                            ({log.target.type})
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm text-muted-foreground">
                        {log.ipAddress}
                      </TableCell>
                      <TableCell>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex justify-center">
                                <DeviceIcon className="h-4 w-4 text-muted-foreground" />
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{log.device.browser}</p>
                              <p className="text-muted-foreground">{log.device.os}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onViewLog(log)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <CollapsibleContent asChild>
                      <TableRow className="bg-muted/20">
                        <TableCell colSpan={8} className="p-0">
                          <div className="p-4 border-t border-dashed">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                              <div>
                                <h4 className="text-sm font-semibold mb-2">Action Details</h4>
                                <p className="text-sm text-muted-foreground">
                                  {log.actionDescription}
                                </p>
                              </div>

                              {log.changes && (
                                <div>
                                  <h4 className="text-sm font-semibold mb-2">Changes</h4>
                                  <div className="space-y-1">
                                    {Object.keys(log.changes.before).map((key) => (
                                      <div key={key} className="text-sm">
                                        <span className="text-muted-foreground">{key}: </span>
                                        <span className="text-red-600 line-through">
                                          {String(log.changes!.before[key])}
                                        </span>
                                        <span className="mx-2">→</span>
                                        <span className="text-green-600">
                                          {String(log.changes!.after[key])}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              <div>
                                <h4 className="text-sm font-semibold mb-2">Metadata</h4>
                                <div className="text-sm space-y-1">
                                  <p>
                                    <span className="text-muted-foreground">Browser: </span>
                                    {log.device.browser}
                                  </p>
                                  <p>
                                    <span className="text-muted-foreground">OS: </span>
                                    {log.device.os}
                                  </p>
                                  <p>
                                    <span className="text-muted-foreground">Session: </span>
                                    <code className="text-xs bg-muted px-1 rounded">
                                      {log.metadata.sessionId}
                                    </code>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    </CollapsibleContent>
                  </>
                </Collapsible>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Rows per page:</span>
          <Select value={rowsPerPage} onValueChange={(value) => {
            setRowsPerPage(value);
            setCurrentPage(1);
          }}>
            <SelectTrigger className="w-[80px] bg-background">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-background border">
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
