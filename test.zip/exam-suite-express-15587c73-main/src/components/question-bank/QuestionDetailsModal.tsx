import {
  CheckSquare,
  ListChecks,
  ToggleLeft,
  AlignLeft,
  FileText,
  Calendar,
  User,
  Tag,
  Award,
  Clock,
  Pencil,
  Trash2,
  Copy,
  X,
  Code,
  Upload,
  ImageIcon,
  Video,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Question, QuestionType, QUESTION_TYPE_LABELS } from "@/types/question";

interface QuestionDetailsModalProps {
  open: boolean;
  onClose: () => void;
  question: Question | null;
  onEdit: () => void;
  onDelete: () => void;
}

const typeIcons: Record<QuestionType, any> = {
  mcq_single: CheckSquare,
  mcq_multiple: ListChecks,
  true_false: ToggleLeft,
  short_answer: AlignLeft,
  long_answer: FileText,
  coding: Code,
  file_upload: Upload,
  image_based: ImageIcon,
  video_based: Video,
};

const difficultyColors = {
  easy: "bg-success/10 text-success",
  medium: "bg-warning/10 text-warning",
  hard: "bg-destructive/10 text-destructive",
};

export function QuestionDetailsModal({
  open,
  onClose,
  question,
  onEdit,
  onDelete,
}: QuestionDetailsModalProps) {
  if (!question) return null;

  const TypeIcon = typeIcons[question.type] || FileText;
  const isMCQ = question.type === "mcq_single" || question.type === "mcq_multiple";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-lg">Question Details</DialogTitle>
              <p className="text-sm text-muted-foreground mt-1 font-mono">{question.id}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={onEdit}>
                <Pencil className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button variant="outline" size="sm">
                <Copy className="h-4 w-4 mr-1" />
                Duplicate
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-destructive hover:text-destructive"
                onClick={onDelete}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Meta Info */}
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2 text-sm">
              <TypeIcon className="h-4 w-4 text-primary" />
              <span>{QUESTION_TYPE_LABELS[question.type]}</span>
            </div>
            <Separator orientation="vertical" className="h-5" />
            <div className="flex items-center gap-2 text-sm">
              <Award className="h-4 w-4 text-muted-foreground" />
              <span>{question.marks} marks</span>
              {question.negativeMarking && (
                <span className="text-destructive">(-{question.negativeMarks})</span>
              )}
            </div>
            <Separator orientation="vertical" className="h-5" />
            <Badge className={cn("capitalize", difficultyColors[question.difficulty])}>
              {question.difficulty}
            </Badge>
          </div>

          {/* Question Text */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Question
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground leading-relaxed">{question.text}</p>
            </CardContent>
          </Card>

          {/* MCQ Options */}
          {isMCQ && question.options && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Answer Options
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {question.options.map((option, index) => (
                  <div
                    key={option.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border",
                      option.isCorrect
                        ? "bg-success/5 border-success/30"
                        : "bg-muted/30 border-border"
                    )}
                  >
                    <div
                      className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium",
                        option.isCorrect
                          ? "bg-success text-success-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className={option.isCorrect ? "font-medium" : ""}>
                      {option.text}
                    </span>
                    {option.isCorrect && (
                      <Badge variant="outline" className="ml-auto text-success border-success/30">
                        Correct
                      </Badge>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* True/False Answer */}
          {question.type === "true_false" && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Correct Answer
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Badge
                  className={
                    question.correctAnswer
                      ? "bg-success/10 text-success"
                      : "bg-destructive/10 text-destructive"
                  }
                >
                  {question.correctAnswer ? "True" : "False"}
                </Badge>
              </CardContent>
            </Card>
          )}

          {/* Ideal Answer for text questions */}
          {(question.type === "short_answer" || question.type === "long_answer") &&
            question.idealAnswer && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Ideal Answer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground">{question.idealAnswer}</p>
                  {question.wordLimit && question.wordLimit > 0 && (
                    <p className="text-sm text-muted-foreground mt-2">
                      Word limit: {question.wordLimit} words
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

          {/* Tags & Meta */}
          <div className="grid sm:grid-cols-2 gap-4">
            <Card>
              <CardContent className="pt-4 space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Tag className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Tags:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {question.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-4 space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Author:</span>
                  <span className="font-medium">{question.author}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Last Updated:</span>
                  <span>{question.lastUpdated}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Student Preview */}
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Student Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-card rounded-lg p-4 border border-border">
                <p className="font-medium mb-4">{question.text}</p>
                {isMCQ && question.options && (
                  <div className="space-y-2">
                    {question.options.map((option, index) => (
                      <div
                        key={option.id}
                        className="flex items-center gap-3 p-2 rounded border border-border hover:bg-muted/50 cursor-pointer"
                      >
                        <div className="w-5 h-5 rounded-full border-2 border-muted-foreground" />
                        <span>{option.text}</span>
                      </div>
                    ))}
                  </div>
                )}
                {question.type === "true_false" && (
                  <div className="flex gap-4">
                    <div className="flex items-center gap-2 p-2 rounded border border-border hover:bg-muted/50 cursor-pointer px-6">
                      <div className="w-4 h-4 rounded-full border-2 border-muted-foreground" />
                      <span>True</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 rounded border border-border hover:bg-muted/50 cursor-pointer px-6">
                      <div className="w-4 h-4 rounded-full border-2 border-muted-foreground" />
                      <span>False</span>
                    </div>
                  </div>
                )}
                {(question.type === "short_answer" || question.type === "long_answer") && (
                  <div className="border border-border rounded-lg p-3 text-muted-foreground text-sm">
                    Type your answer here...
                    {question.wordLimit && question.wordLimit > 0 && (
                      <p className="mt-2 text-xs">Max {question.wordLimit} words</p>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
