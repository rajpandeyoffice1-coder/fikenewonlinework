import { useState, useMemo, useEffect, useRef } from "react";
import { Plus, Upload, Download, Database, Loader2, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { FolderSidebar } from "./FolderSidebar";
import { QuestionFilters } from "./QuestionFilters";
import { QuestionsTable } from "./QuestionsTable";
import { QuestionModal } from "./QuestionModal";
import { QuestionDetailsModal } from "./QuestionDetailsModal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Question, QuestionFolder } from "@/types/question";

// Type mapping between TS (underscores) and DB (hyphens with special cases)
const TS_TO_DB_TYPE: Record<string, string> = {
  mcq_single: 'mcq-single',
  mcq_multiple: 'mcq-multiple',
  true_false: 'true-false',
  short_answer: 'short-answer',
  long_answer: 'long-answer',
  coding: 'code',
  file_upload: 'file-upload',
  image_based: 'mcq-single', // Fallback - not in DB constraint
  video_based: 'mcq-single', // Fallback - not in DB constraint
};

const DB_TO_TS_TYPE: Record<string, string> = {
  'mcq-single': 'mcq_single',
  'mcq-multiple': 'mcq_multiple',
  'true-false': 'true_false',
  'short-answer': 'short_answer',
  'long-answer': 'long_answer',
  'code': 'coding',
  'file-upload': 'file_upload',
};

// Helper to normalize type from DB (hyphens) to TS (underscores)
const normalizeType = (dbType: string): string => {
  return DB_TO_TS_TYPE[dbType] || dbType?.replace(/-/g, '_') || 'mcq_single';
};

// Helper to convert type from TS (underscores) to DB (hyphens) for consistency
const denormalizeType = (tsType: string): string => {
  return TS_TO_DB_TYPE[tsType] || tsType?.replace(/_/g, '-') || 'mcq-single';
};

// Helper to convert DB row to Question type
const dbToQuestion = (row: any): Question => ({
  id: row.id,
  text: row.question_text,
  type: normalizeType(row.type) as Question['type'],
  marks: row.marks,
  negativeMarking: row.negative_marks > 0,
  negativeMarks: row.negative_marks || 0,
  difficulty: row.difficulty,
  tags: row.tags || [],
  subject: row.subject,
  author: "Current User",
  lastUpdated: new Date(row.updated_at).toISOString().split("T")[0],
  options: row.options || [],
  correctAnswer: row.correct_answer === "true",
  idealAnswer: row.correct_answer,
});

export function QuestionBankPage() {
  const { user } = useAuth();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [folders, setFolders] = useState<QuestionFolder[]>([
    { id: "all", name: "All Questions", count: 0 }
  ]);
  const [selectedFolder, setSelectedFolder] = useState("all");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [subject, setSubject] = useState("all");
  const [difficulty, setDifficulty] = useState("all");
  const [questionType, setQuestionType] = useState("all");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [author, setAuthor] = useState("all");

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [viewingQuestion, setViewingQuestion] = useState<Question | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // File input ref for import
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch questions and folders from database
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      setIsLoading(true);
      
      // Fetch questions
      const { data: questionsData, error: questionsError } = await supabase
        .from("questions")
        .select("*")
        .order("created_at", { ascending: false });

      if (questionsError) {
        console.error("Error fetching questions:", questionsError);
        toast({ title: "Error", description: "Failed to load questions", variant: "destructive" });
      } else {
        setQuestions((questionsData || []).map(dbToQuestion));
      }

      // Fetch folders
      const { data: foldersData, error: foldersError } = await supabase
        .from("question_folders")
        .select("*")
        .order("name", { ascending: true });

      if (foldersError) {
        console.error("Error fetching folders:", foldersError);
      } else {
        const dbFolders: QuestionFolder[] = (foldersData || []).map((f: any) => ({
          id: f.id,
          name: f.name,
          count: 0, // Will be calculated based on questions
        }));
        
        // Count questions per folder
        const questionCounts: Record<string, number> = {};
        (questionsData || []).forEach((q: any) => {
          if (q.folder_id) {
            questionCounts[q.folder_id] = (questionCounts[q.folder_id] || 0) + 1;
          }
        });
        
        dbFolders.forEach(f => {
          f.count = questionCounts[f.id] || 0;
        });

        setFolders([
          { id: "all", name: "All Questions", count: questionsData?.length || 0 },
          ...dbFolders
        ]);
      }
      
      setIsLoading(false);
    };

    fetchData();
  }, [user]);

  const filteredQuestions = useMemo(() => {
    return questions.filter((q) => {
      const matchesSearch =
        searchQuery === "" ||
        q.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSubject = subject === "all" || q.subject === subject;
      const matchesDifficulty = difficulty === "all" || q.difficulty === difficulty;
      const matchesType = questionType === "all" || q.type === questionType;
      const matchesTags =
        selectedTags.length === 0 || selectedTags.some((t) => q.tags.includes(t));
      const matchesAuthor = author === "all" || q.author === author;
      const matchesFolder =
        selectedFolder === "all" ||
        q.subject.toLowerCase().includes(
          folders.find((f) => f.id === selectedFolder)?.name.toLowerCase() || ""
        );

      return (
        matchesSearch &&
        matchesSubject &&
        matchesDifficulty &&
        matchesType &&
        matchesTags &&
        matchesAuthor &&
        matchesFolder
      );
    });
  }, [
    questions,
    searchQuery,
    subject,
    difficulty,
    questionType,
    selectedTags,
    author,
    selectedFolder,
    folders,
  ]);

  const paginatedQuestions = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredQuestions.slice(start, start + itemsPerPage);
  }, [filteredQuestions, currentPage]);

  const totalPages = Math.ceil(filteredQuestions.length / itemsPerPage);

  // Derive unique subjects, tags, and authors from actual questions
  const uniqueSubjects = useMemo(() => {
    const subjects = new Set(questions.map(q => q.subject).filter(Boolean));
    return Array.from(subjects).sort();
  }, [questions]);

  const uniqueTags = useMemo(() => {
    const tags = new Set(questions.flatMap(q => q.tags || []));
    return Array.from(tags).sort();
  }, [questions]);

  const uniqueAuthors = useMemo(() => {
    const authors = new Set(questions.map(q => q.author).filter(Boolean));
    return Array.from(authors).sort();
  }, [questions]);

  const clearFilters = () => {
    setSearchQuery("");
    setSubject("all");
    setDifficulty("all");
    setQuestionType("all");
    setSelectedTags([]);
    setAuthor("all");
  };

  const handleCreateFolder = async (name: string) => {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in", variant: "destructive" });
      return;
    }

    const { data, error } = await supabase
      .from("question_folders")
      .insert({ user_id: user.id, name })
      .select()
      .single();

    if (error) {
      console.error("Error creating folder:", error);
      toast({ title: "Error", description: "Failed to create folder", variant: "destructive" });
      return;
    }

    const newFolder: QuestionFolder = {
      id: data.id,
      name: data.name,
      count: 0,
    };
    setFolders([...folders, newFolder]);
    toast({ title: "Folder Created", description: `"${name}" has been created.` });
  };

  const handleSaveQuestion = async (questionData: Partial<Question>) => {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in", variant: "destructive" });
      return;
    }

    // Validate required fields
    if (!questionData.text?.trim()) {
      toast({ title: "Error", description: "Question text is required", variant: "destructive" });
      return;
    }

    if (!questionData.subject) {
      toast({ title: "Error", description: "Subject is required", variant: "destructive" });
      return;
    }

    // Convert form data to DB format - use denormalizeType for consistency with existing data
    const dbData = {
      user_id: user.id,
      question_text: questionData.text.trim(),
      type: denormalizeType(questionData.type || "mcq_single"),
      subject: questionData.subject,
      difficulty: questionData.difficulty || "medium",
      marks: questionData.marks || 1,
      negative_marks: questionData.negativeMarking ? (questionData.negativeMarks || 0) : 0,
      tags: questionData.tags || [],
      options: JSON.parse(JSON.stringify(questionData.options || [])),
      correct_answer: questionData.type === "true_false" 
        ? String(questionData.correctAnswer) 
        : questionData.idealAnswer || "",
    };

    console.log("Saving question with data:", dbData);

    if (editingQuestion) {
      const { error } = await supabase
        .from("questions")
        .update(dbData)
        .eq("id", editingQuestion.id);

      if (error) {
        console.error("Error updating question:", error);
        toast({ title: "Error", description: `Failed to update question: ${error.message}`, variant: "destructive" });
        return;
      }

      setQuestions(questions.map((q) =>
        q.id === editingQuestion.id
          ? { ...q, ...questionData, lastUpdated: new Date().toISOString().split("T")[0] }
          : q
      ));
      toast({ title: "Question Updated", description: "Your changes have been saved." });
    } else {
      const { data, error } = await supabase
        .from("questions")
        .insert([dbData])
        .select()
        .single();

      if (error) {
        console.error("Error creating question:", error);
        toast({ title: "Error", description: `Failed to create question: ${error.message}`, variant: "destructive" });
        return;
      }

      console.log("Question created successfully:", data);
      const newQuestion = dbToQuestion(data);
      setQuestions([newQuestion, ...questions]);
      toast({ title: "Question Added", description: "New question has been added to the bank." });
    }
    setEditingQuestion(null);
  };

  const handleDeleteQuestion = async (id: string) => {
    const { error } = await supabase
      .from("questions")
      .delete()
      .eq("id", id);

    if (error) {
      console.error("Error deleting question:", error);
      toast({ title: "Error", description: "Failed to delete question", variant: "destructive" });
      return;
    }

    setQuestions(questions.filter((q) => q.id !== id));
    setSelectedIds(selectedIds.filter((i) => i !== id));
    toast({ title: "Question Deleted", description: "The question has been removed." });
  };

  const handleBulkDelete = async () => {
    const { error } = await supabase
      .from("questions")
      .delete()
      .in("id", selectedIds);

    if (error) {
      console.error("Error deleting questions:", error);
      toast({ title: "Error", description: "Failed to delete questions", variant: "destructive" });
      return;
    }

    setQuestions(questions.filter((q) => !selectedIds.includes(q.id)));
    const count = selectedIds.length;
    setSelectedIds([]);
    toast({
      title: "Questions Deleted",
      description: `${count} questions have been removed.`,
    });
  };

  const handleView = (question: Question) => {
    setViewingQuestion(question);
  };

  const handleEdit = (question: Question) => {
    setEditingQuestion(question);
    setIsModalOpen(true);
    setViewingQuestion(null);
  };

  // Export questions as JSON
  const handleExport = () => {
    const exportData = filteredQuestions.map(q => ({
      question_text: q.text,
      type: q.type,
      subject: q.subject,
      difficulty: q.difficulty,
      marks: q.marks,
      negative_marks: q.negativeMarks,
      tags: q.tags,
      options: q.options,
      correct_answer: q.type === "true_false" ? String(q.correctAnswer) : q.idealAnswer,
    }));

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `questions_export_${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({ title: "Export Complete", description: `${exportData.length} questions exported successfully.` });
  };

  // Parse CSV content to questions array
  const parseCSV = (text: string): any[] => {
    const lines = text.split('\n').map(line => line.trim()).filter(line => line);
    if (lines.length < 2) return [];

    // Parse header row - handle quoted values
    const parseCSVRow = (row: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < row.length; i++) {
        const char = row[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    };

    const headers = parseCSVRow(lines[0]).map(h => h.toLowerCase().replace(/[^a-z0-9_]/g, '_'));
    console.log('CSV Headers:', headers);

    const questions: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVRow(lines[i]);
      if (values.length === 0 || (values.length === 1 && !values[0])) continue;

      const row: Record<string, string> = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx] || '';
      });

      console.log('Parsed row:', row);

      // Map CSV columns to question fields
      // Support various column name formats
      const question = {
        question_text: row.question_text || row.question || row.text || '',
        type: row.type || row.question_type || 'mcq-single',
        subject: row.subject || row.course || '',
        difficulty: row.difficulty || row.level || 'medium',
        marks: parseInt(row.marks || row.points || '1') || 1,
        negative_marks: parseFloat(row.negative_marks || row.negative_marking || '0') || 0,
        tags: (row.tags || '').split(';').map(t => t.trim()).filter(t => t),
        options: [],
        correct_answer: row.correct_answer || row.answer || '',
      };

      // Parse options - support option_a, option_b, etc. or options column
      if (row.options) {
        // Options as semicolon-separated values
        question.options = row.options.split(';').map(opt => ({ text: opt.trim(), isCorrect: false }));
      } else {
        // Individual option columns
        const optionKeys = ['option_a', 'option_b', 'option_c', 'option_d', 'option_e', 'option_1', 'option_2', 'option_3', 'option_4', 'option_5', 'a', 'b', 'c', 'd', 'e'];
        const options: { text: string; isCorrect: boolean }[] = [];
        
        optionKeys.forEach(key => {
          if (row[key] && row[key].trim()) {
            options.push({ text: row[key].trim(), isCorrect: false });
          }
        });
        
        if (options.length > 0) {
          question.options = options;
        }
      }

      // Mark correct option based on correct_answer
      if (question.correct_answer && question.options.length > 0) {
        const correctAnswerLower = question.correct_answer.toLowerCase();
        const letterMap: Record<string, number> = { 'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4 };
        
        if (letterMap[correctAnswerLower] !== undefined) {
          const idx = letterMap[correctAnswerLower];
          if (question.options[idx]) {
            question.options[idx].isCorrect = true;
          }
        } else {
          // Try matching by text
          question.options.forEach((opt: any) => {
            if (opt.text.toLowerCase() === correctAnswerLower) {
              opt.isCorrect = true;
            }
          });
        }
      }

      if (question.question_text) {
        questions.push(question);
      }
    }

    return questions;
  };

  // Download sample CSV template
  const handleDownloadSampleCSV = () => {
    const sampleCSV = `question_text,type,subject,difficulty,marks,negative_marks,option_a,option_b,option_c,option_d,correct_answer,tags
"What is the capital of France?",mcq-single,Geography,easy,1,0,"London","Paris","Berlin","Madrid",B,geography;capitals
"Which of the following are programming languages?",mcq-multiple,Computer Science,medium,2,0.5,"Python","HTML","JavaScript","CSS","A;C",programming;languages
"The Earth revolves around the Sun.",true-false,Science,easy,1,0,,,,,"true",astronomy;basics
"Explain the process of photosynthesis.",short-answer,Biology,medium,3,0,,,,,,biology;plants
"Write a detailed essay on climate change.",long-answer,Environmental Science,hard,10,0,,,,,,environment;essay
"Write a function to calculate factorial.",code,Computer Science,medium,5,0,,,,,,programming;algorithms`;

    const blob = new Blob([sampleCSV], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'questions_sample_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Sample CSV Downloaded",
      description: "Use this template to format your questions for bulk import.",
    });
  };

  // Import questions from JSON or CSV
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    try {
      const text = await file.text();
      let importedQuestions: any[];

      // Determine file type
      const fileName = file.name.toLowerCase();
      if (fileName.endsWith('.csv')) {
        console.log('Parsing CSV file...');
        importedQuestions = parseCSV(text);
        console.log('Parsed questions:', importedQuestions);
      } else {
        // Assume JSON
        importedQuestions = JSON.parse(text);
      }

      if (!Array.isArray(importedQuestions) || importedQuestions.length === 0) {
        toast({ title: "Error", description: "No valid questions found in the file. Please check the format.", variant: "destructive" });
        return;
      }

      let successCount = 0;
      let errorCount = 0;

      for (const q of importedQuestions) {
        // Normalize type from import - handle both formats
        const importedType = q.type || "mcq-single";
        const normalizedType = denormalizeType(normalizeType(importedType));
        
        const dbData = {
          user_id: user.id,
          question_text: q.question_text || q.text || "",
          type: normalizedType,
          subject: q.subject || "",
          difficulty: q.difficulty || "medium",
          marks: q.marks || 1,
          negative_marks: q.negative_marks || q.negativeMarks || 0,
          tags: q.tags || [],
          options: q.options || [],
          correct_answer: q.correct_answer || q.idealAnswer || "",
        };

        const { error } = await supabase.from("questions").insert([dbData]);

        if (error) {
          console.error("Error importing question:", error);
          errorCount++;
        } else {
          successCount++;
        }
      }

      // Refresh questions
      const { data: questionsData } = await supabase
        .from("questions")
        .select("*")
        .order("created_at", { ascending: false });

      if (questionsData) {
        setQuestions(questionsData.map(dbToQuestion));
      }

      toast({
        title: "Import Complete",
        description: `${successCount} questions imported successfully${errorCount > 0 ? `, ${errorCount} failed` : ""}.`,
      });
    } catch (error) {
      console.error("Import error:", error);
      toast({ title: "Error", description: "Failed to parse import file. Please check the format.", variant: "destructive" });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] -m-6">
      {/* Folder Sidebar */}
      <FolderSidebar
        folders={folders}
        selectedFolder={selectedFolder}
        onSelectFolder={setSelectedFolder}
        onCreateFolder={handleCreateFolder}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-border bg-card">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Database className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Question Bank</h1>
                <p className="text-muted-foreground text-sm">
                  {filteredQuestions.length} questions
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <input
                type="file"
                ref={fileInputRef}
                accept=".json,.csv"
                onChange={handleImport}
                className="hidden"
              />
              <Button variant="outline" size="sm" onClick={handleDownloadSampleCSV}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Sample CSV
              </Button>
              <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                <Upload className="h-4 w-4 mr-2" />
                Import (CSV/JSON)
              </Button>
              <Button variant="outline" onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button onClick={() => setIsModalOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Question
              </Button>
            </div>
          </div>

          <QuestionFilters
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            subject={subject}
            onSubjectChange={setSubject}
            difficulty={difficulty}
            onDifficultyChange={setDifficulty}
            questionType={questionType}
            onTypeChange={setQuestionType}
            selectedTags={selectedTags}
            onTagsChange={setSelectedTags}
            author={author}
            onAuthorChange={setAuthor}
            onClearFilters={clearFilters}
            subjects={uniqueSubjects}
            allTags={uniqueTags}
            authors={uniqueAuthors}
          />
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto p-6">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : paginatedQuestions.length === 0 ? (
            <Card className="p-12">
              <div className="text-center text-muted-foreground">
                <Database className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="font-medium text-lg">No questions found</p>
                <p className="text-sm mt-1">
                  Try adjusting your filters or add a new question
                </p>
                <Button className="mt-4" onClick={() => setIsModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Question
                </Button>
              </div>
            </Card>
          ) : (
            <>
              <QuestionsTable
                questions={paginatedQuestions}
                selectedIds={selectedIds}
                onSelectIds={setSelectedIds}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDeleteQuestion}
                onBulkDelete={handleBulkDelete}
              />

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm text-muted-foreground">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(currentPage * itemsPerPage, filteredQuestions.length)} of{" "}
                    {filteredQuestions.length} questions
                  </p>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(currentPage - 1)}
                    >
                      Previous
                    </Button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1)
                      .filter(
                        (page) =>
                          page === 1 ||
                          page === totalPages ||
                          Math.abs(page - currentPage) <= 1
                      )
                      .map((page, index, arr) => (
                        <span key={page}>
                          {index > 0 && arr[index - 1] !== page - 1 && (
                            <span className="px-2">...</span>
                          )}
                          <Button
                            variant={currentPage === page ? "default" : "outline"}
                            size="sm"
                            onClick={() => setCurrentPage(page)}
                          >
                            {page}
                          </Button>
                        </span>
                      ))}
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(currentPage + 1)}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Modals */}
      <QuestionModal
        open={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingQuestion(null);
        }}
        question={editingQuestion}
        onSave={handleSaveQuestion}
      />

      <QuestionDetailsModal
        open={!!viewingQuestion}
        onClose={() => setViewingQuestion(null)}
        question={viewingQuestion}
        onEdit={() => viewingQuestion && handleEdit(viewingQuestion)}
        onDelete={() => {
          if (viewingQuestion) {
            handleDeleteQuestion(viewingQuestion.id);
            setViewingQuestion(null);
          }
        }}
      />
    </div>
  );
}
