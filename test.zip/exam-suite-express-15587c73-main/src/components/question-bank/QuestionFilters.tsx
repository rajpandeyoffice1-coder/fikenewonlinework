import { Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface QuestionFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  subject: string;
  onSubjectChange: (value: string) => void;
  difficulty: string;
  onDifficultyChange: (value: string) => void;
  questionType: string;
  onTypeChange: (value: string) => void;
  selectedTags: string[];
  onTagsChange: (tags: string[]) => void;
  author: string;
  onAuthorChange: (value: string) => void;
  onClearFilters: () => void;
  subjects: string[];
  allTags: string[];
  authors: string[];
}

export function QuestionFilters({
  searchQuery,
  onSearchChange,
  subject,
  onSubjectChange,
  difficulty,
  onDifficultyChange,
  questionType,
  onTypeChange,
  selectedTags,
  onTagsChange,
  author,
  onAuthorChange,
  onClearFilters,
  subjects,
  allTags,
  authors,
}: QuestionFiltersProps) {
  const hasActiveFilters =
    subject !== "all" ||
    difficulty !== "all" ||
    questionType !== "all" ||
    selectedTags.length > 0 ||
    author !== "all";

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      onTagsChange(selectedTags.filter((t) => t !== tag));
    } else {
      onTagsChange([...selectedTags, tag]);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by keyword, question ID..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filter Row */}
      <div className="flex flex-wrap gap-3 items-center">
        <Select value={subject} onValueChange={onSubjectChange}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Subject" />
          </SelectTrigger>
          <SelectContent className="bg-background">
            <SelectItem value="all">All Subjects</SelectItem>
            {subjects.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={difficulty} onValueChange={onDifficultyChange}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent className="bg-background">
            <SelectItem value="all">All Levels</SelectItem>
            <SelectItem value="easy">Easy</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="hard">Hard</SelectItem>
          </SelectContent>
        </Select>

        <Select value={questionType} onValueChange={onTypeChange}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Question Type" />
          </SelectTrigger>
          <SelectContent className="bg-background">
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="mcq_single">MCQ (Single)</SelectItem>
            <SelectItem value="mcq_multiple">MCQ (Multiple)</SelectItem>
            <SelectItem value="true_false">True/False</SelectItem>
            <SelectItem value="short_answer">Short Answer</SelectItem>
            <SelectItem value="long_answer">Long Answer</SelectItem>
            <SelectItem value="coding">Coding</SelectItem>
            <SelectItem value="file_upload">File Upload</SelectItem>
            <SelectItem value="image_based">Image Based</SelectItem>
            <SelectItem value="video_based">Video Based</SelectItem>
          </SelectContent>
        </Select>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Tags
              {selectedTags.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {selectedTags.length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-64" align="start">
            <div className="space-y-2">
              <p className="text-sm font-medium">Select Tags</p>
              <div className="max-h-48 overflow-y-auto space-y-2">
                {allTags.map((tag) => (
                  <div key={tag} className="flex items-center gap-2">
                    <Checkbox
                      id={tag}
                      checked={selectedTags.includes(tag)}
                      onCheckedChange={() => toggleTag(tag)}
                    />
                    <Label htmlFor={tag} className="text-sm cursor-pointer">
                      {tag}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>

        <Select value={author} onValueChange={onAuthorChange}>
          <SelectTrigger className="w-36">
            <SelectValue placeholder="Author" />
          </SelectTrigger>
          <SelectContent className="bg-background">
            <SelectItem value="all">All Authors</SelectItem>
            {authors.map((a) => (
              <SelectItem key={a} value={a}>
                {a}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={onClearFilters} className="text-muted-foreground">
            Clear Filters
          </Button>
        )}
      </div>

      {/* Active Tags */}
      {selectedTags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedTags.map((tag) => (
            <Badge key={tag} variant="secondary" className="gap-1">
              {tag}
              <button
                onClick={() => toggleTag(tag)}
                className="ml-1 hover:text-destructive"
              >
                ×
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}
