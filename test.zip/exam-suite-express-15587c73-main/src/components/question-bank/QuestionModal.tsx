import { useState, useEffect } from "react";
import { X, Plus, Trash2, Upload, Image, Music, Video, Loader2, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Question, QuestionOption, QuestionType, QUESTION_TYPE_LABELS } from "@/types/question";
import { useSubjects } from "@/hooks/useSubjects";

interface QuestionModalProps {
  open: boolean;
  onClose: () => void;
  question?: Question | null;
  onSave: (question: Partial<Question>) => void;
}

const emptyQuestion: Partial<Question> = {
  text: "",
  type: "mcq_single",
  marks: 1,
  negativeMarking: false,
  negativeMarks: 0,
  difficulty: "medium",
  tags: [],
  subject: "",
  options: [
    { id: "1", text: "", isCorrect: false },
    { id: "2", text: "", isCorrect: false },
  ],
  correctAnswer: true,
  idealAnswer: "",
  wordLimit: 0,
  codeTemplate: "",
  codeLanguage: "javascript",
  mediaUrl: "",
  allowedFileTypes: ["pdf", "doc", "docx"],
};

const CODE_LANGUAGES = [
  { value: "javascript", label: "JavaScript" },
  { value: "python", label: "Python" },
  { value: "java", label: "Java" },
  { value: "cpp", label: "C++" },
  { value: "c", label: "C" },
  { value: "csharp", label: "C#" },
  { value: "go", label: "Go" },
  { value: "rust", label: "Rust" },
  { value: "typescript", label: "TypeScript" },
  { value: "sql", label: "SQL" },
];

const FILE_TYPES = [
  { value: "pdf", label: "PDF" },
  { value: "doc", label: "DOC" },
  { value: "docx", label: "DOCX" },
  { value: "txt", label: "TXT" },
  { value: "jpg", label: "JPG" },
  { value: "png", label: "PNG" },
  { value: "zip", label: "ZIP" },
];

export function QuestionModal({ open, onClose, question, onSave }: QuestionModalProps) {
  const [formData, setFormData] = useState<Partial<Question>>(emptyQuestion);
  const [tagInput, setTagInput] = useState("");
  const { subjects, isLoading: subjectsLoading } = useSubjects();

  useEffect(() => {
    if (question) {
      setFormData(question);
    } else {
      setFormData(emptyQuestion);
    }
  }, [question, open]);

  const handleSave = (addAnother: boolean = false) => {
    onSave(formData);
    if (addAnother) {
      setFormData(emptyQuestion);
    } else {
      onClose();
    }
  };

  const addOption = () => {
    const options = formData.options || [];
    if (options.length < 6) {
      setFormData({
        ...formData,
        options: [...options, { id: Date.now().toString(), text: "", isCorrect: false }],
      });
    }
  };

  const removeOption = (id: string) => {
    const options = formData.options || [];
    if (options.length > 2) {
      setFormData({
        ...formData,
        options: options.filter((o) => o.id !== id),
      });
    }
  };

  const updateOption = (id: string, updates: Partial<QuestionOption>) => {
    const options = formData.options || [];
    setFormData({
      ...formData,
      options: options.map((o) => (o.id === id ? { ...o, ...updates } : o)),
    });
  };

  const toggleCorrectOption = (id: string) => {
    const options = formData.options || [];
    if (formData.type === "mcq_single") {
      setFormData({
        ...formData,
        options: options.map((o) => ({ ...o, isCorrect: o.id === id })),
      });
    } else {
      setFormData({
        ...formData,
        options: options.map((o) =>
          o.id === id ? { ...o, isCorrect: !o.isCorrect } : o
        ),
      });
    }
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), tagInput.trim()],
      });
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter((t) => t !== tag) || [],
    });
  };

  const toggleFileType = (type: string) => {
    const types = formData.allowedFileTypes || [];
    if (types.includes(type)) {
      setFormData({ ...formData, allowedFileTypes: types.filter(t => t !== type) });
    } else {
      setFormData({ ...formData, allowedFileTypes: [...types, type] });
    }
  };

  const isMCQ = formData.type === "mcq_single" || formData.type === "mcq_multiple";
  const isTrueFalse = formData.type === "true_false";
  const isTextAnswer = formData.type === "short_answer" || formData.type === "long_answer";
  const isCoding = formData.type === "coding";
  const isFileUpload = formData.type === "file_upload";
  const isImageBased = formData.type === "image_based";
  const isVideoBased = formData.type === "video_based";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{question ? "Edit Question" : "Add New Question"}</DialogTitle>
          <DialogDescription>
            Fill in the question details below
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Question Text */}
          <div className="space-y-2">
            <Label>
              Question Text <span className="text-destructive">*</span>
            </Label>
            <Textarea
              placeholder="Enter your question here..."
              value={formData.text}
              onChange={(e) => setFormData({ ...formData, text: e.target.value })}
              rows={4}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              Supports bold, italics, and basic formatting
            </p>
          </div>

          {/* Type, Marks, Difficulty Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Question Type</Label>
              <Select
                value={formData.type}
                onValueChange={(value: QuestionType) =>
                  setFormData({ ...formData, type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background">
                  {(Object.keys(QUESTION_TYPE_LABELS) as QuestionType[]).map((type) => (
                    <SelectItem key={type} value={type}>
                      {QUESTION_TYPE_LABELS[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Marks</Label>
              <Input
                type="number"
                min={1}
                value={formData.marks}
                onChange={(e) =>
                  setFormData({ ...formData, marks: parseInt(e.target.value) || 1 })
                }
              />
            </div>

            <div className="space-y-2">
              <Label>Difficulty</Label>
              <Select
                value={formData.difficulty}
                onValueChange={(value: Question["difficulty"]) =>
                  setFormData({ ...formData, difficulty: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background">
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Subject</Label>
              <Select
                value={formData.subject}
                onValueChange={(value) => setFormData({ ...formData, subject: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder={subjectsLoading ? "Loading..." : "Select"} />
                </SelectTrigger>
                <SelectContent className="bg-background">
                  {subjectsLoading ? (
                    <div className="flex items-center justify-center p-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                    </div>
                  ) : subjects.length > 0 ? (
                    subjects.map((s) => (
                      <SelectItem key={s.id} value={s.name}>
                        {s.code} - {s.name}
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-2 text-sm text-muted-foreground">No subjects found</div>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Negative Marking */}
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Negative Marking</Label>
                  <p className="text-sm text-muted-foreground">
                    Deduct marks for wrong answers
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <Switch
                    checked={formData.negativeMarking}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, negativeMarking: checked })
                    }
                  />
                  {formData.negativeMarking && (
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">Deduct:</Label>
                      <Input
                        type="number"
                        min={0}
                        step={0.25}
                        value={formData.negativeMarks}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            negativeMarks: parseFloat(e.target.value) || 0,
                          })
                        }
                        className="w-20"
                      />
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* MCQ Options */}
          {isMCQ && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Answer Options</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addOption}
                  disabled={(formData.options?.length || 0) >= 6}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Option
                </Button>
              </div>
              <div className="space-y-3">
                {formData.options?.map((option, index) => (
                  <div key={option.id} className="flex items-start gap-3">
                    <div className="pt-2">
                      {formData.type === "mcq_single" ? (
                        <RadioGroup value={option.isCorrect ? option.id : ""}>
                          <RadioGroupItem
                            value={option.id}
                            onClick={() => toggleCorrectOption(option.id)}
                          />
                        </RadioGroup>
                      ) : (
                        <Checkbox
                          checked={option.isCorrect}
                          onCheckedChange={() => toggleCorrectOption(option.id)}
                        />
                      )}
                    </div>
                    <div className="flex-1">
                      <Input
                        placeholder={`Option ${index + 1}`}
                        value={option.text}
                        onChange={(e) =>
                          updateOption(option.id, { text: e.target.value })
                        }
                        className={option.isCorrect ? "border-success" : ""}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(option.id)}
                      disabled={(formData.options?.length || 0) <= 2}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                {formData.type === "mcq_single"
                  ? "Select the correct answer"
                  : "Select all correct answers"}
              </p>
            </div>
          )}

          {/* True/False */}
          {isTrueFalse && (
            <div className="space-y-2">
              <Label>Correct Answer</Label>
              <RadioGroup
                value={formData.correctAnswer ? "true" : "false"}
                onValueChange={(value) =>
                  setFormData({ ...formData, correctAnswer: value === "true" })
                }
                className="flex gap-6"
              >
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="true" id="true" />
                  <Label htmlFor="true" className="cursor-pointer">
                    True
                  </Label>
                </div>
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="false" id="false" />
                  <Label htmlFor="false" className="cursor-pointer">
                    False
                  </Label>
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Short/Long Answer */}
          {isTextAnswer && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Ideal Answer (for reference)</Label>
                <Textarea
                  placeholder="Enter the expected answer..."
                  value={formData.idealAnswer}
                  onChange={(e) =>
                    setFormData({ ...formData, idealAnswer: e.target.value })
                  }
                  rows={4}
                />
              </div>
              <div className="space-y-2">
                <Label>Word Limit (optional)</Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="0 for no limit"
                  value={formData.wordLimit || ""}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      wordLimit: parseInt(e.target.value) || 0,
                    })
                  }
                  className="w-32"
                />
              </div>
            </div>
          )}

          {/* Coding Question */}
          {isCoding && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Programming Language</Label>
                <Select
                  value={formData.codeLanguage || "javascript"}
                  onValueChange={(value) => setFormData({ ...formData, codeLanguage: value })}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background">
                    {CODE_LANGUAGES.map((lang) => (
                      <SelectItem key={lang.value} value={lang.value}>
                        {lang.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Code Template (Starter Code)</Label>
                <Textarea
                  placeholder="// Enter starter code template here..."
                  value={formData.codeTemplate || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, codeTemplate: e.target.value })
                  }
                  rows={8}
                  className="font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  This code will be shown to students as a starting point
                </p>
              </div>
              <div className="space-y-2">
                <Label>Expected Solution (for evaluation reference)</Label>
                <Textarea
                  placeholder="// Enter expected solution..."
                  value={formData.idealAnswer || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, idealAnswer: e.target.value })
                  }
                  rows={6}
                  className="font-mono text-sm"
                />
              </div>
            </div>
          )}

          {/* File Upload Question */}
          {isFileUpload && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Allowed File Types</Label>
                <div className="flex flex-wrap gap-2">
                  {FILE_TYPES.map((type) => (
                    <div key={type.value} className="flex items-center gap-2">
                      <Checkbox
                        id={`file-${type.value}`}
                        checked={formData.allowedFileTypes?.includes(type.value)}
                        onCheckedChange={() => toggleFileType(type.value)}
                      />
                      <Label htmlFor={`file-${type.value}`} className="text-sm cursor-pointer">
                        {type.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Instructions for submission</Label>
                <Textarea
                  placeholder="Describe what students should upload..."
                  value={formData.idealAnswer || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, idealAnswer: e.target.value })
                  }
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Image Based Question */}
          {isImageBased && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Question Image</Label>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                  {formData.mediaUrl ? (
                    <div className="space-y-2">
                      <img 
                        src={formData.mediaUrl} 
                        alt="Question" 
                        className="max-h-48 mx-auto rounded"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setFormData({ ...formData, mediaUrl: "" })}
                      >
                        Remove Image
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Image className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Upload an image for this question
                      </p>
                      <Input
                        type="url"
                        placeholder="Enter image URL"
                        value={formData.mediaUrl || ""}
                        onChange={(e) => setFormData({ ...formData, mediaUrl: e.target.value })}
                        className="max-w-md mx-auto"
                      />
                    </>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Expected Answer</Label>
                <Textarea
                  placeholder="Enter the expected answer based on the image..."
                  value={formData.idealAnswer || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, idealAnswer: e.target.value })
                  }
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Video Based Question */}
          {isVideoBased && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Question Video URL</Label>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                  <Video className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Enter a video URL (YouTube, Vimeo, or direct link)
                  </p>
                  <Input
                    type="url"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={formData.mediaUrl || ""}
                    onChange={(e) => setFormData({ ...formData, mediaUrl: e.target.value })}
                    className="max-w-md mx-auto"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Expected Answer</Label>
                <Textarea
                  placeholder="Enter the expected answer based on the video..."
                  value={formData.idealAnswer || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, idealAnswer: e.target.value })
                  }
                  rows={3}
                />
              </div>
            </div>
          )}

          {/* Tags */}
          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Add a tag..."
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                className="flex-1"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            {(formData.tags?.length || 0) > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags?.map((tag) => (
                  <Badge key={tag} variant="secondary" className="gap-1">
                    {tag}
                    <button onClick={() => removeTag(tag)} className="ml-1 hover:text-destructive">
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Attachments - only for non-media types */}
          {!isImageBased && !isVideoBased && (
            <div className="space-y-2">
              <Label>Additional Attachments</Label>
              <div className="flex gap-2">
                <Button type="button" variant="outline" size="sm">
                  <Image className="h-4 w-4 mr-1" />
                  Image
                </Button>
                <Button type="button" variant="outline" size="sm">
                  <Music className="h-4 w-4 mr-1" />
                  Audio
                </Button>
                <Button type="button" variant="outline" size="sm">
                  <Video className="h-4 w-4 mr-1" />
                  Video
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 pt-4 border-t border-border">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="outline" onClick={() => handleSave(true)}>
            Save & Add Another
          </Button>
          <Button onClick={() => handleSave(false)}>Save Question</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
