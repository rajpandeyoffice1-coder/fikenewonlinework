import { useNavigate } from "react-router-dom";
import { Plus, UserPlus, Eye, FileBarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QuickActionProps {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  variant?: "default" | "primary";
}

function QuickActionButton({ icon, label, onClick, variant = "default" }: QuickActionProps) {
  return (
    <Button
      variant={variant === "primary" ? "default" : "outline"}
      onClick={onClick}
      className="h-auto py-4 px-4 flex flex-col items-center gap-2 flex-1 min-w-[120px]"
    >
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </Button>
  );
}

export function QuickActions() {
  const navigate = useNavigate();

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3">
          <QuickActionButton
            icon={<Plus className="h-5 w-5" />}
            label="Create Exam"
            variant="primary"
            onClick={() => navigate("/create-exam")}
          />
          <QuickActionButton icon={<UserPlus className="h-5 w-5" />} label="Add Student" />
          <QuickActionButton icon={<Eye className="h-5 w-5" />} label="Invite Proctor" />
          <QuickActionButton icon={<FileBarChart className="h-5 w-5" />} label="Generate Reports" />
        </div>
      </CardContent>
    </Card>
  );
}
