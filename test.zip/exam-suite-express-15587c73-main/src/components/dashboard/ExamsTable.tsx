import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Download, Eye, Pencil, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface ExamData {
  id: string;
  title: string;
  code: string;
  start_date: string | null;
  end_date: string | null;
  duration: number;
  status: string;
  department: string;
}

interface ExamsTableProps {
  exams: ExamData[];
}

const statusStyles: Record<string, string> = {
  scheduled: "badge-primary",
  ongoing: "badge-success",
  completed: "badge-warning",
  cancelled: "badge-destructive",
  draft: "bg-muted text-muted-foreground",
};

export function ExamsTable({ exams }: ExamsTableProps) {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [department, setDepartment] = useState("all");
  const [dateRange, setDateRange] = useState("all");

  const filteredExams = exams.filter((exam) => {
    const matchesSearch =
      exam.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exam.code.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDepartment = department === "all" || exam.department === department;
    
    return matchesSearch && matchesDepartment;
  });

  const departments = [...new Set(exams.map(e => e.department))];

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle className="text-lg font-semibold">Upcoming Exams</CardTitle>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Export as CSV</DropdownMenuItem>
                <DropdownMenuItem>Export as PDF</DropdownMenuItem>
                <DropdownMenuItem>Export as Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search exams..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={department} onValueChange={setDepartment}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {departments.map((dept) => (
                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-full sm:w-36">
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Dates</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                  Exam Name
                </th>
                <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                  Code
                </th>
                <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                  Date/Time
                </th>
                <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                  Duration
                </th>
                <th className="text-left py-3 px-6 text-sm font-medium text-muted-foreground">
                  Status
                </th>
                <th className="text-right py-3 px-6 text-sm font-medium text-muted-foreground">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredExams.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    No upcoming exams found
                  </td>
                </tr>
              ) : (
                filteredExams.map((exam) => (
                  <tr key={exam.id} className="table-row">
                    <td className="py-4 px-6">
                      <span className="font-medium text-foreground">{exam.title}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-muted-foreground">{exam.code}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-muted-foreground">
                        {exam.start_date 
                          ? format(new Date(exam.start_date), 'MMM dd, yyyy hh:mm a')
                          : 'Not scheduled'}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-muted-foreground">{exam.duration} mins</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={cn("badge capitalize", statusStyles[exam.status] || "badge-primary")}>
                        {exam.status}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => navigate(`/admin/exams/${exam.id}`)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => navigate(`/admin/exams/${exam.id}/edit`)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>Duplicate</DropdownMenuItem>
                            <DropdownMenuItem>Archive</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
