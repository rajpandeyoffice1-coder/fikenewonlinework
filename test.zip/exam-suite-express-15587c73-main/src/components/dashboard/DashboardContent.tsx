import { Activity, Calendar, Users, AlertTriangle, Loader2, RefreshCw } from "lucide-react";
import { StatCard } from "./StatCard";
import { DailyActivityChart, DepartmentPassChart, QuestionTypeChart } from "./AnalyticsCharts";
import { ExamsTable } from "./ExamsTable";
import { QuickActions } from "./QuickActions";
import { useDashboardData } from "@/hooks/useDashboardData";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function DashboardContent() {
  const { 
    loading, 
    stats, 
    upcomingExams, 
    dailyActivity, 
    departmentPassRates, 
    questionTypeDistribution,
    newIncidentCount,
    clearNewIncidentCount,
    refetch
  } = useDashboardData();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's what's happening with your exams today.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {newIncidentCount > 0 && (
            <Badge variant="destructive" className="animate-pulse">
              {newIncidentCount} new incident{newIncidentCount > 1 ? 's' : ''}
            </Badge>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => {
              clearNewIncidentCount();
              refetch();
            }}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
        <StatCard
          title="Ongoing Exams"
          value={stats.ongoingExams}
          subtitle={`${stats.inProgressNow} in progress now`}
          icon={Activity}
          variant="primary"
        />
        <StatCard
          title="Upcoming Exams"
          value={stats.upcomingExams}
          subtitle="Scheduled"
          icon={Calendar}
          variant="success"
        />
        <StatCard
          title="Active Candidates"
          value={stats.activeCandidates.toLocaleString()}
          subtitle="Real-time count"
          icon={Users}
          variant="default"
        />
        <StatCard
          title="Flagged Incidents"
          value={stats.flaggedIncidents}
          subtitle="Today's alerts"
          icon={AlertTriangle}
          variant="warning"
        />
      </div>

      {/* Quick Actions */}
      <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
        <QuickActions />
      </div>

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
        <DailyActivityChart data={dailyActivity} />
        <DepartmentPassChart data={departmentPassRates} />
        <QuestionTypeChart data={questionTypeDistribution} />
      </div>

      {/* Exams Table */}
      <div className="animate-slide-up" style={{ animationDelay: "0.4s" }}>
        <ExamsTable exams={upcomingExams} />
      </div>
    </div>
  );
}
