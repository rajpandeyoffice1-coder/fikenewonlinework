export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          action_description: string
          browser: string | null
          changes: Json | null
          created_at: string
          device_type: string | null
          id: string
          ip_address: string | null
          os: string | null
          raw_log: Json | null
          session_id: string | null
          target_id: string | null
          target_name: string | null
          target_type: string
          user_email: string
          user_id: string | null
          user_name: string
          user_role: string
        }
        Insert: {
          action: string
          action_description: string
          browser?: string | null
          changes?: Json | null
          created_at?: string
          device_type?: string | null
          id?: string
          ip_address?: string | null
          os?: string | null
          raw_log?: Json | null
          session_id?: string | null
          target_id?: string | null
          target_name?: string | null
          target_type: string
          user_email: string
          user_id?: string | null
          user_name: string
          user_role: string
        }
        Update: {
          action?: string
          action_description?: string
          browser?: string | null
          changes?: Json | null
          created_at?: string
          device_type?: string | null
          id?: string
          ip_address?: string | null
          os?: string | null
          raw_log?: Json | null
          session_id?: string | null
          target_id?: string | null
          target_name?: string | null
          target_type?: string
          user_email?: string
          user_id?: string | null
          user_name?: string
          user_role?: string
        }
        Relationships: []
      }
      evaluator_exam_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          created_at: string
          evaluator_id: string
          exam_id: string
          id: string
          role: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          evaluator_id: string
          exam_id: string
          id?: string
          role?: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          evaluator_id?: string
          exam_id?: string
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "evaluator_exam_assignments_evaluator_id_fkey"
            columns: ["evaluator_id"]
            isOneToOne: false
            referencedRelation: "evaluators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "evaluator_exam_assignments_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
        ]
      }
      evaluators: {
        Row: {
          assigned_exams_count: number | null
          created_at: string
          department: string | null
          email: string
          experience: number | null
          id: string
          last_login: string | null
          mobile: string | null
          name: string
          pending_sheets: number | null
          permissions: Json | null
          status: string
          subject_expertise: string[] | null
          total_evaluations: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          assigned_exams_count?: number | null
          created_at?: string
          department?: string | null
          email: string
          experience?: number | null
          id?: string
          last_login?: string | null
          mobile?: string | null
          name: string
          pending_sheets?: number | null
          permissions?: Json | null
          status?: string
          subject_expertise?: string[] | null
          total_evaluations?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          assigned_exams_count?: number | null
          created_at?: string
          department?: string | null
          email?: string
          experience?: number | null
          id?: string
          last_login?: string | null
          mobile?: string | null
          name?: string
          pending_sheets?: number | null
          permissions?: Json | null
          status?: string
          subject_expertise?: string[] | null
          total_evaluations?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      exam_answers: {
        Row: {
          answer_option: Json | null
          answer_text: string | null
          created_at: string
          file_url: string | null
          id: string
          is_flagged: boolean | null
          question_id: string
          session_id: string
          time_spent: number | null
          updated_at: string
        }
        Insert: {
          answer_option?: Json | null
          answer_text?: string | null
          created_at?: string
          file_url?: string | null
          id?: string
          is_flagged?: boolean | null
          question_id: string
          session_id: string
          time_spent?: number | null
          updated_at?: string
        }
        Update: {
          answer_option?: Json | null
          answer_text?: string | null
          created_at?: string
          file_url?: string | null
          id?: string
          is_flagged?: boolean | null
          question_id?: string
          session_id?: string
          time_spent?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_answers_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "exam_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_enrollments: {
        Row: {
          enrolled_at: string
          exam_id: string
          id: string
          status: string
          student_id: string
        }
        Insert: {
          enrolled_at?: string
          exam_id: string
          id?: string
          status?: string
          student_id: string
        }
        Update: {
          enrolled_at?: string
          exam_id?: string
          id?: string
          status?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_enrollments_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_enrollments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_questions: {
        Row: {
          created_at: string
          exam_id: string
          id: string
          marks: number | null
          question_id: string
          question_order: number | null
        }
        Insert: {
          created_at?: string
          exam_id: string
          id?: string
          marks?: number | null
          question_id: string
          question_order?: number | null
        }
        Update: {
          created_at?: string
          exam_id?: string
          id?: string
          marks?: number | null
          question_id?: string
          question_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "exam_questions_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_questions_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_results: {
        Row: {
          created_at: string
          evaluated_at: string | null
          exam_id: string
          grade: string | null
          id: string
          percentage: number | null
          score: number | null
          session_id: string
          status: string
          student_id: string
          submitted_at: string
          total_marks: number
        }
        Insert: {
          created_at?: string
          evaluated_at?: string | null
          exam_id: string
          grade?: string | null
          id?: string
          percentage?: number | null
          score?: number | null
          session_id: string
          status?: string
          student_id: string
          submitted_at?: string
          total_marks: number
        }
        Update: {
          created_at?: string
          evaluated_at?: string | null
          exam_id?: string
          grade?: string | null
          id?: string
          percentage?: number | null
          score?: number | null
          session_id?: string
          status?: string
          student_id?: string
          submitted_at?: string
          total_marks?: number
        }
        Relationships: [
          {
            foreignKeyName: "exam_results_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_results_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "exam_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_results_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      exam_sessions: {
        Row: {
          created_at: string
          exam_id: string
          id: string
          started_at: string
          status: string
          student_id: string
          submitted_at: string | null
          time_remaining: number | null
        }
        Insert: {
          created_at?: string
          exam_id: string
          id?: string
          started_at?: string
          status?: string
          student_id: string
          submitted_at?: string | null
          time_remaining?: number | null
        }
        Update: {
          created_at?: string
          exam_id?: string
          id?: string
          started_at?: string
          status?: string
          student_id?: string
          submitted_at?: string | null
          time_remaining?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "exam_sessions_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_sessions_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      exams: {
        Row: {
          code: string
          course: string | null
          created_at: string
          department: string
          description: string | null
          duration: number
          end_date: string | null
          group_id: string | null
          id: string
          passing_marks: number | null
          semester: string | null
          settings: Json | null
          start_date: string | null
          status: string
          title: string
          total_marks: number
          updated_at: string
          user_id: string
        }
        Insert: {
          code: string
          course?: string | null
          created_at?: string
          department: string
          description?: string | null
          duration?: number
          end_date?: string | null
          group_id?: string | null
          id?: string
          passing_marks?: number | null
          semester?: string | null
          settings?: Json | null
          start_date?: string | null
          status?: string
          title: string
          total_marks?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          code?: string
          course?: string | null
          created_at?: string
          department?: string
          description?: string | null
          duration?: number
          end_date?: string | null
          group_id?: string | null
          id?: string
          passing_marks?: number | null
          semester?: string | null
          settings?: Json | null
          start_date?: string | null
          status?: string
          title?: string
          total_marks?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "exams_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "student_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_settings: {
        Row: {
          created_at: string
          default_timezone: string | null
          exam_defaults: Json | null
          id: string
          language: string | null
          logo_url: string | null
          platform_name: string
          proctoring_settings: Json | null
          security_settings: Json | null
          support_email: string | null
          support_phone: string | null
          university_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          default_timezone?: string | null
          exam_defaults?: Json | null
          id?: string
          language?: string | null
          logo_url?: string | null
          platform_name?: string
          proctoring_settings?: Json | null
          security_settings?: Json | null
          support_email?: string | null
          support_phone?: string | null
          university_name?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          default_timezone?: string | null
          exam_defaults?: Json | null
          id?: string
          language?: string | null
          logo_url?: string | null
          platform_name?: string
          proctoring_settings?: Json | null
          security_settings?: Json | null
          support_email?: string | null
          support_phone?: string | null
          university_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      proctor_exam_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          created_at: string
          exam_id: string
          id: string
          proctor_id: string
          role: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          exam_id: string
          id?: string
          proctor_id: string
          role?: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          exam_id?: string
          id?: string
          proctor_id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "proctor_exam_assignments_exam_id_fkey"
            columns: ["exam_id"]
            isOneToOne: false
            referencedRelation: "exams"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proctor_exam_assignments_proctor_id_fkey"
            columns: ["proctor_id"]
            isOneToOne: false
            referencedRelation: "proctors"
            referencedColumns: ["id"]
          },
        ]
      }
      proctoring_incidents: {
        Row: {
          created_at: string
          details: Json | null
          id: string
          incident_type: string
          message: string
          screenshot_id: string | null
          session_id: string
          severity: string
          student_id: string
          timestamp: string
        }
        Insert: {
          created_at?: string
          details?: Json | null
          id?: string
          incident_type: string
          message: string
          screenshot_id?: string | null
          session_id: string
          severity?: string
          student_id: string
          timestamp?: string
        }
        Update: {
          created_at?: string
          details?: Json | null
          id?: string
          incident_type?: string
          message?: string
          screenshot_id?: string | null
          session_id?: string
          severity?: string
          student_id?: string
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "proctoring_incidents_screenshot_id_fkey"
            columns: ["screenshot_id"]
            isOneToOne: false
            referencedRelation: "proctoring_screenshots"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proctoring_incidents_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "exam_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proctoring_incidents_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      proctoring_screenshots: {
        Row: {
          capture_type: string
          created_at: string
          id: string
          reason: string | null
          screenshot_url: string
          session_id: string
          student_id: string
          timestamp: string
        }
        Insert: {
          capture_type?: string
          created_at?: string
          id?: string
          reason?: string | null
          screenshot_url: string
          session_id: string
          student_id: string
          timestamp?: string
        }
        Update: {
          capture_type?: string
          created_at?: string
          id?: string
          reason?: string | null
          screenshot_url?: string
          session_id?: string
          student_id?: string
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "proctoring_screenshots_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "exam_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "proctoring_screenshots_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      proctors: {
        Row: {
          assigned_exams_count: number | null
          created_at: string
          department: string | null
          email: string
          experience: number | null
          id: string
          incidents_reported: number | null
          last_login: string | null
          mobile: string | null
          name: string
          permissions: Json | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          assigned_exams_count?: number | null
          created_at?: string
          department?: string | null
          email: string
          experience?: number | null
          id?: string
          incidents_reported?: number | null
          last_login?: string | null
          mobile?: string | null
          name: string
          permissions?: Json | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          assigned_exams_count?: number | null
          created_at?: string
          department?: string | null
          email?: string
          experience?: number | null
          id?: string
          incidents_reported?: number | null
          last_login?: string | null
          mobile?: string | null
          name?: string
          permissions?: Json | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      question_folders: {
        Row: {
          created_at: string
          id: string
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      questions: {
        Row: {
          correct_answer: string | null
          created_at: string
          difficulty: string
          folder_id: string | null
          id: string
          marks: number
          media_url: string | null
          negative_marks: number | null
          options: Json | null
          question_text: string
          subject: string
          tags: string[] | null
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          correct_answer?: string | null
          created_at?: string
          difficulty: string
          folder_id?: string | null
          id?: string
          marks?: number
          media_url?: string | null
          negative_marks?: number | null
          options?: Json | null
          question_text: string
          subject: string
          tags?: string[] | null
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          correct_answer?: string | null
          created_at?: string
          difficulty?: string
          folder_id?: string | null
          id?: string
          marks?: number
          media_url?: string | null
          negative_marks?: number | null
          options?: Json | null
          question_text?: string
          subject?: string
          tags?: string[] | null
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_folder_id_fkey"
            columns: ["folder_id"]
            isOneToOne: false
            referencedRelation: "question_folders"
            referencedColumns: ["id"]
          },
        ]
      }
      student_bulk_upload_logs: {
        Row: {
          created_at: string
          failed_count: number
          failed_rows: Json | null
          id: string
          success_count: number
          total_rows: number
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string
          failed_count?: number
          failed_rows?: Json | null
          id?: string
          success_count?: number
          total_rows?: number
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string
          failed_count?: number
          failed_rows?: Json | null
          id?: string
          success_count?: number
          total_rows?: number
          uploaded_by?: string | null
        }
        Relationships: []
      }
      student_group_members: {
        Row: {
          created_at: string
          group_id: string
          id: string
          student_id: string
        }
        Insert: {
          created_at?: string
          group_id: string
          id?: string
          student_id: string
        }
        Update: {
          created_at?: string
          group_id?: string
          id?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "student_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_group_members_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_groups: {
        Row: {
          created_at: string
          department: string | null
          description: string | null
          group_code: string
          group_name: string
          id: string
          semester: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          department?: string | null
          description?: string | null
          group_code: string
          group_name: string
          id?: string
          semester?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          department?: string | null
          description?: string | null
          group_code?: string
          group_name?: string
          id?: string
          semester?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      students: {
        Row: {
          course: string
          created_at: string
          department: Database["public"]["Enums"]["department_enum"]
          email: string
          full_name: string
          id: string
          last_login: string | null
          mobile: string
          password_hash: string | null
          photo_url: string | null
          roll_no: string
          semester: number
          status: Database["public"]["Enums"]["student_status"]
          updated_at: string
        }
        Insert: {
          course: string
          created_at?: string
          department: Database["public"]["Enums"]["department_enum"]
          email: string
          full_name: string
          id?: string
          last_login?: string | null
          mobile: string
          password_hash?: string | null
          photo_url?: string | null
          roll_no: string
          semester: number
          status?: Database["public"]["Enums"]["student_status"]
          updated_at?: string
        }
        Update: {
          course?: string
          created_at?: string
          department?: Database["public"]["Enums"]["department_enum"]
          email?: string
          full_name?: string
          id?: string
          last_login?: string | null
          mobile?: string
          password_hash?: string | null
          photo_url?: string | null
          roll_no?: string
          semester?: number
          status?: Database["public"]["Enums"]["student_status"]
          updated_at?: string
        }
        Relationships: []
      }
      subjects: {
        Row: {
          code: string
          created_at: string
          department: string
          id: string
          name: string
          semester: number
          status: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          department: string
          id?: string
          name: string
          semester: number
          status?: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          department?: string
          id?: string
          name?: string
          semester?: number
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_current_user_email: { Args: never; Returns: string }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      log_audit_action: {
        Args: {
          _action: string
          _action_description: string
          _browser?: string
          _changes?: Json
          _device_type?: string
          _ip_address?: string
          _os?: string
          _raw_log?: Json
          _session_id?: string
          _target_id?: string
          _target_name?: string
          _target_type: string
        }
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "student" | "proctor" | "evaluator"
      department_enum:
        | "CSE"
        | "ECE"
        | "EE"
        | "ME"
        | "CE"
        | "BBA"
        | "MBA"
        | "IT"
        | "CIVIL"
        | "OTHER"
      student_status: "active" | "inactive"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "student", "proctor", "evaluator"],
      department_enum: [
        "CSE",
        "ECE",
        "EE",
        "ME",
        "CE",
        "BBA",
        "MBA",
        "IT",
        "CIVIL",
        "OTHER",
      ],
      student_status: ["active", "inactive"],
    },
  },
} as const
