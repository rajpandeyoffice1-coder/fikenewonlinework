import { z } from 'zod';

// Valid departments
export const VALID_DEPARTMENTS = ['CSE', 'ECE', 'EE', 'ME', 'CE', 'BBA', 'MBA', 'IT', 'CIVIL', 'OTHER'] as const;
export const VALID_STATUSES = ['active', 'inactive'] as const;

// Department display names mapping
export const DEPARTMENT_LABELS: Record<string, string> = {
  'CSE': 'Computer Science & Engineering',
  'ECE': 'Electronics & Communication',
  'EE': 'Electrical Engineering',
  'ME': 'Mechanical Engineering',
  'CE': 'Chemical Engineering',
  'BBA': 'Bachelor of Business Administration',
  'MBA': 'Master of Business Administration',
  'IT': 'Information Technology',
  'CIVIL': 'Civil Engineering',
  'OTHER': 'Other',
};

// Student validation schema
export const studentSchema = z.object({
  full_name: z
    .string()
    .trim()
    .min(3, 'Full name must be at least 3 characters')
    .max(60, 'Full name must be less than 60 characters')
    .regex(/^[a-zA-Z ]+$/, 'Full name can only contain alphabets and spaces'),
  
  roll_no: z
    .string()
    .trim()
    .min(4, 'Roll number must be at least 4 characters')
    .max(15, 'Roll number must be less than 15 characters')
    .regex(/^[a-zA-Z0-9]+$/, 'Roll number must be alphanumeric only'),
  
  email: z
    .string()
    .trim()
    .email('Invalid email address format')
    .max(255, 'Email must be less than 255 characters'),
  
  mobile: z
    .string()
    .transform(val => val.replace(/[\s\-\(\)\+]/g, ''))
    .refine(val => /^[6-9][0-9]{9}$/.test(val), {
      message: 'Mobile must be a valid 10-digit Indian number (starting with 6-9)',
    }),
  
  department: z.enum(VALID_DEPARTMENTS, {
    errorMap: () => ({ message: `Department must be one of: ${VALID_DEPARTMENTS.join(', ')}` }),
  }),
  
  course: z
    .string()
    .trim()
    .min(2, 'Course must be at least 2 characters')
    .max(40, 'Course must be less than 40 characters'),
  
  semester: z
    .number({ invalid_type_error: 'Semester must be a number' })
    .int('Semester must be a whole number')
    .min(1, 'Semester must be between 1 and 12')
    .max(12, 'Semester must be between 1 and 12'),
  
  status: z.enum(VALID_STATUSES).default('active'),
  
  photo_url: z.string().url('Invalid photo URL').optional().nullable(),
  
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters')
    .optional(),
});

// Login validation schema
export const loginSchema = z.object({
  identifier: z
    .string()
    .trim()
    .min(1, 'Roll number or email is required'),
  password: z
    .string()
    .min(1, 'Password is required'),
});

// Profile update validation schema
export const profileUpdateSchema = z.object({
  mobile: z
    .string()
    .transform(val => val.replace(/[\s\-\(\)\+]/g, ''))
    .refine(val => /^[6-9][0-9]{9}$/.test(val), {
      message: 'Mobile must be a valid 10-digit Indian number',
    })
    .optional(),
  
  photo_url: z.string().url('Invalid photo URL').optional().nullable(),
  
  current_password: z.string().optional(),
  
  new_password: z
    .string()
    .min(6, 'New password must be at least 6 characters')
    .optional(),
}).refine(
  (data) => {
    if (data.new_password && !data.current_password) {
      return false;
    }
    return true;
  },
  {
    message: 'Current password is required to set new password',
    path: ['current_password'],
  }
);

// Bulk upload row validation
export const bulkUploadRowSchema = studentSchema.omit({ status: true, photo_url: true, password: true }).extend({
  status: z.enum(VALID_STATUSES).optional(),
});

// Type exports
export type StudentFormData = z.infer<typeof studentSchema>;
export type LoginFormData = z.infer<typeof loginSchema>;
export type ProfileUpdateData = z.infer<typeof profileUpdateSchema>;
export type BulkUploadRow = z.infer<typeof bulkUploadRowSchema>;

// Validation error type
export interface ValidationError {
  field: string;
  message: string;
}

// API response type
export interface ApiResponse<T = unknown> {
  status: 'success' | 'error' | 'validation_error';
  message?: string;
  data?: T;
  errors?: ValidationError[];
}

// Bulk upload response type
export interface BulkUploadResponse {
  status: 'success';
  message: string;
  success_rows: unknown[];
  success_count: number;
  failed_rows: { row: number; data: unknown; errors: ValidationError[] }[];
  failed_count: number;
  auth_accounts_created?: number;
}

// Helper to convert zod errors to ValidationError format
export function zodToValidationErrors(error: z.ZodError): ValidationError[] {
  return error.errors.map((err) => ({
    field: err.path.join('.') || 'unknown',
    message: err.message,
  }));
}

// Validate single student
export function validateStudent(data: unknown): { success: true; data: StudentFormData } | { success: false; errors: ValidationError[] } {
  const result = studentSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, errors: zodToValidationErrors(result.error) };
}

// Validate login
export function validateLogin(data: unknown): { success: true; data: LoginFormData } | { success: false; errors: ValidationError[] } {
  const result = loginSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, errors: zodToValidationErrors(result.error) };
}

// Validate profile update
export function validateProfileUpdate(data: unknown): { success: true; data: ProfileUpdateData } | { success: false; errors: ValidationError[] } {
  const result = profileUpdateSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, errors: zodToValidationErrors(result.error) };
}

// Validate bulk upload data
export function validateBulkUpload(rows: unknown[]): {
  validRows: BulkUploadRow[];
  invalidRows: { row: number; data: unknown; errors: ValidationError[] }[];
} {
  const validRows: BulkUploadRow[] = [];
  const invalidRows: { row: number; data: unknown; errors: ValidationError[] }[] = [];
  const seenRollNos = new Set<string>();
  const seenEmails = new Set<string>();

  rows.forEach((row, index) => {
    const result = bulkUploadRowSchema.safeParse(row);
    
    if (!result.success) {
      invalidRows.push({
        row: index + 1,
        data: row,
        errors: zodToValidationErrors(result.error),
      });
      return;
    }

    const additionalErrors: ValidationError[] = [];

    // Check for duplicates within batch
    const rollLower = result.data.roll_no.toLowerCase();
    if (seenRollNos.has(rollLower)) {
      additionalErrors.push({ field: 'roll_no', message: 'Duplicate roll number in upload' });
    } else {
      seenRollNos.add(rollLower);
    }

    const emailLower = result.data.email.toLowerCase();
    if (seenEmails.has(emailLower)) {
      additionalErrors.push({ field: 'email', message: 'Duplicate email in upload' });
    } else {
      seenEmails.add(emailLower);
    }

    if (additionalErrors.length > 0) {
      invalidRows.push({
        row: index + 1,
        data: row,
        errors: additionalErrors,
      });
    } else {
      validRows.push(result.data);
    }
  });

  return { validRows, invalidRows };
}

// Photo file validation
export function validatePhotoFile(file: File): ValidationError | null {
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  const maxSize = 2 * 1024 * 1024; // 2MB

  if (!allowedTypes.includes(file.type)) {
    return { field: 'photo_file', message: 'Only JPG, JPEG, and PNG files are allowed' };
  }

  if (file.size > maxSize) {
    return { field: 'photo_file', message: 'Photo file must be less than 2MB' };
  }

  return null;
}
