import { supabase } from "@/integrations/supabase/client";

interface AuditLogParams {
  action: string;
  actionDescription: string;
  targetType: string;
  targetId?: string;
  targetName?: string;
  changes?: Record<string, unknown>;
  rawLog?: Record<string, unknown>;
}

/**
 * Secure audit logging function that uses a SECURITY DEFINER database function.
 * User identity is automatically captured server-side, preventing log manipulation.
 */
export async function logAuditAction({
  action,
  actionDescription,
  targetType,
  targetId,
  targetName,
  changes,
  rawLog,
}: AuditLogParams): Promise<{ success: boolean; id?: string; error?: string }> {
  try {
    // Get browser/device info
    const userAgent = navigator.userAgent;
    const browser = getBrowserName(userAgent);
    const os = getOSName(userAgent);
    const deviceType = /Mobile|Android|iPhone|iPad/.test(userAgent) ? "Mobile" : "Desktop";

    const { data, error } = await supabase.rpc("log_audit_action", {
      _action: action,
      _action_description: actionDescription,
      _target_type: targetType,
      _target_id: targetId || null,
      _target_name: targetName || null,
      _changes: changes ? JSON.stringify(changes) : null,
      _ip_address: null, // IP should be captured server-side if needed
      _browser: browser,
      _os: os,
      _device_type: deviceType,
      _session_id: null,
      _raw_log: rawLog ? JSON.stringify(rawLog) : null,
    });

    if (error) {
      console.error("Audit log error:", error);
      return { success: false, error: error.message };
    }

    return { success: true, id: data };
  } catch (err) {
    console.error("Audit log exception:", err);
    return { success: false, error: "Failed to create audit log" };
  }
}

function getBrowserName(userAgent: string): string {
  if (userAgent.includes("Firefox")) return "Firefox";
  if (userAgent.includes("Edg")) return "Edge";
  if (userAgent.includes("Chrome")) return "Chrome";
  if (userAgent.includes("Safari")) return "Safari";
  if (userAgent.includes("Opera") || userAgent.includes("OPR")) return "Opera";
  return "Unknown";
}

function getOSName(userAgent: string): string {
  if (userAgent.includes("Windows")) return "Windows";
  if (userAgent.includes("Mac OS")) return "macOS";
  if (userAgent.includes("Linux")) return "Linux";
  if (userAgent.includes("Android")) return "Android";
  if (userAgent.includes("iOS") || userAgent.includes("iPhone") || userAgent.includes("iPad")) return "iOS";
  return "Unknown";
}
