import { supabase } from '@/integrations/supabase/client';
import type { ApiResponse, BulkUploadResponse, StudentFormData, ValidationError } from '@/lib/studentValidation';

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/student-management`;

interface StudentApiData {
  id: string;
  full_name: string;
  roll_no: string;
  email: string;
  mobile: string;
  department: string;
  course: string;
  semester: number;
  status: 'active' | 'inactive';
  photo_url: string | null;
  last_login: string | null;
  created_at: string;
  updated_at: string;
}

// Helper to get current session token with refresh if needed
async function getAuthToken(): Promise<string | null> {
  // First try to get the current session
  const { data: { session }, error } = await supabase.auth.getSession();
  
  if (error || !session) {
    console.warn('No valid session found, attempting refresh');
    // Try to refresh the session
    const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
    if (refreshError || !refreshData.session) {
      console.error('Failed to refresh session:', refreshError?.message);
      return null;
    }
    return refreshData.session.access_token;
  }
  
  // Check if token is about to expire (within 60 seconds)
  const expiresAt = session.expires_at;
  if (expiresAt) {
    const nowInSeconds = Math.floor(Date.now() / 1000);
    if (expiresAt - nowInSeconds < 60) {
      console.log('Token expiring soon, refreshing...');
      const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
      if (!refreshError && refreshData.session) {
        return refreshData.session.access_token;
      }
    }
  }
  
  return session.access_token;
}

// Helper to make API calls with authentication
async function callStudentApi(
  action: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  body?: unknown,
  params?: Record<string, string>
): Promise<ApiResponse> {
  const url = new URL(FUNCTION_URL);
  url.searchParams.set('action', action);
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.set(key, value);
    });
  }

  // Get the user's JWT token for authentication
  const token = await getAuthToken();
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'apikey': import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
  };

  // Add authorization header if we have a token (required for protected actions)
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url.toString(), {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  return response.json();
}

// List all students
export async function listStudents(): Promise<ApiResponse<StudentApiData[]>> {
  return callStudentApi('list', 'GET') as Promise<ApiResponse<StudentApiData[]>>;
}

// Get single student
export async function getStudent(id: string): Promise<ApiResponse<StudentApiData>> {
  return callStudentApi('get', 'GET', undefined, { id }) as Promise<ApiResponse<StudentApiData>>;
}

// Add new student
export async function addStudent(data: StudentFormData): Promise<ApiResponse<StudentApiData>> {
  return callStudentApi('add', 'POST', data) as Promise<ApiResponse<StudentApiData>>;
}

// Update student
export async function updateStudent(id: string, data: StudentFormData): Promise<ApiResponse<StudentApiData>> {
  return callStudentApi('update', 'PUT', data, { id }) as Promise<ApiResponse<StudentApiData>>;
}

// Delete student
export async function deleteStudent(id: string): Promise<ApiResponse> {
  return callStudentApi('delete', 'DELETE', undefined, { id });
}

// Bulk upload students
export async function bulkUploadStudents(students: StudentFormData[]): Promise<BulkUploadResponse> {
  const response = await callStudentApi('bulk-upload', 'POST', { students });
  return response as unknown as BulkUploadResponse;
}

// Student login
export async function studentLogin(identifier: string, password: string): Promise<ApiResponse<StudentApiData>> {
  const isEmail = identifier.includes('@');
  const body = isEmail 
    ? { email: identifier, password }
    : { roll_no: identifier, password };
  
  return callStudentApi('login', 'POST', body) as Promise<ApiResponse<StudentApiData>>;
}

// Update student profile (self-update)
export async function updateStudentProfile(
  id: string,
  data: {
    mobile?: string;
    photo_url?: string;
    current_password?: string;
    new_password?: string;
  }
): Promise<ApiResponse<StudentApiData>> {
  return callStudentApi('update-profile', 'PUT', { id, ...data }) as Promise<ApiResponse<StudentApiData>>;
}

// Convert API response errors to form errors
export function apiErrorsToFormErrors(errors: ValidationError[]): Record<string, string> {
  return errors.reduce((acc, err) => {
    acc[err.field] = err.message;
    return acc;
  }, {} as Record<string, string>);
}

// Generate CSV for failed rows
export function generateFailedRowsCsv(failedRows: { row: number; data: any; errors: ValidationError[] }[]): string {
  if (failedRows.length === 0) return '';

  const headers = ['Row', 'Full Name', 'Roll No', 'Email', 'Mobile', 'Department', 'Course', 'Semester', 'Error Messages'];
  const rows = failedRows.map(({ row, data, errors }) => [
    row,
    data.full_name || '',
    data.roll_no || '',
    data.email || '',
    data.mobile || '',
    data.department || '',
    data.course || '',
    data.semester || '',
    errors.map(e => `${e.field}: ${e.message}`).join('; '),
  ]);

  const csvContent = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  return csvContent;
}

// Download CSV
export function downloadCsv(csvContent: string, filename: string): void {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
